import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { getPgLogInfo, dirSizeBytes } from '@/server/storage'

/**
 * Storage overview: actual PostgreSQL sizes (bytes, never invented).
 * Breakdown is non-overlapping and sums to the database size:
 * tables(heap) + indexes + logs + backups + other(catalogs/toast/free).
 */
export async function GET() {
  const auth = await requireAuth()
  if (auth.error) return auth.error

  try {
    const [dbSize, relSizes, logInfo] = await Promise.all([
      dbQuery<{ size: string }>('SELECT pg_database_size(current_database()) AS size'),
      dbQuery<{ name: string; total: string; heap: string; indexes: string; rows: string }>(
        `SELECT c.relname AS name,
          pg_total_relation_size(c.oid)::text AS total,
          pg_relation_size(c.oid)::text AS heap,
          pg_indexes_size(c.oid)::text AS indexes,
          COALESCE((SELECT reltuples::bigint FROM pg_class WHERE oid = c.oid), 0)::text AS rows
         FROM pg_class c
         JOIN pg_namespace n ON n.oid = c.relnamespace
         WHERE n.nspname = 'public' AND c.relkind IN ('r', 'p')
         ORDER BY pg_total_relation_size(c.oid) DESC`
      ),
      getPgLogInfo(),
    ])

    const dbSizeBytes = Number(dbSize.rows[0]?.size) || 0
    let tablesBytes = 0
    let indexesBytes = 0
    const tables = relSizes.rows.map((r) => {
      const heap = Number(r.heap) || 0
      const idx = Number(r.indexes) || 0
      tablesBytes += heap
      indexesBytes += idx
      return {
        name: r.name,
        rows: Number(r.rows) || 0,
        totalBytes: Number(r.total) || 0,
        heapBytes: heap,
        indexBytes: idx,
      }
    })

    // Local backup files across configured storage locations.
    let backupsBytes = 0
    try {
      const locs = await dbQuery<{ path: string }>(
        "SELECT path FROM storage_locations WHERE status = 'Active'"
      )
      for (const loc of locs.rows) {
        const backupsDir = require('path').join(loc.path, 'Backups')
        try {
          const sz = dirSizeBytes(backupsDir)
          if (sz !== null) backupsBytes += sz
        } catch {}
      }
    } catch {}

    const logsBytes = logInfo.available ? logInfo.bytes : null
    const known = tablesBytes + indexesBytes + (logsBytes || 0) + backupsBytes
    const otherBytes = Math.max(0, dbSizeBytes - known)

    return NextResponse.json({
      dbSizeBytes,
      tableCount: tables.length,
      breakdown: {
        applicationDataBytes: tablesBytes,
        tablesBytes,
        indexesBytes,
        logsBytes,
        backupsBytes,
        otherBytes,
      },
      logsAvailable: logInfo.available,
      tables: tables.slice(0, 12),
    })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to load storage information', details: err.message },
      { status: 500 }
    )
  }
}
