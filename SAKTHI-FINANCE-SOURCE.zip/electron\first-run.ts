import { dialog, BrowserWindow, shell } from 'electron'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import path from 'node:path'
import { existsSync, readFileSync } from 'node:fs'
import { provisionNewDatabase } from './managed-postgres'

export async function firstRunSetup(settings: string, native: string): Promise<boolean> {
  if (existsSync(path.join(settings, 'runtime.json'))) return true
  if (existsSync(path.join(settings, 'managed-postgres.json'))) {
    await dialog.showMessageBox({ type: 'error', message: 'Existing storage settings need repair', detail: 'Your database was preserved, but its private runtime settings are missing. Do not create another database over it. Contact your developer to recover the settings.' })
    return false
  }
  const welcome = await dialog.showMessageBox({ type: 'info', title: 'Welcome to Sakthi Finance', message: 'Set up this laptop', detail: 'Create a NEW, separate finance database on a drive you choose. No data from another laptop will be copied. Existing databases and PostgreSQL services will not be changed.', buttons: ['Select storage folder', 'Exit'], cancelId: 1 })
  if (welcome.response !== 0) return false
  for (;;) {
    try {
      await promisify(execFile)(path.join(native, 'postgres/bin/initdb.exe'), ['--version'], { windowsHide: true, timeout: 15000 })
      break
    } catch {
      const prerequisite = await dialog.showMessageBox({ type: 'warning', message: 'Windows database support is required', detail: 'Install the included Microsoft Visual C++ x64 runtime. Windows may ask for administrator approval. Your finance data will not be changed.', buttons: ['Open Microsoft installer', 'Exit'], cancelId: 1 })
      if (prerequisite.response !== 0) return false
      const error = await shell.openPath(path.join(native, 'vcredist_x64.exe'))
      if (error) { await dialog.showMessageBox({ type: 'error', message: 'The Microsoft installer could not open. Install Microsoft Visual C++ x64 support, then reopen Sakthi Finance.' }); return false }
      const retry = await dialog.showMessageBox({ type: 'info', message: 'Finish the Microsoft installation first', detail: 'After it finishes, click Check again. If Windows requests a restart, restart before continuing.', buttons: ['Check again', 'Exit'], cancelId: 1 })
      if (retry.response !== 0) return false
    }
  }
  const folder = await dialog.showOpenDialog({ title: 'Choose storage for this laptop’s new finance database', properties: ['openDirectory', 'createDirectory'] })
  if (folder.canceled) return false
  let oauth: { clientId: string; clientSecret: string } | undefined
  try { oauth = JSON.parse(readFileSync(path.join(native, 'desktop-oauth.json'), 'utf8')) } catch {}
  if (!oauth?.clientId || !oauth.clientSecret) {
    await dialog.showMessageBox({ type: 'info', message: 'Desktop Google setup is required', detail: 'Choose the Google Desktop OAuth JSON file supplied by your developer. Do not select a Web client or a file containing database settings.' })
    const file = await dialog.showOpenDialog({ title: 'Select Google Desktop OAuth configuration', filters: [{ name: 'Google Desktop OAuth', extensions: ['json'] }], properties: ['openFile'] })
    if (file.canceled) return false
    try { const data = JSON.parse(readFileSync(file.filePaths[0], 'utf8')); if (data.installed?.client_id && data.installed?.client_secret) oauth = { clientId: data.installed.client_id, clientSecret: data.installed.client_secret } } catch {}
  }
  if (!oauth?.clientId || !oauth.clientSecret) { await dialog.showMessageBox({ type: 'error', message: 'A valid Desktop OAuth configuration is required. Setup was not started.' }); return false }
  const confirm = await dialog.showMessageBox({ type: 'question', message: 'Create the new database here?', detail: path.join(folder.filePaths[0], 'SakthiFinanceData') + '\n\nKeep this drive connected while using Sakthi Finance.', buttons: ['Create new database', 'Cancel'], defaultId: 1, cancelId: 1 })
  if (confirm.response !== 0) return false
  const progress = new BrowserWindow({ width: 540, height: 310, resizable: false, autoHideMenuBar: true, title: 'Setting up Sakthi Finance', webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true } })
  let completed = false
  progress.on('close', event => { if (!completed) event.preventDefault() })
  await progress.loadFile(path.join(__dirname, 'setup-progress.html'))
  progress.setProgressBar(2)
  try {
    await provisionNewDatabase({ selectedFolder: folder.filePaths[0], settingsDirectory: settings, nativeDirectory: native, oauth,
      initialize: async config => {
        delete process.env.DATABASE_URL
        Object.assign(process.env, config)
        const { ensureSchema, closePool } = require('../src/server/database') as typeof import('../src/server/database')
        try { await ensureSchema() } finally { await closePool() }
      },
    })
    return true
  } catch (error) {
    // Show only our fixed setup explanations, never PostgreSQL credentials/errors.
    const message = error instanceof Error ? error.message : ''
    const safe = /^(This installation|Desktop Google|PostgreSQL runtime|Choose a local|SakthiFinanceData|Windows user|PostgreSQL initialization|The new local|Fresh database)/.test(message)
    await dialog.showMessageBox(progress, { type: 'error', message: 'Setup could not finish', detail: safe ? message : 'The new storage folder was retained safely. Check drive permissions and contact your developer. No existing database was replaced.' })
    return false
  } finally { completed = true; progress.destroy() }
}
