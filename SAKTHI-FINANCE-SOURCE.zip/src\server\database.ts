import { Pool, PoolClient, QueryResult, types } from 'pg';
import dotenv from 'dotenv';
import { syncTransaction } from './sync-context';

// PostgreSQL DATE is a calendar day, not an instant. The default parser creates
// local midnight, which JSON converts to the previous UTC day in India.
// Preserve date-only values on every query, including transaction responses.
types.setTypeParser(types.builtins.DATE, (value: string) => value);

dotenv.config();

let dbType: 'automatic' | 'manual' | 'local' = 'automatic';
let manualDbConfig: {
  host: string;
  port: number;
  database: string;
  user: string;
  password: string;
} = {
  host: 'localhost',
  port: 5432,
  database: 'sakthi_finance',
  user: 'postgres',
  password: '1',
};

function resolveDbConfig() {
  // Server-side only. DATABASE_URL (no NEXT_PUBLIC_ prefix) takes precedence;
  // DB_HOST/DB_PORT/DB_NAME/DB_USER/DB_PASSWORD remain as fallback.
  // Never import this module from client components.
  const url = process.env.DATABASE_URL;
  if (url && url.trim()) {
    return {
      connectionString: url.trim(),
      max: 20,
      connectionTimeoutMillis: 3000,
      idleTimeoutMillis: 30000,
      keepAlive: true,
      keepAliveInitialDelayMillis: 10000,
    };
  }
  return {
    host: process.env.DB_HOST || DB_CONFIG.host,
    port: parseInt(process.env.DB_PORT || String(DB_CONFIG.port), 10),
    database: process.env.DB_NAME || DB_CONFIG.database,
    user: process.env.DB_USER || DB_CONFIG.user,
    password: process.env.DB_PASSWORD ?? DB_CONFIG.password,
    max: 20,
    connectionTimeoutMillis: 3000,
    idleTimeoutMillis: 30000,
    keepAlive: true,
    keepAliveInitialDelayMillis: 10000,
  };
}

const DB_CONFIG = {
  host: 'localhost',
  port: 5432,
  database: 'sakthi_finance',
  user: 'postgres',
  password: '1',
  max: 20,
  connectionTimeoutMillis: 3000,
  idleTimeoutMillis: 30000,
  keepAlive: true,
  keepAliveInitialDelayMillis: 10000,
};

let pool: Pool | null = null;
let isConnected = false;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;
const RECONNECT_DELAY_MS = 3000;

let schemaInitPromise: Promise<void> | null = null;
let schemaInitStarted = false;
let schemaReady = false;

export function setDbType(type: 'automatic' | 'manual' | 'local') {
  dbType = type;
}

export function setManualDbConfig(config: {
  host: string;
  port: number;
  database: string;
  user: string;
  password: string;
}) {
  manualDbConfig = config;
  // Update DB_CONFIG with manual settings
  DB_CONFIG.host = config.host;
  DB_CONFIG.port = config.port;
  DB_CONFIG.database = config.database;
  DB_CONFIG.user = config.user;
  DB_CONFIG.password = config.password;
}

export function getDbType(): 'automatic' | 'manual' | 'local' {
  return dbType;
}

export async function ensureSchema(): Promise<void> {
  if (schemaReady) return;
  if (schemaInitStarted) return schemaInitPromise ?? Promise.resolve();
  schemaInitStarted = true;
  schemaInitPromise = (async () => {
    try {
      const { initializeDatabase } = await import('./schema');
      await initializeDatabase();
      schemaReady = true;
    } catch (err: any) {
      console.error('[Schema] Auto-init failed (will retry):', err.message);
      schemaInitPromise = null;
      schemaInitStarted = false;
      throw err;
    }
  })();
  return schemaInitPromise;
}

export function getPool(): Pool {
  if (!pool) {
    pool = new Pool(resolveDbConfig() as any);

    pool.on('error', (err) => {
      console.error('[Database] Unexpected pool error:', err.message);
      isConnected = false;
    });

    pool.on('connect', () => {
      reconnectAttempts = 0;
    });
  }
  return pool;
}

export async function testConnection(): Promise<boolean> {
  const client = await getPool().connect();
  try {
    const result = await client.query('SELECT NOW() as now');
    isConnected = true;
    reconnectAttempts = 0;
    const usingUrl = Boolean(process.env.DATABASE_URL && process.env.DATABASE_URL.trim());
    console.log('══════════════════════════════════════════════════════');
    console.log('  PostgreSQL Connected Successfully (LOCAL, server-side only)');
    if (usingUrl) {
      console.log('  Source   : DATABASE_URL');
      try {
        const u = new URL(process.env.DATABASE_URL as string);
        console.log(`  Database : ${u.pathname.replace('/', '')}`);
        console.log(`  Host     : ${u.hostname}`);
        console.log(`  Port     : ${u.port || '5432'}`);
      } catch {
        console.log('  Database : (from DATABASE_URL)');
      }
    } else {
      console.log(`  Database : ${process.env.DB_NAME || DB_CONFIG.database}`);
      console.log(`  Host     : ${process.env.DB_HOST || DB_CONFIG.host}`);
      console.log(`  Port     : ${process.env.DB_PORT || DB_CONFIG.port}`);
    }
    console.log(`  Time     : ${result.rows[0].now}`);
    console.log('══════════════════════════════════════════════════════');
    return true;
  } catch (err: any) {
    isConnected = false;
    console.error('[Database] Connection failed:', err.message);
    if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
      reconnectAttempts++;
      console.error(`[Database] Retrying connection (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})...`);
      await new Promise((r) => setTimeout(r, RECONNECT_DELAY_MS));
      return testConnection();
    }
    return false;
  } finally {
    client.release();
  }
}

export async function dbQuery<T extends import('pg').QueryResultRow = any>(
  text: string,
  params?: any[]
): Promise<QueryResult<T>> {
  const sync = syncTransaction.getStore();
  if (sync) return sync.client.query<T>(text, params);
  await ensureSchema();
  const start = Date.now();
  try {
    const result = await getPool().query<T>(text, params);
    const duration = Date.now() - start;
    if (process.env.NODE_ENV === 'development') {
      console.log(`[Query] completed in ${duration}ms; parameters: ${params?.length ?? 0}`);
    }
    return result;
  } catch (err: unknown) {
    // Reset pool so the next call can re-establish (e.g. after a transient DB outage)
    const message = err instanceof Error ? err.message : 'Unknown error';
    if (
      message.includes('ECONNREFUSED') ||
      message.includes('ENOTFOUND') ||
      message.includes('EAI_AGAIN') ||
      message.includes('Connection terminated') ||
      message.includes('timeout exceeded')
    ) {
      // Best-effort pool reset, ignore errors
      try {
        await pool?.end();
      } catch {}
      pool = null;
      isConnected = false;
    }
    throw err;
  }
}

export async function dbTransaction<T>(
  fn: (client: PoolClient) => Promise<T>
): Promise<T> {
  const sync = syncTransaction.getStore();
  if (sync) {
    // Existing handlers retain their transaction boundaries as savepoints.
    const name = `sync_${crypto.randomUUID().replace(/-/g, '')}`;
    await sync.client.query(`SAVEPOINT ${name}`);
    try {
      const result = await fn(sync.client);
      await sync.client.query(`RELEASE SAVEPOINT ${name}`);
      return result;
    } catch (error) {
      await sync.client.query(`ROLLBACK TO SAVEPOINT ${name}`);
      throw error;
    }
  }
  const client = await getPool().connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    console.log('[Transaction] Commit successful');
    return result;
  } catch (err: any) {
    await client.query('ROLLBACK');
    console.error('[Transaction] Rollback:', err.message);
    throw err;
  } finally {
    client.release();
  }
}

export function isDatabaseConnected(): boolean {
  return isConnected;
}

export async function closePool(): Promise<void> {
  const current = pool;
  if (current) {
    pool = null;
    isConnected = false;
    try {
      await current.end();
      console.log('[Database] Pool closed');
    } catch (err: any) {
      console.error('[Database] Error closing pool:', err.message);
    }
  }
}

export async function gracefulShutdown(): Promise<void> {
  if (pool) {
    console.log('[Database] Shutting down connection pool...');
    await pool.end();
    pool = null;
    isConnected = false;
    console.log('[Database] Pool shut down complete');
  }
}

export async function getDatabaseStatus(): Promise<{
  connected: boolean;
  database: string;
  host: string;
  port: number;
  tables: number;
}> {
  try {
    const result = await dbQuery(
      "SELECT COUNT(*) as count FROM information_schema.tables WHERE table_schema = 'public'"
    );
    return {
      connected: true,
      database: DB_CONFIG.database,
      host: DB_CONFIG.host,
      port: DB_CONFIG.port,
      tables: parseInt(result.rows[0].count, 10),
    };
  } catch {
    return {
      connected: false,
      database: DB_CONFIG.database,
      host: DB_CONFIG.host,
      port: DB_CONFIG.port,
      tables: 0,
    };
  }
}
