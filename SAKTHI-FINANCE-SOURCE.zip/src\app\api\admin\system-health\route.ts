import { NextResponse } from 'next/server';
import { requireOwner } from '@/lib/api-utils';
import { dbQuery } from '@/server/database';

export const dynamic = 'force-dynamic';

/**
 * System health snapshot from the existing PostgreSQL architecture.
 * Owner-only (Admin and Customer get 403). A database failure returns
 * 500 JSON (the page shows an error state instead of crashing).
 */
export async function GET() {
  const auth = await requireOwner();
  if (auth.error) return auth.error;

  try {
    const started = Date.now();
    await dbQuery('SELECT 1');
    const latencyMs = Date.now() - started;

    const [size, connections, sessions, audit] = await Promise.all([
      dbQuery(`SELECT pg_database_size(current_database()) AS bytes`),
      dbQuery(`SELECT COUNT(*) AS c FROM pg_stat_activity WHERE datname = current_database()`),
      dbQuery(`SELECT COUNT(*) AS c FROM refresh_tokens WHERE revoked_at IS NULL AND expires_at > NOW()`),
      dbQuery(`SELECT MAX(created_at) AS last_event, COUNT(*) AS c FROM audit_events`),
    ]);

    return NextResponse.json({
      app: { status: 'operational' },
      database: {
        status: 'connected',
        latencyMs,
        sizeBytes: Number(size.rows[0]?.bytes) || 0,
        connections: Number(connections.rows[0]?.c) || 0,
      },
      sessions: { active: Number(sessions.rows[0]?.c) || 0 },
      auditLogging: {
        status: audit.rows[0]?.last_event ? 'active' : 'no-events',
        lastEventAt: audit.rows[0]?.last_event || null,
        totalEvents: Number(audit.rows[0]?.c) || 0,
      },
    });
  } catch (err: any) {
    console.error('[GET /api/admin/system-health] Error:', err?.message || err);
    return NextResponse.json(
      { error: 'Unable to connect to the database. Please try again.' },
      { status: 500 }
    );
  }
}
