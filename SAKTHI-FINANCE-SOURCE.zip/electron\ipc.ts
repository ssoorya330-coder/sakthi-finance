import { app, ipcMain, dialog, BrowserWindow, shell, safeStorage, type IpcMainInvokeEvent } from 'electron'
import path from 'node:path'
import { readFile, writeFile, unlink, rename } from 'node:fs/promises'
import { dbQuery } from '../src/server/database'
import { DesktopGoogleBroker, desktopGoogleExchange } from '../src/lib/auth/desktop-google'
import { createSessionFromGoogleIdToken, destroySession, restoreSession, persistRefreshToken, sessionUser, findSessionIdByAccessToken, resolveSessionIdentity } from './session'
import { callApi } from './api-bridge'
import { trustedRenderer, validCall } from './policy'
import { logEvent } from './logging'
import { WindowsVoice } from './speech'
import { MicrophoneConsent } from './microphone-consent'
import { DesktopUpdates } from './updates'
import { autoUpdater } from 'electron-updater'
import updateLog from 'electron-log/main'
import { OnlineUpdates } from './online-updates'
import { TabletService } from './tablet-service'
let desktopUpdates: DesktopUpdates | undefined
let onlineUpdates: OnlineUpdates | undefined
export const startOnlineUpdates = () => onlineUpdates?.start()
export const stopOnlineUpdateChecks = () => onlineUpdates?.stop()
export const launchPendingOnlineUpdate = () => onlineUpdates?.installAfterShutdown() ?? false
export const launchPendingUpdate = () => desktopUpdates?.launchAfterShutdown()
const windowsVoice = new WindowsVoice()
export const stopDesktopVoice = () => windowsVoice.cancel()

const broker = new DesktopGoogleBroker(300000, 1)
let pendingTicket: string | null = null
let pendingCredential: { token: string; expires: number } | null = null
let currentSessionId: number | null = null
const tabletService = new TabletService(() => currentSessionId)
export const stopTabletService = () => tabletService.stop()
let signingIn = false
const writeTargets = new Set<string>()
const sessionPath = () => path.join(app.getPath('userData'), 'sk-desktop-session.encrypted')

async function persistSession() {
  const token = currentSessionId === null ? null : persistRefreshToken(currentSessionId)
  if (!token || !safeStorage.isEncryptionAvailable()) throw Error('Secure session storage unavailable')
  const file = sessionPath(), temporary = file + '.tmp'
  await writeFile(temporary, safeStorage.encryptString(token))
  await rename(temporary, file)
}
export async function restoreStartupSession() {
  if (!safeStorage.isEncryptionAvailable()) throw Error('Secure session storage unavailable')
  try { currentSessionId = await restoreSession(safeStorage.decryptString(await readFile(sessionPath()))) }
  catch (error) { if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error }
}
async function finishLogin(token: string, name?: string) {
  const created = await createSessionFromGoogleIdToken(token, name)
  if (!created.ok) {
    if (created.code === 'name_required') { pendingCredential = { token, expires: Date.now() + 300000 }; return { ok: true, isNewUser: true } }
    return { ok: false, error: created.code }
  }
  if (currentSessionId !== null) await destroySession(currentSessionId)
  await tabletService.stop()
  currentSessionId = findSessionIdByAccessToken(created.session.accessToken)
  pendingCredential = null
  await persistSession()
  return { ok: true, user: sessionUser(currentSessionId!) }
}
async function startGoogleSignIn() {
  if (signingIn) return { ok: false, error: 'busy' }
  const clientId = process.env.GOOGLE_DESKTOP_CLIENT_ID, secret = process.env.GOOGLE_DESKTOP_CLIENT_SECRET
  if (!clientId || !secret) return { ok: false, error: 'not-configured' }
  signingIn = true
  pendingCredential = null
  let ticket: string | undefined
  try {
    const started = await broker.start(clientId, desktopGoogleExchange(clientId, secret))
    ticket = pendingTicket = started.ticket
    await shell.openExternal(started.url)
    while (pendingTicket === ticket) {
      const outcome = broker.poll(ticket)
      if (outcome.status === 'complete') return await finishLogin(outcome.credential)
      if (outcome.status === 'failed') return { ok: false, error: 'exchange-failed' }
      if (outcome.status === 'expired') return { ok: false, error: 'timeout' }
      await new Promise(resolve => setTimeout(resolve, 500))
    }
    return { ok: false, error: 'cancelled' }
  } catch { logEvent('auth_failure'); return { ok: false, error: 'unavailable' } }
  finally { if (ticket) broker.cancel(ticket); pendingTicket = null; signingIn = false }
}
export function cancelPendingSignIn() { if (pendingTicket) broker.cancel(pendingTicket); pendingTicket = null; pendingCredential = null }

export function registerIpcHandlers(getMainWindow: () => BrowserWindow | null) {
  const microphone = new MicrophoneConsent(path.join(app.getPath('userData'), 'microphone-consent.json'))
  desktopUpdates = new DesktopUpdates(app.getPath('userData'), app.getVersion())
  const logger = updateLog.create({logId: 'sakthi-updates'})
  logger.transports.console.level = false
  // Library errors can contain local paths/headers. Log only our bounded event fields.
  autoUpdater.logger = {info: () => {}, warn: () => {}, error: () => {}, debug: () => {}}
  onlineUpdates = new OnlineUpdates(autoUpdater, app.isPackaged, app.getVersion(), state => {
    const window = getMainWindow()
    if (window && !window.isDestroyed()) window.webContents.send('updates:online-event', state)
  }, (event, detail) => logger.info(event, detail ?? ''))
  const handle = (channel: string, operation: (event: IpcMainInvokeEvent, value: any) => unknown) => {
    ipcMain.handle(channel, async (event, value) => {
      const window = getMainWindow()
      if (!window || event.sender !== window.webContents || event.senderFrame !== window.webContents.mainFrame || !trustedRenderer(event.senderFrame.url, !app.isPackaged && process.env.SAKTHI_ELECTRON_DEV === '1')) {
        logEvent('ipc_denied'); throw Error('Desktop request denied')
      }
      try { return await operation(event, value) } catch { logEvent('ipc_failure'); throw Error('Desktop operation failed. Check database and storage availability.') }
    })
  }
  handle('auth:start', () => startGoogleSignIn())
  handle('auth:cancel', () => { cancelPendingSignIn(); return { ok: true } })
  handle('auth:restore', async () => {
    if (currentSessionId === null) await restoreStartupSession()
    const user = currentSessionId === null ? null : await resolveSessionIdentity(currentSessionId)
    return { ok: Boolean(user), user }
  })
  handle('auth:setName', async (_event, value) => {
    const name = typeof value === 'string' ? value.trim() : ''
    if (!name || name.length > 100 || /[\u0000-\u001f\u007f]/.test(name)) return { ok: false, error: 'Enter a valid name.' }
    if (pendingCredential && pendingCredential.expires > Date.now()) return finishLogin(pendingCredential.token, name)
    return { ok: false, error: 'Please sign in again.' }
  })
  handle('auth:logout', async () => {
    await tabletService.stop()
    windowsVoice.cancel()
    cancelPendingSignIn(); writeTargets.clear()
    const id = currentSessionId; currentSessionId = null
    await unlink(sessionPath()).catch(error => { if (error.code !== 'ENOENT') throw error })
    if (id !== null) await destroySession(id)
    return { ok: true }
  })
  handle('api:call', async (_event, value) => {
    if (!validCall(value)) return { status: 400, ok: false, data: { error: 'Invalid desktop request' } }
    return callApi(currentSessionId, value)
  })
  const authenticated = async () => { if (currentSessionId === null || !await resolveSessionIdentity(currentSessionId)) throw Error('Not signed in') }
  handle('tablet:status', async () => {await authenticated();return tabletService.status()})
  handle('tablet:enable', async (_event,environment) => {await authenticated();return tabletService.enable(environment)})
  handle('tablet:disable', async () => {await authenticated();await tabletService.stop();return tabletService.status()})
  handle('tablet:code', async () => {await authenticated();return tabletService.code()})
  handle('tablet:decide', async (_event,value) => {await authenticated();if(typeof value?.requestId!=='string'||typeof value?.approve!=='boolean')throw Error('Invalid decision');return tabletService.decide(value.requestId,value.approve)})
  handle('tablet:revoke', async (_event,id) => {await authenticated();if(typeof id!=='string')throw Error('Invalid device');return tabletService.revoke(id)})
  handle('updates:status', async () => { await authenticated(); return desktopUpdates!.status() })
  handle('updates:online-status', () => onlineUpdates!.status())
  handle('updates:check', () => desktopUpdates!.status().busy ? onlineUpdates!.status() : onlineUpdates!.check())
  handle('updates:download', () => desktopUpdates!.status().busy ? onlineUpdates!.status() : onlineUpdates!.download())
  handle('updates:restart', async () => {
    if (desktopUpdates!.status().busy || onlineUpdates!.status().phase !== 'ready') return {ok: false}
    const answer = await dialog.showMessageBox(getMainWindow()!, {type: 'question', message: 'Restart Sakthi Finance?', detail: 'Save unfinished entries first. The downloaded update will be applied automatically while the app restarts. Your saved finance data is kept.', buttons: ['Restart', 'Later'], defaultId: 1, cancelId: 1})
    if (answer.response !== 0) return {ok: false}
    onlineUpdates!.prepareInstall(); app.quit(); return {ok: true}
  })
  handle('updates:select', async () => {
    await authenticated()
    if (['checking', 'downloading', 'installing'].includes(onlineUpdates!.status().phase)) return desktopUpdates!.status()
    const result = await dialog.showOpenDialog(getMainWindow()!, { title: 'Choose Sakthi Finance update file', filters: [{ name: 'Sakthi Finance update', extensions: ['json'] }], properties: ['openFile'] })
    return result.canceled ? desktopUpdates!.status() : desktopUpdates!.select(result.filePaths[0])
  })
  handle('updates:install', async () => {
    await authenticated()
    if (['checking', 'downloading', 'installing'].includes(onlineUpdates!.status().phase)) return {ok: false}
    const answer = await dialog.showMessageBox(getMainWindow()!, { type: 'question', message: 'Install the verified update?', detail: 'Save all unfinished entries first. Sakthi Finance will close and open the update installer. Saved finance data is kept.', buttons: ['Install update', 'Cancel'], defaultId: 1, cancelId: 1 })
    if (answer.response !== 0) return { ok: false }
    await desktopUpdates!.prepareInstall(); app.quit(); return { ok: true }
  })
  handle('voice:start', async (_event, value) => {
    await authenticated()
    if (typeof value?.id !== 'string' || typeof value?.lang !== 'string') throw Error('Invalid voice request')
    const window = getMainWindow()!
    await windowsVoice.start(value.id, value.lang, () => microphone.request(async () => {
      const answer = await dialog.showMessageBox(window, { type: 'question', buttons: ['Allow and remember', 'Cancel'], defaultId: 1, cancelId: 1, message: 'Allow voice entry on this laptop?', detail: 'Remembered for this Windows profile. Recording starts only when you click a microphone. Audio stays on this PC. You can reset permission in App updates & voice.' })
      return answer.response === 0 && !window.isDestroyed()
    }), event => { if (!window.isDestroyed()) window.webContents.send('voice:event', event) }, value.phrases)
  })
  handle('voice:resetPermission', async () => { await authenticated(); windowsVoice.cancel(); await microphone.reset(); return { ok: true } })
  handle('voice:stop', (_event, id) => { if (typeof id === 'string') windowsVoice.stop(id) })
  handle('voice:cancel', (_event, id) => { if (typeof id === 'string') windowsVoice.cancel(id) })
  handle('dialog:chooseDirectory', async () => {
    await authenticated()
    const result = await dialog.showOpenDialog(getMainWindow()!, { properties: ['openDirectory', 'createDirectory'] })
    return result.canceled ? { ok: false } : { ok: true, path: result.filePaths[0] }
  })
  handle('dialog:chooseSavePath', async (_event, options) => {
    await authenticated()
    const name = typeof options?.defaultName === 'string' ? path.basename(options.defaultName).slice(0, 150) : 'report.pdf'
    const result = await dialog.showSaveDialog(getMainWindow()!, { defaultPath: path.join(app.getPath('documents'), name) })
    if (result.canceled || !result.filePath) return { ok: false }
    writeTargets.add(path.resolve(result.filePath))
    return { ok: true, path: result.filePath }
  })
  handle('export:write', async (_event, payload) => {
    await authenticated()
    if (typeof payload?.path !== 'string' || typeof payload.data !== 'string' || payload.data.length > 64 * 1024 * 1024) return { ok: false, error: 'Invalid export' }
    const target = path.resolve(payload.path)
    if (!writeTargets.delete(target)) return { ok: false, error: 'Choose a save location for this export first.' }
    await writeFile(target, Buffer.from(payload.data, payload.encoding === 'base64' ? 'base64' : 'utf8'))
    return { ok: true }
  })
  handle('app:info', () => ({ version: app.getVersion(), electron: process.versions.electron, chrome: process.versions.chrome, node: process.versions.node }))
}
