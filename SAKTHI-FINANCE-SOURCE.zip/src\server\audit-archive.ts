import { createHash } from 'node:crypto';

/** Raw PostgreSQL JSON avoids rounding large integers/numerics in JavaScript. */
export async function* auditArchiveJson(records: AsyncIterable<string>, metadata: Record<string, unknown>) {
  const checksum = createHash('sha256');
  let count = 0;
  yield `{"archiveVersion":1,"metadata":${JSON.stringify(metadata)},"records":[`;
  for await (const record of records) {
    checksum.update(record, 'utf8').update('\n');
    yield (count ? ',' : '') + record;
    count++;
  }
  yield `],"totalRecords":${count},"recordsSha256":"${checksum.digest('hex')}","checksumFormat":"raw record JSON followed by LF, in archive order"}`;
}
