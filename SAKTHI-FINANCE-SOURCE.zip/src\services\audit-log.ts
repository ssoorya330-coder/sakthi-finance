export interface AuditEntry {
  userId?: string;
  action: 'create' | 'update' | 'delete' | 'login' | 'logout' | 'export' | 'sync';
  entityType: 'customer' | 'loan' | 'collection' | 'payment' | 'user' | 'report';
  entityId?: string;
  details?: string;
}

export async function writeAuditLog(entry: AuditEntry): Promise<void> {
  const BASE_URL = process.env.NEXT_PUBLIC_API_URL || '';
  const uid = entry.userId || '';
  if (!uid) return;

  try {
    const response = await fetch(`${BASE_URL}/api/audit`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-User-Id': uid,
      },
      body: JSON.stringify({
        action: entry.action,
        entityType: entry.entityType,
        entityId: entry.entityId,
        details: entry.details,
      }),
    });

    if (!response.ok) {
      console.warn('[AuditLog] Failed to write audit log:', response.status);
    }
  } catch (err) {
    console.warn('[AuditLog] Failed to write audit log:', err);
  }
}
