import type { PoolClient } from 'pg'
import { dbTransaction, ensureSchema } from './database'
import { recordAuditEvent, type AuditActor } from './audit'

/** Runs inside one transaction. Never deletes a customer or unlinked payments. */
export async function purgeExpiredKanaku(tx: PoolClient, selected?: { loanId:string; owner:string; actor:AuditActor }) {
  const lock = await tx.query('SELECT pg_try_advisory_xact_lock(721904222) AS locked')
  if (!lock.rows[0].locked) return 0
  const due = selected
    ? await tx.query('SELECT * FROM kanaku_trash WHERE loan_id=$1 AND user_id=$2 AND purged_at IS NULL AND purge_after<=NOW()',[selected.loanId,selected.owner])
    : await tx.query(`SELECT * FROM kanaku_trash WHERE purged_at IS NULL AND purge_after<=NOW() ORDER BY purge_after LIMIT 100`)
  if (!due.rows.length) return 0
  // Fail closed if another feature introduces cascades into unrelated tables.
  const cascading = await tx.query(`SELECT 1 FROM pg_constraint WHERE contype='f' AND confdeltype='c'
    AND confrelid IN ('loans'::regclass,'payments'::regclass) LIMIT 1`)
  if(cascading.rows.length) throw new Error('Retention paused: related tables require a safe deletion review.')
  let count=0
  for (const candidate of due.rows) {
    await tx.query('SELECT id FROM customers WHERE id::text=$1 AND user_id=$2 FOR UPDATE',[candidate.customer_id,candidate.user_id])
    const result=await tx.query('SELECT * FROM kanaku_trash WHERE loan_id=$1 AND purge_after<=NOW() AND purged_at IS NULL FOR UPDATE',[candidate.loan_id])
    const row=result.rows[0]
    if(!row)continue // Restored while waiting for the customer lock.
    await tx.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',[row.kanaku_group_key])
    await tx.query("SELECT set_config('sakthi.purge_loan',$1,true)",[row.loan_id])
    const payments=await tx.query('DELETE FROM payments WHERE loan_id=$1 AND customer_id::text=$2 AND user_id=$3 RETURNING payment_id',[row.loan_id,row.customer_id,row.user_id])
    const loan=await tx.query('DELETE FROM loans WHERE loan_id=$1 AND customer_id::text=$2 AND user_id=$3 RETURNING loan_id',[row.loan_id,row.customer_id,row.user_id])
    if(loan.rows.length!==1)throw new Error('Retention stopped: Kanaku ownership could not be verified.')
    await tx.query('UPDATE kanaku_trash SET purged_at=NOW() WHERE loan_id=$1',[row.loan_id])
    await tx.query('UPDATE customers SET updated_at=NOW() WHERE id::text=$1 AND user_id=$2',[row.customer_id,row.user_id])
    await recordAuditEvent(tx,{action:selected?'LOAN_PERMANENTLY_DELETED':'LOAN_RETENTION_EXPIRED',entityType:'loan',entityId:row.loan_id,loanId:row.loan_id,customerId:row.customer_id,
      actor:selected?.actor || {userId:row.user_id,name:'Automatic retention',role:'system'},result:'SUCCESS',after:{paymentsRemoved:payments.rows.length}})
    count++
  }
  await tx.query("SELECT set_config('sakthi.purge_loan','',true)")
  return count
}

export function startKanakuRetention() {
  const state=globalThis as typeof globalThis & { sakthiRetention?: ReturnType<typeof setInterval> }
  if(state.sakthiRetention)return
  let running=false
  const run=async()=>{
    if(running)return
    running=true
    try {await ensureSchema();await dbTransaction(purgeExpiredKanaku)}
    catch(error){console.error('[Kanaku retention] Records retained; will retry:',error instanceof Error?error.message:error)}
    finally{running=false}
  }
  state.sakthiRetention=setInterval(()=>void run(),60*60*1000)
  state.sakthiRetention.unref()
  const first=setTimeout(()=>void run(),15000);first.unref()
}
