'use client'

import { useEffect } from 'react'
import { useDatabaseStore } from '@/store/database-store'
import { useAuthStore } from '@/store/auth-store'
import { usePathname } from 'next/navigation'

/**
 * Load account data only on signed-in application pages.
 */
export function DatabaseProvider({ children }: { children: React.ReactNode }) {
  const boot = useDatabaseStore((s) => s.boot)
  const userId = useAuthStore(s=>s.userId)
  const authenticated = useAuthStore(s=>s.isAuthenticated)
  const role = useAuthStore(s=>s.role)
  const pathname = usePathname()

  useEffect(() => {
    if (!authenticated || !userId || role === 'customer' || pathname === '/login') {
      useDatabaseStore.getState().reset()
      return
    }
    void boot(userId)
  }, [boot, userId, authenticated, role, pathname])

  return <>{children}</>
}
