import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { getDataDirectory, getPgServiceInfo } from '@/server/storage'
import { startCopyJob } from '@/server/migration-copy'

export const dynamic = 'force-dynamic'

/**
 * Start the automatic data-directory copy (runs server-side with robocopy).
 * Safety: refuses unless the PostgreSQL service is fully stopped and the
 * destination validates (empty, writable, not inside the live data dir).
 *
 * The caller passes the previously detected `source` explicitly: once the
 * service is stopped, SHOW data_directory is unavailable, so the source
 * must NOT be re-detected from SQL here — it is validated from disk
 * (existence + PG_VERSION cluster marker) instead.
 */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const destination = (body.destination || '').trim()
    if (!destination) return NextResponse.json({ error: 'Destination is required.' }, { status: 400 })

    const service = await getPgServiceInfo()
    if (service.name && service.state !== 'stopped') {
      return NextResponse.json(
        { ok: false, error: 'PostgreSQL must be fully stopped before copying. Stop the service first.' },
        { status: 200 }
      )
    }

    // Prefer the explicitly passed source (detected before the stop).
    // Fall back to a live lookup only when PostgreSQL is still running.
    let dataDir = (body.source || '').trim() || null
    if (!dataDir) {
      dataDir = await getDataDirectory()
    }
    if (!dataDir) {
      return NextResponse.json(
        { ok: false, error: 'Current data directory could not be detected. Re-detect the installation and retry.' },
        { status: 200 }
      )
    }

    const totalBytes = typeof body.sourceBytes === 'number' && body.sourceBytes > 0 ? body.sourceBytes : null
    try {
      const { jobId, totalBytes: total } = await startCopyJob(dataDir, destination, { totalBytes })
      return NextResponse.json({ ok: true, jobId, totalBytes: total })
    } catch (e: any) {
      return NextResponse.json({ ok: false, error: e?.message || 'Could not start the automatic copy.' }, { status: 200 })
    }
  } catch (err: any) {
    return NextResponse.json(
      { ok: false, error: 'Copy start failed', details: err.message },
      { status: 500 }
    )
  }
}
