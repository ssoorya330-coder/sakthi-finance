import { NextRequest, NextResponse } from 'next/server'
import { requireAuth, requireAuthWithPermission } from '@/lib/api-utils'
import {
  getCashThreshold,
  setCashThreshold,
  CASH_THRESHOLD_KEY,
} from '@/server/cash-compliance'
import { actorFromAuthUser, requestMeta, recordAuditStandalone } from '@/server/audit'

export const dynamic = 'force-dynamic'

/** Read the configured cash-review threshold (existing settings table). */
export async function GET() {
  const auth = await requireAuth()
  if (auth.error) return auth.error
  const threshold = await getCashThreshold()
  return NextResponse.json({ key: CASH_THRESHOLD_KEY, threshold })
}

/** Update the threshold. Restricted to settings managers; change is audited. */
export async function PUT(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const before = await getCashThreshold()
    const threshold = await setCashThreshold(Number(body.threshold))
    const meta = requestMeta(request)
    await recordAuditStandalone({
      action: 'SETTINGS_UPDATED',
      entityType: 'settings',
      entityId: CASH_THRESHOLD_KEY,
      actor: actorFromAuthUser(auth.user),
      ipAddress: meta.ip,
      clientInfo: meta.client,
      result: 'SUCCESS',
      changes: [{ field: 'cash_limit_threshold', label: 'Cash Review Threshold', before, after: threshold }],
    })
    return NextResponse.json({ key: CASH_THRESHOLD_KEY, threshold })
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Invalid threshold.' }, { status: 400 })
  }
}
