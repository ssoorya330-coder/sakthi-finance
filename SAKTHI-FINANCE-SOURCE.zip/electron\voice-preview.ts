/** One decode at a time; keep only the newest audio snapshot while busy. */
export class VoicePreview {
  private pending?: Buffer
  private running?: Promise<void>
  private controller?: AbortController
  private closed = false
  constructor(private decode: (wave: Buffer, signal: AbortSignal) => Promise<string>, private publish: (text: string) => void) {}
  push(wave: Buffer) {
    if (this.closed) { wave.fill(0); return }
    this.pending?.fill(0)
    this.pending = wave
    this.drain()
  }
  private drain() {
    if (this.running || !this.pending || this.closed) return
    const wave = this.pending
    this.pending = undefined
    const controller = this.controller = new AbortController()
    this.running = this.decode(wave, controller.signal)
      .then(text => { if (!this.closed && text) this.publish(text) })
      .catch(() => { /* A partial utterance may not yet contain recognizable words. */ })
      .finally(() => { wave.fill(0); this.running = undefined; this.drain() })
  }
  async close() {
    this.closed = true
    this.pending?.fill(0); this.pending = undefined
    this.controller?.abort()
    await this.running
  }
}
