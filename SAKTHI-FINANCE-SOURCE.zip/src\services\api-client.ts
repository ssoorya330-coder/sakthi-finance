import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import { useDesktopAdapter } from '@/lib/desktop/axios-adapter';
import { tryRefresh, clearClientAuthStorage } from '@/lib/auth/client-auth';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || '';

const api: AxiosInstance = axios.create({
  baseURL: API_BASE,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
  // The session lives in httpOnly cookies (sf_access/sf_refresh). They must
  // travel with every request or the server answers 401 — even same-origin
  // setups break the moment the page host differs (e.g. 127.0.0.1 vs
  // localhost), and the server ignores the Authorization header entirely.
  withCredentials: true,
});

let getTokenFn: (() => Promise<string | null>) | null = null;
let getUserId: (() => string | null) | null = null;

export function setAuthProvider(tokenFn: () => Promise<string | null>, userIdFn: () => string | null) {
  getTokenFn = tokenFn;
  getUserId = userIdFn;
}

api.interceptors.request.use(async (config) => {
  useDesktopAdapter(config);
  if (getTokenFn) {
    const token = await getTokenFn();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  if (getUserId) {
    const userId = getUserId();
    if (userId) {
      config.headers['X-User-Id'] = userId;
    }
  }
  return config;
});

// Lightweight in-memory cache for GET requests (30s TTL) + deduplication
const CACHE_TTL = 30_000;
const cache = new Map<string, { data: any; ts: number }>();
const inflight = new Map<string, Promise<any>>();
let cacheGeneration = 0;

function cacheKey(method: string, url: string) {
  return `${method}:${url}`;
}

async function request<T>(method: string, url: string, data?: unknown): Promise<T> {
  if (typeof window !== 'undefined') {
    const { useAuthStore } = await import('@/store/auth-store');
    const session = useAuthStore.getState();
    if (!window.sakthi && session.isAuthenticated && session.userId && localStorage.getItem(`sf-device-mode:${session.userId}`) === 'on') {
      const { localRequest } = await import('@/lib/device-sync/browser');
      const local = await localRequest(session.userId, session.role, method, url, data);
      if (local.handled) return local.value as T;
    }
  }
  const isGet = method === 'GET';
  const key = cacheKey(method, url);
  if (isGet) {
    const hit = cache.get(key);
    if (hit && Date.now() - hit.ts < CACHE_TTL) return hit.data as T;
    const pending = inflight.get(key);
    if (pending) return pending as Promise<T>;
  }
  const generation = cacheGeneration;
  const promise = api({ method, url, data }).then((r) => {
    if (isGet) {
      if (generation === cacheGeneration) cache.set(key, { data: r.data, ts: Date.now() });
    } else clearCache();
    return r.data as T;
  }).finally(() => { if (inflight.get(key) === promise) inflight.delete(key); });
  if (isGet) inflight.set(key, promise);
  return promise;
}

export function clearCache() {
  cacheGeneration++;
  cache.clear();
  inflight.clear();
}

// Deduplicated refresh so concurrent 401s trigger a single token refresh.
let refreshInFlight: Promise<boolean> | null = null;

async function attemptRefresh(): Promise<boolean> {
  if (refreshInFlight) return refreshInFlight;
  refreshInFlight = (async () => {
    const result = await tryRefresh();
    return result !== null;
  })();
  try {
    return await refreshInFlight;
  } finally {
    setTimeout(() => {
      refreshInFlight = null;
    }, 100);
  }
}

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config as AxiosRequestConfig & {
      _refreshAttempted?: boolean;
    };
    if (!originalRequest) return Promise.reject(error);

    // 401 means the short-lived access cookie expired (or is missing) while
    // the long-lived refresh cookie may still be valid. Recover once via the
    // refresh endpoint — which re-issues the access cookie — then retry the
    // original request with the fresh Bearer mirror. Never downgrade auth:
    // a persistent 401 still rejects and clears stale client state.
    if (error.response?.status === 401 && !originalRequest._refreshAttempted) {
      originalRequest._refreshAttempted = true;
      try {
        const refreshed = await attemptRefresh();
        if (refreshed) {
          if (getTokenFn) {
            const token = await getTokenFn();
            if (token) {
              originalRequest.headers = originalRequest.headers || {};
              (originalRequest.headers as Record<string, string>).Authorization = `Bearer ${token}`;
            }
          }
          return api(originalRequest);
        }
      } catch {
        // fall through to clear-and-reject
      }
      clearClientAuthStorage();
    }

    return Promise.reject(error);
  }
);

// ========== CUSTOMERS ==========
export interface DbCustomer {
  id: string;
  customer_code: string;
  full_name: string;
  phone_number: string;
  alternate_phone: string;
  address: string;
  area_id: number | null;
  city_id: number | null;
  business_id: number | null;
  area_name?: string;
  city_name?: string;
  business_name?: string;
  income: number;
  status: string;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export function mapDbCustomer(c: DbCustomer) {
  return {
    id: c.id,
    customerCode: c.customer_code || '',
    offlinePaidAmount: Number((c as any).offline_paid_amount) || 0,
    fullName: c.full_name,
    mobileNumber: c.phone_number || '',
    alternateMobile: c.alternate_phone || '',
    address: c.address || '',
    areaId: c.area_id,
    areaName: c.area_name || '',
    cityName: c.city_name || '',
    businessName: c.business_name || '',
    monthlyIncome: c.income ? String(c.income) : '',
    status: (c.status || 'Active') as 'Active' | 'Completed' | 'Overdue' | 'Aborted',
    createdAt: c.created_at,
    updatedAt: c.updated_at,
    // Loan fields from JOIN
    loanId: (c as any).loan_id,
    loanCount: Number((c as any).loan_count) || 1,
    cycleNumber: (c as any).cycle_number == null ? undefined : Number((c as any).cycle_number),
    kanakuNumber: (c as any).kanaku_number == null ? undefined : Number((c as any).kanaku_number),
    kanakuSchedules: (c as any).schedules || undefined,
    loanDate: (c as any).loan_date || '',
    dueDate: (c as any).due_date || '',
    loanAmount: (c as any).loan_amount ? String((c as any).loan_amount) : '0',
    interestRate: (c as any).interest_rate ? String((c as any).interest_rate) : '0',
    interestAmount: (c as any).interest_amount ? String((c as any).interest_amount) : '0',
    totalAmount: Number((c as any).total_amount) || 0,
    installmentAmount: Number((c as any).installment_amount) || 0,
    remainingDays: Number((c as any).remaining_days) || 0,
    duration: (c as any).duration ? String((c as any).duration) : '0',
    loanType: ((c as any).loan_type || 'Daily') as 'Daily' | 'Weekly' | 'Monthly' | 'Yearly',
    completedAt: (c as any).completed_at,
    abortedAt: (c as any).aborted_at,
    abortReason: (c as any).abort_reason,
    loanNotes: (c as any).loan_notes || '',
    disbursalMode: (c as any).disbursal_mode || undefined,
    // Legacy aliases
    area: c.area_name || '',
    city: c.city_name || '',
    occupation: c.business_name || '',
  };
}

// ========== LOANS ==========
export interface DbLoan {
  cycle_number?: number;
  kanaku_number?: number;
  request_key?: string;
  disbursal_mode?: string;
  loan_id: string;
  customer_id: string;
  loan_date: string;
  due_date: string;
  loan_amount: number;
  interest_rate: number;
  interest_amount: number;
  total_amount: number;
  installment_amount: number;
  remaining_days: number;
  duration: number;
  loan_type: string;
  status: string;
  completed_at?: string;
  aborted_at?: string;
  abort_reason?: string;
  notes: string;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export function mapDbLoan(l: DbLoan) {
  return {
    loanId: l.loan_id,
    customerId: l.customer_id,
    loanDate: l.loan_date || '',
    dueDate: l.due_date || '',
    loanAmount: l.loan_amount ? String(l.loan_amount) : '0',
    interestRate: l.interest_rate ? String(l.interest_rate) : '0',
    interestAmount: l.interest_amount ? String(l.interest_amount) : '0',
    totalAmount: l.total_amount ? String(l.total_amount) : '0',
    installmentAmount: l.installment_amount ? String(l.installment_amount) : '0',
    remainingDays: Number(l.remaining_days) || 0,
    duration: l.duration ? String(l.duration) : '0',
    loanType: (l.loan_type || 'Daily') as 'Daily' | 'Weekly' | 'Monthly' | 'Yearly',
    status: (l.status || 'Active') as 'Active' | 'Completed' | 'Overdue' | 'Aborted',
    completedAt: l.completed_at,
    abortedAt: l.aborted_at,
    abortReason: l.abort_reason,
    notes: l.notes || '',
    createdAt: l.created_at,
    updatedAt: l.updated_at,
  };
}

// ========== API FUNCTIONS ==========

export async function fetchCustomers(params?: { status?: string; search?: string; page?: number; limit?: number }) {
  const qs = new URLSearchParams();
  if (params?.status && params.status !== 'all') qs.set('status', params.status);
  if (params?.search) qs.set('search', params.search);
  if (params?.page) qs.set('page', String(params.page));
  if (params?.limit) qs.set('limit', String(params.limit));
  return request<{ data: DbCustomer[]; total: number; page: number; limit: number; totalPages: number }>('GET', `/api/customers?${qs}`);
}

export async function fetchCustomerById(id: string) {
  return request<DbCustomer>('GET', `/api/customer/${id}`);
}

export async function createCustomer(data: Partial<DbCustomer>) {
  return request<DbCustomer>('POST', '/api/customer', data);
}

export async function updateCustomer(id: string, data: Partial<DbCustomer>) {
  return request<DbCustomer>('PUT', `/api/customer/${id}`, data);
}

export async function deleteCustomer(id: string) {
  return request<{ success: boolean; id: string }>('DELETE', `/api/customer/${id}`);
}

// ========== LOANS ==========
export async function fetchLoans(params?: { customerId?: string; status?: string }) {
  const qs = new URLSearchParams();
  if (params?.customerId) qs.set('customer_id', params.customerId);
  if (params?.status) qs.set('status', params.status);
  const query = qs.toString();
  return request<{ data: DbLoan[] }>('GET', `/api/loans${query ? `?${query}` : ''}`);
}

export async function fetchLoansByCustomerId(customerId: string) {
  const result = await fetchLoans({ customerId });
  return result.data.map(mapDbLoan);
}

export async function createLoan(data: Partial<DbLoan>) {
  return request<DbLoan>('POST', '/api/loan', data);
}

export async function updateLoan(id: string, data: Partial<DbLoan>) {
  return request<DbLoan>('PUT', `/api/loan/${id}`, data);
}

export async function deleteLoan(id: string) {
  try {
    return await request<{ success: boolean }>('DELETE', `/api/loan/${id}`);
  } catch (error) {
    if (axios.isAxiosError(error)) throw new Error(error.response?.data?.error || 'Connect to the laptop and try again. No deletion was confirmed.');
    throw error;
  }
}

// ========== PAYMENTS ==========
export async function fetchPayments(params?: { customerId?: string; loanId?: string; startDate?: string; endDate?: string }) {
  const qs = new URLSearchParams();
  if (params?.customerId) qs.set('customer_id', params.customerId);
  if (params?.loanId) qs.set('loan_id', params.loanId);
  if (params?.startDate) qs.set('start_date', params.startDate);
  if (params?.endDate) qs.set('end_date', params.endDate);
  return request<{ data: any[] }>('GET', `/api/payments?${qs}`);
}

export async function createPayment(data: any) {
  return request<any>('POST', '/api/payment', data);
}

export async function updatePayment(id: string, data: any) {
  return request<any>('PUT', `/api/payment/${id}`, data);
}

export async function deletePayment(id: string) {
  return request<{ success: boolean }>('DELETE', `/api/payment/${id}`);
}

// ========== DASHBOARD ==========
export async function fetchDashboard() {
  return request<{
    totalCustomers: number; activeCustomers: number; completedCustomers: number; abortedCustomers: number;
    totalLoanAmount: number; totalInterest: number; totalAmount: number;
    todayCollection: number; pendingCollection: number; receivedAmount: number;
  }>('GET', '/api/dashboard');
}

// ========== DAILY COLLECTION ==========
export async function fetchDailyCollection() {
  return request<{ data: any[]; total: number }>('GET', '/api/daily-collection');
}

// ========== REPORTS ==========
export async function fetchReport(type: string) {
  return request<any>('GET', `/api/reports/${type}`);
}

// ========== SEARCH ==========
export async function searchCustomers(query: string) {
  return request<{ data: DbCustomer[] }>('GET', `/api/search?q=${encodeURIComponent(query)}`);
}

// ========== COMPLETED & ABORTED ==========
export async function fetchCompletedCustomers() {
  return request<{ data: DbCustomer[] }>('GET', '/api/completed-customers');
}

export async function fetchAbortedCustomers() {
  return request<{ data: DbCustomer[] }>('GET', '/api/aborted-customers');
}

export async function getDatabaseStatus() {
  return request<{ connected: boolean; database: string; host: string; port: number; tables: number }>('GET', '/api/database/status');
}

export async function setDatabaseType(type: string) {
  return request<{ success: boolean }>('POST', '/api/database/set-type', { type });
}

export async function getDatabaseConfig() {
  return request<{ success: boolean; databaseType: string; host: string; port: number; database: string; user: string }>('GET', '/api/database/get-config');
}

export async function saveDatabaseConfig(config: { type: string; host: string; port: number; database: string; user: string; password: string }) {
  return request<{ success: boolean }>('POST', '/api/database/set-manual-config', config);
}

export async function disconnectDatabase() {
  return request<{ success: boolean; message: string }>('POST', '/api/database/disconnect');
}

export async function connectDatabase() {
  return request<{ success: boolean; message: string }>('POST', '/api/database/connect');
}

export const apiClient = {
  fetchCustomers, fetchCustomerById, createCustomer, updateCustomer, deleteCustomer,
  fetchLoans, fetchLoansByCustomerId, createLoan, updateLoan, deleteLoan,
  fetchPayments, createPayment, updatePayment, deletePayment,
  fetchDashboard, fetchDailyCollection, fetchReport, searchCustomers,
  fetchCompletedCustomers, fetchAbortedCustomers, getDatabaseStatus,
  getDatabaseConfig,
  saveDatabaseConfig,
  disconnectDatabase,
  connectDatabase,
  setAuthProvider,
  clearCache,
};
