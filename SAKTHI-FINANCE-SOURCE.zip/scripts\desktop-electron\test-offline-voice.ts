import { readFileSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import { transcribeWave } from '../../electron/offline-transcription'
import { parseSpokenPhone } from '../../src/lib/voice-phone'

// Generated QA audio only. Do not put a real customer's recording in this directory.
async function main() {
  const preview = process.argv.includes('--preview')
  const cases = [
    ['name', 'Soorya'], ['full-name', 'Ravi Kumar'], ['city', 'Salem'],
    ['phone', '9876543210'], ['address', 'number twelve Gandhi Road Chennai'],
    ['unseen-name', 'Arjun'], ['unseen-city', 'Coimbatore'],
    ['requested-name', 'Arul Vettri'], ['requested-address', 'RS Puram Coimbatore'],
    ['country-phone', '9876543210'], ['double-phone', '9987654321'],
  ]
  const results = []
  for (const [id, expected] of cases) {
    const start = Date.now()
    const file = readFileSync(path.resolve('test-reports/offline-voice-fixtures', id + '.wav'))
    // Windows synthesis adds a non-audio RIFF chunk; rewrap PCM for the capture contract.
    let offset = 12, pcm = Buffer.alloc(0)
    while (offset + 8 <= file.length) {
      const size = file.readUInt32LE(offset + 4)
      if (file.toString('ascii', offset, offset + 4) === 'data') { pcm = file.subarray(offset + 8, offset + 8 + size); break }
      offset += 8 + size + (size % 2)
    }
    const wav = Buffer.alloc(44 + pcm.length)
    wav.write('RIFF'); wav.writeUInt32LE(wav.length - 8, 4); wav.write('WAVEfmt ', 8); wav.writeUInt32LE(16, 16)
    wav.writeUInt16LE(1, 20); wav.writeUInt16LE(1, 22); wav.writeUInt32LE(16000, 24); wav.writeUInt32LE(32000, 28)
    wav.writeUInt16LE(2, 32); wav.writeUInt16LE(16, 34); wav.write('data', 36); wav.writeUInt32LE(pcm.length, 40); pcm.copy(wav, 44)
    let actual = '', error = ''
    try { actual = await transcribeWave(path.resolve('dist-electron/native'), wav, 'en-IN', new AbortController().signal, ['Soorya', 'Ravi Kumar', 'Salem'], preview) }
    catch (e) { error = e instanceof Error ? e.message : 'unknown' }
    const addressNormalize = (text: string) => text.replace(/^(?:number )?(?:twelve|12) /, '12 ')
    let normalized = id.includes('phone') ? parseSpokenPhone(actual) : actual.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim()
    let expectedNormalized = id.includes('phone') ? expected : expected.toLowerCase()
    // Twelve/12 and punctuation are equivalent address values, not a recognition error.
    if (id === 'address') { normalized = addressNormalize(normalized ?? ''); expectedNormalized = addressNormalize(expectedNormalized) }
    results.push({ id, expected, actual, error, milliseconds: Date.now() - start, status: normalized === expectedNormalized ? 'PASS' : 'FAIL' })
    console.log(JSON.stringify(results.at(-1)))
  }
  writeFileSync(preview ? 'test-reports/OFFLINE_VOICE_PREVIEW_TEST.json' : 'test-reports/OFFLINE_VOICE_MODEL_TEST.json', JSON.stringify({ date: new Date().toISOString(), preview, fixture: 'Synthetic speech, not human microphone', results }, null, 2))
  if (results.some(test => test.status !== 'PASS')) process.exitCode = 1
}
void main()
