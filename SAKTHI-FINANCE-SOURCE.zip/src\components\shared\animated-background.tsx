'use client';

import { useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';

interface AnimatedBackgroundProps {
  className?: string;
  intensity?: 'low' | 'medium' | 'high';
}

export default function AnimatedBackground({
  className,
  intensity = 'medium',
}: AnimatedBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animId = 0;
    let w = 0;
    let h = 0;
    let visible = true;

    const resize = () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    // Pause when tab hidden
    const handleVisibility = () => {
      visible = !document.hidden;
      if (visible) {
        animId = requestAnimationFrame(draw);
      } else {
        cancelAnimationFrame(animId);
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);

    const count = intensity === 'high' ? 40 : intensity === 'medium' ? 25 : 12;
    const particles = Array.from({ length: count }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.12,
      vy: (Math.random() - 0.5) * 0.12,
      r: Math.random() * 1.0 + 0.3,
      o: Math.random() * 0.2 + 0.05,
    }));

    const draw = () => {
      if (!visible) return;
      ctx.clearRect(0, 0, w, h);
      for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = w;
        if (p.x > w) p.x = 0;
        if (p.y < 0) p.y = h;
        if (p.y > h) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(201, 168, 76, ${p.o})`;
        ctx.fill();
      }
      animId = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [intensity]);

  const orbCount = intensity === 'high' ? 3 : intensity === 'medium' ? 2 : 1;

  return (
    <div className={cn('fixed inset-0 overflow-hidden pointer-events-none', className)}>
      <canvas ref={canvasRef} className="absolute inset-0 z-0" />

      {Array.from({ length: orbCount }).map((_, i) => (
        <div
          key={i}
          className="absolute rounded-full will-change-transform"
          style={{
            width: `${200 + i * 80}px`,
            height: `${200 + i * 80}px`,
            left: `${15 + i * 22}%`,
            top: `${10 + i * 18}%`,
            background: `radial-gradient(circle, rgba(201,168,76,${0.04 - i * 0.008}) 0%, transparent 70%)`,
            filter: 'blur(40px)',
            animation: `sf-orb-float ${8 + i * 2}s ease-in-out infinite`,
            animationDelay: `${i * 2}s`,
          }}
        />
      ))}

      <div
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(135deg, rgba(201,168,76,0.02) 0%, transparent 40%, rgba(201,168,76,0.015) 60%, transparent 100%)',
          animation: 'sf-bg-pulse 8s ease-in-out infinite',
        }}
      />

      <div className="absolute inset-0 sf-noise" />
    </div>
  );
}
