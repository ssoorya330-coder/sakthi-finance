'use client'

import { Suspense } from 'react'
import { useSidebarStore } from '@/store/sidebar-store'
import Link from 'next/link'
import { ArrowLeft, Wallet } from 'lucide-react'

function LoansContent() {
  const { toggleSidebar } = useSidebarStore()
  return (
    <div className="h-screen bg-[var(--background)] flex flex-col items-center justify-center p-8">
      <div className="bg-white rounded-[20px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04)] p-12 max-w-lg w-full text-center">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button onClick={toggleSidebar} className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors active:scale-95">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="#475569" strokeWidth="2" strokeLinecap="round"><path d="M3 5h14" /><path d="M3 10h14" /><path d="M3 15h14" /></svg>
            </button>
            <Link href="/dashboard" className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors active:scale-95">
              <ArrowLeft className="w-5 h-5 text-slate-600" />
            </Link>
          </div>
        </div>
        <div className="w-16 h-16 rounded-2xl bg-[var(--primary-soft)] flex items-center justify-center mx-auto mb-5">
          <Wallet className="w-8 h-8 text-[var(--primary)]" />
        </div>
        <h1 className="text-2xl font-bold text-slate-900 mb-2">Loan Management</h1>
        <p className="text-slate-500">This section is under development. It will provide comprehensive loan tracking and management tools.</p>
      </div>
    </div>
  )
}

export default function LoansPage() {
  return <Suspense fallback={null}><LoansContent /></Suspense>
}
