import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbTransaction, ensureSchema } from '@/server/database'
import { recordAuditEvent, actorFromAuthUser, requestMeta } from '@/server/audit'
import { resolveCustomerId } from '@/server/customer-identity'

export async function POST(request: NextRequest, { params }: { params: Promise<{ id:string }> }) {
  const auth=await requireAuthWithPermission('customers:update')
  if(auth.error)return auth.error
  const loansAuth=await requireAuthWithPermission('loans:update')
  if(loansAuth.error)return loansAuth.error
  try {
    await ensureSchema()
    const id=await resolveCustomerId((await params).id)
    const owner=auth.user.userId
    const meta=requestMeta(request)
    const status=await dbTransaction(async tx=>{
      const found=await tx.query('SELECT * FROM customers WHERE id=$1 AND user_id=$2 FOR UPDATE',[id,owner])
      const before=found.rows[0]
      if(!before)return null
      if(before.status!=='Aborted')return before.status
      const loans=await tx.query("SELECT * FROM kanaku_loan_balances WHERE customer_id=$1 AND user_id=$2 AND status='Aborted' ORDER BY loan_id",[id,owner])
      for(const loan of loans.rows){
        await tx.query(`UPDATE loans SET status=$1,aborted_at=NULL,abort_reason=NULL,updated_at=NOW() WHERE loan_id=$2 AND customer_id=$3 AND user_id=$4`,[Number(loan.outstanding)>0?'Active':'Completed',loan.loan_id,id,owner])
        await recordAuditEvent(tx,{action:'LOAN_UNABORTED',entityType:'loan',entityId:loan.loan_id,customerId:id,loanId:loan.loan_id,actor:actorFromAuthUser(auth.user),ipAddress:meta.ip,clientInfo:meta.client,before:loan,after:{status:Number(loan.outstanding)>0?'Active':'Completed'}})
      }
      const balances=await tx.query('SELECT outstanding FROM kanaku_loan_balances WHERE customer_id=$1 AND user_id=$2',[id,owner])
      const next=balances.rows.length && balances.rows.every(row=>Number(row.outstanding)===0)?'Completed':'Active'
      await tx.query('UPDATE customers SET status=$1,updated_at=NOW() WHERE id=$2 AND user_id=$3',[next,id,owner])
      await recordAuditEvent(tx,{action:'CUSTOMER_UNABORTED',entityType:'customer',entityId:id,customerId:id,actor:actorFromAuthUser(auth.user),ipAddress:meta.ip,clientInfo:meta.client,before:{status:before.status},after:{status:next}})
      return next
    })
    return NextResponse.json(status?{success:true,status}:{error:'Customer not found.'},{status:status?200:404})
  } catch {
    return NextResponse.json({error:'Unable to unabort this customer. No changes were saved. Check the connection or whether a previous cycle is locked.'},{status:409})
  }
}

