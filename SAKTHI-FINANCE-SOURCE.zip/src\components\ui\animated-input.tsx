'use client'

import { forwardRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { cn } from '@/lib/utils'
import { Eye, EyeOff, Mail, Lock, User, Search, KeyRound } from 'lucide-react'

interface AnimatedInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
  icon?: 'mail' | 'lock' | 'user' | 'search' | 'key'
}

const iconMap = {
  mail: Mail,
  lock: Lock,
  user: User,
  search: Search,
  key: KeyRound,
}

const AnimatedInput = forwardRef<HTMLInputElement, AnimatedInputProps>(
  ({ label, error, icon, className, type, ...props }, ref) => {
    const [showPassword, setShowPassword] = useState(false)
    const [focused, setFocused] = useState(false)
    const IconComponent = icon ? iconMap[icon] : null

    const isPassword = type === 'password'
    const inputType = isPassword && showPassword ? 'text' : type

    return (
      <div className="w-full">
        {label && (
          <motion.label
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            className="block text-[13px] font-medium text-text-secondary mb-2 tracking-wide"
          >
            {label}
          </motion.label>
        )}
        <div className="relative">
          {IconComponent && (
            <div className="absolute left-4 top-1/2 -translate-y-1/2 z-10 pointer-events-none">
              <IconComponent
                className={cn(
                  'w-5 h-5 transition-colors duration-300',
                  focused ? 'text-gold-300' : 'text-text-muted'
                )}
              />
            </div>
          )}
          <input
            ref={ref}
            type={inputType}
            onFocus={(e) => {
              setFocused(true)
              props.onFocus?.(e)
            }}
            onBlur={(e) => {
              setFocused(false)
              props.onBlur?.(e)
            }}
            className={cn(
              'sf-premium-input',
              'w-full h-14 rounded-2xl',
              'text-[15px] text-text-primary placeholder-text-muted',
              'outline-none',
              'transition-all duration-300 ease-out',
              icon ? 'pl-12 pr-5' : 'px-5',
              isPassword && 'pr-[52px]',
              error && '!border-error !shadow-[0_0_0_3px_rgba(248,113,113,0.1)]',
              className
            )}
            {...props}
          />
          {isPassword && (
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className={cn(
                'absolute right-5 top-1/2 -translate-y-1/2 z-10',
                'text-text-muted hover:text-text-secondary',
                'transition-colors duration-200 pointer-events-auto'
              )}
              tabIndex={-1}
            >
              {showPassword ? (
                <EyeOff className="w-[18px] h-[18px]" />
              ) : (
                <Eye className="w-[18px] h-[18px]" />
              )}
            </button>
          )}
        </div>
        <AnimatePresence>
          {error && (
            <motion.p
              initial={{ opacity: 0, y: -4, height: 0 }}
              animate={{ opacity: 1, y: 0, height: 'auto' }}
              exit={{ opacity: 0, y: -4, height: 0 }}
              className="text-[13px] text-error mt-2 tracking-wide"
            >
              {error}
            </motion.p>
          )}
        </AnimatePresence>
      </div>
    )
  }
)

AnimatedInput.displayName = 'AnimatedInput'

export { AnimatedInput }
export default AnimatedInput
