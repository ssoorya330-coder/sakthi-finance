'use client'

import { create } from 'zustand'
import { useCustomerStore } from './customer-store'
import { apiClient } from '@/services/api-client'
import { useAuthStore } from './auth-store'

export type DatabasePhase = 'idle' | 'initializing' | 'ready' | 'error'
export type DatabaseType = 'automatic' | 'manual' | 'local'

interface DatabaseConfig {
  type: DatabaseType
  host: string
  port: number
  database: string
  user: string
  password: string
}

interface DatabaseState {
  phase: DatabasePhase
  userId: string | null
  error: string | null
  dbConnected: boolean
  bootPromise: Promise<boolean> | null
  boot: (userId: string) => Promise<boolean>
  retryConnection: () => Promise<boolean>
  reset: () => void
  initialize: () => Promise<void>
  setConfig: (config: Partial<DatabaseConfig>) => void
  setDatabaseType: (type: DatabaseType) => void
  loadConfig: () => Promise<void>
  saveConfig: (config: DatabaseConfig) => Promise<void>
  disconnect: () => Promise<void>
  connect: () => Promise<void>
}

export const databaseReady = (state: { phase: DatabasePhase }) => state.phase === 'ready'
export const databaseLoading = (state: { phase: DatabasePhase }) => state.phase === 'idle' || state.phase === 'initializing'
export const databaseError = (state: { phase: DatabasePhase }) => state.phase === 'error'

export const useDatabaseStore = create<DatabaseState>()((set, get) => ({
  phase: 'idle',
  userId: null,
  error: null,
  dbConnected: false,
  bootPromise: null,

  initialize: async () => {
    if(!useAuthStore.getState().isAuthenticated || !useAuthStore.getState().userId)return
    const state = get()
    try {
      const config = await apiClient.getDatabaseConfig()
      const dbType = (config.databaseType as DatabaseType) || 'automatic'

      set({ phase: 'initializing' })

      let connected = false

      if (dbType === 'local') {
        // Use local IndexedDB/SQLite
        connected = true
        set({ dbConnected: true, error: null })
      } else if (dbType === 'manual') {
        // Use manual PostgreSQL config - check status
        try {
          const status = await apiClient.getDatabaseStatus()
          connected = status.connected
          // Use type assertion since status type doesn't include detail/error
          const s: any = status
          set({ dbConnected: s.connected, error: s.detail || s.error || null })
        } catch (err: any) {
          connected = false
          set({ error: err.message || 'Database connection failed', dbConnected: false })
        }
      } else {
        // Automatic - use environment variables
        try {
          const status = await apiClient.getDatabaseStatus()
          connected = status.connected
          const s: any = status
          set({ dbConnected: s.connected, error: s.detail || s.error || null })
        } catch (err: any) {
          connected = false
          set({ error: err.message || 'Database connection failed', dbConnected: false })
        }
      }

      if (connected) {
        await useCustomerStore.getState().init()
        set({ phase: 'ready', error: null, bootPromise: null })
      } else {
        set({ phase: 'error', error: 'Database connection failed', bootPromise: null })
      }
    } catch (err: any) {
      set({ phase: 'error', error: err.message || 'Database initialization failed', bootPromise: null })
    }
  },

  boot: async (userId) => {
    const validAccount=()=>useAuthStore.getState().isAuthenticated && useAuthStore.getState().userId===userId && get().userId===userId
    if(!userId || userId==='public' || !useAuthStore.getState().isAuthenticated || useAuthStore.getState().userId!==userId)return false
    const state = get()
    if (state.phase === 'ready' && state.userId === userId) return true
    if (state.bootPromise && state.userId === userId) return state.bootPromise

    const promise = (async () => {
      set({ phase: 'initializing', userId: userId, error: null })
      try {
        const status = await apiClient.getDatabaseStatus()
        if(!validAccount())return false
        set({ dbConnected: status.connected })
        if (!status.connected) throw new Error('PostgreSQL not connected')

        await useCustomerStore.getState().init()
        if(!validAccount())return false
        if(!useCustomerStore.getState().initialized) {
          set({phase:'idle',bootPromise:null})
          return false
        }
        set({ phase: 'ready', error: null, bootPromise: null })
        return true
      } catch (err: any) {
        if(!validAccount())return false
        set({ phase: 'error', error: err.message || 'Database connection failed', bootPromise: null })
        return false
      }
    })()

    set({ bootPromise: promise })
    return promise
  },

  retryConnection: async () => {
    const state = get()
    if (!state.userId) return false
    set({ phase: 'idle', error: null })
    return get().boot(state.userId)
  },

  reset: () => {
    set({ phase: 'idle', userId: null, error: null, dbConnected: false, bootPromise: null })
  },

  setConfig: (config: Partial<DatabaseConfig>) =>
    set((state) => ({
      error: null,
      ...config,
    })),

  setDatabaseType: (type: DatabaseType) =>
    set({
      error: null,
      // Reset connection when type changes
      dbConnected: false,
      phase: 'idle' as DatabasePhase,
    }),

  loadConfig: async () => {
    try {
      await apiClient.getDatabaseConfig()
      set({ error: null })
    } catch (err: any) {
      set({ error: err.message || 'Failed to load database config' })
    }
  },

  saveConfig: async (config: DatabaseConfig) => {
    try {
      await apiClient.saveDatabaseConfig({
        type: config.type,
        host: config.host,
        port: config.port,
        database: config.database,
        user: config.user,
        password: config.password,
      })
      set({ error: null })
    } catch (err: any) {
      set({ error: err.message || 'Failed to save database config' })
    }
  },

  disconnect: async () => {
    try {
      await apiClient.disconnectDatabase()
      set({ dbConnected: false, phase: 'error', error: 'Database disconnected' })
    } catch (err: any) {
      set({ error: err.message || 'Failed to disconnect database' })
    }
  },

  connect: async () => {
    try {
      const result = await apiClient.connectDatabase()
      if (result.success) {
        await get().initialize()
      }
    } catch (err: any) {
      set({ error: err.message || 'Failed to connect to database' })
    }
  },
}))
