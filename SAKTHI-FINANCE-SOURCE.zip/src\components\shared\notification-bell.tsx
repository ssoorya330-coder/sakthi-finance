'use client'

import Link from 'next/link'
import { Bell } from 'lucide-react'
import { useNotifications } from '@/hooks/use-notifications'

export default function NotificationBell() {
  const { data, isError } = useNotifications()
  return <Link href="/dashboard/notifications" aria-label={isError ? 'Notifications unavailable, open to retry' : `Notifications, ${data?.unread ?? 0} unread`} className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white shadow-sm hover:bg-rose-50">
    <Bell className="h-4 w-4 text-slate-600" />
    {!!data?.unread && <span className="absolute -right-1 -top-1 min-w-4 rounded-full bg-[var(--primary)] px-1 text-center text-[10px] font-bold text-white">{data.unread > 99 ? '99+' : data.unread}</span>}
    {isError && <span className="absolute -right-1 -top-1 rounded-full bg-amber-500 px-1 text-xs text-white">!</span>}
  </Link>
}
