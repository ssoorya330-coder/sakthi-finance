'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Landmark } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useSidebarStore } from '@/store/sidebar-store'

interface KanakuRow {
  id: string
  customer_code: string
  kanaku_no: number
  customer: any | null
  loans: any[]
  payments: any[]
  totals: {
    payable: number
    paid: number
    outstanding: number
    completedDate: string | null
    finalPayment: any | null
  }
  status: string
}

const inr0 = (v: any) => {
  const n = Number(v) || 0
  try {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)
  } catch {
    return `Rs. ${n.toLocaleString('en-IN')}`
  }
}

const fmtD = (iso: any) => {
  if (!iso) return '—'
  try {
    const s = String(iso)
    return new Date(s.length <= 10 ? `${s}T00:00:00` : s).toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
    })
  } catch {
    return '—'
  }
}

export default function KanakuDetailContent({ code }: { code: string }) {
  const router = useRouter()
  const toggleSidebar = useSidebarStore((s) => s.toggleSidebar)
  const [rows, setRows] = useState<KanakuRow[] | null>(null)
  const [failed, setFailed] = useState<null | 'denied' | 'error'>(null)
  const mountedRef = useRef(true)

  const load = useCallback(async () => {
    setFailed(null)
    try {
      const res = await fetch(`/api/customer/kanaku/${encodeURIComponent(code)}`, { credentials: 'include' })
      if (res.status === 401) {
        router.replace('/login')
        return
      }
      if (res.status === 403 || res.status === 404) {
        if (mountedRef.current) setFailed('denied')
        return
      }
      if (!res.ok) throw new Error(`Request failed (${res.status})`)
      const json = await res.json().catch(() => null)
      if (mountedRef.current) setRows(Array.isArray(json?.rows) ? json.rows : [])
    } catch {
      if (mountedRef.current) setFailed('error')
    }
  }, [code, router])

  useEffect(() => {
    mountedRef.current = true
    load()
    return () => {
      mountedRef.current = false
    }
  }, [load])

  const name = rows?.[0]?.customer?.full_name ? `${rows[0].customer.full_name} · ` : ''

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-[1100px] mx-auto space-y-5">
        <div className="flex items-center gap-3">
          <button
            onClick={toggleSidebar}
            aria-label="Open menu"
            className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors active:scale-95 shadow-sm flex-shrink-0"
          >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round">
              <path d="M3 5h14" />
              <path d="M3 10h14" />
              <path d="M3 15h14" />
            </svg>
          </button>
          <button
            onClick={() => router.push('/dashboard/my-account')}
            aria-label="Back to My Account"
            className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors active:scale-95 shadow-sm flex-shrink-0"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
            <Landmark className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">Kanaku {rows?.[0]?.kanaku_no ?? code} Details</h1>
            <p className="text-xs sm:text-sm text-slate-500">{name}Loan account history</p>
          </div>
        </div>

        {rows === null && !failed && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 space-y-2.5" aria-label="Loading">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-12 rounded-xl bg-slate-100 animate-pulse" />
            ))}
          </div>
        )}

        {failed === 'denied' && (
          <div className="bg-white rounded-2xl border border-red-200 shadow-sm p-8 text-center">
            <p className="text-sm font-bold text-slate-900">You are not authorized to view this kanaku.</p>
            <button onClick={() => router.replace('/dashboard/my-account')} className="mt-4 px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222]">
              Back to My Account
            </button>
          </div>
        )}

        {failed === 'error' && (
          <div className="bg-white rounded-2xl border border-red-200 shadow-sm p-8 text-center">
            <p className="text-sm font-bold text-slate-900">Unable to load this kanaku. Please try again.</p>
            <button onClick={load} className="mt-4 px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222]">
              Try Again
            </button>
          </div>
        )}

        {rows !== null && !failed && rows.length === 0 && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 text-center">
            <p className="text-sm text-slate-500">No records found for this kanaku.</p>
          </div>
        )}

        {rows !== null &&
          !failed &&
          rows.map((row) => (
            <div key={row.id} className="space-y-5">
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-100 flex flex-wrap items-center gap-2">
                  <p className="text-sm font-bold text-slate-900">
                    {row.customer?.full_name || ''} · Kanaku {row.kanaku_no}
                  </p>
                  <span className={cn(
                    'ml-auto inline-flex items-center px-2.5 py-1 rounded-lg text-[11px] font-bold border',
                    row.status === 'Active'
                      ? 'bg-[var(--primary-soft)] text-[var(--primary)] border-[#E8CFCF]'
                      : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                  )}>
                    {row.status === 'Completed' ? 'Status: Completed' : row.status === 'FULLY PAID' ? 'FULLY PAID' : 'Status: Active'}
                  </span>
                </div>
                <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1">
                  {row.loans.length === 0 && (
                    <p className="text-xs text-slate-500 sm:col-span-2">No loans in this kanaku yet.</p>
                  )}
                  {row.loans.map((l: any) => (
                    <div key={l.loan_id} className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1 rounded-xl bg-slate-50/60 border border-slate-100 p-3 mb-2">
                      {(
                        [
                          ['Loan Amount', inr0(l.loan_amount)],
                          ['Interest Rate', `${Number.isInteger(Number(l.interest_rate)) ? Number(l.interest_rate) : Number(l.interest_rate).toString()}%`],
                          ['Interest Amount', inr0(l.interest_amount)],
                          ['Total Payable', inr0(l.total_amount)],
                          ['Loan Date', fmtD(l.loan_date)],
                          ['Due Date', fmtD(l.due_date)],
                          ['Installment Amount', `${inr0(l.installment_amount || l.installment)}${l.loan_type ? ` · ${l.loan_type}` : ''}`],
                          ['Status', l.status || 'Active'],
                        ] as Array<[string, string]>
                      ).map(([k, v]) => (
                        <div key={k} className="flex justify-between gap-4 py-1 border-b border-slate-100 last:border-0">
                          <span className="text-xs text-slate-500">{k}</span>
                          <span className="text-xs font-semibold text-slate-900 text-right">{v}</span>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-100">
                  <p className="text-sm font-bold text-slate-900">Payment History</p>
                </div>
                {row.payments.length === 0 ? (
                  <p className="px-4 py-8 text-center text-sm text-slate-500">No payments recorded yet.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm min-w-[560px]">
                      <thead>
                        <tr className="bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)] text-left">
                          {['Date', 'Amount', 'Balance', 'Mode'].map((h) => (
                            <th key={h} className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-[#F3DFA7] whitespace-nowrap">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {row.payments.map((pmt: any) => (
                          <tr key={pmt.payment_id} className="hover:bg-slate-50">
                            <td className="px-4 py-2.5 text-xs text-slate-600 tabular-nums whitespace-nowrap">{fmtD(pmt.payment_date)}</td>
                            <td className="px-4 py-2.5 text-xs font-bold text-slate-900 tabular-nums whitespace-nowrap">{inr0(pmt.amount)}</td>
                            <td className="px-4 py-2.5 text-xs tabular-nums font-semibold text-[var(--primary)] whitespace-nowrap">{inr0(pmt.balanceAfter)}</td>
                            <td className="px-4 py-2.5 text-xs text-slate-600 whitespace-nowrap">{pmt.mode || 'Cash'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
                <div className="px-4 py-3 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <span className="text-slate-500">Loan Status: <b className="text-slate-900">{row.status === 'Completed' ? 'COMPLETED' : row.status}</b></span>
                  <span className="text-slate-500">Outstanding: <b className="text-[var(--primary)] tabular-nums">{inr0(row.totals.outstanding)}</b></span>
                  <span className="text-slate-500">Total Paid: <b className="text-slate-900 tabular-nums">{inr0(row.totals.paid)}</b></span>
                  <span className="text-slate-500">Completed Date: <b className="text-slate-900 tabular-nums">{row.totals.completedDate ? fmtD(row.totals.completedDate) : '—'}</b></span>
                </div>
              </div>
            </div>
          ))}
      </div>
    </div>
  )
}
