'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { BarChart3 } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import WidgetCard from './WidgetCard'
import { useCustomerStore } from '@/store/customer-store'
import { formatINR } from '@/lib/dashboard-utils'

const STATUS_COLORS: { key: string; label: string; color: string }[] = [
  { key: 'paid', label: 'Paid', color: '#10B981' },
  { key: 'pending', label: 'Pending', color: '#EAB308' },
  { key: 'overdue', label: 'Overdue', color: '#EF4444' },
  { key: 'partial', label: 'Partial', color: '#8B5CF6' },
]

function dayStr(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

function isDueOn(c: { loanType?: string; loanDate?: string }, date: Date): boolean {
  const start = new Date(c.loanDate + 'T00:00:00')
  if (isNaN(start.getTime())) return false
  switch (c.loanType) {
    case 'Weekly':
      return start.getDay() === date.getDay()
    case 'Monthly':
      return start.getDate() === date.getDate()
    case 'Daily':
    default:
      return true
  }
}

interface DayPoint {
  label: string
  paid: number
  pending: number
  overdue: number
  partial: number
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  const total = payload.reduce((s: number, p: any) => s + (Number(p.value) || 0), 0)
  return (
    <motion.div
      initial={{ opacity: 0, y: 6, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
      className="bg-white/90 backdrop-blur-xl rounded-2xl border border-slate-100 shadow-[0_8px_32px_rgba(0,0,0,0.12)] px-4 py-3 min-w-[180px]"
    >
      <p className="text-[13px] font-semibold text-[var(--text-primary)] mb-2.5 pb-2 border-b border-slate-100">{label}</p>
      <div className="space-y-2">
        {STATUS_COLORS.map((item) => {
          const entry = payload.find((p: any) => p.dataKey === item.key)
          const val = Number(entry?.value) || 0
          if (val === 0) return null
          return (
            <div key={item.key} className="flex items-center justify-between gap-5">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-xs text-slate-600">{item.label}</span>
              </div>
              <span className="text-xs font-semibold text-slate-900">{formatINR(Math.round(val))}</span>
            </div>
          )
        })}
        <div className="flex items-center justify-between gap-5 pt-2 border-t border-slate-100">
          <span className="text-xs font-semibold text-slate-500">Total</span>
          <span className="text-xs font-bold text-[var(--primary)]">{formatINR(Math.round(total))}</span>
        </div>
      </div>
    </motion.div>
  )
}

function RoundedTopBar(props: any) {
  const { fill, x, y, width, height, radius = 6 } = props
  if (height <= 0) return null
  return <rect x={x} y={y} width={width} height={height} rx={radius} ry={radius} fill={fill} />
}

export default function PaymentStatusChart() {
  const customers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const [activeBar, setActiveBar] = useState<string | null>(null)

  const data = useMemo<DayPoint[]>(() => {
    const today = new Date()
    const todayStart = new Date(today)
    todayStart.setHours(0, 0, 0, 0)

    const active = customers.filter((c) => c.status === 'Active' || c.status === 'Overdue')

    const days: DayPoint[] = []
    for (let i = 6; i >= 0; i--) {
      const d = new Date(today)
      d.setDate(d.getDate() - i)
      const ds = dayStr(d)
      const label = d.toLocaleDateString('en-IN', { weekday: 'short' })

      const dayPayments = paymentHistory.filter((p) => (p.paymentDate || '').startsWith(ds))
      const perCustomer: Record<string, number> = {}
      for (const p of dayPayments) {
        perCustomer[p.customerId] = (perCustomer[p.customerId] || 0) + (p.paymentAmount || 0)
      }

      let paid = 0
      let pending = 0
      let overdue = 0
      let partial = 0

      for (const c of active) {
        if (!isDueOn(c, d)) continue
        const dueAmt = Number(c.installmentAmount) || 0
        if (dueAmt <= 0) continue
        const got = perCustomer[c.id] || 0
        if (got >= dueAmt) {
          paid += got
        } else if (got > 0) {
          partial += got
          pending += dueAmt - got
        } else if (d.getTime() < todayStart.getTime()) {
          overdue += dueAmt
        } else {
          pending += dueAmt
        }
      }

      days.push({ label, paid, pending, overdue, partial })
    }
    return days
  }, [customers, paymentHistory])

  return (
    <WidgetCard
      icon={BarChart3}
      title="Payment Status"
      subtitle="Last 7 days"
      action={
        <div className="flex items-center gap-2">
          {STATUS_COLORS.map((item) => (
            <span
              key={item.key}
              className="w-2.5 h-2.5 rounded-full transition-transform duration-200 hover:scale-125"
              style={{ backgroundColor: item.color }}
            />
          ))}
        </div>
      }
    >
      <div className="h-[240px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 10, right: 4, left: -18, bottom: 0 }} barCategoryGap={20} stackOffset="none">
            <defs>
              {STATUS_COLORS.map((item) => (
                <linearGradient key={item.key} id={`payGrad-${item.key}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={item.color} stopOpacity={0.95} />
                  <stop offset="100%" stopColor={item.color} stopOpacity={0.6} />
                </linearGradient>
              ))}
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
            <XAxis
              dataKey="label"
              tick={{ fontSize: 11, fill: '#94A3B8' }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 11, fill: '#94A3B8' }}
              axisLine={false}
              tickLine={false}
              tickFormatter={(v: number) => `${Math.round(v / 1000)}k`}
            />
            <Tooltip
              content={<CustomTooltip />}
              cursor={{ fill: 'rgba(148, 163, 184, 0.08)' }}
            />
            <Bar
              dataKey="paid"
              name="Paid"
              stackId="status"
              fill="url(#payGrad-paid)"
              radius={activeBar === 'paid' ? [7, 7, 0, 0] : 4}
              animationDuration={1000}
              animationEasing="ease-out"
              onMouseEnter={() => setActiveBar('paid')}
              onMouseLeave={() => setActiveBar(null)}
            />
            <Bar
              dataKey="pending"
              name="Pending"
              stackId="status"
              fill="url(#payGrad-pending)"
              radius={4}
              animationDuration={1000}
              animationEasing="ease-out"
              animationBegin={150}
              onMouseEnter={() => setActiveBar('pending')}
              onMouseLeave={() => setActiveBar(null)}
            />
            <Bar
              dataKey="overdue"
              name="Overdue"
              stackId="status"
              fill="url(#payGrad-overdue)"
              radius={4}
              animationDuration={1000}
              animationEasing="ease-out"
              animationBegin={300}
              onMouseEnter={() => setActiveBar('overdue')}
              onMouseLeave={() => setActiveBar(null)}
            />
            <Bar
              dataKey="partial"
              name="Partial"
              stackId="status"
              fill="url(#payGrad-partial)"
              radius={[7, 7, 0, 0]}
              shape={<RoundedTopBar />}
              animationDuration={1000}
              animationEasing="ease-out"
              animationBegin={450}
              onMouseEnter={() => setActiveBar('partial')}
              onMouseLeave={() => setActiveBar(null)}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-100">
        {STATUS_COLORS.map((item) => (
          <div key={item.key} className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
            <span className="text-[11px] font-medium text-slate-500">{item.label}</span>
          </div>
        ))}
      </div>
    </WidgetCard>
  )
}
