'use client'

import { motion, AnimatePresence, useReducedMotion } from 'framer-motion'
import { MicOff, Loader2 } from 'lucide-react'
import { useVoiceInput } from '@/hooks/use-voice-input'
import { cn } from '@/lib/utils'
import { useEffect, useRef, useState } from 'react'
import { parseSpokenPhone, spokenPhoneDigits, phoneVoiceError } from '@/lib/voice-phone'

const IDLE_SHADOW = '0 3px 8px rgba(127,29,29,0.08), inset 0 1px 0 rgba(255,255,255,0.9)'
const HOVER_SHADOW = '0 5px 14px rgba(127,29,29,0.18), inset 0 1px 0 rgba(255,255,255,0.9)'
const LISTEN_GLOW = '0 4px 14px rgba(127,29,29,0.25), inset 0 1px 0 rgba(255,255,255,0.2)'

function VoiceGlyph() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false">
      <rect x="9" y="3" width="6" height="11" rx="3" fill="currentColor" fillOpacity="0.12" stroke="currentColor" strokeWidth="1.7" />
      <path d="M6.5 10.5v.5a5.5 5.5 0 0 0 11 0v-.5M12 16.5V21M9 21h6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
      <path d="M3 8.5v4M21 8.5v4" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" opacity="0.45" />
      <path d="M11 6h2M11 8.5h2" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  )
}

function WaveformBars({ reducedMotion }: { reducedMotion: boolean }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center gap-[2.5px]">
      {[0, 1, 2, 3, 4].map((i) => (
        <motion.span
          key={i}
          className="w-[2.5px] rounded-full bg-white"
          aria-hidden="true"
          animate={reducedMotion ? { height: [8, 14, 20, 14, 8][i], opacity: 1 } : {
            height: [6, 14, 6, 18, 8, 6],
            opacity: [0.7, 1, 0.7, 0.9, 0.6, 0.7],
          }}
          transition={{
            duration: 0.8,
            repeat: Infinity,
            delay: i * 0.12,
            ease: 'easeInOut',
          }}
        />
      ))}
    </div>
  )
}

function PulseRing() {
  return (
    <motion.span
      initial={{ scale: 0.9, opacity: 0.5 }}
      animate={{ scale: 1.5, opacity: 0 }}
      exit={{ scale: 0.9, opacity: 0 }}
      transition={{ duration: 1.2, repeat: Infinity, ease: 'easeOut' }}
      aria-hidden="true"
      className="absolute inset-0 rounded-2xl border border-[var(--primary)]/20 pointer-events-none"
    />
  )
}

interface VoiceMicButtonProps {
  value: string
  onPreview: (text: string) => void
  inputType?: 'text' | 'phone' | 'search'
  phrases?: string[]
  onResult: (text: string) => void
  /** BCP-47 language tag. Defaults to `en-IN`. */
  lang?: string
  className?: string
}

export default function VoiceMicButton({ onResult, onPreview, value, inputType = 'text', lang, className, phrases }: VoiceMicButtonProps) {
  const reducedMotion = !!useReducedMotion()
  const original = useRef(value)
  const latest = useRef(value)
  latest.current = value
  const preview = useRef<string | null>(null)
  const committed = useRef(false)
  const active = useRef(false)
  const [validationError, setValidationError] = useState<string | null>(null)
  const restore = () => {
    // Preserve keyboard edits made after a voice preview.
    if (preview.current !== null && latest.current === preview.current) onPreview(original.current)
    preview.current = null
  }
  const { status, toggle, isSupported, error: recognitionError, interimTranscript, feedback } = useVoiceInput(text => {
    const final = inputType === 'phone' ? parseSpokenPhone(text) : text
    if (final === null) { restore(); setValidationError(phoneVoiceError(text)); return }
    committed.current = true
    onResult(final)
  }, { lang, phrases, onInterim: text => {
    const next = inputType === 'phone' ? spokenPhoneDigits(text) : text
    if (next !== null) { preview.current = next; latest.current = next; onPreview(next) }
  } })
  useEffect(() => {
    if (status === 'idle' && active.current) {
      if (!committed.current) restore()
      active.current = false
    }
  }, [status])
  const beginOrStop = () => {
    if (status === 'idle') {
      original.current = value; preview.current = null; committed.current = false; active.current = true
      setValidationError(null)
    }
    toggle()
  }
  const error = recognitionError || validationError
  const isListening = status === 'listening'
  const isProcessing = status === 'processing'
  const isRequesting = status === 'requesting'
  const isIdle = status === 'idle'

  // Fallback: never render nothing — a disabled button with a clear reason
  // beats a mic that appears to do nothing on unsupported browsers.
  if (!isSupported) {
    return (
      <div className={cn('relative flex items-center', className)}>
        <button
          type="button"
          disabled
          aria-disabled="true"
          aria-label="Voice commands are not supported in this app"
          title="Voice input is unavailable in this app."
          className="relative z-10 flex h-10 w-10 shrink-0 cursor-not-allowed items-center justify-center rounded-2xl border border-slate-200 bg-slate-100 opacity-50 outline-none"
        >
          <MicOff className="h-[16px] w-[16px] text-slate-400" />
        </button>
      </div>
    )
  }

  const tooltipText = error
    ? error
    : status === 'idle'
      ? 'Start Voice Input'
      : status === 'listening'
        ? 'Listening... Click again to stop'
        : status === 'requesting'
          ? 'Requesting microphone access... Click again to cancel'
          : 'Processing...'

  return (
    <div className={cn('relative flex items-center', className)}>
      <AnimatePresence>
        {isListening && !reducedMotion && <PulseRing />}
      </AnimatePresence>

      {/* Small "Listening..." indicator — screen-reader live region included. */}
      <AnimatePresence>
        {isListening && (
          <motion.span
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 4 }}
            transition={{ duration: 0.15 }}
            className="absolute -top-6 right-0 z-20 flex max-w-56 items-center gap-1.5 rounded-full bg-[var(--primary)] px-2.5 py-1 text-[10px] font-bold text-white shadow-md"
          >
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full motion-safe:animate-ping rounded-full bg-white opacity-75" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-white" />
            </span>
            <span data-voice-live className="truncate">{interimTranscript || 'Speak now…'}</span>
          </motion.span>
        )}
      </AnimatePresence>
      <span aria-live="polite" className="sr-only">
        {isListening ? 'Listening for voice input' : isRequesting ? 'Requesting microphone access' : ''}
      </span>

      <motion.button
        type="button"
        aria-label={tooltipText}
        aria-pressed={isListening}
        aria-busy={isProcessing || isRequesting}
        title={tooltipText}
        onClick={beginOrStop}
        disabled={isProcessing}
        className={cn('relative z-10 flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-2xl border outline-none transition-shadow duration-200 focus-visible:ring-2 focus-visible:ring-[var(--primary)]/50 focus-visible:ring-offset-2 disabled:cursor-wait', isListening ? 'border-[var(--primary)]/40 bg-gradient-to-br from-[#B44646] via-[#902828] to-[#681919] text-white' : 'border-[var(--primary)]/15 bg-gradient-to-br from-white via-rose-50 to-[#F4DEDE] text-[var(--primary)]')}
        animate={
          isListening
            ? {
                boxShadow: LISTEN_GLOW,
                scale: 1,
              }
            : {
                boxShadow: IDLE_SHADOW,
                scale: 1,
              }
        }
        whileHover={
          isIdle && !reducedMotion
            ? { scale: 1.05, y: -1, boxShadow: HOVER_SHADOW }
            : {}
        }
        whileTap={reducedMotion ? {} : { scale: 0.95, y: 0 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
      >
        <AnimatePresence mode="wait">
          {isProcessing || isRequesting ? (
            <motion.span
              key="spinner"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.5 }}
              transition={{ duration: 0.15 }}
            >
              <Loader2 aria-hidden="true" className="h-5 w-5 motion-safe:animate-spin text-[var(--primary)]" />
            </motion.span>
          ) : isListening ? (
            <motion.span
              key="waveform"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="relative flex h-[18px] w-[18px] items-center justify-center"
            >
              <WaveformBars reducedMotion={reducedMotion} />
            </motion.span>
          ) : (
            <motion.span
              key="mic"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.5 }}
              transition={{ duration: 0.15 }}
            >
              <VoiceGlyph />
            </motion.span>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Error feedback — small, auto-dismissed by the hook after 15s. */}
      {(interimTranscript || (status !== 'idle' && feedback)) && !error && (
        <span role="status" className="absolute right-0 top-[46px] z-50 w-56 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-700 shadow-lg break-words">
          {interimTranscript || feedback}
        </span>
      )}
      <AnimatePresence>
        {error && (
          <motion.span
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.15 }}
            role="alert"
            className="absolute left-1/2 top-[46px] z-50 w-max max-w-[220px] -translate-x-1/2 whitespace-normal rounded-xl border border-red-200 bg-red-50 px-2.5 py-1.5 text-center text-[11px] font-medium leading-tight text-red-700 shadow-lg"
          >
            {error}
          </motion.span>
        )}
      </AnimatePresence>
    </div>
  )
}
