'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { BadgeIndianRupee, CalendarDays, Landmark, UserRound, WalletCards } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useSidebarStore } from '@/store/sidebar-store'
import { useAuthActions } from '@/hooks/use-auth'

interface LoanRow {
  loan_id: string
  customer_code?: string | null
  loan_date: string | null
  due_date: string | null
  loan_amount: number
  interest_rate: number
  interest_amount: number
  total_amount: number
  installment: number
  installment_amount: number
  balance_amount: number
  received_amount: number
  duration: number
  loan_type: string | null
  status: string | null
  disbursal_mode: string | null
}

interface PaymentRow {
  payment_id: string
  loan_id: string | null
  amount: number
  payment_date: string | null
  payment_time: string | null
  mode: string
  remarks: string | null
}

interface MeData {
  customer: {
    customer_code: string
    full_name: string
    phone_number: string | null
    address: string | null
    city_name: string | null
    area_name: string | null
    business_name: string | null
    status: string | null
  }
  loans: LoanRow[]
  payments: PaymentRow[]
  accounts?: Array<{ id: string; customer_code: string; full_name: string; status: string | null; kanaku_no: number }>
  summary: {
    totalLoans: number
    activeLoans: number
    completedLoans: number
    totalGiven: number
    totalInterest: number
    totalReceivable: number
    totalReceived: number
    totalOutstanding: number
    totalPayments: number
  }
}

const inr0 = (v: any) => {
  const n = Number(v) || 0
  try {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)
  } catch {
    return `Rs. ${n.toLocaleString('en-IN')}`
  }
}

const fmtD = (iso: string | null) => {
  if (!iso) return '—'
  try {
    return new Date(iso.length <= 10 ? `${iso}T00:00:00` : iso).toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
    })
  } catch {
    return '—'
  }
}

export default function MyAccountPage() {
  const router = useRouter()
  const toggleSidebar = useSidebarStore((s) => s.toggleSidebar)
  const { handleLogout } = useAuthActions()
  const [data, setData] = useState<MeData | null>(null)
  const [state, setState] = useState<'loading' | 'ready' | 'denied' | 'failed' | 'link'>('loading')
  const [linkPhone, setLinkPhone] = useState('')
  const [linking, setLinking] = useState(false)
  const [linkError, setLinkError] = useState('')
  const mountedRef = useRef(true)

  const load = useCallback(async () => {
    if (mountedRef.current) setState('loading')
    try {
      const res = await fetch('/api/customer/me', { credentials: 'include' })
      if (res.status === 401) {
        router.replace('/login')
        return
      }
      if (res.status === 403) {
        if (mountedRef.current) setState('denied')
        return
      }
      if (res.status === 404) {
        const body = await res.json().catch(() => null)
        if (mountedRef.current) setState(body?.code === 'not_linked' ? 'link' : 'failed')
        return
      }
      if (!res.ok) throw new Error(`Request failed (${res.status})`)
      const json = (await res.json().catch(() => null)) as MeData | null
      if (!json?.customer) throw new Error('Invalid response')
      if (mountedRef.current) {
        setData(json)
        setState('ready')
      }
    } catch {
      if (mountedRef.current) setState('failed')
    }
  }, [router])

  const submitLink = async () => {
    const digits = linkPhone.replace(/\D/g, '')
    if (digits.length < 10) {
      setLinkError('Enter your registered 10-digit mobile number.')
      return
    }
    setLinking(true)
    setLinkError('')
    try {
      const res = await fetch('/api/customer/link', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: digits }),
      })
      const body = await res.json().catch(() => null)
      if (!res.ok) {
        setLinkError(body?.error || 'Could not link your account. Please try again.')
        return
      }
      setLinkPhone('')
      await load()
    } catch {
      setLinkError('Network error. Please try again.')
    } finally {
      if (mountedRef.current) setLinking(false)
    }
  }

  useEffect(() => {
    mountedRef.current = true
    load()
    return () => {
      mountedRef.current = false
    }
  }, [load])

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-[1100px] mx-auto space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              onClick={toggleSidebar}
              aria-label="Open menu"
              className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors active:scale-95 shadow-sm flex-shrink-0"
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round">
                <path d="M3 5h14" />
                <path d="M3 10h14" />
                <path d="M3 15h14" />
              </svg>
            </button>
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
              <UserRound className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                {data ? `Welcome, ${data.customer.full_name}` : 'My Account'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-500">Your loans, payments, and balance</p>
            </div>
          </div>
          <button
            onClick={() => handleLogout()}
            className="px-4 py-2 rounded-xl text-xs font-semibold border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
          >
            Logout
          </button>
        </div>

        {state === 'loading' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 space-y-2.5" aria-label="Loading">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-12 rounded-xl bg-slate-100 animate-pulse" />
            ))}
          </div>
        )}

        {state === 'link' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 max-w-[480px] mx-auto">
            <h2 className="text-base font-bold text-slate-900 text-center">Customer Mobile Number</h2>
            <p className="text-xs text-slate-500 text-center mt-1 mb-5">
              Enter the mobile number registered with your customer account.
            </p>
            {linkError && (
              <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200">
                <p className="text-[13px] text-red-700">{linkError}</p>
              </div>
            )}
            <label className="block text-xs font-medium text-slate-500 mb-1.5">Mobile number</label>
            <div className="flex items-center rounded-xl border border-slate-300 bg-white overflow-hidden focus-within:border-[var(--primary)]/40">
              <span className="pl-4 pr-1 text-sm font-semibold text-slate-900">+91</span>
              <input
                value={linkPhone}
                onChange={(e) => setLinkPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                inputMode="numeric"
                placeholder="Enter mobile number"
                className="flex-1 px-2 py-3 text-sm outline-none placeholder:text-slate-400"
              />
            </div>
            <button
              onClick={submitLink}
              disabled={linking}
              className="mt-4 w-full h-[48px] rounded-xl bg-[var(--primary)] text-white text-sm font-semibold hover:bg-[#912222] transition-colors disabled:opacity-50"
            >
              {linking ? 'Checking…' : 'Continue'}
            </button>
          </div>
        )}

        {state === 'denied' && (
          <div className="bg-white rounded-2xl border border-red-200 shadow-sm p-8 text-center">
            <p className="text-sm font-bold text-slate-900">You are not authorized to access this page.</p>
            <button onClick={() => router.replace('/login')} className="mt-4 px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222]">
              Go to Login
            </button>
          </div>
        )}

        {state === 'failed' && (
          <div className="bg-white rounded-2xl border border-red-200 shadow-sm p-8 text-center">
            <p className="text-sm font-bold text-slate-900">Unable to load your account. Please try again.</p>
            <button onClick={load} className="mt-4 px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222]">
              Try Again
            </button>
          </div>
        )}

        {state === 'ready' && data && (
          <>
            {/* My Details */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-100 flex items-center gap-2">
                <UserRound className="w-4 h-4 text-[var(--primary)]" />
                <p className="text-sm font-bold text-slate-900">My Details</p>
              </div>
              <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2">
                {(
                  [
                    ['Name', data.customer.full_name],
                    ['Customer ID', data.customer.customer_code],
                    ['Phone', data.customer.phone_number || '—'],
                    ['Status', data.customer.status || 'Active'],
                    ['Business', data.customer.business_name || '—'],
                    ['Area', [data.customer.area_name, data.customer.city_name].filter(Boolean).join(', ') || '—'],
                  ] as Array<[string, string]>
                ).map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-4 py-1.5 border-b border-slate-50 last:border-0">
                    <span className="text-xs text-slate-500">{k}</span>
                    <span className="text-xs font-semibold text-slate-900 text-right">{v}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Summary */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {(
                [
                  ['Total Outstanding', inr0(data.summary.totalOutstanding), WalletCards],
                  ['Total Received', inr0(data.summary.totalReceived), BadgeIndianRupee],
                  ['Active Loans', String(data.summary.activeLoans), Landmark],
                  ['Payments Made', String(data.summary.totalPayments), CalendarDays],
                ] as Array<[string, string, any]>
              ).map(([label, value, Icon]) => (
                <div key={label} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
                  <Icon className="w-5 h-5 text-[var(--primary)]" />
                  <p className="text-lg font-extrabold text-slate-900 tabular-nums mt-2 leading-tight">{value}</p>
                  <p className="text-[11px] font-semibold text-slate-500 mt-0.5">{label}</p>
                </div>
              ))}
            </div>

            {/* Your Kanaku Accounts — each kanaku stays separate */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-100">
                <p className="text-sm font-bold text-slate-900">
                  Your Kanaku Accounts{' '}
                  <span className="text-slate-400 font-semibold">({(data.accounts || []).length})</span>
                </p>
              </div>
              {(data.accounts || []).length === 0 ? (
                <p className="px-4 py-8 text-center text-sm text-slate-500">No kanaku accounts found.</p>
              ) : (
                <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {(data.accounts || []).map((a) => {
                    const rows = data.loans.filter((l) => (l.customer_code || data.customer.customer_code) === a.customer_code)
                    const num = (v: any) => Number(v) || 0
                    const given = rows.reduce((s, l) => s + num(l.loan_amount), 0)
                    const outstanding = rows.reduce((s, l) => s + num(l.balance_amount), 0)
                    const status =
                      rows.length > 0 && rows.every((l) => l.status === 'Completed')
                        ? 'Completed'
                        : rows.length > 0 && given > 0 && outstanding <= 0
                          ? 'FULLY PAID'
                          : rows.length > 0 ? 'Active' : 'No loans'
                    return (
                      <div key={a.id} className="rounded-2xl border border-slate-200 p-4 shadow-sm hover:shadow-md hover:border-[#E8CFCF] transition-all">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-bold text-slate-900">Kanaku {a.kanaku_no}</p>
                          <span className={cn(
                            'ml-auto inline-flex items-center px-2 py-0.5 rounded-lg text-[11px] font-bold border whitespace-nowrap',
                            status === 'Active'
                              ? 'bg-[var(--primary-soft)] text-[var(--primary)] border-[#E8CFCF]'
                              : status === 'No loans'
                                ? 'bg-slate-100 text-slate-500 border-slate-200'
                                : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          )}>
                            {status}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1">
                          {rows.length === 0 ? 'No loans in this kanaku yet.' : `${rows.length} loan${rows.length > 1 ? 's' : ''}`}
                        </p>
                        <p className="text-lg font-extrabold text-slate-900 tabular-nums mt-2 leading-tight">{inr0(given)}</p>
                        <p className="text-[11px] font-semibold text-slate-500">Loan Amount</p>
                        {rows.length > 0 && (
                          <p className="text-[11px] text-slate-500 mt-1">
                            Outstanding: <b className="text-[var(--primary)] tabular-nums">{inr0(outstanding)}</b>
                          </p>
                        )}
                        <button
                          onClick={() => router.push(`/dashboard/my-account/kanaku?code=${encodeURIComponent(a.customer_code)}`)}
                          className="mt-3 w-full px-4 py-2.5 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222] transition-colors"
                        >
                          View
                        </button>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
