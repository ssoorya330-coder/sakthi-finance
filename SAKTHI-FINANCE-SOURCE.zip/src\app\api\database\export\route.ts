import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { compressJsonExport } from '@/server/compressed-export'
import { actorFromAuthUser, requestMeta, recordAuditStandalone } from '@/server/audit'

export const dynamic = 'force-dynamic'

/**
 * Export the caller's OWN application data as a local JSON download.
 * Scoped to the authenticated user — never a global dump.
 */
export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error
  const userId = auth.user.userId

  try {
    const [customers, loans, payments, collections] = await Promise.all([
      dbQuery('SELECT * FROM customers WHERE user_id = $1 ORDER BY created_at ASC', [userId]),
      dbQuery('SELECT * FROM loans WHERE user_id = $1 ORDER BY created_at ASC', [userId]),
      dbQuery('SELECT * FROM payments WHERE user_id = $1 ORDER BY created_at ASC', [userId]),
      dbQuery('SELECT * FROM daily_collection WHERE user_id = $1 ORDER BY collection_date ASC', [userId]),
    ])
    const payload = {
      exportedAt: new Date().toISOString(),
      exportedBy: auth.user.email,
      scope: 'own-records-only',
      customers: customers.rows,
      loans: loans.rows,
      payments: payments.rows,
      dailyCollection: collections.rows,
    }
    const stamp = new Date().toISOString().slice(0, 10)
    {
      const meta = requestMeta(request)
      await recordAuditStandalone({
        action: 'DATA_EXPORTED',
        entityType: 'database',
        entityId: 'sakthi_finance',
        actor: actorFromAuthUser(auth.user),
        ipAddress: meta.ip,
        clientInfo: meta.client,
        result: 'SUCCESS',
        changes: [
          { field: 'customers', label: 'Customers Exported', before: null, after: customers.rows.length },
          { field: 'loans', label: 'Loans Exported', before: null, after: loans.rows.length },
          { field: 'payments', label: 'Payments Exported', before: null, after: payments.rows.length },
        ],
      })
    }
    const archive = await compressJsonExport(payload)
    return new NextResponse(archive as BodyInit, {
      status: 200,
      headers: {
        'Content-Type': 'application/gzip',
        'Content-Disposition': `attachment; filename="sakthi-finance-export-${stamp}.json.gz"`,
        'Cache-Control': 'no-store',
      },
    })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Export failed', details: err.message },
      { status: 500 }
    )
  }
}
