import path from 'path'
import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { getPgServiceInfo, verifyCopiedDataDir } from '@/server/storage'
import { actorFromAuthUser, requestMeta, recordAuditStandalone } from '@/server/audit'
import { execFile } from 'child_process'
import { promisify } from 'util'

const execFileAsync = promisify(execFile);

/**
 * STEP 6 — Point the PostgreSQL Windows service at the NEW data directory.
 * Only rewrites the service's -D flag (physical location). Never touches
 * database contents, tables, or records. Requires elevation; otherwise the
 * UI shows the exact manual command. The copy must verify first.
 */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const destination = (body.destination || '').trim()
    if (!destination) return NextResponse.json({ error: 'Destination is required.' }, { status: 400 })
    if (body.confirmed !== true) {
      return NextResponse.json({ error: 'Configuration change must be explicitly confirmed.' }, { status: 400 })
    }

    // Safety: only re-point at a verified copy. The source/size come from
    // the caller: while PostgreSQL is stopped, SHOW data_directory is
    // unavailable, so they must NOT be re-detected from SQL here.
    const source = (body.source || '').trim() || null
    const sourceBytes =
      typeof body.sourceBytes === 'number' && body.sourceBytes > 0 ? body.sourceBytes : null
    // Rollback restores the original directory while PostgreSQL is stopped:
    // file-presence checks still run, only the size comparison is skipped.
    const skipSizeCheck = body.rollback === true
    const copy = await verifyCopiedDataDir(destination, { source, sourceBytes, skipSizeCheck })
    if (!copy.ok) {
      return NextResponse.json(
        { ok: false, error: 'Destination copy did not verify. Configuration was NOT changed.' },
        { status: 200 }
      )
    }

    const info = await getPgServiceInfo()
    if (!info.name || !info.binaryPath) {
      return NextResponse.json(
        { ok: false, error: 'PostgreSQL service details unavailable. Apply the change manually.', needsManual: true },
        { status: 200 }
      )
    }
    if (info.state !== 'stopped') {
      return NextResponse.json(
        { ok: false, error: 'Stop the PostgreSQL service before changing its data directory.' },
        { status: 200 }
      )
    }

    const normDest = path.win32.normalize(destination).replace(/\\$/, '');
    const newBinPath = info.binaryPath.replace(/-D\s+("[^"]+"|\S+)/, `-D "${normDest}"`);
    if (newBinPath === info.binaryPath) {
      return NextResponse.json(
        { ok: false, error: 'Could not parse the service data-directory flag. Apply the change manually.', needsManual: true },
        { status: 200 }
      )
    }
    // sc.exe config requires a space after `binPath=`.
    const manualCommand = `sc.exe config "${info.name}" binPath= "${newBinPath}"`;
    try {
      const r = await execFileAsync('sc.exe', ['config', info.name, 'binPath=', newBinPath], {
        timeout: 30000,
        windowsHide: true,
        encoding: 'utf8',
      });
      const out = String(r.stdout) + String((r as any).stderr || '');
      if (/Access\s+is\s+denied|FAILED\s+5/i.test(out)) {
        return NextResponse.json(
          { ok: false, error: 'Access denied. Run the manual command in an elevated terminal.', needsManual: true, manualCommand },
          { status: 200 }
        )
      }
      const updated = await getPgServiceInfo()
      const applied = !!updated.binaryPath && updated.binaryPath.includes(normDest)
      if (applied) {
        const meta = requestMeta(request)
        await recordAuditStandalone({
          action: 'DATA_DIRECTORY_CONFIG_CHANGED',
          entityType: 'database',
          entityId: 'sakthi_finance',
          actor: actorFromAuthUser(auth.user),
          ipAddress: meta.ip,
          clientInfo: meta.client,
          source: 'migration-wizard',
          result: 'SUCCESS',
          changes: [{ field: 'data_directory', label: 'Data Directory', before: info.dataDirFromService, after: normDest }],
        })
      }
      return NextResponse.json({
        ok: applied,
        applied,
        needsManual: !applied,
        manualCommand: applied ? null : manualCommand,
        binaryPath: applied ? undefined : updated.binaryPath,
        message: applied ? 'Service now points at the new data directory.' : 'Change may not have applied. Verify manually.',
      })
    } catch (e: any) {
      const msg = String(e?.message || e);
      if (/Access\s+is\s+denied|EPERM|EACCES/i.test(msg)) {
        return NextResponse.json(
          { ok: false, error: 'Access denied. Run the manual command in an elevated terminal.', needsManual: true, manualCommand },
          { status: 200 }
        )
      }
      return NextResponse.json(
        { ok: false, error: `Configuration update failed: ${msg.slice(0, 200)}`, needsManual: true, manualCommand },
        { status: 200 }
      )
    }
  } catch (err: any) {
    return NextResponse.json(
      { ok: false, error: 'Configuration update failed', details: err.message },
      { status: 500 }
    )
  }
}
