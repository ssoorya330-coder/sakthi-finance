import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';
import { dbQuery } from '@/server/database';

/**
 * Supabase Auth OAuth callback (Google → Supabase → here).
 * Exchanges the code for a Supabase session, then ensures a matching row in
 * LOCAL PostgreSQL `users` (linked via supabase_user_id) so account isolation
 * and roles keep working exactly as with direct Google login.
 * Application data is never read from Supabase.
 */
export async function GET(request: NextRequest) {
  const url = new URL(request.url);
  const code = url.searchParams.get('code');
  const next = url.searchParams.get('next') || '/dashboard';

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!supabaseUrl || !anonKey) {
    return NextResponse.redirect(new URL('/login?error=supabase_not_configured', request.url));
  }
  if (!code) {
    return NextResponse.redirect(new URL('/login?error=auth_error', request.url));
  }

  // Use a response we can attach cookies to.
  const redirect = NextResponse.redirect(new URL(next, request.url));
  const supabase = createServerClient(supabaseUrl, anonKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value, options }) => {
          redirect.cookies.set(name, value, options);
        });
      },
    },
  });

  const { data, error } = await supabase.auth.exchangeCodeForSession(code);
  if (error || !data.user) {
    return NextResponse.redirect(new URL('/login?error=auth_error', request.url));
  }

  // Link / provision the local user row (any verified Google account allowed).
  try {
    const supabaseId = data.user.id;
    const email = (data.user.email || '').trim();
    const name =
      (data.user.user_metadata?.full_name as string) ||
      (data.user.user_metadata?.name as string) ||
      (email ? email.split('@')[0] : '');
    const picture = (data.user.user_metadata?.avatar_url as string) || null;
    if (email) {
      const roleRow = await dbQuery<{ role_id: number }>(
        'SELECT role_id FROM roles WHERE role_name = $1',
        ['owner']
      );
      const roleId = roleRow.rows[0]?.role_id ?? null;
      const userId = `user-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      await dbQuery(
        `INSERT INTO users (user_id, supabase_user_id, email, google_email, full_name, role, role_id, is_active, avatar_url, provider)
         VALUES ($1, $2, $3, $3, $4, 'owner', $5, true, $6, 'supabase')
         ON CONFLICT (email) DO UPDATE SET supabase_user_id = COALESCE(users.supabase_user_id, EXCLUDED.supabase_user_id)`,
        [userId, supabaseId, email, name || email.split('@')[0], roleId, picture]
      ).catch(() => {});
      await dbQuery(
        `UPDATE users SET supabase_user_id = COALESCE(supabase_user_id, $1) WHERE supabase_user_id IS NULL AND LOWER(TRIM(email)) = LOWER(TRIM($2))`,
        [supabaseId, email]
      ).catch(() => {});
    }
  } catch {
    // Auth already succeeded; local linking is best-effort and retried on
    // the next API call via getFullUserFromToken fallback.
  }

  return redirect;
}
