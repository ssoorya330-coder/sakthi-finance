'use client'

import { downloadExcel } from '@/lib/download-excel'
import { formatCustomerCode } from '@/utils/customer-id'

import { useState, useMemo, useCallback, memo, Suspense } from 'react'
import { motion } from 'framer-motion'
import {
  BadgeCheck,
  Search,
  IndianRupee,
  Clock,
  TrendingUp,
  Eye,
  FileText,
  FileSpreadsheet,
  Printer,
  Filter,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react'
import { useCustomerStore } from '@/store/customer-store'
import { useSidebarStore } from '@/store/sidebar-store'
import { formatCurrency, formatDateDMY } from '@/features/dashboard/dashboard.styles'
import PaymentHistoryDrawer from '@/components/dashboard/PaymentHistoryDrawer'
import Link from 'next/link'
import type { Customer, PaymentRecord } from '@/types/customer.types'

const ITEMS_PER_PAGE = 15

function ExportButton({ icon: Icon, label, onClick }: { icon: React.FC<{ className?: string }>; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[var(--primary)]/30 bg-white text-sm font-medium text-[var(--primary)] hover:bg-[var(--primary-soft)] hover:border-[var(--primary)]/40 transition-colors active:scale-[0.97]"
    >
      <Icon className="w-4 h-4" />
      {label}
    </button>
  )
}

const SORT_OPTIONS = [
  { value: 'name-asc', label: 'Name A-Z' },
  { value: 'name-desc', label: 'Name Z-A' },
  { value: 'loan-asc', label: 'Loan: Low to High' },
  { value: 'loan-desc', label: 'Loan: High to Low' },
  { value: 'date-asc', label: 'Completion: Oldest' },
  { value: 'date-desc', label: 'Completion: Newest' },
  { value: 'duration-asc', label: 'Duration: Shortest' },
  { value: 'duration-desc', label: 'Duration: Longest' },
]

function CompletedContent() {
  const customers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const getDisplayId = useCustomerStore((s) => s.getDisplayId)
  const { toggleSidebar } = useSidebarStore()
  const [search, setSearch] = useState('')
  const [sortBy, setSortBy] = useState('date-desc')
  const [areaFilter, setAreaFilter] = useState('All')
  const [currentPage, setCurrentPage] = useState(1)
  const [viewingCustomer, setViewingCustomer] = useState<Customer | null>(null)

  const completed = useMemo(() =>
    customers.filter((c) => c.status === 'Completed'),
  [customers])

  const areas = useMemo(() => {
    const unique = [...new Set(completed.map((c) => c.area).filter(Boolean))]
    return ['All', ...unique.sort()]
  }, [completed])

  const filtered = useMemo(() => {
    let result = completed.filter((c) => {
      const q = search.toLowerCase()
      return (
        c.fullName.toLowerCase().includes(q) ||
        c.mobileNumber.includes(q) ||
        c.id.includes(q) ||
        (c.area && c.area.toLowerCase().includes(q))
      )
    })
    if (areaFilter !== 'All') {
      result = result.filter((c) => c.area === areaFilter)
    }
    const [field, dir] = sortBy.split('-') as [string, string]
    const mult = dir === 'asc' ? 1 : -1
    result.sort((a, b) => {
      switch (field) {
        case 'name': return mult * a.fullName.localeCompare(b.fullName)
        case 'loan': return mult * (Number(a.loanAmount) - Number(b.loanAmount))
        case 'date': return mult * ((a.completedAt || '').localeCompare(b.completedAt || ''))
        case 'duration': {
          const dA = a.completedAt && a.loanDate ? (new Date(a.completedAt).getTime() - new Date(a.loanDate).getTime()) : 0
          const dB = b.completedAt && b.loanDate ? (new Date(b.completedAt).getTime() - new Date(b.loanDate).getTime()) : 0
          return mult * (dA - dB)
        }
        default: return 0
      }
    })
    return result
  }, [completed, search, sortBy, areaFilter])

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE)
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE
    return filtered.slice(start, start + ITEMS_PER_PAGE)
  }, [filtered, currentPage])

  const stats = useMemo(() => {
    const totalCompleted = completed.length
    const totalRecovered = completed.reduce((sum, c) => {
      const payments = paymentHistory.filter((p) => p.customerId === c.id)
      return sum + payments.reduce((s, p) => s + p.paymentAmount, c.offlinePaidAmount||0)
    }, 0)
    const totalInterest = completed.reduce((sum, c) => sum + (Number(c.interestAmount) || 0), 0)
    const durations = completed
      .filter((c) => c.completedAt && c.loanDate)
      .map((c) => {
        const start = new Date(c.loanDate || '').getTime()
        const end = new Date(c.completedAt!).getTime()
        return Math.ceil((end - start) / (1000 * 60 * 60 * 24))
      })
    const avgDuration = durations.length > 0 ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length) : 0
    return { totalCompleted, totalRecovered, totalInterest, avgDuration }
  }, [completed, paymentHistory])

  const getPaidAmount = useCallback((customerId: string) => {
    return paymentHistory
      .filter((p) => p.customerId === customerId)
      .reduce((sum, p) => sum + p.paymentAmount, 0)
  }, [paymentHistory])

  const getDuration = useCallback((c: Customer) => {
    if (!c.completedAt || !c.loanDate) return '—'
    const start = new Date(c.loanDate).getTime()
    const end = new Date(c.completedAt).getTime()
    const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24))
    if (days < 30) return `${days}d`
    const months = Math.floor(days / 30)
    const remDays = days % 30
    return remDays > 0 ? `${months}m ${remDays}d` : `${months}m`
  }, [])

  const handleExportCSV = useCallback(() => {
    const headers = ['Customer Code', 'Customer Name', 'Mobile', 'Area', 'Loan Amount', 'Total Paid', 'Interest Earned', 'Loan Date', 'Completion Date', 'Duration']
    const rows = filtered.map((c) => [
      c.id, c.fullName, c.mobileNumber, c.area || '',
      Number(c.loanAmount) || 0, getPaidAmount(c.id), c.interestAmount,
      formatDateDMY(c.loanDate || ''), formatDateDMY(c.completedAt || ''), getDuration(c),
    ])
    const csv = [headers.join(','), ...rows.map((r) => r.map((v) => `"${v}"`).join(','))].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'completed-customers.csv'; a.click()
    URL.revokeObjectURL(url)
  }, [filtered, getPaidAmount, getDuration])

  const handleExportExcel = useCallback(() => {
    const headers = ['Customer Code', 'Customer Name', 'Mobile', 'Area', 'Loan Amount', 'Total Paid', 'Interest Earned', 'Loan Date', 'Completion Date', 'Duration']
    const rows = filtered.map((c) => [
      formatCustomerCode(c.customerCode), c.fullName, c.mobileNumber, c.area || '',
      Number(c.loanAmount) || 0, getPaidAmount(c.id), c.interestAmount,
      formatDateDMY(c.loanDate || ''), formatDateDMY(c.completedAt || ''), getDuration(c),
    ])
    void downloadExcel('completed-customers.xlsx', 'Sakthi Finance - Completed Customers', headers, rows)
  }, [filtered, getPaidAmount, getDuration])

  const handlePrint = useCallback(() => { window.print() }, [])

  return (
    <div className="h-screen bg-[var(--background)] flex flex-col overflow-hidden">
      {/* Header */}
      <div className="bg-white border-b border-[rgba(212,175,55,0.15)] px-8 py-4 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={toggleSidebar}
              className="w-10 h-10 rounded-xl border border-transparent flex items-center justify-center hover:bg-[var(--primary-soft)] hover:border-[var(--primary)]/20 transition-colors flex-shrink-0 active:scale-95"
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round">
                <path d="M3 5h14" /><path d="M3 10h14" /><path d="M3 15h14" />
              </svg>
            </button>
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
                <BadgeCheck className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Completed Customers</h1>
                <p className="text-sm text-slate-500 mt-0.5">{filtered.length} customer{filtered.length !== 1 ? 's' : ''}</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <ExportButton icon={FileText} label="CSV" onClick={handleExportCSV} />
            <ExportButton icon={FileSpreadsheet} label="Excel" onClick={handleExportExcel} />
            <ExportButton icon={Printer} label="Print" onClick={handlePrint} />
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="px-8 pt-5 pb-3 flex-shrink-0">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: 'Completed Customers', value: stats.totalCompleted, icon: BadgeCheck, color: 'from-[var(--primary)] to-[var(--primary-hover)]' },
            { label: 'Amount Recovered', value: formatCurrency(stats.totalRecovered), icon: IndianRupee, color: 'from-[var(--secondary)] to-[#B8943A]' },
            { label: 'Interest Earned', value: formatCurrency(stats.totalInterest), icon: TrendingUp, color: 'from-[var(--secondary)] to-[#B8943A]' },
            { label: 'Avg Loan Duration', value: stats.avgDuration > 0 ? `${stats.avgDuration}d` : '—', icon: Clock, color: 'from-[var(--primary)] to-[var(--primary-hover)]' },
          ].map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.06 }}
              className="bg-white rounded-[18px] border border-[rgba(212,175,55,0.2)] p-4 shadow-[0_1px_2px_rgba(0,0,0,0.04)]"
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}>
                  <stat.icon className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">{stat.label}</p>
                  <p className="text-xl font-bold text-slate-900">{stat.value}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Search & Filters */}
      <div className="px-8 pb-3 flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by name, phone, ID, or area..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setCurrentPage(1) }}
              className="w-full h-12 pl-12 pr-4 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 placeholder:text-slate-400 outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/10 transition-all"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
            <select
              value={areaFilter}
              onChange={(e) => { setAreaFilter(e.target.value); setCurrentPage(1) }}
              className="h-12 pl-10 pr-10 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/10 transition-all appearance-none cursor-pointer min-w-[160px]"
            >
              {areas.map((a) => (
                <option key={a} value={a}>{a === 'All' ? 'All Areas' : a}</option>
              ))}
            </select>
          </div>
          <div className="relative">
            <ArrowUpDown className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="h-12 pl-10 pr-10 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/10 transition-all appearance-none cursor-pointer min-w-[180px]"
            >
              {SORT_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 px-8 pb-6 min-h-0">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-white rounded-[24px] border border-[rgba(212,175,55,0.25)] shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] overflow-hidden h-full flex flex-col"
        >
          {filtered.length === 0 ? (
            <div className="px-6 py-16 text-center flex-1 flex flex-col items-center justify-center">
              <div className="w-16 h-16 rounded-2xl bg-emerald-50 flex items-center justify-center mx-auto mb-4">
                <BadgeCheck className="w-8 h-8 text-emerald-400" />
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-1">No completed customers yet</h3>
              <p className="text-sm text-slate-500">
                {completed.length === 0
                  ? 'Customers will appear here when their loan is fully paid.'
                  : 'Try adjusting your search or filter criteria.'}
              </p>
            </div>
          ) : (
            <div className="overflow-auto flex-1" style={{ maxHeight: 'calc(100vh - 320px)' }}>
              <table className="w-[1400px]">
                <thead className="sticky top-0 z-30">
                  <tr className="border-b border-[var(--secondary)]/30 bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)]">
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)]">Customer Code</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)]">Customer Name</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Mobile</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Area</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Loan Amount</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Total Paid</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Interest Earned</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Loan Date</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Completion Date</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Duration</th>
                    <th className="text-center text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)]">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {paginated.map((c, index) => {
                    const paid = getPaidAmount(c.id)
                    const duration = getDuration(c)
                    const rowBg = index % 2 === 0 ? 'bg-white' : 'bg-[#FCFBF4]'
                    return (
                      <tr key={c.id} className={`border-b border-[rgba(212,175,55,0.12)] last:border-0 hover:bg-[rgba(212,175,55,0.08)] transition-colors ${rowBg}`}>
                        <td className={`px-4 py-3 text-sm font-semibold text-slate-900 ${rowBg}`}>{getDisplayId(c)}</td>
                        <td className={`px-4 py-3 ${rowBg}`}>
                          <Link href={`/dashboard/customers/${c.id}`} className="flex items-center gap-2.5 group">
                            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                              {c.fullName.charAt(0)}
                            </div>
                            <span className="text-sm font-medium text-slate-900 group-hover:text-[var(--primary)] transition-colors">{c.fullName}</span>
                          </Link>
                        </td>
                        <td className="px-4 py-3 text-sm text-slate-600">{c.mobileNumber}</td>
                        <td className="px-4 py-3 text-sm text-slate-600">{c.area || '—'}</td>
                        <td className="px-4 py-3 text-sm font-medium text-slate-900">{formatCurrency(Number(c.loanAmount) || 0)}</td>
                        <td className="px-4 py-3 text-sm font-semibold text-[var(--primary)]">{formatCurrency(paid)}</td>
                        <td className="px-4 py-3 text-sm font-medium text-[var(--secondary)]">{formatCurrency(Number(c.interestAmount) || 0)}</td>
                        <td className="px-4 py-3 text-sm text-slate-500">{formatDateDMY(c.loanDate || '')}</td>
                        <td className="px-4 py-3 text-sm text-slate-500">{c.completedAt ? formatDateDMY(c.completedAt) : '—'}</td>
                        <td className="px-4 py-3 text-sm font-medium text-slate-700">{duration}</td>
                        <td className={`px-4 py-3 ${rowBg}`}>
                          <div className="flex items-center gap-1.5 justify-center">
                            <button
                              onClick={() => setViewingCustomer(c)}
                              className="w-8 h-8 rounded-lg border border-transparent flex items-center justify-center hover:bg-[var(--primary-soft)] hover:border-[var(--primary)]/20 transition-colors"
                              title="Payment History"
                            >
                              <Eye className="w-4 h-4 text-[var(--primary)]" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="px-6 py-3 border-t border-[rgba(212,175,55,0.15)] flex items-center justify-between">
              <p className="text-xs text-slate-500">Page {currentPage} of {totalPages}</p>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="w-8 h-8 rounded-lg border border-[var(--primary)]/20 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="w-4 h-4 text-[var(--primary)]" />
                </button>
                {Array.from({ length: totalPages }, (_, i) => i + 1)
                  .filter((p) => p === 1 || p === totalPages || Math.abs(p - currentPage) <= 1)
                  .reduce<(number | string)[]>((acc, p, i, arr) => {
                    if (i > 0 && p - (arr[i - 1] as number) > 1) acc.push('...')
                    acc.push(p)
                    return acc
                  }, [])
                  .map((p, i) =>
                    typeof p === 'string' ? (
                      <span key={`ell-${i}`} className="w-8 h-8 flex items-center justify-center text-xs text-slate-400">...</span>
                    ) : (
                      <button
                        key={p}
                        onClick={() => setCurrentPage(p)}
                                        className={`w-8 h-8 rounded-lg text-xs font-medium transition-colors ${p === currentPage ? 'bg-[var(--primary)] text-white shadow-sm' : 'border border-[var(--primary)]/20 text-[var(--primary)] hover:bg-[var(--primary-soft)]'}`}
                      >
                        {p}
                      </button>
                    ),
                  )}
                <button
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="w-8 h-8 rounded-lg border border-[var(--primary)]/20 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <ChevronRight className="w-4 h-4 text-[var(--primary)]" />
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>

      {/* Payment History Drawer */}
      <PaymentHistoryDrawer
        customer={viewingCustomer}
        isOpen={!!viewingCustomer}
        onClose={() => setViewingCustomer(null)}
      />
    </div>
  )
}

export default function CompletedCustomersPage() {
  return (
    <Suspense fallback={null}>
      <CompletedContent />
    </Suspense>
  )
}
