'use client'

import { motion } from 'framer-motion'
import { LayoutDashboard, LogOut } from 'lucide-react'
import { useAuthStore } from '@/store/auth-store'
import { useAuthActions } from '@/hooks/use-auth'
import { STAGGER_CONTAINER, STAGGER_CHILD } from '@/animations/variants'
import { AnimatedButton } from '@/components/ui/animated-button'

export default function DashboardPlaceholder() {
  const fullName = useAuthStore((s) => s.userName)
  const { handleLogout, isLoggingOut } = useAuthActions()

  return (
    <motion.div
      variants={STAGGER_CONTAINER}
      initial="hidden"
      animate="visible"
      className="space-y-7 text-center"
    >
      <motion.div variants={STAGGER_CHILD} className="flex justify-center">
        <div className="w-16 h-16 rounded-2xl bg-gold-400/10 border border-gold-400/20 flex items-center justify-center">
          <LayoutDashboard className="w-8 h-8 text-gold-400" />
        </div>
      </motion.div>

      <motion.div variants={STAGGER_CHILD} className="space-y-2">
        <h2 className="text-[26px] font-bold text-white tracking-tight">
          Welcome, {fullName || 'User'}
        </h2>
        <p className="text-[14px] text-text-secondary leading-relaxed">
          You&apos;re successfully authenticated. The full dashboard will be built in Phase 2.
        </p>
      </motion.div>

      <motion.div variants={STAGGER_CHILD} className="flex gap-3 justify-center">
        <AnimatedButton variant="secondary" onClick={handleLogout} disabled={isLoggingOut}>
          <LogOut className="w-4 h-4" />
          {isLoggingOut ? 'Signing out...' : 'Sign Out'}
        </AnimatedButton>
      </motion.div>
    </motion.div>
  )
}
