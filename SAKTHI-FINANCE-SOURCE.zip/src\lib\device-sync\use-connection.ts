'use client'
import { useEffect, useState } from 'react'

/** Internet availability is not proof that the laptop/storage is reachable. */
export function useSyncConnection(user: string | null | undefined) {
  const [connection, setConnection] = useState({ connected: false, message: 'Checking laptop storage…' })
  useEffect(() => {
    let stopped = false, checking = false
    const check = async () => {
      if (!user || checking) return
      checking = true
      try {
        if (!window.sakthi && !navigator.onLine) throw new Error('Offline — entries stay on this device.')
        const response = await fetch('/api/device-sync/connection', { credentials: 'include', cache: 'no-store', signal: AbortSignal.timeout(8000) })
        const body = await response.json()
        if (!response.ok) throw new Error(response.status === 401 ? 'Sign in again to sync. Local records are retained.' : body.error || 'Laptop storage is unavailable.')
        if (body.userId !== user) throw new Error('Sign in to the same account to sync these records.')
        if (!stopped) setConnection({ connected: true, message: 'Laptop storage connected' })
      } catch (error) {
        if (!stopped) setConnection({ connected: false, message: error instanceof Error && error.name !== 'TimeoutError' && error.name !== 'TypeError' ? error.message : 'Laptop unavailable — local records are retained.' })
      } finally { checking = false }
    }
    void check()
    const timer = window.setInterval(check, 15000)
    window.addEventListener('online', check)
    window.addEventListener('offline', check)
    window.addEventListener('focus', check)
    return () => { stopped = true; clearInterval(timer); window.removeEventListener('online', check); window.removeEventListener('offline', check); window.removeEventListener('focus', check) }
  }, [user])
  return connection
}
