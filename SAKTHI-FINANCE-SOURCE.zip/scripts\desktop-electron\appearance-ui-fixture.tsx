import React, { useState } from 'react'
import { createRoot } from 'react-dom/client'
import { AppearanceProvider } from '../../src/providers/appearance-provider'
import AppearanceSection from '../../src/features/settings/AppearanceSection'
import { THEMES, THEME_KEY } from '../../src/lib/appearance'
function Fixture() {
  const [draft, setDraft] = useState('Unsaved customer draft')
  return <AppearanceProvider><div id="semantic-check" className="bg-[var(--primary)] text-white p-4">Sakthi Finance</div><input id="draft" value={draft} onChange={e=>setDraft(e.target.value)} /><AppearanceSection /></AppearanceProvider>
}
const host=document.body.appendChild(document.createElement('div'))
let root=createRoot(host)
root.render(<Fixture />)
const wait=()=>new Promise(resolve=>setTimeout(resolve,100))
const assert=(ok:boolean,message:string)=>{if(!ok)throw Error(message)}
Object.assign(window,{async runAppearanceChecks(){
  await wait(); const passed:string[]=[]
  for(const theme of THEMES){
    const button=[...document.querySelectorAll<HTMLButtonElement>('button')].find(b=>b.textContent?.includes(theme.name))!
    button.click(); await wait()
    assert(document.documentElement.dataset.appearance===theme.id,`Theme did not apply: ${theme.id}`)
    assert(localStorage.getItem(THEME_KEY)===theme.id,`Theme not saved: ${theme.id}`)
    assert(getComputedStyle(document.documentElement).getPropertyValue('--background').trim()===theme.colors[4],`Wrong background: ${theme.id}`)
    assert((document.querySelector('#draft') as HTMLInputElement).value==='Unsaved customer draft','Theme lost draft')
    assert(button.getAttribute('aria-pressed')==='true','Missing selected state')
    const action=getComputedStyle(document.querySelector('#semantic-check')!).backgroundColor
    const rgb=theme.action.match(/\w\w/g)!.map(x=>parseInt(x,16)).join(', ')
    assert(action===`rgb(${rgb})`,`Compiled CSS failed to consume action token: ${theme.id} ${action}`)
    passed.push(`${theme.name}: live tokens, selected state, persistence, draft retained`)
  }
  root.unmount(); root=createRoot(host); root.render(<Fixture />); await wait()
  assert(document.documentElement.dataset.appearance==='peach','Saved theme not restored after mount')
  passed.push('Saved theme restored on new provider mount')
  return passed
}})
