import {readFile,writeFile} from 'node:fs/promises'
const file='D:\\SAKTHI-FINANCE-UPDATES\\firebase.json'
const config=JSON.parse(await readFile(file,'utf8'))
if(!config.hosting || Array.isArray(config.hosting) || config.hosting.public!=='public')throw Error('Unexpected hosting configuration')
if(config.hosting.site && config.hosting.site!=='sakthi-finance-updates')throw Error('Unexpected existing site')
config.hosting.site='sakthi-finance-updates'
await writeFile(file,JSON.stringify(config,null,2)+'\n')
console.log('Hosting site explicitly set; existing cache rules preserved.')
