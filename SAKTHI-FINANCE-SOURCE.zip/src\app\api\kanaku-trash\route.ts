import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery, dbTransaction, ensureSchema } from '@/server/database'
import { actorFromAuthUser, recordAuditEvent, requestMeta } from '@/server/audit'
import { purgeExpiredKanaku } from '@/server/kanaku-retention'

export async function DELETE(request: NextRequest) {
  const auth=await requireAuthWithPermission('loans:delete')
  if(auth.error)return auth.error
  try {
    const {loanId,confirmation}=await request.json()
    if(typeof loanId!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(loanId)||confirmation!=='DELETE PERMANENTLY')
      return NextResponse.json({error:'Confirm permanent deletion of the selected Kanaku.'},{status:400})
    await ensureSchema()
    const deleted=await dbTransaction(async tx=>{
      // Acquire retention lock first, consistently with the scheduled cleanup.
      await tx.query('SELECT pg_advisory_xact_lock(721904222)')
      await tx.query(`SELECT id FROM customers WHERE user_id=$2 AND id::text=(SELECT customer_id FROM kanaku_trash WHERE loan_id=$1 AND user_id=$2) FOR UPDATE`,[loanId,auth.user.userId])
      const row=await tx.query('SELECT * FROM kanaku_trash WHERE loan_id=$1 AND user_id=$2 FOR UPDATE',[loanId,auth.user.userId])
      if(!row.rows[0])return false
      if(row.rows[0].purged_at)return true // Safe retry after lost confirmation.
      // Expiry bypass and deletion are atomic: failure restores the old deadline.
      await tx.query('UPDATE kanaku_trash SET purge_after=LEAST(purge_after,NOW()) WHERE loan_id=$1 AND user_id=$2',[loanId,auth.user.userId])
      const count=await purgeExpiredKanaku(tx,{loanId,owner:auth.user.userId,actor:actorFromAuthUser(auth.user)})
      if(count!==1)throw new Error('Deletion not confirmed')
      return true
    })
    return NextResponse.json(deleted?{success:true}:{error:'Deleted Kanaku not found.'},{status:deleted?200:404})
  } catch {
    return NextResponse.json({error:'Permanent deletion was not confirmed. Refresh to check its status before retrying.'},{status:409})
  }
}

export async function GET() {
  const auth = await requireAuthWithPermission('loans:delete')
  if (auth.error) return auth.error
  const result = await dbQuery(`SELECT t.*,c.full_name,c.customer_code,l.loan_amount,l.interest_rate,l.total_amount,
    paid.payment_count,
    paid.amount + COALESCE(l.legacy_paid_amount,0) AS received_amount,
    GREATEST(0,COALESCE(l.total_amount,0)-paid.amount-COALESCE(l.legacy_paid_amount,0)) AS balance_amount
    FROM kanaku_trash t JOIN customers c ON c.id::text=t.customer_id AND c.user_id=t.user_id
    JOIN loans l ON l.loan_id=t.loan_id AND l.customer_id::text=t.customer_id AND l.user_id=t.user_id
    LEFT JOIN LATERAL (SELECT COUNT(*)::int AS payment_count,COALESCE(SUM(p.amount),0) AS amount
      FROM payments p WHERE p.loan_id=t.loan_id AND p.customer_id::text=t.customer_id AND p.user_id=t.user_id) paid ON true
    WHERE t.user_id=$1 AND t.purged_at IS NULL ORDER BY t.deleted_at DESC`, [auth.user.userId])
  return NextResponse.json({ data: result.rows }, { headers: { 'Cache-Control': 'no-store' } })
}

export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('loans:delete')
  if (auth.error) return auth.error
  const { loanId } = await request.json()
  if (typeof loanId !== 'string' || !/^[0-9a-f-]{36}$/i.test(loanId)) return NextResponse.json({ error: 'Choose a Kanaku.' }, { status: 400 })
  const meta = requestMeta(request)
  await ensureSchema()
  const restored = await dbTransaction(async tx => {
    // Same lock order as payment entry: customer, then loan/group.
    await tx.query(`SELECT id FROM customers WHERE user_id=$2 AND id::text=(SELECT customer_id FROM kanaku_trash WHERE loan_id=$1 AND user_id=$2) FOR UPDATE`, [loanId,auth.user.userId])
    const result = await tx.query(`DELETE FROM kanaku_trash WHERE loan_id=$1 AND user_id=$2 AND purged_at IS NULL AND purge_after>NOW() RETURNING *`, [loanId,auth.user.userId])
    const row = result.rows[0]
    if (!row) return false
    await tx.query('UPDATE customers SET updated_at=NOW() WHERE id::text=$1 AND user_id=$2',[row.customer_id,auth.user.userId])
    await recordAuditEvent(tx,{action:'LOAN_RESTORED',entityType:'loan',entityId:loanId,loanId,customerId:row.customer_id,actor:actorFromAuthUser(auth.user),ipAddress:meta.ip,clientInfo:meta.client,result:'SUCCESS'})
    return true
  })
  return NextResponse.json(restored ? { success:true } : { error:'This Kanaku is unavailable or its 30-day recovery period has ended.' }, { status:restored?200:409 })
}
