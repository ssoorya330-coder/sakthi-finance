import { deflateRawSync } from 'node:zlib';

/**
 * Minimal dependency-free .xlsx workbook builder (ZIP/STORED + OOXML).
 *
 * Uses only Node built-ins (Buffer + a small CRC32 implementation), so no
 * npm package is required. Text cells use inline strings; currency uses the
 * Indian-locale format [$₹-4009] for proper digit grouping.
 */

export type XlsxCell =
  | { t: 's'; v: string; s?: number }
  | { t: 'n'; v: number; s?: number }
  | { t: 'd'; v: string; s?: number } // ISO date (yyyy-mm-dd), styled as date
  | { t: 'e' }; // empty cell

export interface XlsxSheet {
  name: string;
  cols: number[]; // widths
  rows: XlsxCell[][];
  freezeRows?: number; // freeze first N rows
  filterRow?: number; // 1-based header row for autofilter (0 = none)
  merges?: Array<{ from: string; to: string }>; // merged title ranges, e.g. A1:D1
}

// Styles: 0 default | 1 header (white bold on wine) | 2 title (bold 14)
//         3 currency | 4 date | 5 bold | 6 currency bold | 7 subtitle (bold 11)
//         8 percent (0.0%)
//         8 percent (0.0%)
export const XS_DEFAULT = 0;
export const XS_HEADER = 1;
export const XS_TITLE = 2;
export const XS_CURRENCY = 3;
export const XS_DATE = 4;
export const XS_BOLD = 5;
export const XS_CURRENCY_BOLD = 6;
export const XS_PERCENT = 8;
export const XS_SUBTITLE = 7;

const esc = (s: string): string =>
  s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const colLetter = (n: number): string => {
  let s = '';
  let i = n;
  while (i > 0) {
    const m = (i - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    i = Math.floor((i - 1) / 26);
  }
  return s;
};

const ST = (v: string, s?: number): XlsxCell => ({ t: 's', v, s });
const NM = (v: number, s?: number): XlsxCell => ({ t: 'n', v, s });
const DT = (iso: string | null, s: number = XS_DATE): XlsxCell =>
  iso ? { t: 'd', v: iso.slice(0, 10), s } : { t: 'e' };

function cellXml(ref: string, cell: XlsxCell): string {
  if (cell.t === 'e') return `<c r="${ref}"/>`;
  const style = cell.s ? ` s="${cell.s}"` : '';
  if (cell.t === 's') {
    return `<c r="${ref}"${style} t="inlineStr"><is><t>${esc(cell.v)}</t></is></c>`;
  }
  if (cell.t === 'd') {
    const [y, m, d] = cell.v.split('-').map(Number);
    const serial = Math.round(Date.UTC(y, m - 1, d) / 86400000) + 25569;
    return `<c r="${ref}"${style}><v>${serial}</v></c>`;
  }
  const v = Number.isFinite(cell.v) ? cell.v : 0;
  return `<c r="${ref}"${style}><v>${v}</v></c>`;
}

function sheetXml(sheet: XlsxSheet): string {
  const maxCols = sheet.rows.reduce((max, row) => Math.max(max, row.length), sheet.cols.length);
  const cols = sheet.cols
    .map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`)
    .join('');
  const dim = `A1:${colLetter(maxCols)}${sheet.rows.length}`;
  const freeze = sheet.freezeRows
    ? `<sheetViews><sheetView workbookViewId="0"><pane ySplit="${sheet.freezeRows}" topLeftCell="A${sheet.freezeRows + 1}" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>`
    : `<sheetViews><sheetView workbookViewId="0"/></sheetViews>`;
  const filter = sheet.filterRow
    ? `<autoFilter ref="A${sheet.filterRow}:${colLetter(maxCols)}${sheet.rows.length}"/>`
    : '';
  const merges =
    sheet.merges && sheet.merges.length > 0
      ? `<mergeCells count="${sheet.merges.length}">${sheet.merges.map((m) => `<mergeCell ref="${m.from}:${m.to}"/>`).join('')}</mergeCells>`
      : '';
  const rows = sheet.rows
    .map((cells, ri) => {
      const parts: string[] = [];
      for (let ci = 0; ci < cells.length; ci += 1) {
        parts.push(cellXml(`${colLetter(ci + 1)}${ri + 1}`, cells[ci]));
      }
      return `<row r="${ri + 1}">${parts.join('')}</row>`;
    })
    .join('');
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">` +
    `<dimension ref="${dim}"/>${freeze}<cols>${cols}</cols><sheetData>${rows}</sheetData>${filter}${merges}</worksheet>`
  );
}

const STYLES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="3"><numFmt numFmtId="164" formatCode="[$\u20B9-4009]#,##0.00"/><numFmt numFmtId="165" formatCode="dd-mmm-yyyy"/><numFmt numFmtId="166" formatCode="0.0%"/></numFmts>
<fonts count="4">
<font><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="14"/><color rgb="FF7F1D1D"/><name val="Calibri"/></font>
<font><b/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
</fonts>
<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF7F1D1D"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="9">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="3" fillId="2" borderId="0" xfId="0" applyFill="1"/>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="164" fontId="1" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="166" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
</cellXfs>
</styleSheet>`;

const CONTENT_TYPES = (count: number): string => {
  const sheets = Array.from(
    { length: count },
    (_, i) =>
      `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`
  ).join('');
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
    `<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>` +
    `<Default Extension="xml" ContentType="application/xml"/>` +
    `<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>` +
    `<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>` +
    sheets +
    `</Types>`
  );
};

const RELS = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;

const WORKBOOK = (sheets: XlsxSheet[]): string =>
  `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
  `<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">` +
  `<sheets>${sheets.map((s, i) => `<sheet name="${esc(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`;

const WORKBOOK_RELS = (count: number): string => {
  const rels = Array.from(
    { length: count },
    (_, i) =>
      `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`
  ).join('');
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rId${count + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>${rels}</Relationships>`
  );
};

// CRC32 (IEEE) for ZIP/STORED entries.
const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i += 1) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function dosDateTime(d: Date): { time: number; date: number } {
  return {
    time: ((d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2)) & 0xffff,
    date: ((((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xffff),
  };
}

export function buildZip(files: Array<{ name: string; data: Buffer }>, compress = true): Buffer {
  if (files.length > 65535) throw new Error('Too many files for this archive.');
  const now = new Date();
  const { time, date } = dosDateTime(now);
  const chunks: Buffer[] = [];
  const central: Buffer[] = [];
  let offset = 0;
  for (const f of files) {
    if (f.name.startsWith('/') || f.name.includes('\\') || f.name.split('/').includes('..')) throw new Error('Invalid archive path.');
    const data = compress ? deflateRawSync(f.data, { level: 9 }) : f.data;
    const method = compress ? 8 : 0;
    const name = Buffer.from(f.name, 'utf8');
    const crc = crc32(f.data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6); // UTF-8 filenames
    local.writeUInt16LE(method, 8);
    local.writeUInt16LE(time, 10);
    local.writeUInt16LE(date, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(f.data.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    chunks.push(local, name, data);
    const head = Buffer.alloc(46);
    head.writeUInt32LE(0x02014b50, 0);
    head.writeUInt16LE(20, 4);
    head.writeUInt16LE(20, 6);
    head.writeUInt16LE(0x0800, 8);
    head.writeUInt16LE(method, 10);
    head.writeUInt16LE(time, 12);
    head.writeUInt16LE(date, 14);
    head.writeUInt32LE(crc, 16);
    head.writeUInt32LE(data.length, 20);
    head.writeUInt32LE(f.data.length, 24);
    head.writeUInt16LE(name.length, 28);
    head.writeUInt16LE(0, 30);
    head.writeUInt16LE(0, 32);
    head.writeUInt16LE(0, 34);
    head.writeUInt16LE(0, 36);
    head.writeUInt32LE(0, 38);
    head.writeUInt32LE(offset, 42);
    central.push(head, name);
    offset += local.length + name.length + data.length;
    if (offset > 0xffffffff) throw new Error('Archive exceeds ZIP size limit.');
  }
  const centralSize = central.reduce((a, b) => a + b.length, 0);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);
  return Buffer.concat([...chunks, ...central, end]);
}

/** Assemble a multi-sheet .xlsx workbook. Returns the file bytes. */
export function buildXlsx(sheets: XlsxSheet[]): Buffer {
  const files = [
    { name: '[Content_Types].xml', data: Buffer.from(CONTENT_TYPES(sheets.length), 'utf8') },
    { name: '_rels/.rels', data: Buffer.from(RELS, 'utf8') },
    { name: 'xl/workbook.xml', data: Buffer.from(WORKBOOK(sheets), 'utf8') },
    { name: 'xl/_rels/workbook.xml.rels', data: Buffer.from(WORKBOOK_RELS(sheets.length), 'utf8') },
    { name: 'xl/styles.xml', data: Buffer.from(STYLES, 'utf8') },
    ...sheets.map((s, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: Buffer.from(sheetXml(s), 'utf8') })),
  ];
  return buildZip(files, false);
}

export const x = { ST, NM, DT };
