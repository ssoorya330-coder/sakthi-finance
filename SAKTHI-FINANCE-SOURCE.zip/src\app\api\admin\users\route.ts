import { NextRequest, NextResponse } from 'next/server'
import { requireOwner } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { actorFromAuthUser, requestMeta, recordAuditStandalone } from '@/server/audit'

export async function GET(request: NextRequest) {
  const auth = await requireOwner()
  if (auth.error) return auth.error

  try {
    const result = await dbQuery(
      `SELECT u.id, u.user_id, u.email, u.full_name, u.role, r.role_name, u.is_active,
              u.avatar_url, u.provider, u.last_login_at, u.created_at, u.updated_at,
              (SELECT COUNT(*)::int FROM customers c WHERE c.user_id=u.user_id) AS customer_count,
              (SELECT COUNT(DISTINCT l.customer_id)::int FROM kanaku_loan_balances l WHERE l.user_id=u.user_id AND l.outstanding>0 AND l.status IN ('Active','Overdue')) AS active_customer_count,
              (SELECT COUNT(*)::int FROM customers c WHERE c.user_id=u.user_id AND c.status='Completed') AS completed_customer_count,
              (SELECT COUNT(*)::int FROM customers c WHERE c.user_id=u.user_id AND c.status='Aborted') AS aborted_customer_count,
              totals.loan_count, totals.loan_amount, totals.total_amount, totals.paid_amount, totals.balance_amount
       FROM users u
       LEFT JOIN roles r ON u.role_id = r.role_id
       LEFT JOIN LATERAL (SELECT COUNT(*)::int AS loan_count,COALESCE(SUM(loan_amount),0) AS loan_amount,
         COALESCE(SUM(total_amount),0) AS total_amount,COALESCE(SUM(paid_amount),0) AS paid_amount,
         COALESCE(SUM(outstanding),0) AS balance_amount FROM kanaku_loan_balances l WHERE l.user_id=u.user_id) totals ON true
       ORDER BY u.created_at ASC`
    )

    return NextResponse.json({ users: result.rows })
  } catch (err: any) {
    console.error('[GET /api/admin/users] Error:', err.message)
    return NextResponse.json({ error: 'Failed to fetch users' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  const auth = await requireOwner()
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const { email, full_name } = body

    if (!email || !email.trim()) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 })
    }

    // No role assignment through the application: pre-provisioned accounts
    // always start at the default role. Roles are an internal/server-side
    // value only and can never be chosen through any application endpoint.
    const userRole = 'owner'

    // Get role_id
    const roleResult = await dbQuery('SELECT role_id FROM roles WHERE role_name = $1', [userRole])
    const roleId = roleResult.rows[0]?.role_id

    if (!roleId) {
      return NextResponse.json({ error: 'Default role is not provisioned' }, { status: 500 })
    }

    // Check if email already exists
    const existing = await dbQuery('SELECT user_id FROM users WHERE email = $1', [email.trim()])
    if (existing.rows.length > 0) {
      return NextResponse.json({ error: 'A user with this email already exists' }, { status: 409 })
    }

    // Create user (they will authenticate via Google on first login)
    const userId = `user-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
    const result = await dbQuery(
      `INSERT INTO users (user_id, email, full_name, role, role_id, is_active, provider)
       VALUES ($1, $2, $3, $4, $5, true, 'google')
       RETURNING *`,
      [userId, email.trim(), full_name || null, userRole, roleId]
    )

    // Audit log
    await dbQuery(
      `INSERT INTO audit_logs (action, entity_type, entity_id, details, user_id)
       VALUES ('create', 'user', $1, $2, $3)`,
      [userId, JSON.stringify({ email: email.trim(), role: userRole }), auth.user.userId]
    ).catch(() => {})
    {
      const meta = requestMeta(request)
      await recordAuditStandalone({
        action: 'USER_CREATED',
        entityType: 'user',
        entityId: userId,
        actor: actorFromAuthUser(auth.user),
        ipAddress: meta.ip,
        clientInfo: meta.client,
        result: 'SUCCESS',
        changes: [
          { field: 'email', label: 'Email', before: null, after: email.trim() },
          { field: 'role', label: 'Role', before: null, after: userRole },
        ],
      })
    }

    return NextResponse.json(result.rows[0], { status: 201 })
  } catch (err: any) {
    console.error('[POST /api/admin/users] Error:', err.message)
    return NextResponse.json({ error: 'Failed to create user' }, { status: 500 })
  }
}
