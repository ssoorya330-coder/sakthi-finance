'use client'

import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'

interface WidgetCardProps {
  icon: React.ComponentType<{ className?: string }>
  title: string
  subtitle?: string
  action?: React.ReactNode
  children: React.ReactNode
  delay?: number
  className?: string
}

export default function WidgetCard({
  icon: Icon,
  title,
  subtitle,
  action,
  children,
  delay = 0,
  className,
}: WidgetCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, delay, ease: [0.16, 1, 0.3, 1] }}
      whileHover={{ y: -6, scale: 1.02 }}
      className={cn(
        'group relative overflow-hidden bg-white rounded-[24px] border border-[rgba(127,29,29,0.08)]',
        'shadow-[0_1px_3px_rgba(0,0,0,0.04),0_12px_32px_rgba(0,0,0,0.05)]',
        'transition-shadow duration-300',
        'hover:shadow-[0_8px_28px_rgba(127,29,29,0.10),0_20px_56px_rgba(127,29,29,0.12),0_0_44px_rgba(212,175,55,0.12)]',
        className
      )}
    >
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: 'linear-gradient(135deg, rgba(212,175,55,0.05), transparent 38%, rgba(127,29,29,0.04))' }}
      />
      {/* Thin curved line + circular line pattern overlays */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none"
        viewBox="0 0 400 300"
        fill="none"
        preserveAspectRatio="xMidYMid slice"
      >
        <path d="M-20 240 C 90 180, 180 300, 420 220" stroke="rgba(127,29,29,0.05)" strokeWidth="1" />
        <path d="M-20 272 C 120 210, 220 322, 420 252" stroke="rgba(212,175,55,0.05)" strokeWidth="1" />
        <circle cx="362" cy="42" r="72" stroke="rgba(127,29,29,0.04)" strokeWidth="1" />
        <circle cx="362" cy="42" r="108" stroke="rgba(212,175,55,0.04)" strokeWidth="1" />
        <circle cx="28" cy="282" r="62" stroke="rgba(212,175,55,0.04)" strokeWidth="1" />
      </svg>
      <div className="absolute -top-24 -right-24 w-56 h-56 rounded-full bg-gradient-to-br from-[var(--primary)]/[0.06] to-[var(--secondary)]/[0.06] blur-3xl pointer-events-none transition-opacity duration-300 group-hover:opacity-100" />
      <div className="absolute -bottom-28 -left-24 w-56 h-56 rounded-full bg-gradient-to-br from-[var(--secondary)]/[0.05] to-[var(--primary)]/[0.05] blur-3xl pointer-events-none" />

      <div className="relative z-10 p-6 h-full flex flex-col">
        <div className="flex items-start justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-[13px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20 transition-transform duration-300 group-hover:scale-105 group-hover:rotate-3">
              <Icon className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-[var(--text-primary)] tracking-tight">{title}</h3>
              {subtitle && <p className="text-xs font-medium text-slate-500 mt-0.5">{subtitle}</p>}
            </div>
          </div>
          {action}
        </div>
        <div className="flex-1 min-h-0">{children}</div>
      </div>
    </motion.div>
  )
}
