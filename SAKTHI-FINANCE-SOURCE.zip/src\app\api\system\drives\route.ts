import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/api-utils'
import { listLocalDrives } from '@/server/storage'

export const dynamic = 'force-dynamic'

/** Fixed local drives detected from the OS. LOCAL ONLY — never invented. */
export async function GET() {
  const auth = await requireAuth()
  if (auth.error) return auth.error

  try {
    const drives = await listLocalDrives()
    return NextResponse.json({ drives })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to detect local drives', details: err.message },
      { status: 500 }
    )
  }
}
