import axios, {
  type AxiosInstance,
  type AxiosRequestConfig,
  type AxiosResponse,
  type InternalAxiosRequestConfig,
} from 'axios';
import { tryRefresh, readAccessTokenFromCookie } from '@/lib/auth/client-auth';
import { useDesktopAdapter } from '@/lib/desktop/axios-adapter';

const MAX_RETRIES = 1;
const RETRY_DELAY_MS = 1500;

let getTokenFn: (() => Promise<string | null>) | null = null;
let getUserIdFn: (() => string | null) | null = null;
let getAccessTokenFn: (() => Promise<string | null>) | null = null;

export function getToken(): Promise<string | null> {
  return getTokenFn ? getTokenFn() : Promise.resolve(null);
}

export function setTokenProvider(
  tokenFn: () => Promise<string | null>,
  userIdFn: () => string | null
): void {
  getTokenFn = tokenFn;
  getUserIdFn = userIdFn;
}

// Backwards-compat alias
export function setSupabaseTokenProvider(
  tokenFn: () => Promise<string | null>,
  userIdFn: () => string | null
): void {
  setTokenProvider(tokenFn, userIdFn);
}

export function getSupabaseToken(): Promise<string | null> {
  return getToken();
}

export function setAccessTokenProvider(
  tokenFn: () => Promise<string | null>
): void {
  getAccessTokenFn = tokenFn;
}

async function resolveAccessToken(): Promise<string | null> {
  if (getAccessTokenFn) {
    return getAccessTokenFn();
  }
  // Fallback: read from the access cookie directly (the server sets it as
  // httpOnly, so this returns null — the real bearer is the httpOnly cookie
  // that the browser attaches automatically to same-origin requests).
  if (typeof document !== 'undefined') {
    return readAccessTokenFromCookie();
  }
  return null;
}

const client: AxiosInstance = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || '',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
  withCredentials: true,
});

client.interceptors.request.use(async (config: InternalAxiosRequestConfig) => {
  useDesktopAdapter(config);
  // Prefer the access token from a custom provider (so the frontend can
  // mirror it after a refresh). The browser also attaches the httpOnly
  // access cookie automatically for same-origin requests, so this is mainly
  // needed for cross-origin / non-cookie contexts.
  const accessToken = await resolveAccessToken();
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`;
  }

  // Fallback: also support the refresh-token provider token
  const providerToken = await getToken();
  if (providerToken && !config.headers.Authorization) {
    config.headers.Authorization = `Bearer ${providerToken}`;
  }

  if (getUserIdFn) {
    const userId = getUserIdFn();
    if (userId) {
      config.headers['X-User-Id'] = userId;
    }
  }
  return config;
});

let refreshInFlight: Promise<boolean> | null = null;

/**
 * Try to refresh the access token. Deduplicates concurrent refresh attempts.
 * Returns true if a fresh access token is now available.
 */
async function attemptRefresh(): Promise<boolean> {
  if (refreshInFlight) return refreshInFlight;
  refreshInFlight = (async () => {
    const result = await tryRefresh();
    return result !== null;
  })();
  try {
    return await refreshInFlight;
  } finally {
    // Allow next refresh after a short delay to avoid bursty calls
    setTimeout(() => {
      refreshInFlight = null;
    }, 100);
  }
}

client.interceptors.response.use(
  (response: AxiosResponse) => response,
  async (error) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & {
      _retryCount?: number;
      _refreshAttempted?: boolean;
    };

    if (!originalRequest) {
      return Promise.reject(error);
    }

    const status = error.response?.status;
    const isRetryable = ['get', 'head'].includes(originalRequest.method || 'get') && (!status || (status >= 500 && status < 600));

    if (isRetryable && (originalRequest._retryCount ?? 0) < MAX_RETRIES) {
      originalRequest._retryCount = (originalRequest._retryCount ?? 0) + 1;
      const attempt = originalRequest._retryCount;
      await new Promise((r) => setTimeout(r, RETRY_DELAY_MS * attempt));
      return client(originalRequest);
    }

    // 401 → try refresh once, then retry the original request
    if (status === 401 && !originalRequest._refreshAttempted) {
      originalRequest._refreshAttempted = true;
      try {
        const refreshed = await attemptRefresh();
        if (refreshed) {
          const newToken = await resolveAccessToken();
          if (newToken) {
            originalRequest.headers.Authorization = `Bearer ${newToken}`;
          }
          return client(originalRequest);
        }
      } catch (refreshErr) {
        // fall through to clear-and-reject
      }
      // Refresh failed — clear client auth state
      if (typeof window !== 'undefined') {
        try {
          const authKeys = [
            'sf-auth',
            'sf-sync',
            'sf-sidebar',
            'sf-toast',
            'sf_access_token',
            'sf_refresh_token',
            'sf_user',
            'sf_active_user_id',
          ];
          authKeys.forEach((k) => {
            try { localStorage.removeItem(k) } catch {}
            try { sessionStorage.removeItem(k) } catch {}
          });
        } catch {}
      }
    }

    return Promise.reject(error);
  }
);

export { client as apiClient };

export async function apiGet<T>(url: string, config?: AxiosRequestConfig): Promise<T> {
  const { data } = await client.get<T>(url, config);
  return data;
}

export async function apiPost<T>(url: string, body?: unknown, config?: AxiosRequestConfig): Promise<T> {
  const { data } = await client.post<T>(url, body, config);
  return data;
}

export async function apiPut<T>(url: string, body?: unknown, config?: AxiosRequestConfig): Promise<T> {
  const { data } = await client.put<T>(url, body, config);
  return data;
}

export async function apiDelete<T>(url: string, config?: AxiosRequestConfig): Promise<T> {
  const { data } = await client.delete<T>(url, config);
  return data;
}

export async function apiDownload(url: string): Promise<Blob> {
  const { data } = await client.get<Blob>(url, { responseType: 'blob' });
  return data;
}

export async function apiUpload<T>(
  url: string,
  file: File,
  additionalFields?: Record<string, string>
): Promise<T> {
  const formData = new FormData();
  formData.append('file', file);
  if (additionalFields) {
    Object.entries(additionalFields).forEach(([key, val]) =>
      formData.append(key, val)
    );
  }
  const { data } = await client.post<T>(url, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return data;
}
