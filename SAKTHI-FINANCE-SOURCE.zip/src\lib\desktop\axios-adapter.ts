import { AxiosError, type InternalAxiosRequestConfig, type AxiosResponse } from 'axios'
import { isDesktopApp, installDesktopFetchBridge } from './bridge'

// Existing clients keep their normal request/response/error semantics in a web
// browser; only Electron substitutes transport, not the finance operations.
export function useDesktopAdapter(config: InternalAxiosRequestConfig) {
  if (!isDesktopApp()) return config
  installDesktopFetchBridge()
  config.adapter = async cfg => {
    let url = cfg.url || '/'
    if (/^https?:/i.test(url)) {
      const parsed = new URL(url)
      if (!['localhost', '127.0.0.1'].includes(parsed.hostname)) throw new AxiosError('External request is not a desktop API operation', 'ERR_BAD_REQUEST', cfg)
      url = parsed.pathname + parsed.search
    }
    if (!url.startsWith('/api/')) url = '/api' + (url.startsWith('/') ? url : '/' + url)
    const parsed = new URL(url, 'http://sakthi.desktop')
    for (const [key, value] of Object.entries(cfg.params || {})) if (value != null) parsed.searchParams.set(key, String(value))
    const response = await window.fetch(parsed.pathname + parsed.search, {
      method: cfg.method?.toUpperCase() || 'GET', body: cfg.data, signal: cfg.signal as AbortSignal | undefined,
    })
    const data = cfg.responseType === 'blob' ? await response.blob() : cfg.responseType === 'arraybuffer' ? await response.arrayBuffer() : cfg.responseType === 'text' ? await response.text() : await response.json()
    const result: AxiosResponse = { data, status: response.status, statusText: response.statusText, headers: Object.fromEntries(response.headers), config: cfg }
    if (!(cfg.validateStatus || (status => status >= 200 && status < 300))(response.status)) throw new AxiosError('Desktop request failed', 'ERR_BAD_RESPONSE', cfg, undefined, result)
    return result
  }
  return config
}
