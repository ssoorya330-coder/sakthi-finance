/**
 * Minimal in-memory sliding-window rate limiter for sensitive admin
 * endpoints. No new dependencies; single-process best-effort (fail-open).
 */

const buckets = new Map<string, number[]>();

function prune(now: number, windowMs: number, hits: number[]): number[] {
  const cutoff = now - windowMs;
  return hits.filter((t) => t > cutoff);
}

/**
 * Returns true when the request is allowed (and records the hit),
 * false when the caller exceeds `max` hits per `windowMs`.
 */
export function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const hits = prune(now, windowMs, buckets.get(key) || []);
  if (hits.length >= max) {
    buckets.set(key, hits);
    return false;
  }
  hits.push(now);
  buckets.set(key, hits);
  // Bound memory: drop empty/old buckets opportunistically.
  if (buckets.size > 5000) {
    for (const [k, v] of buckets) {
      if (prune(now, windowMs, v).length === 0) buckets.delete(k);
      if (buckets.size <= 4000) break;
    }
  }
  return true;
}

export function rateLimitKey(request: Request, scope: string): string {
  const ip =
    request.headers.get('x-forwarded-for')?.split(',')[0].trim() ||
    request.headers.get('x-real-ip') ||
    'unknown';
  return `${scope}:${ip}`;
}
