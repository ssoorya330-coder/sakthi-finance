import React, { useState } from 'react'
import { createRoot } from 'react-dom/client'
import VoiceMicButton from '../../src/components/ui/voice-mic-button'
import type { VoiceEvent } from '../../electron/speech'

// Isolated Electron QA: synthetic IPC events, no microphone or finance connection.
const listeners = new Set<(event: VoiceEvent) => void>()
let current = ''
let commits = 0
Object.assign(window, { sakthi: { voice: {
  onEvent(callback: (event: VoiceEvent) => void) { listeners.add(callback); return () => listeners.delete(callback) },
  async start(id: string) { current = id; emit('ready') },
  async stop() {},
  async cancel() {},
} } })
function emit(type: VoiceEvent['type'], text?: string, id = current) {
  for (const callback of [...listeners]) callback({ id, type, text, ...(type === 'error' ? { error: 'recognition-failed' } : {}) })
}
function Fixture() {
  const [name, setName] = useState('Original name')
  const [phone, setPhone] = useState('9123456789')
  return <><section id="name"><input value={name} onChange={e => setName(e.target.value)} />
    <VoiceMicButton value={name} onPreview={setName} onResult={text => { commits++; setName(text) }} /></section>
    <section id="phone"><input value={phone} onChange={e => setPhone(e.target.value)} />
    <VoiceMicButton inputType="phone" value={phone} onPreview={setPhone} onResult={text => { commits++; setPhone(text) }} /></section></>
}
const root = createRoot(document.body.appendChild(document.createElement('div')))
root.render(<Fixture />)
const wait = (ms = 60) => new Promise(resolve => setTimeout(resolve, ms))
const input = (field: string) => document.querySelector<HTMLInputElement>(`#${field} input`)!.value
const click = async (field: string) => { document.querySelector<HTMLButtonElement>(`#${field} button`)!.click(); await wait() }
const assert = (condition: boolean, message: string) => { if (!condition) throw Error(message) }
Object.assign(window, { async runVoiceChecks() {
  const passed: string[] = []
  await wait(500)
  await click('name'); emit('interim', 'Arul'); await wait()
  assert(input('name') === 'Arul', 'Live text missing')
  assert(document.querySelector('[data-voice-live]')?.textContent === 'Arul', 'Listening badge must show the current words')
  emit('interim', 'Arul Vet'); await wait()
  assert(input('name') === 'Arul Vet', 'Interim duplicated')
  emit('result', 'Arul Vettri'); emit('end'); await wait()
  assert(input('name') === 'Arul Vettri' && commits === 1, 'Final was not committed once')
  passed.push('Text previews replace and final commits once')
  await click('phone'); emit('interim', 'nine eight seven six'); await wait()
  assert(input('phone') === '9876' && !document.querySelector('[role="alert"]'), 'Partial phone validated too early')
  emit('result', 'plus nine one nine eight seven six five four three two one zero'); emit('end'); await wait()
  assert(input('phone') === '9876543210', 'Country prefix normalization failed')
  passed.push('Live phone digits and final country-code normalization')
  await wait(450); await click('phone'); emit('interim', '123456'); await wait()
  emit('result', '123456'); emit('end'); await wait()
  assert(input('phone') === '9876543210', 'Invalid phone erased valid value')
  assert(document.body.textContent!.includes('Only 6 digits'), 'Final phone feedback missing')
  passed.push('Incomplete final restores original number with digit-count feedback')
  await click('name'); const old = current; emit('interim', 'Temporary'); await wait()
  await wait(450); await click('phone'); emit('result', 'Ghost', old); await wait()
  assert(input('name') === 'Arul Vettri' && listeners.size === 1, 'Switch did not restore/isolate')
  emit('error'); emit('end'); await wait()
  passed.push('Switching microphones rolls back preview and rejects late results')
  for (let i = 0; i < 20; i++) {
    await wait(450); await click('name'); emit('interim', `Name ${i}`); await wait()
    emit('result', `Name ${i}`); emit('end'); await wait()
    assert(listeners.size === 0 && input('name') === `Name ${i}`, 'Repeated use leaked listener or result')
  }
  passed.push('Twenty repeated sessions without accumulating IPC listeners')
  await wait(450); await click('name'); root.unmount(); await wait()
  emit('result', 'Late after navigation')
  assert(listeners.size === 0, 'Unmount leaked IPC listener')
  passed.push('Unmount removes active listener')
  return passed
} })
