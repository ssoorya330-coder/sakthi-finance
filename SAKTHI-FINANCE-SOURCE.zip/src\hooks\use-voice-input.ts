'use client'

import { useState, useRef, useCallback, useEffect } from 'react'
import { DesktopSpeechRecognition } from '@/lib/desktop/speech-recognition'
import type {
  SpeechRecognition,
  SpeechRecognitionConstructor,
  SpeechRecognitionErrorEvent,
  SpeechRecognitionEvent,
} from '@/types/speech'

export type VoiceStatus = 'idle' | 'requesting' | 'listening' | 'processing'

export interface UseVoiceInputOptions {
  phrases?: string[]
  /** BCP-47 language tag. Defaults to `en-IN`. */
  lang?: string
  /** Fired with the interim (non-final) transcript as it arrives. */
  onInterim?: (text: string) => void
  /** Fired with a user-friendly error message. */
  onError?: (message: string) => void
}

export interface UseVoiceInputReturn {
  status: VoiceStatus
  start: () => void
  stop: () => void
  toggle: () => void
  isSupported: boolean
  /** User-friendly error message, or null when there is no error. */
  error: string | null
  /** Latest interim transcript (cleared when recognition ends). */
  interimTranscript: string
  feedback: string
}

const DEFAULT_LANG = 'en-IN'
const RAPID_CLICK_GUARD_MS = 400
const ERROR_AUTO_CLEAR_MS = 15000

const MSG_UNSUPPORTED = 'Voice commands are not supported in this app.'
const MSG_NO_SPEECH = 'No words were returned by speech recognition. Check your microphone and speak again.'
const MSG_PERMISSION = 'Allow microphone access in Windows Settings (Privacy & security > Microphone) for this app, then try again.'
const MSG_NO_MIC = 'No microphone was found or the microphone is unavailable.'
const MSG_NETWORK = 'Speech recognition service is unavailable. Check your internet connection.'

// Module-level singleton: only one recognition may be active at a time,
// even though forms (e.g. Add Customer) render several mic buttons.
let activeRecognition: SpeechRecognition | null = null
let activeTeardown: (() => void) | null = null

function vLog(...args: Array<string | number | boolean>): void {
  if (process.env.NODE_ENV !== 'production') {
    // Intentionally never logs transcript text or PII — event names only.
    console.debug('[Sakthi Voice]', ...args)
  }
}

function getSpeechRecognitionConstructor(): SpeechRecognitionConstructor | null {
  if (typeof window === 'undefined') return null
  if (window.sakthi?.voice) return DesktopSpeechRecognition
  return window.SpeechRecognition || window.webkitSpeechRecognition || null
}

export function isSpeechSupported(): boolean {
  return getSpeechRecognitionConstructor() !== null
}

function friendlyErrorMessage(error: string): string {
  switch (error) {
    case 'low-confidence':
      return 'I could not hear that clearly. Please repeat the name slowly, or type it. Your field was not changed.'
    case 'not-allowed':
      return MSG_PERMISSION
    case 'service-not-allowed':
      return 'Speech recognition is blocked. Check microphone and speech permissions in Windows Settings for this app.'
    case 'audio-capture':
      return MSG_NO_MIC
    case 'no-speech':
      return MSG_NO_SPEECH
    case 'network':
      return MSG_NETWORK
    case 'language-not-supported':
      return 'This speech language is not supported by the installed voice model.'
    case 'model-missing':
      return 'The offline voice model is missing. Install the complete Sakthi Finance update.'
    case 'timeout':
      return 'Voice processing took too long. Try a shorter phrase.'
    case 'recognition-failed':
      return 'The offline voice model could not process this recording. Please try again.'
    case 'helper-missing':
    case 'helper-unavailable':
      return 'Windows voice input could not start. Reinstall the latest Sakthi Finance app and try again.'
    case 'aborted':
      return ''
    default:
      return 'Voice input failed. Please try again.'
  }
}

/** Continuous dictation with one active field at a time. */
export function useVoiceInput(
  onResult: (text: string) => void,
  options?: UseVoiceInputOptions
): UseVoiceInputReturn {
  const [status, setStatus] = useState<VoiceStatus>('idle')
  // Deterministic first render (false on server AND first client render),
  // then detect support post-hydration to avoid hydration mismatches.
  const [isSupported, setIsSupported] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [interimTranscript, setInterimTranscript] = useState('')
  const [feedback, setFeedback] = useState('')

  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const mountedRef = useRef(false)
  const startingRef = useRef(false)
  const lastAttemptRef = useRef(0)
  const sessionRef = useRef(0)
  const finalTranscriptRef = useRef('')
  const pendingTranscriptRef = useRef('')
  const deliveredLengthRef = useRef(0)
  const lastDeliveredRef = useRef({ text: '', at: 0 })
  const userStoppedRef = useRef(false)
  const sawErrorRef = useRef(false)
  const silenceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const deadlineRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const errorTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Always call the latest onResult without re-creating start/stop.
  const onResultRef = useRef(onResult)
  const onInterimRef = useRef(options?.onInterim)
  const onErrorRef = useRef(options?.onError)
  const lang = options?.lang ?? DEFAULT_LANG
  const phrasesRef = useRef(options?.phrases)
  phrasesRef.current = options?.phrases

  useEffect(() => {
    onResultRef.current = onResult
  }, [onResult])
  useEffect(() => {
    onInterimRef.current = options?.onInterim
    onErrorRef.current = options?.onError
  }, [options?.onInterim, options?.onError])

  const clearErrorTimer = useCallback(() => {
    if (errorTimerRef.current) {
      clearTimeout(errorTimerRef.current)
      errorTimerRef.current = null
    }
  }, [])

  const setErrorSafe = useCallback(
    (message: string | null) => {
      if (!mountedRef.current) return
      setError(message)
      if (message) {
        sawErrorRef.current = true
        onErrorRef.current?.(message)
        clearErrorTimer()
        errorTimerRef.current = setTimeout(() => {
          if (mountedRef.current) setError(null)
          errorTimerRef.current = null
        }, ERROR_AUTO_CLEAR_MS)
      }
    },
    [clearErrorTimer]
  )

  const clearSessionTimers = useCallback(() => {
    if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current)
    if (deadlineRef.current) clearTimeout(deadlineRef.current)
  }, [])

  const deactivate = useCallback(() => {
    clearSessionTimers()
    sessionRef.current += 1
    recognitionRef.current = null
    startingRef.current = false
    finalTranscriptRef.current = ''
    pendingTranscriptRef.current = ''
    deliveredLengthRef.current = 0
    if (mountedRef.current) {
      setStatus('idle')
      setInterimTranscript('')
      setFeedback('')
    }
  }, [clearSessionTimers])

  /** Deliver any final text not yet passed to onResult. Returns true if speech exists. */
  const flushTranscript = useCallback((): boolean => {
    // Interim hypotheses are display-only on every engine, including browsers.
    const full = pendingTranscriptRef.current.trim() === finalTranscriptRef.current.trim() ? finalTranscriptRef.current : ''
    // Remove auto-inserted sentence-ending dots, preserving initials and decimals.
    const chunk = full.trim().replace(/[.\s]+$/u, '')
    const hasSpeech = chunk.length > 0
    if (hasSpeech && deliveredLengthRef.current === 0) {
      deliveredLengthRef.current = full.length
      const duplicate = lastDeliveredRef.current.text === chunk && Date.now() - lastDeliveredRef.current.at < 2500
      if (!duplicate && chunk && mountedRef.current) {
        lastDeliveredRef.current = { text: chunk, at: Date.now() }
        onResultRef.current(chunk)
      }
    }
    return hasSpeech
  }, [])

  const stop = useCallback(() => {
    vLog('stop requested')
    clearSessionTimers()
    userStoppedRef.current = true
    // Invalidate any in-flight permission request for this session.
    sessionRef.current += 1
    startingRef.current = false
    const rec = recognitionRef.current
    if (rec) {
      setStatus('processing')
      try {
        rec.stop()
      } catch {
        // Already stopped/aborted — onend will still normalize state.
      }
    } else if (mountedRef.current) {
      // Was still requesting permission — nothing to stop.
      setStatus('idle')
      setInterimTranscript('')
    }
    // onend normalizes the rest; force idle if it never fires.
    window.setTimeout(() => {
      if (rec && recognitionRef.current === rec) {
        flushTranscript()
        deactivate()
        if (activeRecognition === rec) {
          activeRecognition = null
          activeTeardown = null
        }
        try { rec.abort() } catch { /* Already stopped. */ }
      }
    }, window.sakthi?.voice ? 125000 : 2000)
  }, [deactivate, flushTranscript, clearSessionTimers])

  const start = useCallback(() => {
    vLog('microphone button clicked')
    if (!mountedRef.current) return

    const now = Date.now()
    if (now - lastAttemptRef.current < RAPID_CLICK_GUARD_MS) {
      vLog('rapid click ignored')
      return
    }
    lastAttemptRef.current = now

    if (startingRef.current || recognitionRef.current) {
      vLog('already started — ignoring duplicate start')
      return
    }

    if (!window.isSecureContext) {
      setErrorSafe('Microphone access requires a secure context. Start the desktop application normally.')
      return
    }
    const SR = getSpeechRecognitionConstructor()
    if (!SR) {
      vLog('recognition unavailable')
      setErrorSafe(MSG_UNSUPPORTED)
      return
    }

    // Stop any recognition owned by another mic-button instance first.
    if (activeTeardown) {
      const previous = activeRecognition
      activeTeardown()
      vLog('aborting previous active recognition')
      try {
        previous?.abort()
      } catch {
        // Ignore — previous instance is going away regardless.
      }
      activeRecognition = null
      activeTeardown = null
    }

    const mySession = sessionRef.current + 1
    sessionRef.current = mySession
    startingRef.current = true
    userStoppedRef.current = false
    sawErrorRef.current = false
    clearErrorTimer()
    setErrorSafe(null)
    finalTranscriptRef.current = ''
    pendingTranscriptRef.current = ''
    deliveredLengthRef.current = 0
    setInterimTranscript('')
    setStatus('requesting')
    setFeedback('Starting microphone…')
    activeTeardown = deactivate

    let retryCount = 0
    let useLocal = false
    let audioDetected = false
    let soundDetected = false
    let retryError: string | null = null
    const noSpeechMessage = () => soundDetected
      ? 'Audio was detected, but no words were recognized. Check the selected language and try speaking again.'
      : audioDetected
        ? 'The microphone opened but no sound was detected. Check the selected microphone and Windows input volume, then try again.'
        : MSG_NO_SPEECH

    const beginRecognition = () => {
      // Aborted while permission was being acquired (user pressed stop,
      // unmounted, or a newer session started) — stay quiet.
      if (!mountedRef.current || sessionRef.current !== mySession || userStoppedRef.current) {
        vLog('session cancelled before recognition start')
        return
      }

      const recognition = new SR()
      // Retry an empty continuous session once in single-utterance mode.
      recognition.continuous = retryCount === 0
      recognition.interimResults = true
      recognition.maxAlternatives = 3
      recognition.lang = lang
      if (window.sakthi?.voice && recognition instanceof DesktopSpeechRecognition) recognition.phrases = phrasesRef.current ?? []
      if ('processLocally' in recognition) recognition.processLocally = useLocal
      recognition.onaudiostart = () => {
        if (recognitionRef.current !== recognition) return
        audioDetected = true
        setFeedback('Microphone ready — speak now')
      }
      recognition.onsoundstart = () => {
        if (recognitionRef.current !== recognition) return
        soundDetected = true
        setFeedback('Sound detected — recognizing…')
      }
      recognition.onspeechstart = () => {
        if (recognitionRef.current !== recognition) return
        soundDetected = true
        setFeedback('Listening…')
      }
      recognition.onspeechend = () => {
        if (recognitionRef.current !== recognition) return
        if (!window.sakthi?.voice) stop()
      }
      recognition.onaudioend = () => {
        if (recognitionRef.current !== recognition) return
        setFeedback('Finishing…')
      }
      recognition.onprocessing = () => {
        if (recognitionRef.current !== recognition || !mountedRef.current) return
        clearSessionTimers()
        setStatus('processing')
        setFeedback('Finishing…')
        deadlineRef.current = setTimeout(() => {
          if (recognitionRef.current !== recognition) return
          setErrorSafe(friendlyErrorMessage('timeout'))
          try { recognition.abort() } catch { /* Already ended. */ }
          if (activeRecognition === recognition) { activeRecognition = null; activeTeardown = null }
          deactivate()
        }, 125000)
      }

      recognition.onstart = () => {
        if (recognitionRef.current !== recognition) return
        clearSessionTimers()
        if (!userStoppedRef.current) deadlineRef.current = setTimeout(stop, 60000)
        vLog('recognition started')
        setFeedback(retryCount ? 'Listening again — please repeat your words' : 'Listening — speak now')
        startingRef.current = false
        if (mountedRef.current && sessionRef.current === mySession) setStatus('listening')
      }

      recognition.onresult = (event: SpeechRecognitionEvent) => {
        if (recognitionRef.current !== recognition || !mountedRef.current) return
        vLog('recognition result received')
        let interim = ''
        const finals: string[] = []
        for (let i = 0; i < event.results.length; i += 1) {
          const result = event.results[i]
          const transcript = result[0]?.transcript ?? ''
          if (result.isFinal) {
            const confidence = result[0]?.confidence
            if (typeof confidence === 'number' && confidence > 0 && confidence < 0.55) {
              finalTranscriptRef.current = ''
              pendingTranscriptRef.current = ''
              setErrorSafe(`I heard: “${transcript.trim()}”. Please repeat or type it; your field was not changed.`)
              return
            }
            finals.push(transcript.trim())
          } else {
            interim += transcript
          }
        }
        finalTranscriptRef.current = finals.join(' ')
        // Keep the latest hypothesis for display, never for execution.
        pendingTranscriptRef.current = [...finals, interim.trim()].filter(Boolean).join(' ')
        if (mountedRef.current) {
          const preview = [...finals, interim].filter(Boolean).join(' ')
          setInterimTranscript(preview)
          onInterimRef.current?.(preview)
          if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current)
          if (!userStoppedRef.current && !window.sakthi?.voice) silenceTimerRef.current = setTimeout(stop, 6000)
        }
        // Commit the complete utterance on end so partial phone numbers do not
        // overwrite a valid field or produce premature validation errors.
      }

      recognition.onnomatch = () => {
        // Speech was heard but produced no usable alternative. Do not fail
        // here — the session continues and onend decides based on the
        // accumulated transcript.
        vLog('recognition no match')
      }

      recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
        if (recognitionRef.current !== recognition) return
        clearSessionTimers()
        const code = typeof event.error === 'string' ? event.error : 'unknown'
        if (code === 'low-confidence') {
          pendingTranscriptRef.current = ''
          finalTranscriptRef.current = ''
        }
        vLog('recognition error', code)
        startingRef.current = false
        if (code === 'aborted') {
          // User-initiated stop — not an error.
          if (mountedRef.current) {
            setInterimTranscript('')
            setStatus('idle')
          }
          if (activeRecognition === recognition) {
            activeRecognition = null
            activeTeardown = null
          }
          recognitionRef.current = null
          return
        }
        // Usable speech already arrived (finals delivered or pending):
        // this is a success, not a failure — flush and stay silent instead
        // of overwriting the result with a "no speech" message.
        if (finalTranscriptRef.current.trim().length > 0) {
          vLog('error after speech received — delivering transcript')
          flushTranscript()
          if (mountedRef.current) {
            setStatus('idle')
            setInterimTranscript('')
          }
          if (activeRecognition === recognition) {
            activeRecognition = null
            activeTeardown = null
          }
          recognitionRef.current = null
          return
        }
        const message = friendlyErrorMessage(code)
        // Let onend release the old recognizer before attempting a retry.
        if (!userStoppedRef.current && retryCount === 0 && (code === 'no-speech' || code === 'network' || (useLocal && (code === 'language-not-supported' || code === 'service-not-allowed')))) {
          retryError = code
          deadlineRef.current = setTimeout(() => {
            if (recognitionRef.current !== recognition) return
            recognition.onend?.call(recognition, new Event('end'))
          }, 2000)
          return
        }
        if (mountedRef.current) {
          setErrorSafe(code === 'no-speech' ? noSpeechMessage() : message)
          setStatus('idle')
          setInterimTranscript('')
        }
        if (activeRecognition === recognition) {
          activeRecognition = null
          activeTeardown = null
        }
        recognitionRef.current = null
      }

      recognition.onend = () => {
        if (recognitionRef.current !== recognition) return
        clearSessionTimers()
        vLog('recognition ended')
        startingRef.current = false
        // Flush any undelivered final text (e.g. single-utterance flow where
        // onend arrives right after the final result).
        const hasSpeech = flushTranscript()
        if (!hasSpeech && !userStoppedRef.current && !sawErrorRef.current && retryCount === 0) {
          retryCount += 1
          // If local recognition failed, let the platform service try next.
          useLocal = false
          startingRef.current = true
          recognitionRef.current = null
          activeRecognition = null
          try { recognition.abort() } catch { /* Already ended. */ }
          setStatus('requesting')
          setFeedback('Retrying microphone — please repeat when Listening appears')
          // Preserve ownership while waiting so another field can cancel this retry.
          activeTeardown = deactivate
          deadlineRef.current = setTimeout(beginRecognition, 300)
          return
        }
        if (mountedRef.current) {
          // An empty manual stop also needs feedback, but must never retry.
          if (!hasSpeech && !sawErrorRef.current) {
            setErrorSafe(retryError === 'network' ? MSG_NETWORK : noSpeechMessage())
          }
          setStatus('idle')
          setInterimTranscript('')
        }
        if (activeRecognition === recognition) {
          activeRecognition = null
          activeTeardown = null
        }
        recognitionRef.current = null
        setFeedback('')
      }

      recognitionRef.current = recognition
      activeRecognition = recognition
      activeTeardown = () => {
        deactivate()
      }

      try {
        vLog('recognition initialized')
        deadlineRef.current = setTimeout(() => {
          if (recognitionRef.current !== recognition) return
          setErrorSafe('Speech recognition did not start. Check microphone permission and try again.')
          deactivate()
          if (activeRecognition === recognition) { activeRecognition = null; activeTeardown = null }
          try { recognition.abort() } catch { /* Already stopped. */ }
        }, 20000)
        recognition.start()
      } catch (err) {
        clearSessionTimers()
        const name = err instanceof DOMException ? err.name : 'Error'
        vLog('start threw', name)
        setErrorSafe(name === 'NotAllowedError' ? MSG_PERMISSION : 'Unable to start voice input. Please try again.')
        // `InvalidStateError: recognition has already started` — recover
        // gracefully instead of crashing the component.
        startingRef.current = false
        recognitionRef.current = null
        if (activeRecognition === recognition) {
          activeRecognition = null
          activeTeardown = null
        }
        if (mountedRef.current && sessionRef.current === mySession) setStatus('idle')
      }
    }

    // Prefer an installed local recognizer for the exact selected language.
    // Keep setup bounded and fall back automatically without extra controls.
    if (SR.available && 'processLocally' in SR.prototype) {
      const localOptions = { langs: [lang], processLocally: true }
      const isCurrent = () => mountedRef.current && sessionRef.current === mySession && !userStoppedRef.current
      let settled = false
      const ready = (local: boolean) => {
        if (settled || !isCurrent()) return
        settled = true
        clearSessionTimers()
        useLocal = local
        beginRecognition()
      }
      deadlineRef.current = setTimeout(() => ready(false), 1500)
      try {
        void SR.available(localOptions).then(result => ready(result === 'available'), () => ready(false))
      } catch {
        ready(false)
      }
    } else {
      beginRecognition()
    }
  }, [lang, clearErrorTimer, setErrorSafe, deactivate, flushTranscript, clearSessionTimers, stop])

  const toggle = useCallback(() => {
    if (recognitionRef.current || startingRef.current) stop()
    else start()
  }, [status, start, stop])

  useEffect(() => {
    mountedRef.current = true
    // Post-hydration only: enabling here never causes a hydration mismatch.
    setIsSupported(isSpeechSupported())
    vLog('hook mounted')
    return () => {
      mountedRef.current = false
      sessionRef.current += 1
      clearErrorTimer()
      clearSessionTimers()
      const rec = recognitionRef.current
      if (rec) {
        try {
          rec.abort()
        } catch {
          // Ignore teardown errors.
        }
        recognitionRef.current = null
      }
      if (activeRecognition === rec || activeTeardown === deactivate) {
        activeRecognition = null
        activeTeardown = null
      }
      vLog('hook unmounted — recognition cleaned up')
    }
  }, [clearErrorTimer, deactivate, clearSessionTimers])

  return { status, start, stop, toggle, isSupported, error, interimTranscript, feedback }
}
