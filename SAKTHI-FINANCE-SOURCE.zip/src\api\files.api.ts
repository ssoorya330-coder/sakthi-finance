import { apiGet, apiUpload, apiDelete } from './client';
import type { ApiResponse } from '@/types/api.types';
import type { FileUploadResponse, PresignedUrlResponse } from './types';

function unwrap<T>(res: ApiResponse<T>): T {
  if (!res.success || res.data === undefined) {
    throw new Error(res.message || 'Request failed');
  }
  return res.data;
}

export const filesApi = {
  async uploadFile(file: File, type?: string): Promise<FileUploadResponse> {
    const res = await apiUpload<ApiResponse<FileUploadResponse>>(
      '/api/files/upload',
      file,
      type ? { type } : undefined
    );
    return unwrap(res);
  },

  async deleteFile(key: string): Promise<void> {
    const res = await apiDelete<ApiResponse>(
      `/api/files/${encodeURIComponent(key)}`
    );
    if (!res.success) throw new Error(res.message || 'Delete failed');
  },

  async getPresignedUrl(key: string): Promise<PresignedUrlResponse> {
    const res = await apiGet<ApiResponse<PresignedUrlResponse>>(
      `/api/files/presigned-url/${encodeURIComponent(key)}`
    );
    return unwrap(res);
  },
};
