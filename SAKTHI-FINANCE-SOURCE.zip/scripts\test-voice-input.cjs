const assert = require('node:assert/strict');
const fs = require('fs');
const vm = require('vm');
const ts = require('typescript');
function compile(file, imports, globals = {}) {
  const exports = {};
  vm.runInNewContext(ts.transpileModule(fs.readFileSync(file, 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText,
    { exports, require: name => imports[name], ...globals });
  return exports;
}
const { parseSpokenPhone } = compile('src/lib/voice-phone.ts', {});
assert.equal(parseSpokenPhone('nine eight seven six five four three two one zero'), '9876543210');
assert.equal(parseSpokenPhone('nine eight double seven six five four three two one'), '9877654321');
assert.equal(parseSpokenPhone('+91 98765 43210'), '9876543210');
assert.equal(parseSpokenPhone('nine eight unknown seven'), null);
assert.equal(parseSpokenPhone('9876543210123'), null);
assert.equal(parseSpokenPhone(''), null);
let current;
const react = {
 useState: value => { const owner = current; const index = owner.states.push(value) - 1; return [value, v => { owner.states[index] = typeof v === 'function' ? v(owner.states[index]) : v; }]; },
 useRef: value => ({ current: value }), useCallback: callback => callback,
 useEffect: callback => current.effects.push(callback),
};
const recognitions = [];
class Recognition {
 constructor() { recognitions.push(this); }
 start() { this.onstart?.({}); }
 stop() { this.stopped = true; }
 abort() { this.onerror?.({error: 'aborted'}); this.onend?.({}); }
}
const requests = [];
const timers = new Map(); let timerId = 0;
const setTimer = callback => { timers.set(++timerId, callback); return timerId; };
const { useVoiceInput } = compile('src/hooks/use-voice-input.ts', {react}, {
 window: { SpeechRecognition: Recognition, setTimeout: setTimer },
 navigator: { mediaDevices: { getUserMedia: () => new Promise(resolve => requests.push(resolve)) } },
 setTimeout: setTimer, clearTimeout: id => timers.delete(id), DOMException,
 process: {env: {NODE_ENV: 'production'}},
});
function mount() {
 current = { states: [], effects: [], results: [] };
 const owner = current;
 owner.hook = useVoiceInput(text => owner.results.push(text));
 owner.cleanups = owner.effects.map(effect => effect()).filter(Boolean);
 return owner;
}
async function grant() { requests.shift()({ getTracks: () => [{stop() {}}] }); await Promise.resolve(); }
function result(rec, words) { rec.onresult({resultIndex: 0, results: words.map(text => ({0: {transcript: text}, isFinal: true}))}); }
(async () => {
 const first = mount(); first.hook.start();
 const second = mount(); second.hook.start();
 await grant(); assert.equal(recognitions.length, 0, 'Cancelled permission request must not start');
 await grant(); const rec = recognitions.at(-1);
 const staleResult = rec.onresult, staleEnd = rec.onend;
 result(rec, ['Sakthi']); result(rec, ['Sakthi', 'Kumar']);
 assert.equal(second.results.length, 0, 'Do not commit partial utterances');
 rec.onend({}); assert.deepEqual(second.results, ['Sakthi Kumar']);
 assert.equal(second.states[0], 'idle');
 const third = mount(); third.hook.start(); await grant(); const thirdRec = recognitions.at(-1);
 staleResult({resultIndex: 0, results: [{0: {transcript: 'Wrong field'}, isFinal: true}]}); staleEnd({});
 assert.deepEqual(second.results, ['Sakthi Kumar']);
 third.hook.stop(); result(thirdRec, ['Final after stop']); thirdRec.onend({});
 assert.deepEqual(third.results, ['Final after stop']);
 const fourth = mount(); fourth.hook.start(); await grant();
 recognitions.at(-1).onerror({error: 'not-allowed'});
 assert.equal(fourth.states[0], 'idle'); assert.match(fourth.states[2], /permission/);
 const fifth = mount(); fifth.hook.start(); fifth.cleanups.forEach(fn => fn());
 const count = recognitions.length; await grant(); assert.equal(recognitions.length, count);
 const sixth = mount(); sixth.hook.start(); await grant(); sixth.hook.stop();
 for (const callback of [...timers.values()]) callback();
 assert.equal(sixth.states[0], 'idle', 'Recover if recognition never ends');
 console.log('Voice regression checks passed: phone dictation, session switching, stale events, complete utterances, stop, permission errors, unmount and timeout recovery.');
})().catch(error => { console.error(error); process.exitCode = 1; });
