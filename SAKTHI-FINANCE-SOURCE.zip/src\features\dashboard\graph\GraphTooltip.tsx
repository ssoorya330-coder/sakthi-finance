'use client'

import { motion } from 'framer-motion'
import { GRAPH_METRICS } from './graph.types'
import type { MetricKey } from './graph.types'
import { formatINR } from '@/lib/dashboard-utils'

interface TooltipPayloadEntry {
  dataKey?: MetricKey
  value?: number
  color?: string
}

export interface GraphTooltipProps {
  active?: boolean
  payload?: TooltipPayloadEntry[]
  label?: string | number
}

export default function GraphTooltip({ active, payload, label }: GraphTooltipProps) {
  if (!active || !payload || payload.length === 0) return null

  return (
    <motion.div
      initial={{ opacity: 0, y: 6, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 6, scale: 0.96 }}
      transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
      className="bg-white/90 backdrop-blur-xl rounded-2xl border border-slate-100 shadow-[0_8px_32px_rgba(0,0,0,0.12)] px-4 py-3 min-w-[220px]"
    >
      <p className="text-[13px] font-semibold text-slate-900 mb-2.5 pb-2 border-b border-slate-100">
        {String(label ?? '')}
      </p>
      <div className="space-y-2">
        {payload.map((entry) => {
          const metric = GRAPH_METRICS.find((m) => m.key === entry.dataKey)
          if (!metric) return null
          return (
            <div key={metric.key} className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: entry.color || metric.color }}
                />
                <span className="text-xs text-slate-600">{metric.label}</span>
              </div>
              <span className="text-xs font-semibold text-slate-900 tabular-nums">
                {formatINR(entry.value ?? 0)}
              </span>
            </div>
          )
        })}
      </div>
    </motion.div>
  )
}
