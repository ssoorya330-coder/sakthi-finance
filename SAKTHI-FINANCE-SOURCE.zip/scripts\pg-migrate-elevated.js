/*
 * Elevated PostgreSQL data-directory migration worker (Windows only).
 *
 * Launched automatically by the app through the Windows UAC mechanism
 * (Start-Process -Verb RunAs) — the user only approves the UAC dialog,
 * never opens a terminal or runs commands manually.
 *
 * Jobs:
 *   node pg-migrate-elevated.js --jobDir <dir>
 *
 * Reads  <jobDir>/params.json:
 *   { mode: 'migrate' | 'restore',
 *     source?: string,        // migrate: current data dir (detected before stop)
 *     destination: string,    // migrate: new dir | restore: original dir
 *     serviceName?: string }  // auto-detected when omitted
 *
 * Writes <jobDir>/started.json on boot (UAC-approval heartbeat) and
 * <jobDir>/progress.json continuously (atomic write via rename):
 *   { status, stage, operation, copiedBytes, totalBytes, stagePercent,
 *     error, errorKind, rolledBack, newDir }
 *
 * Safety rules (hard):
 * - Never kills postgres.exe / never force-terminates anything.
 * - Never deletes the source/original directory, ever.
 * - migrate: stop -> copy -> verify files -> re-point service -> start.
 *   On failure AFTER the service was re-pointed: restore the original
 *   binPath, restart on it, and report rolledBack:true.
 * - No credentials are used or needed (file + service operations only).
 */

const { spawn, execFile } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { promisify } = require('util');

const execFileAsync = promisify(execFile);
const SYS32 = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32');
const SC = path.join(SYS32, 'sc.exe');
const ROBOCOPY = path.join(SYS32, 'robocopy.exe');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function fail(message, kind) {
  const e = new Error(message);
  e.kind = kind || 'unknown';
  throw e;
}

function isPermissionError(text) {
  return /access\s+is\s+denied|FAILED\s+5|EPERM|EACCES|privilege/i.test(String(text || ''));
}

function sanitizeDir(input, label) {
  const raw = String(input || '').trim();
  if (!raw) fail(`${label} is required.`, 'disk');
  // Normalize forward slashes first: PostgreSQL itself reports the data
  // directory with forward slashes. Never reject for slash style or for
  // living under Program Files.
  const trimmed = raw.replace(/\//g, '\\');
  if (!/^[A-Za-z]:\\/.test(trimmed)) fail(`${label} must be an absolute local path (e.g. D:\\PostgreSQL\\data).`, 'disk');
  if (/["`$&|<>^]/.test(trimmed)) fail(`${label} contains invalid characters.`, 'disk');
  return path.win32.normalize(trimmed).replace(/\\$/, '');
}

function sanitizeServiceName(name) {
  const n = String(name || '').trim();
  if (!/^[A-Za-z0-9_.$-]+$/.test(n)) fail('Invalid PostgreSQL service name.', 'postgres');
  return n;
}

/** Recursive folder size (metadata only). Single walk per call. */
function dirSizeBytes(dir, maxFiles = 2000000) {
  let total = 0;
  let files = 0;
  const stack = [dir];
  while (stack.length > 0) {
    const cur = stack.pop();
    let entries;
    try {
      entries = fs.readdirSync(cur, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const e of entries) {
      const full = path.join(cur, e.name);
      try {
        if (e.isDirectory()) {
          if (!e.isSymbolicLink()) stack.push(full);
        } else if (e.isFile()) {
          total += fs.statSync(full).size;
          if (++files > maxFiles) return total;
        }
      } catch {
        continue;
      }
    }
  }
  return total;
}

async function sc(args, timeoutMs) {
  return execFileAsync(SC, args, { timeout: timeoutMs || 30000, windowsHide: true, encoding: 'utf8' });
}

function parseScState(out) {
  const m = String(out).match(/STATE\s*:\s*\d+\s+(\w+)/i);
  return m ? m[1].toLowerCase() : 'unknown';
}

function parseScBinaryPath(out) {
  const m = String(out).match(/BINARY_PATH_NAME\s*:\s*(.+)/i);
  return m ? m[1].trim() : null;
}

function parseDataDir(binPath) {
  if (!binPath) return null;
  const m = binPath.match(/-D\s+("[^"]+"|\S+)/);
  if (!m) return null;
  return m[1].replace(/^"|"$/g, '');
}

async function detectServiceName(preferred) {
  if (preferred) return sanitizeServiceName(preferred);
  const { stdout } = await sc(['query', 'state=', 'all'], 20000);
  const names = [];
  for (const line of String(stdout).split(/\r?\n/)) {
    const m = line.match(/SERVICE_NAME\s*:\s*(.+)/i);
    if (m && /^postgresql/i.test(m[1].trim())) names.push(m[1].trim());
  }
  if (names.length === 0) fail('No PostgreSQL Windows service was detected.', 'postgres');
  return names[0];
}

async function serviceState(name) {
  try {
    const { stdout } = await sc(['query', name], 15000);
    return parseScState(stdout);
  } catch {
    return 'unknown';
  }
}

async function waitForState(name, want, timeoutMs, what) {
  const start = Date.now();
  for (;;) {
    const state = await serviceState(name);
    if (state === want) return;
    if (Date.now() - start > timeoutMs) {
      fail(`${what} did not reach "${want}" in time (last state: ${state}).`, 'postgres');
    }
    await sleep(4000);
  }
}

async function stopServiceClean(name) {
  const state = await serviceState(name);
  if (state === 'stopped') return;
  try {
    await sc(['stop', name], 60000);
  } catch (e) {
    if (isPermissionError(e.message)) {
      fail('Administrator permission is required to stop the PostgreSQL service.', 'permission');
    }
    fail(`Could not stop the PostgreSQL service: ${String(e.message || e).slice(0, 200)}`, 'postgres');
  }
  await waitForState(name, 'stopped', 120000, 'PostgreSQL service stop');
}

async function startServiceClean(name) {
  const state = await serviceState(name);
  if (state === 'running') return;
  try {
    await sc(['start', name], 60000);
  } catch (e) {
    if (isPermissionError(e.message)) {
      fail('Administrator permission is required to start the PostgreSQL service.', 'permission');
    }
    fail(`Could not start the PostgreSQL service: ${String(e.message || e).slice(0, 200)}`, 'postgres');
  }
  await waitForState(name, 'running', 120000, 'PostgreSQL service start');
}

async function readBinPath(name) {
  const { stdout } = await sc(['qc', name], 15000);
  const binPath = parseScBinaryPath(stdout);
  if (!binPath) fail('PostgreSQL service configuration could not be read.', 'postgres');
  return binPath;
}

async function applyBinPath(name, newBinPath) {
  try {
    const r = await execFileAsync(SC, ['config', name, 'binPath=', newBinPath], {
      timeout: 30000, windowsHide: true, encoding: 'utf8',
    });
    const out = String(r.stdout) + String(r.stderr || '');
    if (isPermissionError(out)) {
      fail('Administrator permission is required to update the PostgreSQL service configuration.', 'permission');
    }
  } catch (e) {
    if (e.kind) throw e;
    if (isPermissionError(e.message)) {
      fail('Administrator permission is required to update the PostgreSQL service configuration.', 'permission');
    }
    fail(`PostgreSQL configuration update failed: ${String(e.message || e).slice(0, 200)}`, 'postgres');
  }
  const updated = await readBinPath(name);
  return updated;
}

function runRobocopy(src, dest) {
  return new Promise((resolve) => {
    const args = [src, dest, '/MIR', '/COPYALL', '/DCOPY:DAT', '/MT:32', '/J', '/R:2', '/W:2', '/XJ', '/NP', '/NFL', '/NDL'];
    let proc;
    try {
      proc = spawn(ROBOCOPY, args, { windowsHide: true, stdio: 'ignore' });
    } catch (e) {
      resolve({ ok: false, exitCode: -1, error: String((e && e.message) || e) });
      return;
    }
    proc.on('error', (e) => resolve({ ok: false, exitCode: -1, error: String((e && e.message) || e) }));
    // Robocopy exit codes 0-7 are SUCCESS (copied / extras / mismatches are
    // informational). 8+ means real failure. Never treat 1-7 as failure.
    proc.on('close', (code) => {
      const exit = typeof code === 'number' ? code : -1;
      if (exit >= 0 && exit <= 7) resolve({ ok: true, exitCode: exit });
      else resolve({ ok: false, exitCode: exit, error: `Copy failed (exit code ${exit}).` });
    });
  });
}

function verifyCopyOnDisk(src, dest, srcVersion, srcSize) {
  const checks = [];
  const push = (ok, label) => checks.push({ ok, label });
  let dstVersion = null;
  try {
    dstVersion = fs.readFileSync(path.join(dest, 'PG_VERSION'), 'utf8').trim();
    push(!srcVersion || dstVersion === srcVersion, 'Version marker');
  } catch {
    push(false, 'Version marker');
  }
  for (const f of ['postgresql.conf', 'pg_hba.conf', 'pg_ident.conf']) {
    try {
      fs.accessSync(path.join(dest, f), fs.constants.R_OK);
      push(true, f);
    } catch {
      push(false, f);
    }
  }
  try {
    const entries = fs.readdirSync(path.join(dest, 'base'));
    push(entries.length > 0, 'base/');
  } catch {
    push(false, 'base/');
  }
  if (srcSize && srcSize > 0) {
    const dstSize = dirSizeBytes(dest);
    const ratio = dstSize / srcSize;
    push(ratio >= 0.95 && ratio <= 1.05, 'size');
  }
  const bad = checks.filter((c) => !c.ok).map((c) => c.label);
  if (bad.length > 0) fail(`Copied data did not verify (${bad.join(', ')}). The original data was not modified.`, 'disk');
  return dstVersion;
}

async function main() {
  const jobIdx = process.argv.indexOf('--jobDir');
  const jobDir = jobIdx >= 0 ? process.argv[jobIdx + 1] : null;
  if (!jobDir || !fs.existsSync(jobDir)) {
    throw new Error('Migration job directory is missing.');
  }
  const progressPath = path.join(jobDir, 'progress.json');
  const writeProgress = (p) => {
    const tmp = progressPath + '.tmp.' + crypto.randomBytes(4).toString('hex');
    fs.writeFileSync(tmp, JSON.stringify(p));
    fs.renameSync(tmp, progressPath);
  };
  // Heartbeat: proves UAC was approved and the worker is alive.
  fs.writeFileSync(path.join(jobDir, 'started.json'), JSON.stringify({ at: new Date().toISOString() }));

  const params = JSON.parse(fs.readFileSync(path.join(jobDir, 'params.json'), 'utf8'));
  const mode = params.mode === 'restore' ? 'restore' : 'migrate';
  const dest = sanitizeDir(params.destination, 'Destination');

  const set = (stage, operation, extra) => writeProgress(Object.assign(
    { status: 'running', stage, operation, copiedBytes: null, totalBytes: null, stagePercent: null, error: null, errorKind: null, rolledBack: false },
    extra || {}
  ));

  let serviceName = null;
  let originalBinPath = null;
  let configChanged = false;

  try {
    if (os.platform() !== 'win32') fail('Automatic migration is only supported on Windows.', 'unknown');

    if (mode === 'restore') {
      // Restore: point the service back at the original directory and start it.
      set('configuring', 'Restoring PostgreSQL configuration...');
      serviceName = await detectServiceName(params.serviceName);
      const current = await readBinPath(serviceName);
      const next = current.replace(/-D\s+("[^"]+"|\S+)/, `-D "${dest}"`);
      if (next === current) fail('PostgreSQL service data-directory flag could not be parsed.', 'postgres');
      const updated = await applyBinPath(serviceName, next);
      if (!updated.includes(dest)) fail('Previous configuration could not be restored.', 'postgres');
      set('starting', 'Starting PostgreSQL service...');
      await startServiceClean(serviceName);
      writeProgress({ status: 'done', stage: 'done', operation: 'Previous configuration restored.', copiedBytes: null, totalBytes: null, stagePercent: 100, error: null, errorKind: null, rolledBack: true, newDir: dest });
      return;
    }

    // ---- migrate mode ----
    const src = sanitizeDir(params.source, 'Source data directory');
    if (src.toLowerCase() === dest.toLowerCase()) fail('Destination must differ from the current data directory.', 'disk');
    if (dest.toLowerCase().startsWith(src.toLowerCase() + '\\')) fail('Destination must not be inside the current data directory.', 'disk');

    set('validating', 'Detecting PostgreSQL installation...');
    serviceName = await detectServiceName(params.serviceName);
    try {
      fs.accessSync(src, fs.constants.R_OK);
      if (!fs.statSync(src).isDirectory()) throw new Error('not a directory');
      fs.accessSync(path.join(src, 'PG_VERSION'), fs.constants.R_OK);
    } catch {
      fail('Source does not look like a PostgreSQL data directory (PG_VERSION not readable).', 'disk');
    }
    const srcVersion = fs.readFileSync(path.join(src, 'PG_VERSION'), 'utf8').trim();
    originalBinPath = await readBinPath(serviceName);
    if (!parseDataDir(originalBinPath)) fail('PostgreSQL service data-directory flag could not be parsed.', 'postgres');

    set('preparing', 'Preparing destination...');
    try {
      const st = fs.statSync(dest);
      if (!st.isDirectory()) fail('Destination exists but is not a folder.', 'disk');
      if (fs.readdirSync(dest).length > 0) {
        // Resume-safe: a non-empty destination is only acceptable when it is
        // clearly a previous copy of THIS source (same PG_VERSION). Robocopy
        // /MIR then syncs only the delta — no duplicate full copy.
        let resume = false;
        try {
          const dv = fs.readFileSync(path.join(dest, 'PG_VERSION'), 'utf8').trim();
          resume = !!srcVersion && dv === srcVersion;
        } catch {}
        if (!resume) fail('Destination folder must be empty.', 'disk');
        set('preparing', 'Resuming previous copy...');
      }
    } catch (e) {
      if (e.kind) throw e;
      if (e && e.code !== 'ENOENT') fail('Destination cannot be used.', 'disk');
      try {
        fs.mkdirSync(dest, { recursive: true });
      } catch {
        fail('Destination cannot be created. Check permissions and free space.', 'permission');
      }
    }
    try {
      fs.accessSync(dest, fs.constants.W_OK);
    } catch {
      fail('Administrator permission is required to write to the destination.', 'permission');
    }

    set('stopping', 'Stopping PostgreSQL service...');
    await stopServiceClean(serviceName);

    set('copying', 'Copying PostgreSQL data...', { copiedBytes: 0 });
    const totalBytes = dirSizeBytes(src);
    if (!totalBytes || totalBytes <= 0) fail('Could not measure the source data directory.', 'disk');
    set('copying', 'Copying PostgreSQL data...', { copiedBytes: 0, totalBytes, stagePercent: 0 });

    const copyPromise = runRobocopy(src, dest);
    let copyResult = null;
    copyPromise.then((r) => { copyResult = r; });
    for (;;) {
      await sleep(2000);
      if (copyResult) break;
      let copied = null;
      try {
        copied = dirSizeBytes(dest);
      } catch {}
      const frac = copied !== null && totalBytes > 0 ? Math.min(1, copied / totalBytes) : 0;
      set('copying', 'Copying PostgreSQL data...', { copiedBytes: copied, totalBytes, stagePercent: Math.floor(frac * 100) });
    }
    if (!copyResult.ok) fail(`${copyResult.error || 'Copy failed.'} The original data was not modified.`, 'disk');
    set('copying', 'Copying PostgreSQL data...', { copiedBytes: totalBytes, totalBytes, stagePercent: 100, exitCode: copyResult.exitCode });

    set('verifying', 'Verifying copied data...');
    verifyCopyOnDisk(src, dest, srcVersion, totalBytes);

    set('configuring', 'Updating PostgreSQL configuration...');
    const newBinPath = originalBinPath.replace(/-D\s+("[^"]+"|\S+)/, `-D "${dest}"`);
    const updated = await applyBinPath(serviceName, newBinPath);
    if (!updated.includes(dest)) fail('PostgreSQL configuration change could not be confirmed.', 'postgres');
    configChanged = true;

    set('starting', 'Starting PostgreSQL...');
    await startServiceClean(serviceName);

    writeProgress({ status: 'done', stage: 'done', operation: 'PostgreSQL is running on the new location.', copiedBytes: totalBytes, totalBytes, stagePercent: 100, error: null, errorKind: null, rolledBack: false, newDir: dest, serviceName });
  } catch (e) {
    // Roll back ONLY if we already re-pointed the service; otherwise the
    // original configuration is still in place. Never delete any data.
    let rolledBack = false;
    let msg = (e && e.message) || 'Migration failed.';
    const kind = (e && e.kind) || 'unknown';
    if (configChanged && serviceName && originalBinPath) {
      try {
        await applyBinPath(serviceName, originalBinPath);
        configChanged = false;
        rolledBack = true;
        try {
          await startServiceClean(serviceName);
          msg += ' Previous configuration was restored and PostgreSQL is running on the original location.';
        } catch {
          msg += ' Previous configuration was restored but PostgreSQL could not be restarted automatically.';
        }
      } catch (re) {
        msg += ` Previous configuration could not be restored automatically: ${String((re && re.message) || re).slice(0, 160)}`;
      }
    }
    try {
      writeProgress({ status: 'failed', stage: 'failed', operation: 'Migration did not complete.', copiedBytes: null, totalBytes: null, stagePercent: null, error: msg, errorKind: kind, rolledBack });
    } catch {}
    process.exitCode = 1;
  }
}

main().catch((e) => {
  try {
    const jobIdx = process.argv.indexOf('--jobDir');
    const jobDir = jobIdx >= 0 ? process.argv[jobIdx + 1] : null;
    if (jobDir && fs.existsSync(jobDir)) {
      fs.writeFileSync(path.join(jobDir, 'progress.json'), JSON.stringify({
        status: 'failed', stage: 'failed', operation: 'Migration did not complete.',
        copiedBytes: null, totalBytes: null, stagePercent: null,
        error: String((e && e.message) || e), errorKind: 'unknown', rolledBack: false,
      }));
    }
  } catch {}
  process.exitCode = 1;
});
