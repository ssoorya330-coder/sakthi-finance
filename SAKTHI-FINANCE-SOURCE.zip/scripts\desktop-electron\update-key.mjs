import { generateKeyPairSync, createPublicKey } from 'node:crypto'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
await mkdir('desktop-private', { recursive: true })
let privateKey
try { privateKey = await readFile('desktop-private/update-signing.pem', 'utf8') }
catch (error) {
  if (error.code !== 'ENOENT') throw error
  const keys = generateKeyPairSync('ed25519', { privateKeyEncoding: { type: 'pkcs8', format: 'pem' }, publicKeyEncoding: { type: 'spki', format: 'pem' } })
  privateKey = keys.privateKey
  await writeFile('desktop-private/update-signing.pem', privateKey, { flag: 'wx' })
}
console.log(createPublicKey(privateKey).export({ type: 'spki', format: 'pem' }))
