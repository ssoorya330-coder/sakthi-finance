import { mkdtemp, writeFile, readdir, appendFile, readFile } from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import { DesktopUpdates } from '../../electron/updates'
async function main() {
  const root = await mkdtemp(path.resolve('test-reports/usb-update-'))
  const { version } = JSON.parse(await readFile('package.json', 'utf8'))
  const manifest = path.resolve(`release/electron/SakthiFinance-${version}.sfupdate.json`)
  const update = new DesktopUpdates(root, '1.0.0')
  await update.select(manifest)
  assert.equal(update.status().ready, true)
  assert.equal(update.status().release?.version,version)
  await update.prepareInstall() // Verify only: deliberately never launch installer.
  const folders = await readdir(path.join(root,'updates'))
  const staged = path.join(root,'updates',folders[0],'SakthiFinanceUpdate.exe')
  await appendFile(staged,'QA tamper test')
  await assert.rejects(update.prepareInstall())
  const current = new DesktopUpdates(root,version)
  await current.select(manifest)
  assert.equal(current.status().ready,false)
  await writeFile('test-reports/USB_UPDATE_PACKAGE_TEST.json',JSON.stringify({date:new Date().toISOString(),tests:[
    {test:'Actual signed installer stages locally without executing it',status:'PASS'},
    {test:'Hash verified again before installation is permitted',status:'PASS'},
    {test:'Tampering with staged installer blocks installation',status:'PASS'},
    {test:'Same version is rejected',status:'PASS'}
  ],retainedIsolatedTestFolder:root},null,2))
  console.log('4 package integration checks passed; no installer executed and no finance database accessed.')
}
main().catch(()=>{console.error('Update package integration check failed');process.exitCode=1})
