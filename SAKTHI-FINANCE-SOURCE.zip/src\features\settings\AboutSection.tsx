'use client'

import { useState, useCallback, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Info,
  Code2,
  FileText,
  Sparkles,
  Activity,
  User,
  Scale,
  Copy,
  Check,
  RefreshCw,
  FileCode,
  Terminal,
  Monitor,
  Mail,
  Globe,
  Database,
  Cloud,
  Wifi,
  WifiOff,
  Lock,
  Zap,
  Clock,
  Palette,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import SystemInfoDialog from './SystemInfoDialog'
import { useAppVersion } from '@/hooks/use-app-version'

const BUILD = 'Production'
const RELEASE_DATE = 'July 2026'
const COPYRIGHT = '© 2026 Sakthi Finance'
const DEVELOPER = 'Soorya S'
const PROJECT = 'Sakthi Finance'
const SUPPORT_EMAIL = 'support@sakthifinance.com'
const WEBSITE = 'https://sakthifinance.com'

const appInfo = [
  { label: 'Application Name', value: 'Sakthi Finance', icon: Sparkles },
  { label: 'Version', value: '', icon: Code2 },
  { label: 'Build', value: BUILD, icon: Zap },
  { label: 'Release Date', value: RELEASE_DATE, icon: Clock },
  { label: 'Platform', value: 'Windows / Web', icon: Monitor },
  { label: 'Framework', value: 'Next.js 16 + React 19', icon: Code2 },
  { label: 'Language', value: 'TypeScript', icon: FileCode },
  { label: 'UI Framework', value: 'Tailwind CSS + shadcn/ui', icon: Palette },
  { label: 'Database', value: 'SQLite (Offline) / PostgreSQL (Online)', icon: Database },
  { label: 'Authentication', value: 'Custom', icon: Lock },
  { label: 'Synchronization', value: 'Offline + Online', icon: RefreshCw },
]

const features = [
  'Customer Management',
  'Loan Management',
  'Payment Collection',
  'Payment History',
  'Dashboard Analytics',
  'Reports',
  'Offline Mode',
  'Online Synchronization',
  'Automatic Backup',
  'Export PDF',
  'Export Excel',
  'Secure Authentication',
]

const systemStatus = [
  { label: 'SQLite', status: 'Connected', color: 'emerald', icon: Database },
  { label: 'Cloud Database', status: 'Connected', color: 'emerald', icon: Cloud },
  { label: 'Synchronization', status: 'Active', color: 'emerald', icon: RefreshCw },
  { label: 'Application Status', status: 'Healthy', color: 'emerald', icon: Activity },
]

function Card({
  children,
  className,
  delay = 0,
}: {
  children: React.ReactNode
  className?: string
  delay?: number
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: [0.16, 1, 0.3, 1] }}
      className={cn(
        'bg-white rounded-[20px] border border-slate-100 p-6',
        'shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)]',
        className
      )}
    >
      {children}
    </motion.div>
  )
}

function CardHeader({
  icon: Icon,
  title,
}: {
  icon: React.FC<{ className?: string }>
  title: string
}) {
  return (
    <div className="flex items-center gap-3 mb-5">
      <div className="w-9 h-9 rounded-xl bg-[var(--primary-soft)] flex items-center justify-center">
        <Icon className="w-4.5 h-4.5 text-[var(--primary)]" />
      </div>
      <h3 className="text-base font-bold text-slate-900">{title}</h3>
    </div>
  )
}

function StatusBadge({ status, color }: { status: string; color: string }) {
  const colorMap: Record<string, string> = {
    emerald: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    amber: 'bg-amber-50 text-amber-700 border-amber-200',
    red: 'bg-red-50 text-red-700 border-red-200',
  }

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border',
        colorMap[color] || colorMap.emerald
      )}
    >
      <span
        className={cn(
          'w-1.5 h-1.5 rounded-full',
          color === 'emerald' && 'bg-emerald-500',
          color === 'amber' && 'bg-amber-500',
          color === 'red' && 'bg-red-500'
        )}
      />
      {status}
    </span>
  )
}

export default function AboutSection() {
  const appVersion = useAppVersion()
  const [copied, setCopied] = useState(false)
  const [showSystemInfo, setShowSystemInfo] = useState(false)
  const [isOnline, setIsOnline] = useState(
    typeof navigator === 'undefined' ? true : navigator.onLine
  )

  useEffect(() => {
    const on = () => setIsOnline(true)
    const off = () => setIsOnline(false)
    window.addEventListener('online', on)
    window.addEventListener('offline', off)
    return () => {
      window.removeEventListener('online', on)
      window.removeEventListener('offline', off)
    }
  }, [])

  const statusList = isOnline
    ? [
        ...systemStatus,
        { label: 'Internet', status: 'Online', color: 'emerald', icon: Wifi },
      ]
    : [
        ...systemStatus,
        { label: 'Internet', status: 'Offline', color: 'amber', icon: WifiOff },
      ]

  const handleCopyVersion = useCallback(() => {
    navigator.clipboard.writeText(`${PROJECT} ${appVersion} (${BUILD})`)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }, [appVersion])

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight mb-1">About Sakthi Finance</h2>
        <p className="text-sm text-slate-500">Enterprise Finance & Loan Management System</p>
      </div>

      <Card delay={0.1}>
        <CardHeader icon={Info} title="Application Information" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {appInfo.map((item) => {
            const Icon = item.icon as React.ComponentType<{ className?: string }>
            return (
              <div
                key={item.label}
                className="flex items-start gap-3 p-3 rounded-xl bg-slate-50/80 hover:bg-slate-50 transition-colors"
              >
                <div className="w-8 h-8 rounded-lg bg-white border border-slate-100 flex items-center justify-center flex-shrink-0 shadow-sm">
                  <Icon className="w-4 h-4 text-slate-500" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-0.5">{item.label}</p>
                  <p className="text-sm font-semibold text-slate-900 truncate">{item.label === 'Version' ? appVersion : item.value}</p>
                </div>
              </div>
            )
          })}
        </div>
      </Card>

      <Card delay={0.2}>
        <CardHeader icon={FileText} title="Description" />
        <p className="text-sm text-slate-600 leading-relaxed">
          Sakthi Finance is an enterprise loan and finance management application designed to manage
          customers, loans, payments, collections, reports, and synchronization between offline and online
          databases. The application is built for speed, reliability, and secure financial record management.
        </p>
      </Card>

      <Card delay={0.3}>
        <CardHeader icon={Sparkles} title="Features" />
        <div className="flex flex-wrap gap-2">
          {features.map((feature) => (
            <span
              key={feature}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100"
            >
              <Check className="w-3 h-3" />
              {feature}
            </span>
          ))}
        </div>
      </Card>

      <Card delay={0.4}>
        <CardHeader icon={Activity} title="System Status" />
        <div className="space-y-3">
          {statusList.map((item) => {
            const Icon = item.icon as React.ComponentType<{ className?: string }>
            return (
              <div
                key={item.label}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-50/80 hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-white border border-slate-100 flex items-center justify-center shadow-sm">
                    <Icon className="w-4 h-4 text-slate-500" />
                  </div>
                  <span className="text-sm font-medium text-slate-700">{item.label}</span>
                </div>
                <StatusBadge status={item.status} color={item.color} />
              </div>
            )
          })}
        </div>
      </Card>

      <Card delay={0.5}>
        <CardHeader icon={User} title="Developer Information" />
        <div className="space-y-3">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50/80 hover:bg-slate-50 transition-colors">
            <div className="w-8 h-8 rounded-lg bg-white border border-slate-100 flex items-center justify-center shadow-sm">
              <User className="w-4 h-4 text-slate-500" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Developer</p>
              <p className="text-sm font-semibold text-slate-900">{DEVELOPER}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50/80 hover:bg-slate-50 transition-colors">
            <div className="w-8 h-8 rounded-lg bg-white border border-slate-100 flex items-center justify-center shadow-sm">
              <Sparkles className="w-4 h-4 text-slate-500" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Project</p>
              <p className="text-sm font-semibold text-slate-900">{PROJECT}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50/80 hover:bg-slate-50 transition-colors">
            <div className="w-8 h-8 rounded-lg bg-white border border-slate-100 flex items-center justify-center shadow-sm">
              <Mail className="w-4 h-4 text-slate-500" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Support</p>
              <p className="text-sm font-semibold text-slate-900">{SUPPORT_EMAIL}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50/80 hover:bg-slate-50 transition-colors">
            <div className="w-8 h-8 rounded-lg bg-white border border-slate-100 flex items-center justify-center shadow-sm">
              <Globe className="w-4 h-4 text-slate-500" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Website</p>
              <p className="text-sm font-semibold text-[var(--primary)]">{WEBSITE}</p>
            </div>
          </div>
        </div>
      </Card>

      <Card delay={0.6}>
        <CardHeader icon={Scale} title="License" />
        <div className="space-y-3">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50/80 hover:bg-slate-50 transition-colors">
            <div className="w-8 h-8 rounded-lg bg-white border border-slate-100 flex items-center justify-center shadow-sm">
              <Scale className="w-4 h-4 text-slate-500" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">License</p>
              <p className="text-sm font-semibold text-slate-900">Private Enterprise Software</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50/80 hover:bg-slate-50 transition-colors">
            <div className="w-8 h-8 rounded-lg bg-white border border-slate-100 flex items-center justify-center shadow-sm">
              <Info className="w-4 h-4 text-slate-500" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Copyright</p>
              <p className="text-sm font-semibold text-slate-900">{COPYRIGHT}</p>
              <p className="text-xs text-slate-500 mt-0.5">All Rights Reserved</p>
            </div>
          </div>
        </div>
      </Card>

      <Card delay={0.7}>
        <CardHeader icon={Terminal} title="Actions" />
        <div className="flex flex-wrap gap-3">
          <button type="button" onClick={() => window.dispatchEvent(new Event('sakthi:open-updates'))} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 transition-colors active:scale-[0.98]">
            <RefreshCw className="w-4 h-4" />
            Check for Updates
          </button>
          <button className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors active:scale-[0.98]">
            <FileText className="w-4 h-4" />
            View Changelog
          </button>
          <button
            onClick={handleCopyVersion}
            className={cn(
              'inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-colors active:scale-[0.98]',
              copied
                ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
            )}
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied!' : 'Copy Version'}
          </button>
          <button
            onClick={() => setShowSystemInfo(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors active:scale-[0.98]"
          >
            <Monitor className="w-4 h-4" />
            System Information
          </button>
        </div>
      </Card>

      <SystemInfoDialog open={showSystemInfo} onOpenChange={setShowSystemInfo} />
    </div>
  )
}
