'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Settings,
  Info,
  Palette,
  Shield,
  UserRound,
  Landmark,
  ChevronRight,
} from 'lucide-react'
import AboutSection from './AboutSection'
import AccountSection from './AccountSection'
import AppearanceSection from './AppearanceSection'
import ApplicationSection from './ApplicationSection'
import SecuritySection from './SecuritySection'
import TopBar from '@/components/dashboard/TopBar'
import DeviceSyncPanel from '@/features/database/DeviceSyncPanel'
import ServerConnection from './ServerConnection'
import TabletConnection from './TabletConnection'

type SettingsTab = 'account' | 'appearance' | 'application' | 'security' | 'about' | 'sync'

interface MenuItem {
  id: SettingsTab
  label: string
  icon: React.FC<{ className?: string }>
}

const menuItems: MenuItem[] = [
  { id: 'sync', label: 'Synchronization', icon: Landmark },
  { id: 'account', label: 'Account', icon: UserRound },
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'application', label: 'Application', icon: Landmark },
  { id: 'security', label: 'Security', icon: Shield },
  { id: 'about', label: 'About', icon: Info },
]

export default function SettingsContent() {
  const [activeTab, setActiveTab] = useState<SettingsTab>('account')

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-[1400px] mx-auto">
        <TopBar title="Settings" subtitle="Manage your application preferences" />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="hidden lg:block mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
              <Settings className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Settings</h1>
              <p className="text-sm text-slate-500">Manage your application preferences</p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="bg-white rounded-[20px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] overflow-hidden sticky top-6">
              <div className="p-4 border-b border-slate-100">
                <h2 className="text-sm font-semibold text-slate-900">Settings Menu</h2>
              </div>
              <nav className="p-2">
                {menuItems.map((item) => {
                  const Icon = item.icon as React.ComponentType<{ className?: string }>
                  const isActive = activeTab === item.id

                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 group ${
                        isActive
                          ? 'bg-[var(--primary-soft)] text-[var(--primary)]'
                          : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                        }`}
                    >
                      <Icon
                        className={`w-5 h-5 flex-shrink-0 ${
                          isActive ? 'text-[var(--primary)]' : 'text-slate-400 group-hover:text-slate-600'
                        }`}
                      />
                      <span className="flex-1 text-left">{item.label}</span>
                      {isActive && (
                        <ChevronRight className="w-4 h-4 text-[var(--primary)]" />
                      )}
                    </button>
                  )
                })}
              </nav>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="min-w-0"
          >
            <AnimatePresence mode="wait">
              {activeTab === 'sync' && <div><TabletConnection /><ServerConnection /><DeviceSyncPanel connected={false} /></div>}
              {activeTab === 'account' && (
                <motion.div
                  key="account"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                >
                  <AccountSection />
                </motion.div>
              )}
              {activeTab === 'appearance' && (
                <motion.div
                  key="appearance"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                >
                  <AppearanceSection />
                </motion.div>
              )}
              {activeTab === 'application' && (
                <motion.div
                  key="application"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                >
                  <ApplicationSection />
                </motion.div>
              )}
              {activeTab === 'security' && (
                <motion.div
                  key="security"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                >
                  <SecuritySection />
                </motion.div>
              )}
              {activeTab === 'about' && (
                <motion.div
                  key="about"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                >
                  <AboutSection />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
