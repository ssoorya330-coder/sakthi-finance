import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { AUDIT_COLUMNS } from '@/server/audit-query'

export const dynamic = 'force-dynamic'

/** Single audit event with full before/after payload. Read-only. */
export async function GET(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuthWithPermission('audit:read')
  if (auth.error) return auth.error

  try {
    const { id } = await params
    const res = await dbQuery(
      `SELECT ${AUDIT_COLUMNS}
       FROM audit_events WHERE audit_id = $1 OR CAST(seq AS TEXT) = $1 LIMIT 1`,
      [id]
    )
    if (res.rows.length === 0) {
      return NextResponse.json({ error: 'Audit event not found' }, { status: 404 })
    }
    return NextResponse.json({ event: res.rows[0] })
  } catch (err: any) {
    return NextResponse.json({ error: 'Failed to load audit event' }, { status: 500 })
  }
}

