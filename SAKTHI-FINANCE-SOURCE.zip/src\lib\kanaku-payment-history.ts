import type { DbLoan } from '@/services/api-client'
import { customerPaymentLedger, mapPayment } from './payment-history'

export type HistoryKanaku = DbLoan & {
  paid_amount?: number | string
  outstanding?: number | string
  legacy_paid_amount?: number | string
  snapshot_paid_amount?: number | string
  installment?: number | string
}

export const kanakuLabel = (loan: HistoryKanaku) => `Cycle ${loan.cycle_number ?? '—'} · Kanaku ${loan.kanaku_number ?? '—'}`

/** Defense in depth: never use customer-wide store history for a loan statement. */
export function selectedKanakuPayments(rows: Record<string, any>[], loan: HistoryKanaku) {
  const matching = rows.filter(row => String(row.customer_id) === String(loan.customer_id) && String(row.loan_id) === String(loan.loan_id))
  return customerPaymentLedger(matching.map(mapPayment), String(loan.customer_id), Math.max(0, Number(loan.total_amount) - Number(loan.snapshot_paid_amount ?? loan.legacy_paid_amount ?? 0)))
}

export async function fetchKanakuPayments(api: { fetchPayments: (params: { customerId: string; loanId: string }) => Promise<{ data: any[] }> }, loan: HistoryKanaku) {
  const result = await api.fetchPayments({ customerId: String(loan.customer_id), loanId: String(loan.loan_id) })
  return selectedKanakuPayments(result.data, loan)
}

/** Display the next unpaid scheduled installment; never modifies loan amounts. */
export function nextKanakuDueDate(loan: HistoryKanaku): string | null {
  if (loan.status === 'Completed' || Number(loan.outstanding) === 0) return null
  const installment = Number(loan.installment_amount || loan.installment)
  const duration = Number(loan.duration)
  const start = new Date(`${String(loan.loan_date).slice(0, 10)}T00:00:00Z`)
  if (!Number.isFinite(start.getTime()) || !Number.isFinite(installment) || Math.round(installment * 100) <= 0 || !Number.isFinite(duration) || duration <= 0) return loan.due_date || null
  const period = Math.min(duration, Math.floor(Math.round(Number(loan.paid_amount || 0) * 100) / Math.round(installment * 100)) + 1)
  const next = new Date(start)
  if (loan.loan_type === 'Daily' || loan.loan_type === 'Weekly') next.setUTCDate(next.getUTCDate() + period * (loan.loan_type === 'Weekly' ? 7 : 1))
  else if (loan.loan_type === 'Monthly' || loan.loan_type === 'Yearly') {
    next.setUTCDate(1)
    next.setUTCMonth(next.getUTCMonth() + period * (loan.loan_type === 'Yearly' ? 12 : 1))
    next.setUTCDate(Math.min(start.getUTCDate(), new Date(Date.UTC(next.getUTCFullYear(), next.getUTCMonth() + 1, 0)).getUTCDate()))
  } else return loan.due_date || null
  const day = next.toISOString().slice(0, 10)
  return loan.due_date && day > String(loan.due_date).slice(0, 10) ? String(loan.due_date).slice(0, 10) : day
}
