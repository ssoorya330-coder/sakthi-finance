import fs from 'fs'
import os from 'os'
import path from 'path'
import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'

export const dynamic = 'force-dynamic'

const JOB_PREFIX = 'sakthi-pg-migrate-'
/** How long to keep reporting "waiting for approval" before calling it denied. */
const APPROVAL_TIMEOUT_MS = 150000

/** Poll the elevated worker's real progress (phase + actual bytes on disk). */
export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  const jobId = request.nextUrl.searchParams.get('id') || ''
  if (!/^[0-9a-f]{24}$/.test(jobId)) {
    return NextResponse.json({ error: 'Migration job id is required.' }, { status: 400 })
  }
  const jobDir = path.join(os.tmpdir(), JOB_PREFIX + jobId)
  try {
    const st = fs.statSync(jobDir)
    if (!st.isDirectory()) throw new Error('missing')
  } catch {
    return NextResponse.json({ status: 'failed', error: 'Unknown migration job.' })
  }

  try {
    const raw = fs.readFileSync(path.join(jobDir, 'progress.json'), 'utf8')
    return NextResponse.json(JSON.parse(raw))
  } catch {
    // No progress yet: still waiting for UAC approval, or approval timed out.
    try {
      const startedAt = fs.statSync(path.join(jobDir, 'params.json')).mtimeMs
      if (Date.now() - startedAt > APPROVAL_TIMEOUT_MS) {
        return NextResponse.json({
          status: 'failed',
          elevationDenied: true,
          error: 'Administrator permission is required to move the PostgreSQL data directory.',
        })
      }
    } catch {}
    return NextResponse.json({ status: 'awaiting-approval' })
  }
}
