import { requireAuth } from '@/lib/api-utils'
import { ensureSchema, getPool } from '@/server/database'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  const auth = await requireAuth()
  if (auth.error) return auth.error
  await ensureSchema()
  const client = await getPool().connect()
  try {
    await client.query('LISTEN app_notifications')
  } catch (error) {
    client.release(true)
    throw error
  }
  const encoder = new TextEncoder()
  let cleanup = () => {}
  const stream = new ReadableStream({
    start(controller) {
      let closed = false
      let heartbeat: ReturnType<typeof setInterval> | undefined
      let expiry: ReturnType<typeof setTimeout> | undefined
      const send = (event: string, data: unknown) => {
        if (!closed) controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`))
      }
      const onNotification = (event: { payload?: string }) => {
        try {
          const data = JSON.parse(event.payload || '{}')
          if (data.userId === auth.user.userId) send('notification', { id: data.id, title: data.title, kind: data.kind })
        } catch { /* Ignore unrelated malformed database messages. */ }
      }
      cleanup = () => {
        if (closed) return
        closed = true
        clearInterval(heartbeat)
        clearTimeout(expiry)
        request.signal.removeEventListener('abort', cleanup)
        client.removeListener('notification', onNotification)
        client.removeListener('error', cleanup)
        client.release(true)
        try { controller.close() } catch { /* Reader already cancelled. */ }
      }
      client.on('notification', onNotification)
      client.on('error', cleanup)
      request.signal.addEventListener('abort', cleanup, { once: true })
      if (request.signal.aborted) { cleanup(); return }
      send('ready', {})
      heartbeat = setInterval(() => send('heartbeat', {}), 15000)
      // Reconnect periodically to recheck authentication and release resources.
      expiry = setTimeout(cleanup, 55000)
    },
    cancel() { cleanup() },
  })
  return new Response(stream, { headers: { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-store', 'X-Accel-Buffering': 'no' } })
}
