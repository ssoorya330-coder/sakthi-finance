/**
 * Database entry point (server-side only).
 *
 * This module was missing (empty `src/db/` folder) which broke any
 * `@/db` import. The real implementation lives in `src/server/database.ts`
 * (pool + helpers) and `src/server/schema.ts` (auto-init). This file simply
 * re-exports that implementation so both `@/db` and `@/server/database`
 * resolve to the same pool.
 *
 * NEVER import this from a client component — it holds DB credentials.
 */
export {
  getPool,
  dbQuery,
  dbTransaction,
  testConnection,
  ensureSchema,
  getDatabaseStatus,
  isDatabaseConnected,
  closePool,
  gracefulShutdown,
  setDbType,
  setManualDbConfig,
  getDbType,
} from '@/server/database';
export { initializeDatabase, verifyTables } from '@/server/schema';
