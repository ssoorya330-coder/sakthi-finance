﻿'use client'
import { useCallback, useEffect, useRef, useState } from 'react'
import {
  RefreshCw, CheckCircle2, XCircle, HardDrive, Server,
  Download, Upload, RotateCcw, FileJson, Activity, Info,
  Settings as SettingsIcon, Trash2, Plus, AlertTriangle, X, Loader2,
  Copy, Check, MoreVertical, FolderPlus,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import DatabaseHeader from './DatabaseHeader'
import StorageWizard, { formatBytes } from './StorageWizard'
import MigrationWizard from './MigrationWizard'
import { useQueryClient } from '@tanstack/react-query'
import { clearAppCache } from '@/lib/clear-app-cache'
import DeviceSyncPanel from './DeviceSyncPanel'

/* ============================== types ============================== */
interface DbStatus {
  connected: boolean
  database: string
  host: string
  port: number
  tables: number
  version?: string | null
  serverTime?: string | null
  dbSizeBytes?: number | null
  username?: string | null
  lastCheck?: string
  error?: string
  detail?: string
}
interface StorageInfo {
  dbSizeBytes: number
  tableCount: number
  breakdown: {
    applicationDataBytes: number
    tablesBytes: number
    indexesBytes: number
    logsBytes: number | null
    backupsBytes: number
    otherBytes: number
  }
}
interface TableInfo { name: string; totalBytes: number; heapBytes: number; indexBytes: number }
interface RecordCounts { customers: string; loans: string; payments: string; completed: string; aborted: string }
interface SystemInfo {
  dataDirectory: string | null
  dataDirSizeBytes: number | null
  drive: { root: string; totalBytes: number; freeBytes: number; usedBytes: number } | null
}
interface StorageLocation {
  id: string; name: string; path: string; drive: string; purpose: string
  maxBytes: number | null; status: string; lastUsedAt: string | null
  driveTotalBytes: number | null; driveFreeBytes: number | null; driveUsedBytes: number | null
  reachable: boolean
}
interface BackupRecord {
  id: string; filename: string; sizeBytes: number; storageName: string | null
  storageLocationId?: string | null
  status: string; pgVersion: string | null; createdAt: string; exists: boolean
}

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, { credentials: 'include', ...init })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error((data as any).error || `Request failed (${res.status})`)
  return data as T
}

/** "2026-09-12 10:24:17 AM" */
function fmtDateTime(iso: string | null | undefined): string {
  if (!iso) return 'Unavailable'
  try {
    const d = new Date(iso)
    const pad = (n: number) => String(n).padStart(2, '0')
    let h = d.getHours()
    const ampm = h >= 12 ? 'PM' : 'AM'
    h = h % 12 || 12
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(h)}:${pad(d.getMinutes())}:${pad(d.getSeconds())} ${ampm}`
  } catch {
    return 'Unavailable'
  }
}
function shortVersion(v: string | null | undefined): string {
  if (!v) return 'Unavailable'
  return v.split(' ').slice(0, 2).join(' ')
}

/* ============================== bits ============================== */
function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn('bg-white rounded-[18px] border border-slate-200/70 shadow-[0_1px_2px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.05)] p-5', className)}>
      {children}
    </div>
  )
}
function CardHead({ title, subtitle, right }: { title: string; subtitle: string; right?: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 mb-4">
      <div>
        <h3 className="text-[15px] font-bold text-slate-900 tracking-tight">{title}</h3>
        <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>
      </div>
      {right}
    </div>
  )
}
function Dot({ tone }: { tone: 'green' | 'red' | 'amber' | 'slate' }) {
  const m = { green: 'bg-emerald-500', red: 'bg-red-500', amber: 'bg-amber-500', slate: 'bg-slate-300' }
  return <span className={cn('inline-block w-2 h-2 rounded-full', m[tone])} />
}
function Bar({ pct, color }: { pct: number; color: string }) {
  return (
    <div className="h-2 rounded-full bg-slate-200/80 overflow-hidden">
      <div className="h-full rounded-full transition-all duration-700" style={{ width: `${Math.min(100, Math.max(0, pct))}%`, backgroundColor: color }} />
    </div>
  )
}
function Modal({ title, subtitle, onClose, children, wide }: { title: string; subtitle?: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className={cn('w-full bg-white rounded-[22px] shadow-2xl max-h-[90vh] overflow-y-auto', wide ? 'max-w-[720px]' : 'max-w-[520px]')}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 sticky top-0 bg-white rounded-t-[22px]">
          <div>
            <h3 className="text-base font-bold text-slate-900">{title}</h3>
            {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500"><X className="w-4 h-4" /></button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  )
}
function Donut({ segments, centerValue, centerLabel, size = 168 }: { segments: Array<{ value: number; color: string }>; centerValue: string; centerLabel: string; size?: number }) {
  const total = segments.reduce((s, x) => s + x.value, 0)
  const R = 70
  const C = 2 * Math.PI * R
  let acc = 0
  return (
    <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox="0 0 168 168">
        <circle cx="84" cy="84" r={R} fill="none" stroke="#EEF2F7" strokeWidth="24" />
        {total > 0 && segments.map((s, i) => {
          if (s.value <= 0) return null
          const frac = s.value / total
          const el = (
            <circle
              key={i} cx="84" cy="84" r={R} fill="none" stroke={s.color} strokeWidth="24"
              strokeDasharray={`${frac * C} ${C}`}
              strokeDashoffset={-acc * C}
              strokeLinecap="butt"
              transform="rotate(-90 84 84)"
            />
          )
          acc += frac
          return el
        })}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none px-6 text-center">
        <span className="text-xl font-extrabold text-slate-900 tracking-tight leading-none">{centerValue}</span>
        <span className="text-[10px] font-medium text-slate-400 mt-1.5">{centerLabel}</span>
      </div>
    </div>
  )
}

/* ============================== page ============================== */
const SEG_COLORS = ['var(--primary)', '#D97706', 'var(--secondary)', '#3B82F6', '#10B981', '#CBD5E1']

export default function DatabasePage() {
  const queryClient = useQueryClient()
  const [clearingCache, setClearingCache] = useState(false)
  const cacheClearInProgress = useRef(false)
  const [cacheMessage, setCacheMessage] = useState<{ ok: boolean; text: string } | null>(null)
  const [status, setStatus] = useState<DbStatus | null>(null)
  const [storage, setStorage] = useState<StorageInfo | null>(null)
  const [fullTables, setFullTables] = useState<TableInfo[]>([])
  const [recordCounts, setRecordCounts] = useState<RecordCounts | null>(null)
  const [system, setSystem] = useState<SystemInfo | null>(null)
  const [locations, setLocations] = useState<StorageLocation[]>([])
  const [backups, setBackups] = useState<BackupRecord[]>([])
  const storageSaveInProgress = useRef(false)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const [busy, setBusy] = useState<string | null>(null)
  const [svcState, setSvcState] = useState<string | null>(null)
  const [svcName, setSvcName] = useState<string | null>(null)
  const [svcStarting, setSvcStarting] = useState(false)

  const [wizardOpen, setWizardOpen] = useState(false)
  const [migrationOpen, setMigrationOpen] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [menuOpenId, setMenuOpenId] = useState<string | null>(null)
  const [editTarget, setEditTarget] = useState<StorageLocation | null>(null)
  const [removeTarget, setRemoveTarget] = useState<StorageLocation | null>(null)
  const [backupTab, setBackupTab] = useState<'backup' | 'restore' | 'export' | 'import'>('backup')
  const [confirmRestoreId, setConfirmRestoreId] = useState<string | null>(null)
  const [importFile, setImportFile] = useState<File | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const loadStatus = useCallback(async () => {
    try {
      const s = await api<DbStatus>('/api/database/status')
      setStatus(s)
      // When disconnected, find the actual reason: report a stopped Windows
      // service honestly (never fake Connected) and offer the safe start
      // mechanism the app already has. Non-admin callers get no service
      // info (403) — the page then simply stays Disconnected.
      if (!s?.connected) {
        try {
          const svc = await api<{ state?: string; name?: string | null }>('/api/database/migration/service')
          setSvcState(svc?.state || null)
          setSvcName(svc?.name || null)
        } catch {
          setSvcState(null)
          setSvcName(null)
        }
      } else {
        setSvcState(null)
        setSvcName(null)
      }
      return s
    } catch {
      setStatus({ connected: false, database: '', host: 'localhost', port: 5432, tables: 0 })
      return null
    }
  }, [])

  const loadAll = useCallback(async (spin = true) => {
    if (spin) setRefreshing(true)
    setLoadError(null)
    try {
      const s = await loadStatus()
      if (s?.connected) {
        const [st, tb, sys, loc, bak] = await Promise.all([
          api<StorageInfo>('/api/database/storage').catch(() => null),
          api<{ tables: TableInfo[]; recordCounts?: RecordCounts }>('/api/database/tables').catch(() => ({ tables: [], recordCounts: undefined })),
          api<SystemInfo>('/api/database/system').catch(() => null),
          api<{ locations: StorageLocation[] }>('/api/storage').catch(() => ({ locations: [] })),
          api<{ backups: BackupRecord[] }>('/api/database/backups').catch(() => ({ backups: [] })),
        ])
        setStorage(st)
        setFullTables(tb.tables || [])
        setRecordCounts(tb.recordCounts || null)
        setSystem(sys)
        setLocations(loc.locations || [])
        setBackups(bak.backups || [])
      }
    } catch (e: any) {
      setLoadError(e.message || 'Failed to load database information.')
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [loadStatus])

  useEffect(() => {
    loadAll()
    const t = setInterval(() => loadStatus(), 30000)
    return () => clearInterval(t)
  }, [loadAll, loadStatus])

  const connected = status?.connected === true
  const dbSize = status?.dbSizeBytes ?? storage?.dbSizeBytes ?? null
  const drive = system?.drive || null
  const driveLetter = drive ? drive.root.replace(/\\$/, '') : null
  const diskPctUsed = drive && drive.totalBytes > 0 ? (drive.usedBytes / drive.totalBytes) * 100 : null

  /* breakdown (bytes, truthful; % of database size) */
  const heap = storage?.breakdown.applicationDataBytes ?? 0
  const idx = storage?.breakdown.indexesBytes ?? 0
  const overhead = Math.max(0, fullTables.reduce((s, t) => s + Math.max(0, t.totalBytes - t.heapBytes - t.indexBytes), 0))
  const logs = storage?.breakdown.logsBytes ?? null
  const bakBytes = storage?.breakdown.backupsBytes ?? 0
  const other = dbSize !== null
    ? Math.max(0, dbSize - heap - overhead - idx - bakBytes - (logs || 0))
    : 0
  const denom = dbSize && dbSize > 0 ? dbSize : 0
  const pct = (v: number) => (denom > 0 ? `${((v / denom) * 100).toFixed(1)}%` : '—')
  const segRows = [
    { name: 'Application Data', value: heap, color: SEG_COLORS[0] },
    { name: 'Tables', value: overhead, color: SEG_COLORS[1] },
    { name: 'Indexes', value: idx, color: SEG_COLORS[2] },
    { name: 'Logs', value: logs, color: SEG_COLORS[3] },
    { name: 'Backups', value: bakBytes, color: SEG_COLORS[4] },
    { name: 'Other', value: other, color: SEG_COLORS[5] },
  ]

  const backupStorages = locations.filter((l) => l.status === 'Active' && ['Database Backups', 'Application Backups', 'General Storage'].includes(l.purpose))
  const defaultStorage = backupStorages[0] || null
  const latestBackup = backups.find((b) => b.status === 'Successful' && b.exists) || backups[0] || null

  const freePct = drive && drive.totalBytes > 0 ? (drive.freeBytes / drive.totalBytes) * 100 : null
  const diskTone = !drive ? 'slate' : freePct !== null && freePct < 5 ? 'red' : freePct !== null && freePct < 10 ? 'amber' : 'green'
  const health: Array<[string, string, 'green' | 'red' | 'amber' | 'slate']> = [
    ['Database', connected ? 'Healthy' : 'Down', connected ? 'green' : 'red'],
    ['PostgreSQL', connected ? 'Connected' : 'Disconnected', connected ? 'green' : 'red'],
    ['Disk', !drive ? 'Unavailable' : diskTone === 'green' ? 'Healthy' : diskTone === 'amber' ? 'Low space' : 'Critical', diskTone],
    ['Storage', locations.some((l) => l.status === 'Active') ? 'Healthy' : 'None', locations.some((l) => l.status === 'Active') ? 'green' : 'slate'],
    ['Backup', latestBackup ? 'Available' : 'Not Configured', latestBackup ? 'green' : 'amber'],
  ]

  async function doBackup() {
    if (storageSaveInProgress.current) return
    const target = defaultStorage
    if (!target || !target.reachable) {
      setMsg({ ok: false, text: 'Selected storage is unavailable. Reconnect it or explicitly select another storage folder. Nothing was saved elsewhere.' })
      return
    }
    if (backupStorages.length === 0) {
      setMsg({ ok: false, text: 'No backup storage configured. Add a local storage location first.' })
      return
    }
    storageSaveInProgress.current = true
    setBusy('backup')
    setMsg(null)
    try {
      const d = await api<{ backup: { filename: string; sizeBytes: number } }>('/api/database/backups', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ storage_location_id: target.id }),
      })
      setMsg({ ok: true, text: `Backup successful: ${d.backup.filename} (${formatBytes(d.backup.sizeBytes)}).` })
      loadAll(false)
    } catch (e: any) {
      setMsg({ ok: false, text: e.message })
    } finally {
      storageSaveInProgress.current = false
      setBusy(null)
    }
  }
  async function doRestore(id: string) {
    setBusy('restore')
    setMsg(null)
    try {
      await api('/api/database/restore', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ backup_id: id, confirmed: true }) })
      setMsg({ ok: true, text: 'Database restored successfully.' })
      setConfirmRestoreId(null)
      loadAll(false)
    } catch (e: any) {
      setMsg({ ok: false, text: e.message })
    } finally {
      setBusy(null)
    }
  }
  async function doExport() {
    setBusy('export')
    try {
      const res = await fetch('/api/database/export', { credentials: 'include' })
      if (!res.ok) {
        const d = await res.json().catch(() => ({}))
        throw new Error((d as any).error || 'Export failed.')
      }
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `sakthi-finance-export-${new Date().toISOString().slice(0, 10)}.json.gz`
      a.click()
      URL.revokeObjectURL(url)
      setMsg({ ok: true, text: 'Export downloaded.' })
    } catch (e: any) {
      setMsg({ ok: false, text: e.message })
    } finally {
      setBusy(null)
    }
  }
  async function doImport() {
    if (!importFile) return
    setBusy('import')
    setMsg(null)
    try {
      const form = new FormData()
      form.append('file', importFile)
      form.append('confirmed', 'true')
      const res = await fetch('/api/database/import', { method: 'POST', credentials: 'include', body: form })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error((data as any).error || 'Import failed.')
      setMsg({ ok: true, text: 'Import completed successfully.' })
      setImportFile(null)
      loadAll(false)
    } catch (e: any) {
      setMsg({ ok: false, text: e.message })
    } finally {
      setBusy(null)
    }
  }
  async function doRemove(id: string) {
    setBusy('remove')
    try {
      await api(`/api/storage/${id}`, { method: 'DELETE' })
      setMsg({ ok: true, text: 'Storage configuration removed. Files on the drive were kept.' })
      setRemoveTarget(null)
      loadAll(false)
    } catch (e: any) {
      setMsg({ ok: false, text: e.message })
    } finally {
      setBusy(null)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[var(--background)]">
        <DatabaseHeader />
        <div className="pt-20 px-4 max-w-[1400px] mx-auto flex items-center justify-center py-24">
          <Loader2 className="w-6 h-6 animate-spin text-[var(--primary)]" />
          <span className="ml-2 text-sm text-slate-500">Loading database information…</span>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <DatabaseHeader />
      <div className="pt-16 px-4 sm:px-6 lg:px-8 py-6 max-w-[1400px] mx-auto space-y-5">

        {/* ================= HEADER ================= */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-transparent flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 25.6 25.6" className="w-8 h-8 block shrink-0" role="img" aria-label="PostgreSQL"><style>{`.B{stroke-linecap:round}.C{stroke-linejoin:round}.D{stroke-linejoin:miter}.E{stroke-width:.716}`}</style><g fill="none" stroke="#fff"><path d="M18.983 18.636c.163-1.357.114-1.555 1.124-1.336l.257.023c.777.035 1.793-.125 2.4-.402 1.285-.596 2.047-1.592.78-1.33-2.89.596-3.1-.383-3.1-.383 3.053-4.53 4.33-10.28 3.227-11.687-3.004-3.84-8.205-2.024-8.292-1.976l-.028.005c-.57-.12-1.2-.19-1.93-.2-1.308-.02-2.3.343-3.054.914 0 0-9.277-3.822-8.846 4.807.092 1.836 2.63 13.9 5.66 10.25C8.29 15.987 9.36 14.86 9.36 14.86c.53.353 1.167.533 1.834.468l.052-.044a2.01 2.01 0 0 0 .021.518c-.78.872-.55 1.025-2.11 1.346-1.578.325-.65.904-.046 1.056.734.184 2.432.444 3.58-1.162l-.046.183c.306.245.285 1.76.33 2.842s.116 2.093.337 2.688.48 2.13 2.53 1.7c1.713-.367 3.023-.896 3.143-5.81" fill="#000" stroke="#000" strokeLinecap="butt" strokeWidth="2.149" className="D" /><path d="M23.535 15.6c-2.89.596-3.1-.383-3.1-.383 3.053-4.53 4.33-10.28 3.228-11.687-3.004-3.84-8.205-2.023-8.292-1.976l-.028.005a10.31 10.31 0 0 0-1.929-.201c-1.308-.02-2.3.343-3.054.914 0 0-9.278-3.822-8.846 4.807.092 1.836 2.63 13.9 5.66 10.25C8.29 15.987 9.36 14.86 9.36 14.86c.53.353 1.167.533 1.834.468l.052-.044a2.02 2.02 0 0 0 .021.518c-.78.872-.55 1.025-2.11 1.346-1.578.325-.65.904-.046 1.056.734.184 2.432.444 3.58-1.162l-.046.183c.306.245.52 1.593.484 2.815s-.06 2.06.18 2.716.48 2.13 2.53 1.7c1.713-.367 2.6-1.32 2.725-2.906.088-1.128.286-.962.3-1.97l.16-.478c.183-1.53.03-2.023 1.085-1.793l.257.023c.777.035 1.794-.125 2.39-.402 1.285-.596 2.047-1.592.78-1.33z" fill="#336791" stroke="none" /><g className="E"><g className="B"><path d="M12.814 16.467c-.08 2.846.02 5.712.298 6.4s.875 2.05 2.926 1.612c1.713-.367 2.337-1.078 2.607-2.647l.633-5.017M10.356 2.2S1.072-1.596 1.504 7.033c.092 1.836 2.63 13.9 5.66 10.25C8.27 15.95 9.27 14.907 9.27 14.907m6.1-13.4c-.32.1 5.164-2.005 8.282 1.978 1.1 1.407-.175 7.157-3.228 11.687" className="C" /><path d="M20.425 15.17s.2.98 3.1.382c1.267-.262.504.734-.78 1.33-1.054.49-3.418.615-3.457-.06-.1-1.745 1.244-1.215 1.147-1.652-.088-.394-.69-.78-1.086-1.744-.347-.84-4.76-7.29 1.224-6.333.22-.045-1.56-5.7-7.16-5.782S7.99 8.196 7.99 8.196" strokeLinejoin="bevel" /></g><g className="C"><path d="M11.247 15.768c-.78.872-.55 1.025-2.11 1.346-1.578.325-.65.904-.046 1.056.734.184 2.432.444 3.58-1.163.35-.49-.002-1.27-.482-1.468-.232-.096-.542-.216-.94.23z" /><path d="M11.196 15.753c-.08-.513.168-1.122.433-1.836.398-1.07 1.316-2.14.582-5.537-.547-2.53-4.22-.527-4.22-.184s.166 1.74-.06 3.365c-.297 2.122 1.35 3.916 3.246 3.733" className="B" /></g></g><g fill="#fff" className="D"><path d="M10.322 8.145c-.017.117.215.43.516.472s.558-.202.575-.32-.215-.246-.516-.288-.56.02-.575.136z" strokeWidth=".239" /><path d="M19.486 7.906c.016.117-.215.43-.516.472s-.56-.202-.575-.32.215-.246.516-.288.56.02.575.136z" strokeWidth=".119" /></g><path d="M20.562 7.095c.05.92-.198 1.545-.23 2.524-.046 1.422.678 3.05-.413 4.68" className="B C E" /></g></svg>
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">Database Management</h1>
              <p className="text-xs sm:text-sm text-slate-500">Manage your PostgreSQL database, storage and local backups</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className={cn('inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border', connected ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200')}>
              <Dot tone={connected ? 'green' : 'red'} /> PostgreSQL {connected ? 'Connected' : 'Disconnected'}
            </span>
            <button onClick={() => loadAll()} disabled={refreshing} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50">
              <RefreshCw className={cn('w-3.5 h-3.5', refreshing && 'animate-spin')} /> Refresh
            </button>
          </div>
        </div>

        {loadError && (
          <div className="flex items-start gap-2 p-4 rounded-2xl bg-amber-50 border border-amber-200 text-sm text-amber-800">
            <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" /> {loadError}
          </div>
        )}

        <DeviceSyncPanel connected={connected} />
        {!connected && svcState === 'stopped' && (
          <div className="flex items-start gap-2 p-4 rounded-2xl bg-red-50 border border-red-200 text-sm text-red-700">
            <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span className="flex-1">PostgreSQL Windows service{svcName ? ` (“${svcName}”)` : ''} is stopped — that is why the database shows Disconnected.</span>
            <button
              disabled={svcStarting}
              onClick={async () => {
                setSvcStarting(true)
                try {
                  const r = await api<{ ok: boolean; message?: string; manualCommand?: string | null }>('/api/database/migration/service', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'start' }),
                  })
                  if (!r.ok) {
                    setMsg({ ok: false, text: r.manualCommand ? `${r.message} Run in an elevated terminal: ${r.manualCommand}` : (r.message || 'Could not start PostgreSQL.') })
                  }
                } catch (e: any) {
                  setMsg({ ok: false, text: e.message || 'Could not start PostgreSQL.' })
                } finally {
                  setSvcStarting(false)
                  loadAll(false)
                }
              }}
              className="px-3 py-1.5 rounded-lg bg-[var(--primary)] text-white text-xs font-semibold flex-shrink-0 disabled:opacity-50"
            >
              {svcStarting ? 'Starting…' : 'Start PostgreSQL'}
            </button>
          </div>
        )}
        {msg && (
          <div className={cn('flex items-start gap-2 p-4 rounded-2xl border text-sm', msg.ok ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-red-50 border-red-200 text-red-700')}>
            {msg.ok ? <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" /> : <XCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />}
            <span className="flex-1">{msg.text}</span>
            <button onClick={() => setMsg(null)}><X className="w-4 h-4 opacity-60" /></button>
          </div>
        )}

        <Card>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-[15px] font-bold text-slate-900">Application Cache</h3>
              <p className="text-xs text-slate-500 mt-1">Clear temporary cached files and refresh cached views on this browser. Saved records, offline changes and your login are kept.</p>
            </div>
            <button type="button" disabled={clearingCache || Boolean(busy)} onClick={async () => {
              if (cacheClearInProgress.current) return
              cacheClearInProgress.current = true
              setClearingCache(true)
              setCacheMessage(null)
              try {
                await queryClient.cancelQueries()
                const result = await clearAppCache('caches' in window ? window.caches : undefined)
                queryClient.removeQueries({ type: 'inactive' })
                await queryClient.resetQueries({ type: 'active' })
                setCacheMessage(result.failed
                  ? { ok: false, text: 'Some cached files could not be cleared. Please try again.' }
                  : { ok: true, text: 'Application cache cleared. Cached views refreshed; saved data is unchanged.' })
                await loadAll()
              } catch {
                setCacheMessage({ ok: false, text: 'Cache clearing could not finish. Please try again. Saved data is unchanged.' })
              } finally {
                cacheClearInProgress.current = false
                setClearingCache(false)
              }
            }} className="shrink-0 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50">
              {clearingCache ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              {clearingCache ? 'Clearing…' : 'Clear Cache'}
            </button>
          </div>
          {cacheMessage && <p role={cacheMessage.ok ? 'status' : 'alert'} className={cn('mt-3 text-xs', cacheMessage.ok ? 'text-emerald-700' : 'text-red-700')}>{cacheMessage.text}</p>}
        </Card>

        {/* ================= ROW 1 ================= */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">

          {/* ---------- PostgreSQL Database ---------- */}
          <Card>
            <h3 className="text-[15px] font-bold text-slate-900 tracking-tight">PostgreSQL Database</h3>
            <p className="text-xs text-slate-500 mt-0.5 mb-3">Local PostgreSQL (Offline)</p>
            <p className="text-[13px] font-semibold text-slate-800 flex items-center gap-1.5 mb-4">
              <Dot tone={connected ? 'green' : 'red'} /> {connected ? 'Connected' : 'Disconnected'}
            </p>
            <div className="grid grid-cols-2 gap-3">
              {[
                ['Total Database Size', dbSize !== null ? formatBytes(dbSize) : 'Unavailable', '(Database only)'],
                ['Data Directory Size', system?.dataDirSizeBytes != null ? formatBytes(system.dataDirSizeBytes) : 'Unavailable', '(PostgreSQL files)'],
                ['Disk Capacity', drive ? formatBytes(drive.totalBytes) : 'Unavailable', driveLetter ? `(Local Drive ${driveLetter})` : '(Local drive)'],
                ['Disk Free Space', drive ? formatBytes(drive.freeBytes) : 'Unavailable', freePct !== null ? `(${freePct.toFixed(1)}% remaining)` : ''],
              ].map(([label, value, sub]) => (
                <div key={label as string} className="rounded-xl bg-slate-50 border border-slate-100 px-3 py-2.5">
                  <p className="text-[10.5px] font-medium text-slate-500 leading-tight">{label}</p>
                  <p className="text-[17px] font-extrabold text-slate-900 tracking-tight mt-0.5 tabular-nums">{value}</p>
                  <p className="text-[10.5px] text-slate-400">{sub}</p>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <Bar pct={diskPctUsed ?? 0} color="var(--primary)" />
              <p className="text-xs text-slate-500 mt-2">
                {drive ? `${formatBytes(drive.usedBytes)} used of ${formatBytes(drive.totalBytes)} (${(diskPctUsed || 0).toFixed(1)}%)` : 'Disk usage unavailable'}
              </p>
            </div>
          </Card>

          {/* ---------- Database Details ---------- */}
          <Card>
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <h3 className="text-[15px] font-bold text-slate-900 tracking-tight">Database Details</h3>
                <p className="text-xs text-slate-500 mt-0.5">Connection and configuration information</p>
              </div>
              <button onClick={() => setSettingsOpen(true)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 bg-white hover:bg-slate-50 flex-shrink-0">
                <SettingsIcon className="w-3.5 h-3.5" /> Settings
              </button>
            </div>
            <div className="text-[13px]">
              {[
                ['Database Type', 'PostgreSQL'],
                ['Version', shortVersion(status?.version)],
                ['Host', status?.host || 'localhost'],
                ['Port', String(status?.port ?? 5432)],
                ['Database Name', status?.database || '—'],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-3 py-[7px] border-b border-slate-100">
                  <span className="text-slate-500">{k}</span>
                  <span className="font-semibold text-slate-900 text-right break-all">{v}</span>
                </div>
              ))}
              <div className="flex justify-between gap-3 py-[7px] border-b border-slate-100">
                <span className="text-slate-500">Connection Status</span>
                <span className="font-semibold text-slate-900 inline-flex items-center gap-1.5"><Dot tone={connected ? 'green' : 'red'} /> {connected ? 'Connected' : 'Disconnected'}</span>
              </div>
              <div className="py-[7px] border-b border-slate-100">
                <p className="text-slate-500">PostgreSQL Server Time</p>
                <p className="font-semibold text-slate-900 text-right tabular-nums">{fmtDateTime(status?.serverTime)}</p>
              </div>
              {[
                ['Database Size', dbSize !== null ? formatBytes(dbSize) : 'Unavailable'],
                ['Tables', status?.tables ?? storage?.tableCount ?? 'Unavailable'],
              ].map(([k, v]) => (
                <div key={k as string} className="flex justify-between gap-3 py-[7px] border-b border-slate-100">
                  <span className="text-slate-500">{k}</span>
                  <span className="font-semibold text-slate-900 tabular-nums">{v}</span>
                </div>
              ))}
              <div className="py-[7px]">
                <p className="text-slate-500">Last Database Check</p>
                <p className="font-semibold text-slate-900 text-right tabular-nums">{fmtDateTime(status?.lastCheck)}</p>
              </div>
            </div>
          </Card>

          {/* ---------- Local PostgreSQL Storage ---------- */}
          <Card>
            <h3 className="text-[15px] font-bold text-slate-900 tracking-tight">Local PostgreSQL Storage</h3>
            <p className="text-xs text-slate-500 mt-0.5 mb-4">Your data is stored locally on this computer.</p>
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Storage Location</p>
            <div className="flex items-center gap-2 rounded-xl bg-slate-50 border border-slate-100 px-3 py-2.5 mb-4">
              <p className="flex-1 min-w-0 text-[12.5px] font-mono text-slate-800 truncate">{system?.dataDirectory || 'Unavailable'}</p>
              {system?.dataDirectory && (
                <button
                  title="Copy path"
                  onClick={() => navigator.clipboard?.writeText(system.dataDirectory as string).catch(() => {})}
                  className="w-7 h-7 rounded-lg hover:bg-slate-200/70 flex items-center justify-center text-slate-500 flex-shrink-0"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <p className="text-[13px] font-bold text-slate-900 mb-2">Local Disk ({driveLetter || '—'})</p>
            <div className="space-y-1.5 text-[13px] mb-3">
              {[
                ['Total', drive ? formatBytes(drive.totalBytes) : 'Unavailable'],
                ['Used', drive ? formatBytes(drive.usedBytes) : 'Unavailable'],
                ['Free', drive ? formatBytes(drive.freeBytes) : 'Unavailable'],
              ].map(([k, v]) => (
                <div key={k as string} className="flex justify-between">
                  <span className="text-slate-500">{k}:</span>
                  <span className="font-bold text-slate-900 tabular-nums">{v}</span>
                </div>
              ))}
            </div>
            <div className="rounded-xl bg-slate-50 border border-slate-100 px-3 py-2.5 flex justify-between items-center">
              <span className="text-[13px] font-semibold text-slate-700">PostgreSQL Database</span>
              <span className="text-[13px] font-bold text-slate-900 tabular-nums">Size: {dbSize !== null ? formatBytes(dbSize) : 'Unavailable'}</span>
            </div>
            <button onClick={() => setMigrationOpen(true)} className="mt-3 w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50">
              Migrate Data Directory to Another Disk
            </button>
          </Card>
        </div>

        {/* ================= ROW 2 ================= */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-5">

          {/* ---------- Storage Usage Breakdown ---------- */}
          <Card className="xl:col-span-4">
            <CardHead title="Storage Usage Breakdown" subtitle="How your local database storage is being used" />
            {denom > 0 ? (
              <>
                <div className="flex justify-center py-1">
                  <Donut
                    segments={segRows.filter((s) => s.value !== null && (s.value as number) > 0).map((s) => ({ value: s.value as number, color: s.color }))}
                    centerValue={formatBytes(dbSize)}
                    centerLabel="Total Used"
                  />
                </div>
                <div className="mt-3">
                  {segRows.map((s) => (
                    <div key={s.name} className="flex items-center gap-2 py-[7px] border-b border-slate-100 last:border-0">
                      <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: s.color }} />
                      <span className="text-[13px] text-slate-600 flex-1">{s.name}</span>
                      {s.value === null ? (
                        <span className="text-xs text-slate-400">Unavailable</span>
                      ) : (
                        <span className="text-right">
                          <span className="block text-[13px] font-bold text-slate-900 tabular-nums leading-tight">{formatBytes(s.value)}</span>
                          <span className="block text-[11px] text-slate-400 tabular-nums">{pct(s.value)}</span>
                        </span>
                      )}
                    </div>
                  ))}
                  <div className="flex items-center gap-2 py-[7px]">
                    <span className="text-[13px] font-bold text-slate-900 flex-1">Total Used</span>
                    <span className="text-right">
                      <span className="block text-[13px] font-extrabold text-slate-900 tabular-nums leading-tight">{formatBytes(dbSize)}</span>
                      <span className="block text-[11px] text-slate-400 tabular-nums">100%</span>
                    </span>
                  </div>
                </div>
                <div className="mt-3 rounded-xl bg-amber-50/70 border border-amber-100 p-3.5 flex gap-2.5">
                  <Info className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-[13px] font-bold text-slate-900">About Storage Usage</p>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      Your database uses {formatBytes(dbSize)} out of {drive ? formatBytes(drive.totalBytes) : 'unavailable disk space'}
                      {diskPctUsed !== null && dbSize !== null && drive ? ` (${((dbSize / drive.totalBytes) * 100).toFixed(1)}%)` : ''}.
                      You can manage storage by configuring additional local storage if needed.
                    </p>
                  </div>
                </div>
              </>
            ) : (
              <p className="text-sm text-slate-500 py-8 text-center">Storage breakdown unavailable{connected ? '' : ' (database disconnected)'}</p>
            )}
          </Card>

          {/* ---------- Additional Storage ---------- */}
          <Card className="xl:col-span-4">
            <div className="flex items-start justify-between gap-3 mb-4">
              <div>
                <h3 className="text-[15px] font-bold text-slate-900 tracking-tight">Additional Storage</h3>
                <p className="text-xs text-slate-500 mt-0.5">Configured local storage locations for backups and additional data.</p>
              </div>
              <button onClick={() => setWizardOpen(true)} className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222] flex-shrink-0">
                <Plus className="w-3.5 h-3.5" /> Add Storage
              </button>
            </div>
            {locations.length === 0 ? (
              <div className="text-center py-10 border border-dashed border-slate-200 rounded-2xl">
                <HardDrive className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="text-sm text-slate-500">No additional storage configured</p>
              </div>
            ) : (
              <div className="space-y-4 max-h-[560px] overflow-y-auto pr-0.5">
                {locations.map((loc) => {
                  const usedPct = loc.driveTotalBytes ? ((loc.driveUsedBytes || 0) / loc.driveTotalBytes) * 100 : null
                  const isDefault = defaultStorage?.id === loc.id
                  return (
                    <div key={loc.id} className="rounded-2xl border border-slate-200 p-4">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="text-[14px] font-bold text-slate-900 truncate">{loc.drive ? `${loc.drive} ` : ''}{loc.name}</p>
                          <p className="text-[11.5px] font-mono text-slate-500 truncate">{loc.path}</p>
                        </div>
                        <div className="relative flex-shrink-0">
                          <button onClick={() => setMenuOpenId(menuOpenId === loc.id ? null : loc.id)} className="w-7 h-7 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-500">
                            <MoreVertical className="w-4 h-4" />
                          </button>
                          {menuOpenId === loc.id && (
                            <>
                              <div className="fixed inset-0 z-10" onClick={() => setMenuOpenId(null)} />
                              <div className="absolute right-0 top-8 z-20 w-36 rounded-xl border border-slate-200 bg-white shadow-xl py-1">
                                <button onClick={() => { setEditTarget(loc); setMenuOpenId(null) }} className="w-full text-left px-3 py-2 text-xs font-medium hover:bg-slate-50">Settings</button>
                                <button onClick={() => { setRemoveTarget(loc); setMenuOpenId(null) }} className="w-full text-left px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50">Remove</button>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 mt-2">
                        <span className={cn('inline-flex items-center gap-1 text-[11px] font-bold', loc.status === 'Active' ? 'text-emerald-700' : 'text-slate-400')}>
                          <Dot tone={loc.status === 'Active' ? 'green' : 'slate'} /> {loc.status}
                        </span>
                        {isDefault && <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[var(--primary-soft)] text-[var(--primary)] border border-[var(--primary)]/20">Default</span>}
                      </div>
                      <div className="grid grid-cols-3 gap-2 mt-3 text-center">
                        <div><p className="text-[10px] text-slate-400">Total Space</p><p className="text-[13px] font-bold tabular-nums">{formatBytes(loc.driveTotalBytes)}</p></div>
                        <div><p className="text-[10px] text-slate-400">Used</p><p className="text-[13px] font-bold tabular-nums">{formatBytes(loc.driveUsedBytes)}</p></div>
                        <div><p className="text-[10px] text-slate-400">Free</p><p className="text-[13px] font-bold tabular-nums">{formatBytes(loc.driveFreeBytes)}</p></div>
                      </div>
                      <p className="text-xs text-slate-500 mt-2">Purpose <span className="font-semibold text-slate-700">{loc.purpose}</span></p>
                      {usedPct !== null ? (
                        <>
                          <Bar pct={usedPct} color="#D97706" />
                          <p className="text-[11px] text-slate-400 mt-1 tabular-nums">{usedPct.toFixed(1)}% used</p>
                        </>
                      ) : (
                        <p className="text-[11px] text-slate-400 mt-1">{loc.reachable ? '' : 'Drive unreachable.'}</p>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </Card>

          {/* ---------- Right stack: Backup + Health ---------- */}
          <div className="xl:col-span-4 space-y-5">
            <Card>
              <CardHead title="Local Backup" subtitle="Manage your database backups and restore data." />
              <div className="grid grid-cols-2 gap-2 mb-4">
                {([
                  ['backup', 'Backup Database', Download],
                  ['restore', 'Restore Database', RotateCcw],
                  ['export', 'Export Data', FileJson],
                  ['import', 'Import Data', Upload],
                ] as const).map(([key, label, Icon]) => (
                  <button
                    key={key}
                    onClick={() => setBackupTab(key)}
                    className={cn(
                      'inline-flex items-center justify-center gap-1.5 px-2 py-2.5 rounded-xl text-[11.5px] font-semibold border transition-colors',
                      backupTab === key ? 'bg-[var(--primary)] text-white border-[var(--primary)]' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    )}
                  >
                    <Icon className="w-3.5 h-3.5" /> {label}
                  </button>
                ))}
              </div>

              {backupTab === 'backup' && (
                <div>
                  <div className="text-[13px] space-y-0">
                    <InfoRow label="Last Backup" value={latestBackup ? fmtDateTime(latestBackup.createdAt) : 'Never'} />
                    <InfoRow label="Size" value={latestBackup ? formatBytes(latestBackup.sizeBytes) : '—'} />
                    <InfoRow label="Location" value={latestBackup?.storageName || (backupStorages.length ? defaultStorage?.path || '—' : 'No backup storage configured')} mono />
                    <div className="flex justify-between gap-3 py-2 border-b border-slate-100">
                      <span className="text-slate-500">Status</span>
                      <span className="font-semibold inline-flex items-center gap-1.5">
                        {latestBackup ? (<><Dot tone={latestBackup.status === 'Successful' && latestBackup.exists ? 'green' : 'red'} /> {latestBackup.status}</>) : '—'}
                      </span>
                    </div>
                    <InfoRow label="Version" value={process.env.NEXT_PUBLIC_APP_VERSION ? `v${process.env.NEXT_PUBLIC_APP_VERSION}` : (latestBackup?.pgVersion ? shortVersion(latestBackup.pgVersion) : '—')} last />
                  </div>
                  <button onClick={() => doBackup()} disabled={Boolean(busy)} className="mt-3 w-full px-4 py-2.5 rounded-xl bg-[var(--primary)] text-white text-sm font-semibold hover:bg-[#912222] disabled:opacity-50 inline-flex items-center justify-center gap-2">
                    {busy === 'backup' && <Loader2 className="w-4 h-4 animate-spin" />} Backup Database
                  </button>
                  {backupStorages.length === 0 && <p className="text-[11px] text-amber-700 mt-2">No backup storage configured — add a local storage location first.</p>}
                </div>
              )}

              {backupTab === 'restore' && (
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {backups.length === 0 && <p className="text-[13px] text-slate-500 py-4 text-center">No backups available.</p>}
                  {backups.map((b) => (
                    <div key={b.id} className="rounded-xl border border-slate-100 px-3 py-2.5">
                      <p className="text-xs font-mono font-semibold text-slate-800 truncate">{b.filename}</p>
                      <p className="text-[11px] text-slate-500">{fmtDateTime(b.createdAt)} · {formatBytes(b.sizeBytes)}{b.exists ? '' : ' · file missing'}</p>
                      {confirmRestoreId === b.id ? (
                        <div className="flex gap-2 mt-2">
                          <button onClick={() => doRestore(b.id)} disabled={busy === 'restore' || !b.exists} className="flex-1 px-2 py-1.5 rounded-lg bg-red-600 text-white text-[11px] font-bold disabled:opacity-50">Confirm Overwrite</button>
                          <button onClick={() => setConfirmRestoreId(null)} className="flex-1 px-2 py-1.5 rounded-lg border text-[11px] font-semibold">Cancel</button>
                        </div>
                      ) : (
                        <button onClick={() => setConfirmRestoreId(b.id)} disabled={!b.exists} className="mt-2 text-[11px] font-bold text-[var(--primary)] hover:underline disabled:opacity-40 disabled:no-underline">
                          Restore this backup
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {backupTab === 'export' && (
                <div>
                  <p className="text-[13px] text-slate-600 mb-3">Download your records as a compressed JSON file (.json.gz) to save storage. Extract it to read the JSON. For database restore, use a full backup.</p>
                  <button onClick={doExport} disabled={busy === 'export'} className="w-full px-4 py-2.5 rounded-xl bg-[var(--primary)] text-white text-sm font-semibold hover:bg-[#912222] disabled:opacity-50 inline-flex items-center justify-center gap-2">
                    {busy === 'export' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />} Export Data
                  </button>
                </div>
              )}

              {backupTab === 'import' && (
                <div>
                  <input ref={fileRef} type="file" accept=".dump,.sql,.backup" className="hidden" onChange={(e) => {
                    const f = e.target.files?.[0]
                    if (f) setImportFile(f)
                    e.target.value = ''
                  }} />
                  {!importFile ? (
                    <button onClick={() => fileRef.current?.click()} className="w-full px-4 py-2.5 rounded-xl border border-dashed border-slate-300 text-sm font-medium text-slate-600 hover:bg-slate-50">
                      Choose backup file (.dump / .sql)
                    </button>
                  ) : (
                    <div className="space-y-2">
                      <p className="text-xs font-mono break-all">{importFile.name} ({formatBytes(importFile.size)})</p>
                      <WarnBox text="Importing overwrites the current database." />
                      <div className="flex gap-2">
                        <button onClick={() => setImportFile(null)} className="flex-1 px-3 py-2 rounded-xl border text-xs font-semibold">Cancel</button>
                        <button onClick={doImport} disabled={busy === 'import'} className="flex-1 px-3 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-bold disabled:opacity-50 inline-flex items-center justify-center gap-2">
                          {busy === 'import' && <Loader2 className="w-3.5 h-3.5 animate-spin" />} Import
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </Card>

            <Card>
              <CardHead title="Storage Health" subtitle="Current status of your database and storage" />
              <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-2 2xl:grid-cols-3 gap-2.5">
                {health.map(([label, value, tone]) => (
                  <div key={label} className="rounded-xl border border-slate-100 bg-slate-50/60 px-3 py-2.5 text-center">
                    <p className="text-[11px] font-medium text-slate-500">{label}</p>
                    <p className="text-[12.5px] font-bold text-slate-900 inline-flex items-center gap-1.5 mt-0.5"><Dot tone={tone} /> {value}</p>
                  </div>
                ))}
              </div>
              {diskTone === 'amber' && <p className="text-xs font-semibold text-amber-700 mt-3">Storage space is running low.</p>}
              {diskTone === 'red' && <p className="text-xs font-semibold text-red-700 mt-3">Critical: insufficient storage space.</p>}
            </Card>
          </div>
        </div>
      </div>

      <section aria-label="Database records and storage" className="mx-auto mb-6 max-w-[1400px] px-4 sm:px-6 lg:px-8">
        <Card>
          <CardHead title="Your Records & Storage" subtitle="Saved laptop records for your signed-in account. Pending tablet entries appear in Device Synchronization above." />
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3">
            {([['customers','Customers'],['loans','Kanaku / Loans'],['payments','Payment Records'],['completed','Completed Customers'],['aborted','Aborted Customers']] as const).map(([table,label])=><div key={table} className="rounded-xl border border-[var(--secondary)]/20 bg-[var(--background)] p-4">
              <p className="text-sm font-semibold text-slate-600">{label}</p>
              <p className="mt-1 text-2xl font-bold text-[var(--primary)]">{connected&&recordCounts?Number(recordCounts[table]).toLocaleString('en-IN'):'Unavailable'}</p>
              {table==='completed'||table==='aborted'?<><p className="mt-2 text-xs text-slate-500">Included in Customers table storage.</p><a href={`/dashboard/${table}-customers`} className="mt-3 inline-block text-sm font-semibold text-[var(--primary)] underline">View customer details →</a></>:<p className="mt-2 text-xs text-slate-500">Table: {table} · Storage: {connected&&fullTables.some(t=>t.name===table)?formatBytes(fullTables.find(t=>t.name===table)!.totalBytes):'Unavailable'}</p>}
            </div>)}
          </div>
          <div className="mt-4 space-y-2 text-sm text-slate-600">
            <p>Database tables: <b>{connected?fullTables.length:'Unavailable'}</b> · Total database storage: <b>{connected&&dbSize!==null?formatBytes(dbSize):'Unavailable'}</b></p>
            <p className="break-all">Stored at: <b>{connected?system?.dataDirectory||'Unavailable':'Database disconnected'}</b></p>
            <p className="text-xs text-slate-500">Table sizes include indexes and all accounts using each shared table. Record counts above are for your account only.</p>
          </div>
        </Card>
      </section>

      {/* ================= MODALS ================= */}
      <StorageWizard open={wizardOpen} onClose={() => setWizardOpen(false)} onConfigured={() => { loadAll(false); setMsg({ ok: true, text: 'Storage configured successfully.' }) }} />
      <MigrationWizard open={migrationOpen} onClose={() => { setMigrationOpen(false); loadAll(false) }} />

      {editTarget && (
        <StorageSettingsModal location={editTarget} onClose={() => setEditTarget(null)} onSaved={() => { setEditTarget(null); loadAll(false) }} />
      )}

      {removeTarget && (
        <Modal title="Remove this storage configuration?" onClose={() => setRemoveTarget(null)}>
          <p className="text-sm text-slate-600"><b className="text-slate-900">{removeTarget.name}</b> ({removeTarget.path}) will be removed.</p>
          <p className="text-sm text-slate-600 mt-2">This only removes the storage from Sakthi Finance. Existing files on the drive will not be deleted.</p>
          <div className="flex gap-2 mt-5">
            <button onClick={() => setRemoveTarget(null)} className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium hover:bg-slate-50">Cancel</button>
            <button onClick={() => doRemove(removeTarget.id)} disabled={busy === 'remove'} className="flex-1 px-4 py-2.5 rounded-xl bg-red-600 text-white text-sm font-medium hover:bg-red-700 disabled:opacity-50 inline-flex items-center justify-center gap-2">
              {busy === 'remove' && <Loader2 className="w-4 h-4 animate-spin" />} Remove
            </button>
          </div>
        </Modal>
      )}

      {settingsOpen && <ConnectionSettingsModal onClose={() => setSettingsOpen(false)} onChanged={() => loadAll(false)} />}
    </div>
  )
}

/* ============================== sub-parts ============================== */
function InfoRow({ label, value, mono, last }: { label: string; value: React.ReactNode; mono?: boolean; last?: boolean }) {
  return (
    <div className={cn('flex justify-between gap-3 py-2', !last && 'border-b border-slate-100')}>
      <span className="text-slate-500 flex-shrink-0">{label}</span>
      <span className={cn('font-semibold text-slate-900 text-right break-all', mono && 'font-mono text-[12px]')}>{value}</span>
    </div>
  )
}
function WarnBox({ text }: { text: string }) {
  return (
    <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-800">
      <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" /> {text}
    </div>
  )
}

function StorageSettingsModal({ location, onClose, onSaved }: { location: StorageLocation; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(location.name)
  const [purpose, setPurpose] = useState(location.purpose)
  const [allocation, setAllocation] = useState(location.maxBytes ? String(Math.round(location.maxBytes / 1073741824)) : '')
  const [status, setStatus] = useState(location.status)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function save() {
    setSaving(true)
    setError(null)
    try {
      let maxBytes: number | null = null
      if (allocation.trim()) {
        const gb = Number(allocation)
        if (!Number.isFinite(gb) || gb <= 0) throw new Error('Allocation must be a positive number of GB, or empty for available space.')
        maxBytes = Math.round(gb * 1024 ** 3)
      }
      await api(`/api/storage/${location.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, purpose, maxBytes, status }),
      })
      onSaved()
    } catch (e: any) {
      setError(e.message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <Modal title="Storage Settings" subtitle={location.path} onClose={onClose}>
      <div className="space-y-4">
        <div>
          <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} className="mt-1.5 w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--primary)]/30" />
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Purpose</label>
          <select value={purpose} onChange={(e) => setPurpose(e.target.value)} className="mt-1.5 w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm bg-white focus:outline-none">
            {['Database Backups', 'Application Backups', 'Documents', 'General Storage'].map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Max Allocation (GB, empty = available space)</label>
          <input value={allocation} onChange={(e) => setAllocation(e.target.value)} inputMode="decimal" placeholder="Available space" className="mt-1.5 w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--primary)]/30" />
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Status</label>
          <select value={status} onChange={(e) => setStatus(e.target.value)} className="mt-1.5 w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm bg-white focus:outline-none">
            <option value="Active">Active</option>
            <option value="Disabled">Disabled</option>
          </select>
        </div>
        {error && <p className="text-xs text-red-600">{error}</p>}
        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium hover:bg-slate-50">Cancel</button>
          <button onClick={save} disabled={saving} className="flex-1 px-4 py-2.5 rounded-xl bg-[var(--primary)] text-white text-sm font-medium hover:bg-[#912222] disabled:opacity-50 inline-flex items-center justify-center gap-2">
            {saving && <Loader2 className="w-4 h-4 animate-spin" />} Save
          </button>
        </div>
      </div>
    </Modal>
  )
}

function ConnectionSettingsModal({ onClose, onChanged }: { onClose: () => void; onChanged: () => void }) {
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'
  const [dbType, setDbType] = useState<'automatic' | 'manual'>('automatic')
  const [host, setHost] = useState('localhost')
  const [port, setPort] = useState(5432)
  const [database, setDatabase] = useState('sakthi_finance')
  const [user, setUser] = useState('postgres')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null)

  useEffect(() => {
    fetch(`${API_URL}/api/database/get-config`)
      .then((r) => r.json())
      .then((d) => {
        if (d.success) {
          if (d.databaseType === 'manual') setDbType('manual')
          setHost(d.host || 'localhost')
          setPort(Number(d.port) || 5432)
          setDatabase(d.database || 'sakthi_finance')
          setUser(d.user || 'postgres')
        }
      })
      .catch(() => setMsg({ ok: false, text: `Backend at ${API_URL} is unreachable.` }))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function call(path: string, body?: unknown) {
    setBusy(true)
    setMsg(null)
    try {
      const res = await fetch(`${API_URL}${path}`, {
        method: body === undefined ? 'GET' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: body === undefined ? undefined : JSON.stringify(body),
      })
      const data = await res.json().catch(() => ({}))
      if (path === '/api/database/status') {
        setMsg(data.connected ? { ok: true, text: `Connected — ${data.database} on ${data.host}:${data.port}.` } : { ok: false, text: data.detail || data.error || 'Not connected.' })
      } else {
        setMsg({ ok: true, text: (data as any).message || 'Done.' })
      }
      onChanged()
    } catch (e: any) {
      setMsg({ ok: false, text: e.message })
    } finally {
      setBusy(false)
    }
  }

  return (
    <Modal title="Connection Settings" subtitle="Local PostgreSQL connection (passwords are never displayed)" onClose={onClose}>
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          {(['automatic', 'manual'] as const).map((t) => (
            <button
              key={t}
              onClick={() => { setDbType(t); call('/api/database/set-type', { type: t }) }}
              className={cn('px-3 py-2.5 rounded-xl border text-sm font-medium capitalize', dbType === t ? 'border-[var(--primary)] bg-[var(--primary-soft)] text-[var(--primary)]' : 'border-slate-200 hover:bg-slate-50')}
            >
              {t}
            </button>
          ))}
        </div>
        {dbType === 'manual' && (
          <div className="grid grid-cols-2 gap-3">
            <label className="text-xs text-slate-600">Host<input value={host} onChange={(e) => setHost(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none" /></label>
            <label className="text-xs text-slate-600">Port<input type="number" value={port} onChange={(e) => setPort(Number(e.target.value))} className="mt-1 w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none" /></label>
            <label className="text-xs text-slate-600">Database<input value={database} onChange={(e) => setDatabase(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none" /></label>
            <label className="text-xs text-slate-600">User<input value={user} onChange={(e) => setUser(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none" /></label>
            <label className="text-xs text-slate-600 col-span-2">Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter to change" className="mt-1 w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none" /></label>
            <button disabled={busy} onClick={() => call('/api/database/set-manual-config', { host, port, database, user, ...(password ? { password } : {}) })} className="col-span-2 px-4 py-2.5 rounded-xl bg-[var(--primary)] text-white text-sm font-medium hover:bg-[#912222] disabled:opacity-50">
              Save Configuration
            </button>
          </div>
        )}
        <div className="grid grid-cols-3 gap-2">
          <button disabled={busy} onClick={() => call('/api/database/connect', {})} className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium hover:bg-slate-50 disabled:opacity-50">Connect</button>
          <button disabled={busy} onClick={() => call('/api/database/disconnect', {})} className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium hover:bg-slate-50 disabled:opacity-50">Disconnect</button>
          <button disabled={busy} onClick={() => call('/api/database/reconnect', {})} className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium hover:bg-slate-50 disabled:opacity-50">Reconnect</button>
        </div>
        {msg && <p className={cn('text-xs font-medium', msg.ok ? 'text-emerald-700' : 'text-red-600')}>{msg.text}</p>}
      </div>
    </Modal>
  )
}
