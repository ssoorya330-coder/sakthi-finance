import { NextResponse } from 'next/server'
import { getDatabaseStatus, dbQuery } from '@/server/database'

export async function GET() {
  try {
    const status = await getDatabaseStatus()
    // Extended details — all read-only server values, never credentials.
    let version: string | null = null
    let serverTime: string | null = null
    let dbSizeBytes: number | null = null
    let username: string | null = null
    if (status.connected) {
      try {
        const v = await dbQuery<{ version: string }>('SELECT version() AS version')
        version = v.rows[0]?.version || null
      } catch {}
      try {
        const t = await dbQuery<{ now: string }>('SELECT NOW() AS now')
        serverTime = t.rows[0]?.now || null
      } catch {}
      try {
        const s = await dbQuery<{ size: string }>('SELECT pg_database_size(current_database()) AS size')
        dbSizeBytes = Number(s.rows[0]?.size)
      } catch {}
      try {
        const u = await dbQuery<{ user: string }>('SELECT current_user AS user')
        username = u.rows[0]?.user || null
      } catch {}
    }
    return NextResponse.json({
      ...status,
      version,
      serverTime,
      dbSizeBytes,
      username,
      lastCheck: new Date().toISOString(),
    })
  } catch (err: any) {
    return NextResponse.json(
      { connected: false, database: 'unknown', error: err.message },
      { status: 500 }
    )
  }
}
