import { NextRequest, NextResponse } from 'next/server'
import { requireOwner } from '@/lib/api-utils'
import { canAssignRole, normalizeRole } from '@/config/rbac'
import { dbQuery } from '@/server/database'
import { actorFromAuthUser, requestMeta, recordAuditStandalone } from '@/server/audit'
import { rateLimit, rateLimitKey } from '@/lib/rate-limit'
import { isDeveloperEmail } from '@/config/developer-access'

const ASSIGNABLE_ROLES = ['admin', 'owner'] as const

async function auditDenied(
  request: NextRequest,
  authUser: { userId: string; name: string; role: string },
  entityId: string,
  reason: string
) {
  try {
    const meta = requestMeta(request)
    await recordAuditStandalone({
      action: 'UNAUTHORIZED_ACCESS',
      entityType: 'user',
      entityId,
      actor: actorFromAuthUser(authUser as any),
      ipAddress: meta.ip,
      clientInfo: meta.client,
      reason,
      result: 'FAILED',
    })
  } catch {}
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  // Owner-only endpoint: explicit rule role === 'owner'. Admin and
  // Customer are both rejected here, before any role logic below.
  const auth = await requireOwner()
  if (auth.error) return auth.error

  if (!rateLimit(rateLimitKey(request, 'admin-users-put'), 30, 60_000)) {
    return NextResponse.json({ error: 'Too many requests. Please slow down.' }, { status: 429 })
  }

  try {
    const { id } = await params
    const body = await request.json()
    const { is_active, role: newRoleRaw, reason } = body as {
      is_active?: boolean
      role?: string
      reason?: string
    }

    // Load the target user first (server-side, trusted source).
    const target = await dbQuery(
      `SELECT u.user_id, u.id, u.email, u.full_name, u.is_active, u.role, r.role_name FROM users u LEFT JOIN roles r ON u.role_id = r.role_id WHERE u.user_id = $1 OR u.id::text = $1 LIMIT 1`,
      [id]
    )
    if (target.rows.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }
    const row = target.rows[0]
    if(isDeveloperEmail(row.email) && (newRoleRaw !== undefined || is_active === false)) {
      return NextResponse.json({error:'Developer accounts cannot be demoted or disabled here.'},{status:403})
    }
    const targetRole = normalizeRole(row.role_name || row.role)
    const actorRole = normalizeRole(auth.user.role)
    const meta = requestMeta(request)
    const actor = actorFromAuthUser(auth.user)

    // Only owners may touch owner accounts.
    if (targetRole === 'owner' && actorRole !== 'owner') {
      await auditDenied(request, { userId: auth.user.userId, name: auth.user.name, role: auth.user.role }, row.user_id, 'Attempt to modify an Owner account')
      return NextResponse.json(
        { error: 'Only the Owner can modify an Owner account' },
        { status: 403 }
      )
    }

    const updates: string[] = []
    const values: any[] = []
    let paramIndex = 1
    const auditChanges: Array<{ field: string; label: string; before: any; after: any }> = []
    let roleChanged = false
    let statusChanged: 'deactivated' | 'reactivated' | null = null

    // ── Role change ──────────────────────────────────────────────
    if (newRoleRaw !== undefined) {
      const newRole = String(newRoleRaw).toLowerCase()
      if (!(ASSIGNABLE_ROLES as readonly string[]).includes(newRole)) {
        return NextResponse.json({ error: 'Invalid role' }, { status: 400 })
      }
      if (newRole === targetRole) {
        return NextResponse.json({ error: 'User already has this role' }, { status: 400 })
      }
      // Nobody may change their own role (prevents self-promotion and
      // accidental self-lockout).
      if (row.user_id === auth.user.userId) {
        await auditDenied(request, { userId: auth.user.userId, name: auth.user.name, role: auth.user.role }, row.user_id, 'Attempt to change own role')
        return NextResponse.json(
          { error: 'You cannot change your own role' },
          { status: 403 }
        )
      }
      // Owner accounts grant Owner only via explicit Owner action; admins
      // can never assign Owner (enforced by canAssignRole + target guard).
      if (!canAssignRole(actorRole, newRole)) {
        await auditDenied(request, { userId: auth.user.userId, name: auth.user.name, role: auth.user.role }, row.user_id, `Attempt to assign role '${newRole}'`)
        return NextResponse.json(
          { error: 'You do not have permission to assign this role' },
          { status: 403 }
        )
      }
      // Last-owner protection: never demote the only remaining Owner.
      if (targetRole === 'owner' && newRole !== 'owner') {
        const owners = await dbQuery(
          `SELECT COUNT(*) AS c FROM users u LEFT JOIN roles r ON u.role_id = r.role_id WHERE COALESCE(r.role_name, u.role) = 'owner' AND u.is_active IS NOT FALSE`
        )
        if (Number(owners.rows[0]?.c || 0) <= 1) {
          return NextResponse.json(
            { error: 'Cannot demote the only remaining Owner account' },
            { status: 403 }
          )
        }
      }
      const roleRow = await dbQuery('SELECT role_id FROM roles WHERE role_name = $1', [newRole])
      const roleId = roleRow.rows[0]?.role_id
      if (!roleId) {
        return NextResponse.json({ error: 'Role is not provisioned' }, { status: 500 })
      }
      updates.push(`role = $${paramIndex}`, `role_id = $${paramIndex + 1}`)
      values.push(newRole, roleId)
      paramIndex += 2
      auditChanges.push({ field: 'role', label: 'Role', before: targetRole, after: newRole })
      roleChanged = true
    }

    // ── Account status (activate / deactivate / suspend) ─────────
    if (is_active !== undefined) {
      const next = Boolean(is_active)
      const prev = row.is_active !== false
      if (next !== prev) {
        updates.push(`is_active = $${paramIndex}`)
        values.push(next)
        paramIndex += 1
        statusChanged = next ? 'reactivated' : reason === 'suspended' ? 'deactivated' : 'deactivated'
        auditChanges.push({ field: 'is_active', label: 'Account Active', before: prev, after: next })
      }
    }

    if (updates.length === 0) {
      return NextResponse.json({ error: 'No fields to update' }, { status: 400 })
    }

    updates.push(`updated_at = NOW()`)
    values.push(id)

    const result = await dbQuery(
      `UPDATE users SET ${updates.join(', ')} WHERE user_id = $${paramIndex} OR id::text = $${paramIndex} RETURNING *`,
      values
    )

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Audit log (legacy table, best-effort)
    await dbQuery(
      `INSERT INTO audit_logs (action, entity_type, entity_id, details, user_id)
       VALUES ('update', 'user', $1, $2, $3)`,
      [id, JSON.stringify({ is_active, role: newRoleRaw ?? undefined }), auth.user.userId]
    ).catch(() => {})

    if (roleChanged) {
      await recordAuditStandalone({
        action: 'ROLE_CHANGED',
        entityType: 'user',
        entityId: row.user_id,
        actor,
        ipAddress: meta.ip,
        clientInfo: meta.client,
        result: 'SUCCESS',
        changes: auditChanges.filter((c) => c.field === 'role'),
      })
    }
    if (statusChanged) {
      await recordAuditStandalone({
        action: 'USER_STATUS_CHANGED',
        entityType: 'user',
        entityId: row.user_id,
        actor,
        ipAddress: meta.ip,
        clientInfo: meta.client,
        reason: reason || statusChanged,
        result: 'SUCCESS',
        changes: auditChanges.filter((c) => c.field === 'is_active'),
      })
    }

    return NextResponse.json(result.rows[0])
  } catch (err: any) {
    console.error('[PUT /api/admin/users/:id] Error:', err.message)
    return NextResponse.json({ error: 'Failed to update user' }, { status: 500 })
  }
}

