'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import LoginActivityContent from '@/features/admin-access/LoginActivityContent'

export default function LoginActivityContentPage() {
  return (
    <ClientPageGate requireRole="owner">
      <LoginActivityContent />
    </ClientPageGate>
  )
}
