'use client'
import { hasPermission, type Role, type Permission } from '@/config/rbac'
import { applyLocal, loanGroup, materialize, pending } from './model'
import { localTransaction, readWorkspace } from './local'
import type { Row, SyncKind, SyncOperation, SyncSnapshot, SyncWorkspace } from './types'
import { activateSnapshot, validateSnapshot } from './snapshot'

const key=(user:string)=>`sf-device-mode:${user}`
export function deviceMode(user:string) {try{return localStorage.getItem(key(user))==='on'}catch{return false}}
async function json(url:string,init?:RequestInit) {
  const response=await fetch(url,{credentials:'include',cache:'no-store',signal:AbortSignal.timeout(60000),...init})
  const body=await response.json().catch(()=>({}))
  if(!response.ok)throw Object.assign(new Error(body.error||'Laptop connection failed.'),{status:response.status,body})
  return body
}
export async function prepareDevice(user:string) {
  if(!window.isSecureContext)throw new Error('Offline browser use requires HTTPS on the tablet. Connect using the laptop’s trusted HTTPS address, then prepare again.')
  if(!navigator.serviceWorker)throw new Error('This browser cannot open the app offline.')
  await navigator.serviceWorker.register('/sw.js')
  await navigator.serviceWorker.ready
  const existing=await readWorkspace(user)
  if(existing?.queue.some(pending))throw new Error('Sync or resolve your pending records before downloading a fresh snapshot.')
  const snapshot=await json('/api/device-sync/snapshot') as SyncSnapshot
  validateSnapshot(snapshot,user)
  if(snapshot.userId!==user)throw new Error('Account changed. Sign in again before preparing offline data.')
  // Download the shell and SQLite assets now, not when the tablet is offline.
  const cache=await caches.open('sakthi-finance-offline-shell-v2')
  for(const path of ['/dashboard','/dashboard/customers','/dashboard/add-customer','/dashboard/completed-customers','/dashboard/aborted-customers','/dashboard/settings','/database','/offline-sql/sql-wasm.js','/offline-sql/sql-wasm.wasm']) {
    const response=await fetch(path,{credentials:'include'})
    if(!response.ok||response.redirected)throw new Error('Offline pages could not be downloaded. Sign in and retry.')
    await cache.put(path,response.clone())
    if(response.headers.get('content-type')?.includes('text/html')) {
      const html=await response.text()
      const assets=[...html.matchAll(/(?:src|href)="([^"\s]+\.(?:js|css)(?:\?[^"\s]*)?)"/g)].map(m=>m[1]).filter(p=>p.startsWith('/_next/'))
      for(const asset of new Set(assets)) {const r=await fetch(asset);if(!r.ok)throw new Error('An offline application asset could not be downloaded. Retry preparation.');await cache.put(asset,r)}
    }
  }
  // Include lazy-loaded components, not only the scripts referenced by HTML.
  const manifest=await json('/api/device-sync/assets')
  if(!Array.isArray(manifest.assets)||!manifest.assets.length)throw new Error('Offline asset list is incomplete.')
  const assets:string[]=manifest.assets
  let next=0
  await Promise.all(Array.from({length:4},async()=>{while(next<assets.length){
    const asset=assets[next++]
    if(!asset.startsWith('/_next/static/'))throw new Error('Invalid offline asset path.')
    const r=await fetch(asset,{signal:AbortSignal.timeout(30000)})
    if(!r.ok)throw new Error('Could not prepare offline assets. Retry while connected.')
    await cache.put(asset,r)
  }}))
  await navigator.storage?.persist?.()
  await localTransaction(user,state=>{
    if(state?.queue.some(pending))throw new Error('New local records were added during preparation. Sync them first.')
    const queue=(state?.queue||[]).filter(op=>op.status!=='SYNCED')
    return{state:{enabled:true,deviceId:state?.deviceId||crypto.randomUUID(),snapshot,queue,mappings:state?.mappings||{},history:state?.history||[],lastSync:snapshot.capturedAt},value:null}
  })
  localStorage.setItem(key(user),'on')
  window.dispatchEvent(new Event('sf-device-sync-changed'))
}
export async function disableDevice(user:string) {
  await localTransaction(user,state=>{if(state?.queue.some(pending))throw new Error('Pending records must be synced before leaving device mode.');if(state)state.enabled=false;return{state,value:null}})
  localStorage.removeItem(key(user))
  window.dispatchEvent(new Event('sf-device-sync-changed'))
}

/** Used by the existing API client only after explicit device preparation. */
export async function localRequest(user:string,role:Role,method:string,url:string,input?:unknown):Promise<{handled:boolean;value?:any}> {
  if(!deviceMode(user))return{handled:false}
  const u=new URL(url,window.location.origin),path=u.pathname
  const entity=path.match(/^\/api\/(customer|loan|payment)(?:\/([^/]+))?$/)
  const handledGet=['/api/customers','/api/loans','/api/payments','/api/completed-customers','/api/aborted-customers','/api/search'].includes(path)||(entity?.[1]==='customer'&&entity[2])
  if(method==='GET'&&!handledGet)return{handled:false}
  if(method!=='GET'&&!entity)return{handled:false}
  return localTransaction(user,w=>{
    if(!w?.enabled)throw new Error('Offline database is not ready. Prepare this device again while connected.')
    const s=materialize(w)
    if(method==='GET') {
      const customerId=u.searchParams.get('customer_id'),loanId=u.searchParams.get('loan_id'),status=u.searchParams.get('status')
      let rows:Row[]=[]
      if(path==='/api/loans') rows=(customerId?loanGroup(s,customerId):s.loans).map(loan=>({...loan,customer_code:s.customers.find(c=>String(c.id)===String(loan.customer_id))?.customer_code}))
      else if(path==='/api/payments')rows=s.payments.filter(p=>(!customerId||String(p.customer_id)===customerId)&&(!loanId||String(p.loan_id)===loanId)&&(!u.searchParams.get('start_date')||p.payment_date>=u.searchParams.get('start_date')!)&&(!u.searchParams.get('end_date')||p.payment_date<=u.searchParams.get('end_date')!))
      else if(entity?.[2]) {const customer=s.customers.find(c=>String(c.id)===decodeURIComponent(entity[2]));if(!customer)throw new Error('Customer is not in this device snapshot.');return{state:w,value:{handled:true,value:customer}}}
      else rows=s.customers.filter(c=>(path!=='/api/completed-customers'||c.status==='Completed')&&(path!=='/api/aborted-customers'||c.status==='Aborted'))
      if(status&&status!=='all')rows=rows.filter(r=>r.status===status)
      const search=(u.searchParams.get('search')||u.searchParams.get('q')||'').toLowerCase()
      if(search)rows=rows.filter(r=>['full_name','phone_number','customer_code','area_name','city_name','business_name'].some(k=>String(r[k]||'').toLowerCase().includes(search)))
      const total=rows.length,page=Math.max(1,Number(u.searchParams.get('page'))||1),limit=Math.max(1,Number(u.searchParams.get('limit'))||total||1)
      return{state:w,value:{handled:true,value:{data:rows.slice((page-1)*limit,page*limit),total,page,limit,totalPages:Math.ceil(total/limit)}}}
    }
    if(method!=='POST'&&method!=='PUT')throw new Error('Deletion is not available in device mode. Sync pending work and return to online mode first.')
    const kind=entity![1] as SyncKind, permission=`${kind==='customer'?'customers':kind==='loan'?'loans':'payments'}:${method==='POST'?'create':'update'}` as Permission
    if(!hasPermission(role,permission))throw new Error('Your role does not allow this action.')
    const d=structuredClone(input||{}) as Row
    const recordId=method==='POST'?crypto.randomUUID():decodeURIComponent(entity![2]||'')
    const old=kind==='customer'?s.customers.find(c=>String(c.id)===recordId):kind==='loan'?s.loans.find(l=>String(l.loan_id)===recordId):s.payments.find(p=>String(p.payment_id)===recordId)
    const customerId=kind==='customer'?recordId:String(d.customer_id||old?.customer_id||'')
    if(method==='PUT'&&!old)throw new Error('Record is missing from the offline snapshot.')
    if(kind==='customer'&&method==='POST') {if(!String(d.full_name||'').trim())throw new Error('Customer name is required.');d.__localLoanId=crypto.randomUUID()}
    const enqueue=(id:string,data:Row)=>{
      const op:SyncOperation={id:crypto.randomUUID(),deviceId:w.deviceId,createdBy:user,kind,method,recordId:id,customerId,data,recordedAt:new Date().toISOString(),baseRevision:w.snapshot.revisions[customerId]||null,status:'PENDING'}
      if(kind==='payment'&&method==='POST'&&!data.payment_time)data.payment_time=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Kolkata',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(new Date(op.recordedAt))
      applyLocal(s,op);w.queue.push(op)
      return op
    }
    if(kind==='payment'&&method==='POST') {
      let remaining=Math.round(Number(d.amount)*100)
      if(!/^\d+(\.\d{1,2})?$/.test(String(d.amount))||remaining<=0)throw new Error('Enter a positive payment amount.')
      const targets=s.loans.filter(l=>String(l.customer_id)===customerId&&(!d.loan_id||String(l.loan_id)===String(d.loan_id))&&Number(l.outstanding)>0).sort((a,b)=>Number(a.cycle_number)-Number(b.cycle_number)||Number(a.kanaku_number)-Number(b.kanaku_number))
      if(remaining>targets.reduce((n,l)=>n+Math.round(Number(l.outstanding)*100),0))throw new Error('Received amount exceeds the available balance.')
      const records=[]
      for(const l of targets) {if(!remaining)break;const part=Math.min(remaining,Math.round(Number(l.outstanding)*100));remaining-=part;const id=crypto.randomUUID();enqueue(id,{...d,loan_id:l.loan_id,amount:part/100});records.push(s.payments.find(p=>p.payment_id===id))}
      if(remaining||!records.length)throw new Error('No Kanaku balance is available for this payment.')
      return{state:w,value:{handled:true,value:{...records[0],payments:records,sync_status:'PENDING'}}}
    }
    enqueue(recordId,d)
    const value=kind==='customer'?s.customers.find(c=>String(c.id)===recordId):kind==='loan'?s.loans.find(l=>String(l.loan_id)===recordId):s.payments.find(p=>String(p.payment_id)===recordId)
    return{state:w,value:{handled:true,value:{...value,sync_status:'PENDING'}}}
  },method!=='GET')
}

export async function synchronizeDevice(user:string) {
  if(!navigator.locks)throw new Error('Use a supported browser over HTTPS to synchronize safely.')
  return navigator.locks.request(`sakthi-sync:${user}`,{ifAvailable:true},async lock=>{
    if(!lock)throw new Error('Another tab is already synchronizing this device.')
    const count={synced:0,duplicates:0,failed:0,conflicts:0}
    let message='Synchronization completed.'
    const before=await readWorkspace(user)
    if(!before)throw new Error('Prepare this device before syncing.')
    // A lightweight database probe avoids downloading every record twice.
    const connection=await json('/api/device-sync/connection',{signal:AbortSignal.timeout(8000)})
    if(connection.userId!==user)throw new Error('Sign in to the same account used for these offline records.')
    await json('/api/device-sync/activity',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({event:'started',deviceId:before.deviceId})})
    for(;;) {
      const op=await localTransaction(user,w=>{
        const op=w?.queue.find(pending)
        if(op&&op.status!=='CONFLICT'){op.status='SYNCING';op.error=undefined}
        return{state:w,value:op?structuredClone(op):null}
      })
      if(!op)break
      if(op.status==='CONFLICT'){count.conflicts++;message='Review the conflict below, then sync again.';break}
      try {
        const confirmation=await json('/api/device-sync',{method:'POST',headers:{'Content-Type':'application/json','X-Sync-Owner':user},body:JSON.stringify(op)})
        if(confirmation.operationId!==op.id||confirmation.status!=='SYNCED')throw new Error('Laptop did not confirm this record. Retry safely.')
        await localTransaction(user,w=>{
          if(!w)throw new Error('Local database unavailable.')
          const saved=w.queue.find(p=>p.id===op.id)!
          saved.status='SYNCED';saved.error=undefined
          Object.assign(w.mappings,confirmation.mappings)
          w.snapshot.revisions[op.customerId]=confirmation.revision
          w.snapshot.revisions[confirmation.customerId]=confirmation.revision
          for(const next of w.queue.filter(p=>pending(p)&&(w.mappings[p.customerId]||p.customerId)===confirmation.customerId))next.baseRevision=confirmation.revision
          return{state:w,value:null}
        })
        count.synced++;if(confirmation.duplicate)count.duplicates++
      } catch(error:any) {
        await localTransaction(user,w=>{const failed=w?.queue.find(p=>p.id===op.id);if(failed){failed.status=error.status===409?'CONFLICT':'FAILED';failed.error=error.message;failed.serverRevision=error.body?.revision;failed.serverRecord=error.body?.record}return{state:w,value:null}})
        if(error.status===409)count.conflicts++;else count.failed++
        message=error.message;break
      }
    }
    const after=await readWorkspace(user)
    if(!after?.queue.some(pending)) {
      try {
        const snapshot=await json('/api/device-sync/snapshot') as SyncSnapshot
        if(snapshot.userId!==user)throw new Error('Account changed during synchronization.')
        await localTransaction(user,w=>{if(w)activateSnapshot(w,snapshot);return{state:w,value:null}})
      }catch {message='Uploads confirmed, but downloading the latest laptop records failed. Retry Sync Now.';count.failed++}
    }
    if(!count.failed&&!count.conflicts&&count.synced>0) {
      try {
        const storageId=localStorage.getItem('sf-backup-storage-id')
        await json('/api/database/backups',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(storageId?{storage_location_id:storageId}:{})})
        message+=' A verified backup was created in configured storage.'
      } catch(error:any) {message+=` Records are saved in PostgreSQL, but backup needs attention: ${error.message}`}
    }
    try {await json('/api/device-sync/activity',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({event:'finished',deviceId:before.deviceId,...count})})}
    catch {message+=' Sync summary audit could not upload; local history is retained.'}
    await localTransaction(user,w=>{w?.history.unshift({date:new Date().toISOString(),...count,message});return{state:w,value:null}})
    return{...count,message}
  })
}
export async function resolveConflict(user:string,id:string,choice:'tablet'|'laptop') {
  await localTransaction(user,w=>{
    const op=w?.queue.find(p=>p.id===id)
    if(!w||!op||op.status!=='CONFLICT')throw new Error('Conflict is no longer available.')
    if(choice==='tablet'){
      if(!op.serverRevision)throw new Error('This conflict cannot be overridden. Check the missing record or validation error on the laptop.')
      op.baseRevision=op.serverRevision;op.status='PENDING';op.error=undefined
    } else {op.discarded=true;op.error='User chose laptop version; original tablet entry retained here for review.'}
    return{state:w,value:null}
  })
}
