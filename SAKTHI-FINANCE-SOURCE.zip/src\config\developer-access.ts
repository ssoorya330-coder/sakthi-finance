/** Admin Access is a separate capability, not implied by the Owner role. */
export function isDeveloperEmail(email: string | null | undefined): boolean {
  return ['ssoorya330@gmail.com', 'soorya3312@gmail.com'].includes((email || '').trim().toLowerCase())
}
