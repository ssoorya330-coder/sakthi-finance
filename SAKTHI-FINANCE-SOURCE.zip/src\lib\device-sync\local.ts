'use client'
import type { SyncWorkspace } from './types'
import { sealImage, unsealImage, type SealedImage } from './vault'

let engine: Promise<any> | undefined
function sqlite(): Promise<any> {
  if (!engine) engine=new Promise((resolve,reject)=>{
    const init=()=> (window as any).initSqlJs({locateFile:()=>'/offline-sql/sql-wasm.wasm'}).then(resolve,reject)
    if((window as any).initSqlJs) {init();return}
    const script=document.createElement('script');script.src='/offline-sql/sql-wasm.js';script.onload=init
    script.onerror=()=>reject(new Error('SQLite is not downloaded. Prepare this device while connected to the laptop.'))
    document.head.appendChild(script)
  }).catch(error=>{engine=undefined;throw error})
  return engine
}
function open(): Promise<IDBDatabase> {
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open('sakthi-device-sqlite-v1',2)
    req.onupgradeneeded=()=>{for(const name of ['databases','keys'])if(!req.result.objectStoreNames.contains(name))req.result.createObjectStore(name)}
    req.onsuccess=()=>{req.result.onversionchange=()=>req.result.close();resolve(req.result)};req.onerror=()=>reject(req.error)
    req.onblocked=()=>reject(new Error('Close older Sakthi Finance tabs and retry. Local records are retained.'))
  })
}
function read<T>(db:IDBDatabase,store:string,id:string):Promise<T> {
  return new Promise((resolve,reject)=>{const r=db.transaction(store).objectStore(store).get(id);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})
}
function put(db:IDBDatabase,store:string,id:string,value:unknown):Promise<void> {
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(store,'readwrite',{durability:'strict'});tx.objectStore(store).put(value,id)
    tx.oncomplete=()=>resolve();tx.onabort=tx.onerror=()=>reject(tx.error||new Error('Local save failed. Keep this page open and retry.'))
  })
}
/** Shared cross-tab lock; crypto outside IDB transactions; atomic durable replacement. */
export async function localTransaction<T>(userId:string,fn:(state:SyncWorkspace|null)=>{state:SyncWorkspace|null;value:T},write=true):Promise<T> {
  if(!userId||!navigator.locks||!crypto.subtle)throw new Error('Offline storage requires a supported browser and trusted HTTPS.')
  return navigator.locks.request(`sf-vault:${userId}`,async()=>{
    const SQL=await sqlite(),storage=await open()
    let db:any
    try {
      const image=await read<SealedImage|Uint8Array|undefined>(storage,'databases',userId)
      let key=await read<CryptoKey|undefined>(storage,'keys',userId)
      const encrypted=!!image&&'version' in image&&image.version===2
      if(encrypted&&!key)throw new Error('Offline encryption key is missing. Do not clear storage.')
      if(!key){key=await crypto.subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt','decrypt']);await put(storage,'keys',userId,key)}
      const bytes=image?(encrypted?await unsealImage(image as SealedImage,key,userId):new Uint8Array(image as Uint8Array)):undefined
      db=new SQL.Database(bytes)
      db.run('CREATE TABLE IF NOT EXISTS workspace(id INTEGER PRIMARY KEY CHECK(id=1), data TEXT NOT NULL)')
      const rows=db.exec('SELECT data FROM workspace WHERE id=1')
      const current=rows.length?JSON.parse(String(rows[0].values[0][0])):null
      const outcome=fn(current)
      if((write||!encrypted)&&outcome.state){
        db.run('INSERT OR REPLACE INTO workspace(id,data) VALUES(1,?)',[JSON.stringify(outcome.state)])
        // Queue remains authoritative in workspace. Remove its legacy duplicate.
        db.run('DROP TABLE IF EXISTS sync_queue')
        db.run('VACUUM')
        await put(storage,'databases',userId,await sealImage(db.export(),key,userId))
        try{localStorage.removeItem(`sf-offline-customers-v1:${userId}`)}catch{/* The encrypted transaction has already committed. */}
      }
      if(write)window.dispatchEvent(new Event('sf-device-sync-changed'))
      return outcome.value
    }finally{db?.close();storage.close()}
  })
}
export const readWorkspace=(userId:string)=>localTransaction(userId,state=>({state,value:state}),false)

export async function downloadLocalRecovery(userId:string) {
  const password=window.prompt('Recovery password (at least 12 characters). Keep it separately; it cannot be recovered.')
  if(password===null)return
  if(password.length<12)throw new Error('Use at least 12 characters.')
  const state=await readWorkspace(userId)
  if(!state)throw new Error('No local database to export.')
  const salt=crypto.getRandomValues(new Uint8Array(16))
  const material=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveKey'])
  const key=await crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:310000,hash:'SHA-256'},material,{name:'AES-GCM',length:256},false,['encrypt'])
  const image=await sealImage(new TextEncoder().encode(JSON.stringify(state)),key,userId)
  const bytes=(v:ArrayBuffer|Uint8Array)=>Array.from(v instanceof Uint8Array?v:new Uint8Array(v))
  const payload={format:'sakthi-recovery-v2',userId,salt:bytes(salt),iterations:310000,...image,iv:bytes(image.iv),ciphertext:bytes(image.ciphertext)}
  const url=URL.createObjectURL(new Blob([JSON.stringify(payload)],{type:'application/json'}))
  const a=document.createElement('a');a.href=url;a.download=`SakthiFinance-encrypted-recovery-${Date.now()}.json`;a.click()
  setTimeout(()=>URL.revokeObjectURL(url),1000)
}
