import { dbQuery } from '@/server/database';

export interface GroupAccount {
  id: string;
  customer_code: string;
  full_name: string;
  status: string | null;
  /**
   * Customer-facing sequential number (1, 2, 3…) within this person's
   * group, ordered by account creation. Display only — never used for
   * queries or authorization (internal ids/codes are).
   */
  kanaku_no: number;
}

export interface PersonGroup {
  primaryId: string;
  groupIds: string[];
  accounts: GroupAccount[];
}

/**
 * Resolve the person group for a linked customers.id: all kanaku rows
 * sharing its normalized phone AND normalized name. Server-only.
 * A missing/empty phone never groups (single row only).
 */
export async function getPersonGroup(customerId: string): Promise<PersonGroup | null> {
  const primary = await dbQuery(
    `SELECT id, customer_code, full_name, phone_normalized FROM customers WHERE id = $1 LIMIT 1`,
    [customerId]
  );
  if (primary.rows.length === 0) return null;
  const p = primary.rows[0] as any;
  const normName = String(p.full_name || '').trim().toLowerCase().replace(/\s+/g, ' ');
  let accounts: GroupAccount[] = [
    { id: p.id, customer_code: p.customer_code, full_name: p.full_name, status: null, kanaku_no: 1 },
  ];
  if (p.phone_normalized && normName) {
    const group = await dbQuery(
      `SELECT id, customer_code, full_name, status FROM customers
       WHERE phone_normalized = $1
         AND LOWER(TRIM(REGEXP_REPLACE(COALESCE(full_name, ''), '\\s+', ' ', 'g'))) = $2
       ORDER BY created_at ASC, id ASC`,
      [p.phone_normalized, normName]
    );
    if (group.rows.length > 0) {
      accounts = group.rows.map((r: any, i: number) => ({
        id: r.id,
        customer_code: r.customer_code,
        full_name: r.full_name,
        status: r.status,
        kanaku_no: i + 1,
      }));
    }
  }
  return { primaryId: p.id, groupIds: accounts.map((a) => a.id), accounts };
}
