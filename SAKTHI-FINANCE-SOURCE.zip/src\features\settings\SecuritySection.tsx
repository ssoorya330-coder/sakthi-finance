'use client'

import { motion } from 'framer-motion'
import { Shield, LogOut, Loader2 } from 'lucide-react'
import { useAuthStore } from '@/store/auth-store'
import { useAuthActions } from '@/hooks/use-auth'

/**
 * Security section. Sign out reuses the existing authentication flow
 * (server logout + local state clear + redirect to /login).
 */
export default function SecuritySection() {
  const userEmail = useAuthStore((s) => s.userEmail)
  const { handleLogout, isLoggingOut } = useAuthActions()

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-white rounded-[20px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] overflow-hidden"
    >
      <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-[var(--primary-soft)] flex items-center justify-center">
          <Shield className="w-4 h-4 text-[var(--primary)]" />
        </div>
        <div>
          <h2 className="text-base font-semibold text-slate-900">Security</h2>
          <p className="text-xs text-slate-500 mt-0.5">Session and sign-out</p>
        </div>
      </div>

      <div className="p-5 space-y-4">
        <div className="rounded-xl bg-slate-50 border border-slate-100 px-4 py-3">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Signed in as</p>
          <p className="text-sm font-semibold text-slate-900 mt-1 truncate">{userEmail || '—'}</p>
          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
            Signing out ends this browser session only and returns to the login page.
          </p>
        </div>
        <button
          type="button"
          onClick={handleLogout}
          disabled={isLoggingOut}
          className="h-[44px] px-6 rounded-xl border border-red-200 text-sm font-semibold text-red-700 bg-white hover:bg-red-50 transition-all duration-200 active:scale-[0.97] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2.5"
        >
          {isLoggingOut ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Signing out...
            </>
          ) : (
            <>
              <LogOut className="w-4 h-4" />
              Sign out
            </>
          )}
        </button>
      </div>
    </motion.div>
  )
}
