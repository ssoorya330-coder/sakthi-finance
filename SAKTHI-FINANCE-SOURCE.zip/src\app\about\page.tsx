'use client'

import { motion } from 'framer-motion'
import { Info } from 'lucide-react'
import TopBar from '@/components/dashboard/TopBar'
import AboutSection from '@/features/settings/AboutSection'

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-[#F7F9EC]">
      <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-[1400px] mx-auto">
        <TopBar title="About" subtitle="Application information" />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="hidden lg:flex items-center gap-3 mb-8"
        >
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#7F1D1D] to-[#9B1D1D] flex items-center justify-center shadow-lg shadow-[#7F1D1D]/20">
            <Info className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">About</h1>
            <p className="text-sm text-slate-500">Application information and system status</p>
          </div>
        </motion.div>
        <AboutSection />
      </div>
    </div>
  )
}
