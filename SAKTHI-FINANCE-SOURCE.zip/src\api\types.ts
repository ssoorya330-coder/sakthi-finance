import type { PaginatedResponse } from '@/types/api.types';

// ── Customers ──
export interface CustomerDto {
  id: number;
  customerId: string;
  fullName: string;
  mobileNumber: string;
  alternateMobile?: string;
  address?: string;
  area?: string;
  city?: string;
  occupation?: string;
  monthlyIncome?: number;
  notes?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  activeLoans: number;
  totalLoanAmount: number;
}

export interface CreateCustomerRequest {
  customerId: string;
  fullName: string;
  mobileNumber: string;
  alternateMobile?: string;
  address?: string;
  area?: string;
  city?: string;
  occupation?: string;
  monthlyIncome?: number;
  notes?: string;
}

export type UpdateCustomerRequest = Partial<Omit<CreateCustomerRequest, 'customerId'>>;

export interface CustomerStatsResponse {
  totalCustomers: number;
  newCustomersThisMonth: number;
  newCustomersThisWeek: number;
  totalMonthlyIncome: number;
  byCity: { city: string; count: number }[];
  byArea: { area: string; count: number }[];
}

export type CustomerListResponse = PaginatedResponse<CustomerDto>;

// ── Loans ──
export interface LoanDto {
  id: number;
  customerId: number;
  customerName: string;
  customerNumber: string;
  loanAmount: number;
  interestRate: number;
  loanType: string;
  duration: number;
  loanDate: string;
  dueDate?: string;
  totalAmount: number;
  interestAmount: number;
  installmentAmount: number;
  remainingDays: number;
  status: string;
  nextCollectionDate?: string;
  notes?: string;
  collectedAmount: number;
  pendingAmount: number;
  totalInstallments: number;
  paidInstallments: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateLoanRequest {
  customerId: number;
  loanAmount: number;
  interestRate: number;
  loanType: string;
  duration: number;
  loanDate?: string;
  notes?: string;
}

export interface UpdateLoanRequest {
  interestRate?: number;
  loanType?: string;
  duration?: number;
  dueDate?: string;
  nextCollectionDate?: string;
  status?: string;
  notes?: string;
}

export type LoanListResponse = PaginatedResponse<LoanDto>;

// ── Collections ──
export interface CollectionDto {
  id: number;
  loanId: number;
  customerId: number;
  customerName: string;
  customerIdCode: string;
  amount: number;
  collectionDate: string;
  collectedBy: string;
  notes?: string;
  createdAt: string;
  loanPendingAmount: number;
}

export interface CreateCollectionRequest {
  loanId: number;
  customerId: number;
  amount: number;
  collectionDate?: string;
  notes?: string;
}

export type CollectionListResponse = PaginatedResponse<CollectionDto>;

// ── Dashboard ──
export interface DashboardStats {
  totalLoanAmount: number;
  totalCollectedAmount: number;
  pendingAmount: number;
  totalCustomers: number;
  activeLoans: number;
  completedLoans: number;
  overdueLoans: number;
  abortedLoans: number;
  totalInterest: number;
  totalRepaymentAmount: number;
  totalBalance: number;
  todayCollections: number;
  todayCollectionAmount: number;
  thisMonthCollections: number;
  thisMonthCollectionAmount: number;
  newCustomersThisMonth: number;
}

export interface RecentActivity {
  type: string;
  description: string;
  amount?: number;
  date: string;
  relatedId?: string;
}

export interface MonthData {
  month: string;
  amount: number;
  count: number;
}

export interface MonthlyTrendData {
  collections: MonthData[];
  loans: MonthData[];
}

export interface LoanStatusSummary {
  status: string;
  count: number;
  totalAmount: number;
}

export interface TopCollector {
  collectorName: string;
  totalCollected: number;
  collectionCount: number;
}

export interface DashboardResponse {
  stats: DashboardStats;
  recentActivity: RecentActivity[];
  monthlyTrend: MonthlyTrendData;
  loanStatusSummary: LoanStatusSummary[];
  topCollectors: TopCollector[];
}

// ── Reports ──
export interface ReportDto {
  id: number;
  reportType: string;
  title: string;
  filePath?: string;
  generatedBy: string;
  createdAt: string;
}

export interface ReportDataDto extends ReportDto {
  data: string;
}

export interface GenerateReportRequest {
  reportType: string;
  fromDate?: string;
  toDate?: string;
  customerId?: number;
  loanId?: number;
}

export type ReportListResponse = PaginatedResponse<ReportDto>;

// ── Settings ──
export interface SettingDto {
  id: number;
  key: string;
  value: string;
  description?: string;
  dataType: string;
  updatedAt: string;
}

export interface UpdateSettingRequest {
  value: string;
  description?: string;
  dataType?: string;
}

// ── Search ──
export interface SearchResultItem {
  type: string;
  id: number;
  title: string;
  subtitle: string;
  url?: string;
  metadata?: Record<string, unknown>;
}

export interface SearchResponse {
  customers: SearchResultItem[];
  loans: SearchResultItem[];
  totalResults: number;
}

// ── Sync ──
export interface SyncItem {
  localId?: number;
  serverId?: number;
  operation: string;
  timestamp: string;
  data?: string;
}

export interface SyncPushRequest {
  lastSyncTime: string;
  customers: SyncItem[];
  loans: SyncItem[];
  collections: SyncItem[];
  payments: SyncItem[];
}

export interface SyncPushResponse {
  serverTime: string;
  processedCount: number;
  conflicts?: SyncConflict[];
}

export interface SyncConflict {
  entityType: string;
  entityId: number;
  message: string;
}

export interface SyncPullResponse {
  serverTime: string;
  customers: SyncItem[];
  loans: SyncItem[];
  collections: SyncItem[];
  payments: SyncItem[];
}

// ── Files ──
export interface FileUploadResponse {
  url: string;
  key: string;
  fileName: string;
  size: number;
  contentType: string;
  uploadedAt: string;
}

export interface PresignedUrlResponse {
  url: string;
  expiresAt: string;
}

// ── Notifications ──
export interface NotificationDto {
  id: number;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  link?: string;
  createdAt: string;
}

export interface UnreadCountResponse {
  count: number;
}

export type NotificationListResponse = PaginatedResponse<NotificationDto>;
