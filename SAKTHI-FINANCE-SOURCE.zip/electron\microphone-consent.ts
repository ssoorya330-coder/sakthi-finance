import { readFile, writeFile, rename, unlink } from 'node:fs/promises'
export class MicrophoneConsent {
  private pending?: Promise<boolean>
  constructor(private file: string) {}
  async allowed() {
    try { return JSON.parse(await readFile(this.file, 'utf8')).allowed === true } catch { return false }
  }
  async request(prompt: () => Promise<boolean>): Promise<boolean> {
    if (await this.allowed()) return true
    if (!this.pending) this.pending = (async () => {
      if (!await prompt()) return false
      await writeFile(this.file + '.tmp', JSON.stringify({ allowed: true, version: 1 }))
      await rename(this.file + '.tmp', this.file)
      return true
    })().finally(() => { this.pending = undefined })
    return this.pending
  }
  async reset() { await this.pending; await unlink(this.file).catch(error => { if (error.code !== 'ENOENT') throw error }) }
}
