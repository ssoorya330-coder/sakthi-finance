import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import { testConnection, gracefulShutdown, getDatabaseStatus, dbQuery, getPool, closePool, setDbType, setManualDbConfig } from './database';
import { initializeDatabase, verifyTables } from './schema';
import { z } from 'zod';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
// NOTE: this legacy Express server (port 5000) is NOT used by the Next.js
// frontend (NEXT_PUBLIC_API_URL points at :3000). It is kept for tooling but
// must enforce the same account isolation as the Next.js routes.

app.use(cors({
  origin: ['http://localhost:3000', 'http://127.0.0.1:3000'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-User-Id'],
}));
app.use(express.json({ limit: '50mb' }));

app.use((req: Request, _res: Response, next: NextFunction) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

function getVerifiedUserId(req: Request): string | null {
  const auth = req.headers['authorization'] as string | undefined;
  if (auth && auth.startsWith('Bearer ')) {
    try {
      const secret = process.env.JWT_ACCESS_SECRET || 'sakthi-finance-access-secret-default-change-me';
      const decoded = jwt.verify(auth.slice(7), secret) as { sub?: string };
      if (decoded && typeof decoded.sub === 'string' && decoded.sub) return decoded.sub;
    } catch {
      return null;
    }
  }
  return null;
}

function getUserId(req: Request): string | null {
  return getVerifiedUserId(req) || (req.headers['x-user-id'] as string) || null;
}

function getSupabaseUserId(req: Request): string | null {
  // Legacy name: actually the verified app-JWT sub, else the X-User-Id hint.
  return getUserId(req);
}

// Helper to get user id for filtering. Mutating routes must call
// requireVerifiedUser() instead and reject unverified callers with 401.
function resolveUserId(req: Request): string | null {
  return getUserId(req);
}

function requireVerifiedUser(req: Request, res: Response): string | null {
  const verified = getVerifiedUserId(req);
  if (!verified) {
    res.status(401).json({ error: 'Unauthorized: valid access token required' });
    return null;
  }
  return verified;
}

function requireUserScope(req: Request, res: Response): string | null {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ error: 'Unauthorized' });
    return null;
  }
  return userId;
}

// ========== HEALTH CHECK ==========
app.get('/api/health', async (_req: Request, res: Response) => {
  try {
    await dbQuery('SELECT 1');
    res.json({ status: 'ok', database: 'connected' });
  } catch (err: any) {
    res.json({ status: 'error', database: 'disconnected', error: err.message });
  }
});

// ========== DATABASE STATUS ==========
app.get('/api/database/status', async (_req: Request, res: Response) => {
  try {
    const result = await dbQuery('SELECT NOW() as time, version() as version');
    const status = await getDatabaseStatus();
    res.json({
      connected: true,
      database: status.database,
      host: status.host,
      port: status.port,
      tables: status.tables,
      time: result.rows[0].time,
      version: result.rows[0].version,
    });
  } catch (err: any) {
    console.error('[GET /api/database/status] Error:', err.message);
    let errorMessage = err.message || 'Unknown error';
    let errorDetail = '';
    if (err.message?.includes('password authentication failed')) {
      errorDetail = 'Incorrect PostgreSQL password.';
    } else if (err.message?.includes('does not exist')) {
      errorDetail = `Database ${process.env.DB_NAME} does not exist.`;
    } else if (err.message?.includes('could not connect')) {
      errorDetail = 'PostgreSQL Service is not running.';
    } else if (err.message?.includes('ECONNREFUSED')) {
      errorDetail = `Cannot connect to PostgreSQL at ${process.env.DB_HOST}:${process.env.DB_PORT}. Check if PostgreSQL is running.`;
    }
    res.json({ connected: false, error: errorMessage, detail: errorDetail });
  }
});

// ========== DATABASE RECONNECT ==========
app.post('/api/database/reconnect', async (_req: Request, res: Response) => {
  try {
    await closePool();
    const connected = await testConnection();
    if (connected) {
      res.json({ success: true, message: 'Reconnected successfully' });
    } else {
      res.json({ success: false, error: 'Failed to reconnect' });
    }
  } catch (err: any) {
    res.json({ success: false, error: err.message });
  }
});

// ========== DATABASE DISCONNECT ==========
app.post('/api/database/disconnect', async (_req: Request, res: Response) => {
  try {
    await closePool();
    res.json({ success: true, message: 'Database disconnected successfully' });
  } catch (err: any) {
    res.json({ success: false, error: err.message });
  }
});

// ========== DATABASE CONNECT ==========
app.post('/api/database/connect', async (_req: Request, res: Response) => {
  try {
    const connected = await testConnection();
    if (connected) {
      res.json({ success: true, message: 'Database connected successfully' });
    } else {
      res.json({ success: false, error: 'Failed to connect to database' });
    }
  } catch (err: any) {
    res.json({ success: false, error: err.message });
  }
});

// ========== DATABASE CONFIGURATION ==========
app.post('/api/database/set-type', async (req: Request, res: Response) => {
  try {
    const { type } = req.body;
    if (!type || !['automatic', 'manual', 'local'].includes(type)) {
      return res.status(400).json({ error: 'Invalid database type' });
    }
    setDbType(type as 'automatic' | 'manual' | 'local');
    res.json({ success: true, databaseType: type });
  } catch (err: any) {
    res.json({ success: false, error: err.message });
  }
});

app.post('/api/database/set-manual-config', async (req: Request, res: Response) => {
  try {
    const { host, port, database, user, password } = req.body;
    if (!host || !database || !user) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    setManualDbConfig({ host, port: port || 5432, database, user, password: password || '1' });
    res.json({ success: true, message: 'Manual database configuration saved' });
  } catch (err: any) {
    res.json({ success: false, error: err.message });
  }
});

app.get('/api/database/get-config', async (_req: Request, res: Response) => {
  try {
    const status = await getDatabaseStatus();
    res.json({
      success: true,
      databaseType: 'automatic', // Default, client reads from store
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT || '5432',
      database: process.env.DB_NAME || 'sakthi_finance',
      user: process.env.DB_USER || 'postgres',
    });
  } catch (err: any) {
    res.json({ success: false, error: err.message });
  }
});

// ========== CUSTOMER CRUD (legacy Express; same isolation as Next.js routes) ==========
app.get('/api/customers', async (req: Request, res: Response) => {
  try {
    const userId = requireUserScope(req, res);
    if (!userId) return;
    const { status, search, page = '1', limit = '50' } = req.query;
    const offset = (parseInt(page as string) - 1) * parseInt(limit as string);

    let query = 'SELECT * FROM customers WHERE user_id = $1';
    const params: any[] = [userId];
    let paramIdx = 2;

    if (status && status !== 'all') { query += ` AND status = $${paramIdx++}`; params.push(status); }
    if (search) { query += ` AND (full_name ILIKE $${paramIdx} OR phone_number ILIKE $${paramIdx} OR customer_code ILIKE $${paramIdx})`; params.push(`%${search}%`); paramIdx++; }

    const countResult = await dbQuery(`SELECT COUNT(*) as total ${query.replace('SELECT *', '')}`, params);
    const total = parseInt(countResult.rows[0].total, 10);
    query += ` ORDER BY created_at DESC LIMIT $${paramIdx++} OFFSET $${paramIdx++}`;
    params.push(parseInt(limit as string), offset);

    const result = await dbQuery(query, params);
    res.json({ data: result.rows, total, page: parseInt(page as string), limit: parseInt(limit as string), totalPages: Math.ceil(total / parseInt(limit as string)) });
  } catch (err: any) {
    console.error('[GET /api/customers] Error:', err.message);
    res.status(500).json({ error: 'Failed to fetch customers', details: err.message });
  }
});

app.get('/api/customer/:id', async (req: Request, res: Response) => {
  try {
    const userId = requireUserScope(req, res);
    if (!userId) return;
    const result = await dbQuery('SELECT * FROM customers WHERE id = $1 AND user_id = $2', [req.params.id, userId]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Customer not found' });
    res.json(result.rows[0]);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch customer', details: err.message });
  }
});

app.post('/api/customer', async (req: Request, res: Response) => {
  try {
    const userId = requireVerifiedUser(req, res);
    if (!userId) return;
const createCustomerSchema = z.object({
      full_name: z.string().min(1, 'Full name is required'),
      phone_number: z.string().optional(),
      alternate_phone: z.string().optional(),
      address: z.string().optional(),
      area: z.string().optional(),
      city: z.string().optional(),
      business: z.string().optional(),
      income: z.number().default(0),
      status: z.enum(['Active', 'Completed', 'Overdue', 'Aborted']).default('Active'),
      loan_date: z.string().optional(),
      due_date: z.string().optional(),
      loan_amount: z.number().default(0),
      interest_rate: z.number().default(0),
      interest_amount: z.number().default(0),
      total_amount: z.number().default(0),
      installment_amount: z.number().default(0),
      remaining_days: z.number().default(0),
      duration: z.number().default(0),
      loan_type: z.enum(['Daily', 'Weekly', 'Monthly']).default('Daily'),
      notes: z.string().optional(),
      customer_code: z.string().optional(),
    });
    const validated = createCustomerSchema.parse(req.body);
    const { full_name, phone_number, alternate_phone, address, area, city, business, income: inc, status, loan_date, due_date, loan_amount: la, interest_rate: ir, interest_amount: ia, total_amount: ta, installment_amount: ia2, remaining_days: rd, duration: dur, loan_type: lt, notes: n } = validated;
    // Server-authoritative per-account code: never trust client input, never
    // use a global sequence — each account has its own 001, 002, ... series.
    const maxResult = await dbQuery(`SELECT customer_code FROM customers WHERE user_id = $1 AND customer_code ~ '^[0-9]+$' ORDER BY (customer_code::int) DESC LIMIT 1`, [userId]);
    const maxCode = maxResult.rows[0]?.customer_code;
    const nextNum = maxCode ? parseInt(maxCode, 10) + 1 : 1;
    const code = String(nextNum).padStart(3, '0');
    const result = await dbQuery(
      `INSERT INTO customers (customer_code, full_name, phone_number, alternate_phone, address, area, city, business, income, status, loan_date, due_date, loan_amount, interest_rate, interest_amount, total_amount, installment_amount, remaining_days, duration, loan_type, notes, user_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22) RETURNING *`,
      [code, full_name, phone_number || null, alternate_phone || null, address || null, area || null, city || null, business || null, inc || 0, status || 'Active', loan_date || null, due_date || null, la || 0, ir || 0, ia || 0, ta || 0, ia2 || 0, rd || 0, dur || 0, lt || 'Daily', n || null, userId]
    );
    await dbQuery(`INSERT INTO audit_logs (action, entity_type, entity_id, details, user_id) VALUES ($1,$2,$3,$4,$5)`, ['create', 'customer', result.rows[0].id, JSON.stringify({ full_name }), userId]);
    console.log('[INSERT] Customer created:', result.rows[0].full_name);
    res.status(201).json(result.rows[0]);
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: err.issues[0].message });
    }
    console.error('[POST /api/customer] Error:', err.message);
    res.status(500).json({ error: 'Failed to create customer', details: err.message });
  }
});

app.put('/api/customer/:id', async (req: Request, res: Response) => {
  try {
    const userId = requireVerifiedUser(req, res);
    if (!userId) return;
    const updateCustomerSchema = z.object({
      full_name: z.string().min(1, 'Full name is optional but if provided must be valid').optional(),
      phone_number: z.string().optional(),
      alternate_phone: z.string().optional(),
      address: z.string().optional(),
      area: z.string().optional(),
      city: z.string().optional(),
      business: z.string().optional(),
      income: z.number().optional(),
      status: z.enum(['Active', 'Completed', 'Overdue', 'Aborted']).optional(),
      loan_date: z.string().optional(),
      due_date: z.string().optional(),
      loan_amount: z.number().optional(),
      interest_rate: z.number().optional(),
      interest_amount: z.number().optional(),
      total_amount: z.number().optional(),
      installment_amount: z.number().optional(),
      remaining_days: z.number().optional(),
      duration: z.number().optional(),
      loan_type: z.enum(['Daily', 'Weekly', 'Monthly']).optional(),
      notes: z.string().optional(),
      abort_reason: z.string().optional(),
    });
    const validated = updateCustomerSchema.parse(req.body);
    const { full_name, phone_number, alternate_phone, address, area, city, business, income: inc, status, loan_date, due_date, loan_amount: la, interest_rate: ir, interest_amount: ia, total_amount: ta, installment_amount: ia2, remaining_days: rd, duration: dur, loan_type: lt, notes: n, abort_reason: ar } = validated;
    const result = await dbQuery(
      `UPDATE customers SET full_name=$1, phone_number=$2, alternate_phone=$3, address=$4, area=$5, city=$6, business=$7, income=$8, status=$9, loan_date=$10, due_date=$11, loan_amount=$12, interest_rate=$13, interest_amount=$14, total_amount=$15, installment_amount=$16, remaining_days=$17, duration=$18, loan_type=$19, notes=$20, abort_reason=$21, updated_at=NOW() WHERE id=$22 AND user_id=$23 RETURNING *`,
      [full_name, phone_number || null, alternate_phone || null, address || null, area || null, city || null, business || null, inc || 0, status, loan_date || null, due_date || null, la || 0, ir || 0, ia || 0, ta || 0, ia2 || 0, rd || 0, dur || 0, lt || 'Daily', n || null, ar || null, req.params.id, userId]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Customer not found' });
    await dbQuery(`INSERT INTO audit_logs (action, entity_type, entity_id, details, user_id) VALUES ($1,$2,$3,$4,$5)`, ['update', 'customer', req.params.id, JSON.stringify({ full_name }), userId]);
    res.json(result.rows[0]);
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: err.issues[0].message });
    }
    console.error('[PUT /api/customer] Error:', err.message);
    res.status(500).json({ error: 'Failed to update customer', details: err.message });
  }
});

app.delete('/api/customer/:id', async (req: Request, res: Response) => {
  try {
    const userId = requireVerifiedUser(req, res);
    if (!userId) return;
    const result = await dbQuery('DELETE FROM customers WHERE id = $1 AND user_id = $2 RETURNING id, full_name', [req.params.id, userId]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Customer not found' });
    await dbQuery(`INSERT INTO audit_logs (action, entity_type, entity_id, user_id) VALUES ($1,$2,$3,$4)`, ['delete', 'customer', req.params.id, userId]);
    res.json({ success: true, id: req.params.id });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete customer', details: err.message });
  }
});

// ========== LOAN CRUD (same isolation as Next.js routes) ==========
app.get('/api/loans', async (req: Request, res: Response) => {
  try {
    const userId = requireUserScope(req, res);
    if (!userId) return;
    let query = 'SELECT l.*, c.full_name as customer_name FROM loans l JOIN customers c ON l.customer_id = c.id WHERE l.user_id = $1';
    const params: any[] = [userId];
    let paramIdx = 2;
    if (req.query.customer_id) { query += ` AND l.customer_id = $${paramIdx++}`; params.push(req.query.customer_id); }
    if (req.query.status) { query += ` AND l.status = $${paramIdx++}`; params.push(req.query.status); }
    query += ' ORDER BY l.created_at DESC';
    const result = await dbQuery(query, params);
    res.json({ data: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch loans', details: err.message });
  }
});

app.post('/api/loan', async (req: Request, res: Response) => {
  try {
    const userId = requireVerifiedUser(req, res);
    if (!userId) return;
    const { customer_id, loan_amount, interest_rate, duration, loan_type, installment, total_amount, balance_amount, received_amount, status } = req.body;
    const owner = await dbQuery('SELECT id FROM customers WHERE id = $1 AND user_id = $2', [customer_id, userId]);
    if (owner.rows.length === 0) return res.status(404).json({ error: 'Customer not found' });
    const result = await dbQuery(
      `INSERT INTO loans (customer_id, loan_amount, interest_rate, duration, loan_type, installment, total_amount, balance_amount, received_amount, status, user_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [customer_id, loan_amount || 0, interest_rate || 0, duration || 0, loan_type || 'Daily', installment || 0, total_amount || 0, balance_amount || (loan_amount || 0), received_amount || 0, status || 'Active', userId]
    );
    res.status(201).json(result.rows[0]);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to create loan', details: err.message });
  }
});

app.put('/api/loan/:id', async (req: Request, res: Response) => {
  try {
    const userId = requireVerifiedUser(req, res);
    if (!userId) return;
    const { loan_amount, interest_rate, duration, loan_type, installment, total_amount, balance_amount, received_amount, status } = req.body;
    const result = await dbQuery(
      `UPDATE loans SET loan_amount=$1, interest_rate=$2, duration=$3, loan_type=$4, installment=$5, total_amount=$6, balance_amount=$7, received_amount=$8, status=$9, updated_at=NOW() WHERE loan_id=$10 AND user_id=$11 RETURNING *`,
      [loan_amount || 0, interest_rate || 0, duration || 0, loan_type || 'Daily', installment || 0, total_amount || 0, balance_amount || 0, received_amount || 0, status, req.params.id, userId]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Loan not found' });
    res.json(result.rows[0]);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update loan', details: err.message });
  }
});

app.delete('/api/loan/:id', async (req: Request, res: Response) => {
  try {
    const userId = requireVerifiedUser(req, res);
    if (!userId) return;
    const result = await dbQuery('DELETE FROM loans WHERE loan_id = $1 AND user_id = $2 RETURNING loan_id', [req.params.id, userId]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Loan not found' });
    res.json({ success: true, id: req.params.id });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete loan', details: err.message });
  }
});

// ========== PAYMENT CRUD (same isolation as Next.js routes) ==========
app.get('/api/payments', async (req: Request, res: Response) => {
  try {
    const userId = requireUserScope(req, res);
    if (!userId) return;
    let query = 'SELECT p.*, c.full_name as customer_name FROM payments p JOIN customers c ON p.customer_id = c.id WHERE p.user_id = $1';
    const params: any[] = [userId];
    let paramIdx = 2;
    if (req.query.customer_id) { query += ` AND p.customer_id = $${paramIdx++}`; params.push(req.query.customer_id); }
    if (req.query.loan_id) { query += ` AND p.loan_id = $${paramIdx++}`; params.push(req.query.loan_id); }
    if (req.query.start_date) { query += ` AND p.payment_date >= $${paramIdx++}`; params.push(req.query.start_date); }
    if (req.query.end_date) { query += ` AND p.payment_date <= $${paramIdx++}`; params.push(req.query.end_date); }
    query += ' ORDER BY p.payment_date DESC, p.created_at DESC';
    const result = await dbQuery(query, params);
    res.json({ data: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch payments', details: err.message });
  }
});

app.post('/api/payment', async (req: Request, res: Response) => {
  try {
    const userId = requireVerifiedUser(req, res);
    if (!userId) return;
    const { loan_id, customer_id, amount, payment_date, payment_time, payment_method, remarks } = req.body;
    const owner = await dbQuery('SELECT id FROM customers WHERE id = $1 AND user_id = $2', [customer_id, userId]);
    if (owner.rows.length === 0) return res.status(404).json({ error: 'Customer not found' });
    if (loan_id) {
      const loanOwner = await dbQuery('SELECT loan_id FROM loans WHERE loan_id = $1 AND user_id = $2', [loan_id, userId]);
      if (loanOwner.rows.length === 0) return res.status(404).json({ error: 'Loan not found' });
    }
    const result = await dbQuery(
      `INSERT INTO payments (loan_id, customer_id, amount, payment_date, payment_time, payment_method, remarks, user_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [loan_id, customer_id, amount || 0, payment_date, payment_time || null, payment_method || 'Cash', remarks || null, userId]
    );
    // PostgreSQL updates the linked Kanaku balance and completion atomically.
    await dbQuery(`INSERT INTO daily_collection (collection_date, customer_id, amount, payment_method, remarks, user_id) VALUES ($1,$2,$3,$4,$5,$6)`, [payment_date, customer_id, amount || 0, payment_method || 'Cash', remarks || null, userId]);
    res.status(201).json(result.rows[0]);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to record payment', details: err.message });
  }
});

app.put('/api/payment/:id', async (req: Request, res: Response) => {
  try {
    const userId = requireVerifiedUser(req, res);
    if (!userId) return;
    const { amount, payment_date, payment_time, payment_method, remarks } = req.body;
    const result = await dbQuery(
      `UPDATE payments SET amount=$1, payment_date=$2, payment_time=$3, payment_method=$4, remarks=$5 WHERE payment_id=$6 AND user_id=$7 RETURNING *`,
      [amount || 0, payment_date, payment_time || null, payment_method || 'Cash', remarks || null, req.params.id, userId]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Payment not found' });
    res.json(result.rows[0]);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update payment', details: err.message });
  }
});

app.delete('/api/payment/:id', async (req: Request, res: Response) => {
  try {
    const userId = requireVerifiedUser(req, res);
    if (!userId) return;
    const result = await dbQuery('DELETE FROM payments WHERE payment_id = $1 AND user_id = $2 RETURNING payment_id', [req.params.id, userId]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Payment not found' });
    res.json({ success: true, id: req.params.id });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete payment', details: err.message });
  }
});

// ========== DASHBOARD (per-account; 401 when unauthenticated) ==========
app.get('/api/dashboard', async (req: Request, res: Response) => {
  try {
    const userId = requireUserScope(req, res);
    if (!userId) return;
    const today = new Date().toISOString().split('T')[0];

    const [customers, todayCollection, activeLoans] = await Promise.all([
      dbQuery(`SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE status = 'Active') as active, COUNT(*) FILTER (WHERE status = 'Completed') as completed, COUNT(*) FILTER (WHERE status = 'Aborted') as aborted, COALESCE(SUM(loan_amount), 0) as total_loan_amount, COALESCE(SUM(interest_amount), 0) as total_interest, COALESCE(SUM(total_amount), 0) as total_amount FROM customers WHERE user_id = $1`, [userId]),
      dbQuery(`SELECT COALESCE(SUM(amount), 0) as today_total FROM daily_collection WHERE collection_date = $1 AND user_id = $2`, [today, userId]),
      dbQuery(`SELECT COALESCE(SUM(balance_amount), 0) as pending, COALESCE(SUM(received_amount), 0) as received FROM loans WHERE status = 'Active' AND user_id = $1`, [userId]),
    ]);

    res.json({
      totalCustomers: parseInt(customers.rows[0].total, 10),
      activeCustomers: parseInt(customers.rows[0].active, 10),
      completedCustomers: parseInt(customers.rows[0].completed, 10),
      abortedCustomers: parseInt(customers.rows[0].aborted, 10),
      totalLoanAmount: parseFloat(customers.rows[0].total_loan_amount),
      totalInterest: parseFloat(customers.rows[0].total_interest),
      totalAmount: parseFloat(customers.rows[0].total_amount),
      todayCollection: parseFloat(todayCollection.rows[0].today_total),
      pendingCollection: parseFloat(activeLoans.rows[0].pending),
      receivedAmount: parseFloat(activeLoans.rows[0].received),
    });
  } catch (err: any) {
    console.error('[GET /api/dashboard] Error:', err.message);
    res.status(500).json({ error: 'Failed to fetch dashboard data', details: err.message });
  }
});

// ========== DAILY COLLECTION (per-account) ==========
app.get('/api/daily-collection', async (req: Request, res: Response) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const userId = requireUserScope(req, res);
    if (!userId) return;
    const query = 'SELECT dc.*, c.full_name as customer_name FROM daily_collection dc JOIN customers c ON dc.customer_id = c.id WHERE dc.collection_date = $1 AND dc.user_id = $2 ORDER BY dc.created_at DESC';
    const result = await dbQuery(query, [today, userId]);
    const total = result.rows.reduce((sum: number, r: any) => sum + parseFloat(r.amount), 0);
    res.json({ data: result.rows, total });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch daily collection', details: err.message });
  }
});

// ========== REPORTS (per-account) ==========
app.get('/api/reports/:type', async (req: Request, res: Response) => {
  try {
    const { type } = req.params;
    const userId = requireUserScope(req, res);
    if (!userId) return;
    let startDate: string;
    const endDate = new Date().toISOString().split('T')[0];
    const now = new Date();
    switch (type) {
      case 'Daily': startDate = endDate; break;
      case 'Weekly': const weekAgo = new Date(now); weekAgo.setDate(weekAgo.getDate() - 7); startDate = weekAgo.toISOString().split('T')[0]; break;
      case 'Monthly': startDate = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0]; break;
      case 'Yearly': startDate = `${now.getFullYear()}-01-01`; break;
      default: startDate = endDate;
    }
    let userFilter = ' AND user_id = $3';
    const params: any[] = [startDate, endDate, userId];
    const [collections, customers] = await Promise.all([
      dbQuery(`SELECT COALESCE(SUM(amount), 0) as total, COUNT(*) as count FROM daily_collection WHERE collection_date BETWEEN $1 AND $2${userFilter}`, params),
      dbQuery(`SELECT COUNT(*) as new_customers FROM customers WHERE created_at::date BETWEEN $1 AND $2${userFilter}`, params),
    ]);
    res.json({ reportType: type, startDate, endDate, totalCollection: parseFloat(collections.rows[0].total), paymentCount: parseInt(collections.rows[0].count, 10), newCustomers: parseInt(customers.rows[0].new_customers, 10) });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to generate report', details: err.message });
  }
});

// ========== SEARCH (per-account) ==========
app.get('/api/search', async (req: Request, res: Response) => {
  try {
    const { q } = req.query;
    const userId = requireUserScope(req, res);
    if (!userId) return;
    const query = `SELECT id, customer_code, full_name, phone_number, status FROM customers WHERE user_id = $2 AND (full_name ILIKE $1 OR phone_number ILIKE $1 OR customer_code ILIKE $1)`;
    const params: any[] = [`%${q}%`, userId];
    const result = await dbQuery(`${query} ORDER BY full_name LIMIT 50`, params);
    res.json({ data: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: 'Search failed', details: err.message });
  }
});

// ========== COMPLETED & ABORTED (per-account) ==========
app.get('/api/completed-customers', async (req: Request, res: Response) => {
  try {
    const userId = requireUserScope(req, res);
    if (!userId) return;
    const result = await dbQuery("SELECT c.* FROM customers c WHERE c.status = 'Completed' AND c.user_id = $1 ORDER BY c.updated_at DESC", [userId]);
    res.json({ data: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch completed customers', details: err.message });
  }
});

app.get('/api/aborted-customers', async (req: Request, res: Response) => {
  try {
    const userId = requireUserScope(req, res);
    if (!userId) return;
    const result = await dbQuery("SELECT c.* FROM customers c WHERE c.status = 'Aborted' AND c.user_id = $1 ORDER BY c.updated_at DESC", [userId]);
    res.json({ data: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch aborted customers', details: err.message });
  }
});

// ========== START SERVER ==========
async function startServer() {
  console.log('=====================================');
  console.log('  Sakthi Finance Backend Starting...');
  console.log('=====================================');

  const connected = await testConnection();
  if (!connected) {
    console.warn('[Server] PostgreSQL not available — running in degraded (offline) mode');
    console.warn('[Server] Add Customer will use local fallback until DB is available');
  } else {
    try {
      await initializeDatabase();
      const tables = await verifyTables();
      console.log(`[Schema] Tables: ${tables.join(', ')}`);
    } catch (e: any) {
      console.warn('[Server] Schema init failed, continuing in degraded mode:', e.message);
    }
  }

  app.listen(PORT, () => {
    console.log('=====================================');
    console.log(`  Server running on http://localhost:${PORT}`);
    console.log(`  API base: http://localhost:${PORT}/api`);
    console.log(`  Database: ${connected ? (process.env.DB_NAME || 'sakthi_finance') : 'offline (no DB)'}`);
    console.log('=====================================');
  });
}

process.on('SIGTERM', async () => { await gracefulShutdown(); process.exit(0); });
process.on('SIGINT', async () => { await gracefulShutdown(); process.exit(0); });

startServer();
