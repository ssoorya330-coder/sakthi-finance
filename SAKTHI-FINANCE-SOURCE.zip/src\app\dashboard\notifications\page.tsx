'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, Bell, RefreshCw } from 'lucide-react'
import { useNotifications, useReadNotification } from '@/hooks/use-notifications'

export default function NotificationsPage() {
  const [page, setPage] = useState(1)
  const { data, isPending, isError, isFetching, refetch } = useNotifications(page)
  const markRead = useReadNotification()

  return (
    <main className="max-w-4xl mx-auto p-4 sm:p-8">
      <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm text-slate-600 hover:text-[var(--primary)] mb-6"><ArrowLeft className="w-4 h-4" /> Back to dashboard</Link>
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div><h1 className="text-2xl font-bold text-slate-900">Notifications</h1><p className="text-sm text-slate-500 mt-1">{data ? `${data.unread} unread notifications` : 'Your received messages and alerts'}</p></div>
        <div className="flex items-center gap-3">
          <button onClick={() => refetch()} disabled={isFetching} aria-label="Refresh notifications" className="p-2 rounded-xl border border-slate-200 bg-white disabled:opacity-50"><RefreshCw className={`w-4 h-4 ${isFetching ? 'animate-spin' : ''}`} /></button>
          <button onClick={() => markRead.mutate({ all: true })} disabled={!data?.unread || markRead.isPending} className="text-sm font-medium text-[var(--primary)] disabled:opacity-40">Mark all as read</button>
        </div>
      </div>
      {markRead.isError && <p role="alert" className="mb-4 text-sm text-red-700">{markRead.error.message}</p>}
      {isError ? <div role="alert" className="p-8 bg-white rounded-2xl text-center"><p>Unable to load notifications.</p><button onClick={() => refetch()} className="text-[var(--primary)] underline mt-3">Try again</button></div>
        : isPending ? <p role="status" className="p-8 text-center text-slate-500">Loading notifications...</p>
        : !data?.items.length ? <div className="p-12 rounded-2xl bg-white border border-slate-100 text-center"><Bell className="w-10 h-10 mx-auto mb-4 text-[var(--primary)]" /><h2 className="font-semibold text-slate-900">No notifications yet</h2><p className="mt-2 text-sm text-slate-500">New messages and alerts will appear here when received.</p></div>
        : <ul className="space-y-3">{data.items.map(item => <li key={item.id} className={`p-5 rounded-2xl border ${item.isRead ? 'bg-white border-slate-100' : 'bg-[var(--primary-soft)] border-[var(--primary)]/15'}`}>
          <div className="flex items-start justify-between gap-4"><h2 className="font-semibold text-slate-900 break-words min-w-0">{item.title}</h2>{!item.isRead && <span className="text-xs font-semibold text-[var(--primary)]">Unread</span>}</div>
          <p className="mt-2 text-sm text-slate-600 whitespace-pre-wrap break-words">{item.message}</p>
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3"><time dateTime={item.createdAt} className="text-xs text-slate-500">{new Date(item.createdAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</time>{!item.isRead && <button disabled={markRead.isPending} onClick={() => markRead.mutate({ id: item.id })} className="text-xs font-semibold text-[var(--primary)] disabled:opacity-40">Mark as read</button>}</div>
        </li>)}</ul>}
      {(page > 1 || (data?.total ?? 0) > 20) && <div className="flex items-center justify-between mt-6 text-sm"><button disabled={page === 1 || isFetching} onClick={() => setPage(p => p - 1)} className="disabled:opacity-40">Previous</button><span>Page {page}</span><button disabled={!data || page * 20 >= data.total || isFetching} onClick={() => setPage(p => p + 1)} className="disabled:opacity-40">Next</button></div>}
    </main>
  )
}
