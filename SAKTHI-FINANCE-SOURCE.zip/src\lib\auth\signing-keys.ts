import { randomBytes } from 'node:crypto'

const dev = globalThis as typeof globalThis & { sakthiDevelopmentKeys?: Record<string, string> }
export function signingKey(name: 'JWT_ACCESS_SECRET' | 'JWT_REFRESH_SECRET'): string {
  const configured = process.env[name]
  if (configured) {
    if (configured.length < 32 || /default|changeme|change-me|placeholder|REPLACE_WITH/i.test(configured)) throw new Error(`${name} must be a private random value of at least 32 characters`)
    return configured
  }
  if (process.env.NODE_ENV === 'production') throw new Error(`${name} is required in production`)
  // Never use a known fallback. Development sessions intentionally expire on restart.
  dev.sakthiDevelopmentKeys ??= {}
  return dev.sakthiDevelopmentKeys[name] ??= randomBytes(48).toString('base64url')
}
export function validateSigningKeys() {
  if (signingKey('JWT_ACCESS_SECRET') === signingKey('JWT_REFRESH_SECRET')) throw new Error('Access and refresh signing keys must be different')
}
