import { cp, readFile, writeFile, readdir, access } from 'node:fs/promises'
import { spawnSync } from 'node:child_process'
import { randomBytes } from 'node:crypto'
import path from 'node:path'
import dotenv from 'dotenv'
import { stageServer } from './stage-server.mjs'

const root = process.cwd()
const license = path.join(root, 'desktop/node-LICENSE.txt')
await access(license)
const built = spawnSync(process.execPath, ['node_modules/next/dist/bin/next', 'build'], { stdio: 'inherit', env: {
  ...process.env, JWT_ACCESS_SECRET: randomBytes(48).toString('base64url'), JWT_REFRESH_SECRET: randomBytes(48).toString('base64url'),
  NEXT_PUBLIC_API_URL: '', SAKTHI_SERVER_URL: '', NEXT_PUBLIC_SAKTHI_SERVER_URL: '',
} })
if (built.status !== 0) process.exit(built.status || 1)
const stage = await stageServer()
await cp(process.execPath, path.join(stage, 'node.exe'))
await cp(license, path.join(stage, 'node-LICENSE.txt'))
for (const name of ['backend-launcher.mjs', 'runtime-config.mjs']) await cp(path.join(root, 'scripts/desktop', name), path.join(stage, name))

const env = { ...dotenv.parse(await readFile('.env')), ...dotenv.parse(await readFile('.env.local')) }
const secrets = Object.entries(env).filter(([key, value]) => /SECRET|PASSWORD|DATABASE_URL/.test(key) && value.length >= 8).map(([, value]) => Buffer.from(value))
async function scan(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const file = path.join(directory, entry.name)
    if (entry.isDirectory()) { await scan(file); continue }
    if (entry.isSymbolicLink()) throw Error('Unexpected symlink in release staging')
    if (entry.name.startsWith('.env')) throw Error('Environment file in release staging')
    if (entry.name === 'node.exe') continue
    const contents = await readFile(file)
    if (secrets.some(secret => contents.includes(secret))) throw Error(`Private value found in staged file: ${path.relative(stage, file)}`)
  }
}
await scan(stage)
await writeFile(path.join(stage, 'release-checked.json'), JSON.stringify({ node: process.version, buildId: (await readFile('.next/BUILD_ID', 'utf8')).trim() }))
// The generated config contains only paths, not credentials. The stage path is
// passed via SAKTHI_DESKTOP_STAGE because a quoted path with spaces (e.g.
// "D:\SAKTHI FINANCE") is not preserved when the CLI executes beforeBuildCommand.
await writeFile(path.join(stage, 'tauri.release.json'), JSON.stringify({
  build: { beforeBuildCommand: 'node scripts/desktop/release-check.mjs' },
  bundle: { resources: { [`${stage.replaceAll('\\', '/')}/`]: 'runtime/' } },
}, null, 2))
console.log(`RELEASE_STAGE=${stage}`)
