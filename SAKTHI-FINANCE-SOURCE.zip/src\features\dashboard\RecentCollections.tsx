'use client'

import { motion } from 'framer-motion'
import { ArrowUpRight } from 'lucide-react'
import { formatCurrency, formatDate } from './dashboard.styles'

const recentCollections: { id: string; customer: string; amount: number; collectionType: string; date: string; paymentMethod: string }[] = []

const typeColors: Record<string, { bg: string; text: string }> = {
  Cash: { bg: 'bg-[var(--primary-soft)]', text: 'text-[var(--primary)]' },
  UPI: { bg: 'bg-[#FFF8E5]', text: 'text-[var(--secondary)]' },
  'Bank Transfer': { bg: 'bg-[var(--primary-soft)]', text: 'text-[var(--primary)]' },
  Cheque: { bg: 'bg-[var(--primary-soft)]', text: 'text-[var(--primary-hover)]' },
}

export default function RecentCollections() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.8, ease: [0.16, 1, 0.3, 1] }}
      className="bg-white rounded-[18px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] overflow-hidden"
    >
      <div className="flex items-center justify-between px-6 pt-6 pb-4">
        <div>
          <h3 className="text-lg font-bold text-slate-900">Recent Collections</h3>
          <p className="text-sm text-slate-500 mt-0.5">Latest payment collections</p>
        </div>
        <button className="flex items-center gap-1 text-sm font-medium text-[var(--primary)] hover:text-[var(--primary-hover)] transition-colors">
          View All
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-100">
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-3">
                Customer
              </th>
              <th className="text-right text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-3">
                Amount
              </th>
              <th className="text-center text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-3">
                Collection Type
              </th>
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-3">
                Date
              </th>
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-3">
                Payment Method
              </th>
            </tr>
          </thead>
          <tbody>
            {recentCollections.map((collection, i) => {
              const typeStyle = typeColors[collection.collectionType] || {
                bg: 'bg-slate-50',
                text: 'text-slate-700',
              }
              return (
                <motion.tr
                  key={collection.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.9 + i * 0.05 }}
                  className="border-b border-slate-50 last:border-0 hover:bg-slate-50/50 transition-colors"
                >
                  <td className="px-6 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                        {collection.customer.charAt(0)}
                      </div>
                      <span className="text-sm font-medium text-slate-900">
                        {collection.customer}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-3.5 text-sm font-semibold text-[var(--primary)] text-right">
                    +{formatCurrency(collection.amount)}
                  </td>
                  <td className="px-6 py-3.5 text-center">
                    <span
                      className={`inline-flex px-2.5 py-1 rounded-lg text-xs font-semibold ${typeStyle.bg} ${typeStyle.text}`}
                    >
                      {collection.collectionType}
                    </span>
                  </td>
                  <td className="px-6 py-3.5 text-sm text-slate-500">
                    {formatDate(collection.date)}
                  </td>
                  <td className="px-6 py-3.5 text-sm text-slate-600">{collection.paymentMethod}</td>
                </motion.tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </motion.div>
  )
}
