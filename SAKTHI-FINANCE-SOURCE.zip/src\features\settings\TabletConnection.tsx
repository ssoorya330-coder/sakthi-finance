'use client'

import {useEffect,useRef,useState} from 'react'
import {QRCodeSVG} from 'qrcode.react'
import {pairingQr} from '@/lib/desktop/pairing-qr'
import type {TabletStatus} from '@/lib/desktop/bridge'

export default function TabletConnection() {
  const [state,setState]=useState<TabletStatus|null>(null)
  const [environment,setEnvironment]=useState<'development'|'production'>('development')
  const [code,setCode]=useState<{code:string;expiresAt:number}|null>(null)
  const [busy,setBusy]=useState(false)
  const [error,setError]=useState('')
  const [address,setAddress]=useState('')
  const [now,setNow]=useState(Date.now())
  const approvalDialog=useRef<HTMLDialogElement>(null)
  const [dismissed,setDismissed]=useState<string|null>(null)
  const pending=state?.pending[0]
  useEffect(()=>{
    if(!state?.enabled||busy)return
    let cancelled=false
    let timer:ReturnType<typeof setTimeout>|undefined
    const refresh=async()=>{
      try {
        const current=await window.sakthi!.tablet.status()
        if(!cancelled){setState(current);setError('')}
      }catch{if(!cancelled)setError('Cannot check pairing requests. Check laptop sign-in and storage, then retry.')}
      finally{if(!cancelled)timer=setTimeout(refresh,2000)}
    }
    void refresh()
    return()=>{cancelled=true;if(timer)clearTimeout(timer)}
  },[state?.enabled,busy])
  useEffect(()=>{
    const dialog=approvalDialog.current
    if(!dialog)return
    if(pending&&dismissed!==pending.requestId){if(!dialog.open)dialog.showModal()}
    else if(dialog.open)dialog.close()
  },[pending?.requestId,dismissed])
  useEffect(()=>{if(!code)return;const timer=setInterval(()=>setNow(Date.now()),1000);return()=>clearInterval(timer)},[code])
  const run=async(task:()=>Promise<void>)=>{setBusy(true);setError('');try{await task()}catch{setError('Connection could not finish. Check laptop sign-in, configured database and storage.')}finally{setBusy(false)}}
  useEffect(()=>{if(window.sakthi?.tablet)void run(async()=>setState(await window.sakthi!.tablet.status()))},[])
  if(!state)return null
  const api=()=>window.sakthi!.tablet
  return <section className="bg-white border rounded-2xl p-6 mb-6 space-y-4">
    <h2 className="text-xl font-semibold">Tablet Connection</h2>
    <dialog ref={approvalDialog} onCancel={()=>setDismissed(pending?.requestId??null)} aria-labelledby="tablet-approval-title" className="m-auto w-[min(92vw,460px)] rounded-2xl border p-6 shadow-xl backdrop:bg-black/40">
      {pending&&<div className="space-y-4">
        <h3 id="tablet-approval-title" className="text-xl font-semibold">Allow this tablet to connect?</h3>
        <p><strong>{pending.deviceName}</strong> has requested access using your Google account and pairing code.</p>
        <p className="text-sm break-all">Device: {pending.deviceId}<br/>Environment: {state.environment}</p>
        <p>Approve only if you just requested this connection from your tablet.</p>
        {error&&<p role="alert" className="text-red-700">{error}</p>}
        <div className="flex justify-end gap-3">
          <button autoFocus disabled={busy} className="border rounded-lg px-4 py-2" onClick={()=>void run(async()=>setState(await api().decide(pending.requestId,false)))}>Reject</button>
          <button disabled={busy} className="bg-red-900 text-white rounded-lg px-4 py-2" onClick={()=>void run(async()=>setState(await api().decide(pending.requestId,true)))}>{busy?'Saving…':'Approve tablet'}</button>
        </div>
      </div>}
    </dialog>
    <p>Connect your tablet over the same Wi-Fi. PostgreSQL stays on this laptop. Only approved devices can sync with the signed-in account.</p>
    <p>{state.laptopName} · {state.enabled?`${state.environment} connection enabled`:'Connection disabled'}</p>
    {error&&<p role="alert" className="text-red-700">{error}</p>}
    {!state.enabled?<div className="flex gap-3">
      <select aria-label="Laptop environment" value={environment} onChange={e=>setEnvironment(e.target.value as typeof environment)}><option value="development">Development — test data</option><option value="production">Production — business data</option></select>
      <button disabled={busy} className="border rounded-lg px-4 py-2" onClick={()=>void run(async()=>setState(await api().enable(environment)))}>Enable tablet connection</button>
    </div>:<>
      <p>Generate a code, then tap <strong>Scan laptop QR code</strong> on your tablet. Both devices must use the same Wi-Fi.</p>
      <p className="text-sm">After scanning, continue with Google on the tablet. Its approval request will appear here automatically.</p>
      <label className="block">Laptop Wi-Fi address<select className="block border rounded-lg p-2 max-w-full" value={state.addresses.includes(address)?address:state.addresses[0]||''} onChange={e=>setAddress(e.target.value)}>{state.addresses.map(item=><option key={item} value={item}>{item}</option>)}</select></label>
      <div className="flex flex-wrap gap-3">
        <button disabled={busy||!state.addresses.length} className="border rounded-lg px-4 py-2" onClick={()=>void run(async()=>{setCode(null);const fresh=await api().code();setNow(Date.now());setCode(fresh)})}>Generate QR / connection code</button>
        <button disabled={busy} className="border rounded-lg px-4 py-2" onClick={()=>void run(async()=>setState(await api().status()))}>Refresh pairing requests</button>
        <button disabled={busy} className="border rounded-lg px-4 py-2" onClick={()=>void run(async()=>{setState(await api().disable());setCode(null)})}>Disable connection</button>
      </div>
      {code&&code.expiresAt>now&&state.fingerprint&&state.addresses.length>0&&<div className="border rounded-xl p-4 inline-flex flex-col gap-3 items-center bg-white text-slate-900">
        <QRCodeSVG value={pairingQr({address:state.addresses.includes(address)?address:state.addresses[0],fingerprint:state.fingerprint,code:code.code,expiresAt:code.expiresAt,laptopName:state.laptopName,environment:state.environment!})} size={280} level="M" marginSize={4} title="Scan with Sakthi Finance on your tablet" />
        <p className="text-3xl font-bold tracking-widest">{code.code}</p>
        <p>Expires in {Math.ceil((code.expiresAt-now)/1000)} seconds</p>
        <p>Scan only from this laptop. Google sign-in and laptop approval are still required.</p>
      </div>}
      {code&&code.expiresAt<=now&&<p role="status">Code expired. Generate a new QR code.</p>}
      <details><summary>Manual connection details</summary><p className="break-all">Address: {state.addresses.includes(address)?address:state.addresses[0]}</p><p className="font-mono text-sm break-all">SHA-256: {state.fingerprint}</p></details>
      {state.pending.map(item=><div key={item.requestId} className="border rounded-lg p-3 flex gap-4 items-center"><span>{item.deviceName} requests access</span><button disabled={busy} onClick={()=>void run(async()=>setState(await api().decide(item.requestId,true)))}>Approve</button><button disabled={busy} onClick={()=>void run(async()=>setState(await api().decide(item.requestId,false)))}>Reject</button></div>)}
      {state.devices.map(item=><div key={item.deviceId} className="flex gap-4"><span>{item.deviceName} — trusted</span><button disabled={busy} onClick={()=>void run(async()=>setState(await api().revoke(item.deviceId)))}>Revoke access</button></div>)}
      <p className="text-sm">Keep Sakthi Finance open and signed in while syncing. Allow its connection only on your trusted private Wi-Fi network. Never open PostgreSQL to the tablet.</p>
    </>}
  </section>
}
