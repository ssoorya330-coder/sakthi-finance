import fs from 'fs'
import path from 'path'
import { NextRequest, NextResponse } from 'next/server'
import { requireAuth, requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { runPgBackup, verifyBackupArchive } from '@/server/storage'
import { actorFromAuthUser, requestMeta, recordAuditStandalone } from '@/server/audit'

export const dynamic = 'force-dynamic'

/** List local backup records (newest first), flagged if the file is missing. */
export async function GET() {
  const auth = await requireAuth()
  if (auth.error) return auth.error
  try {
    const result = await dbQuery(
      `SELECT b.*, s.name AS storage_name FROM backup_records b
       LEFT JOIN storage_locations s ON s.id = b.storage_location_id
       ORDER BY b.created_at DESC LIMIT 50`
    )
    const records = result.rows.map((r: any) => ({
      id: r.id,
      filename: r.filename,
      sizeBytes: Number(r.size_bytes) || 0,
      storageLocationId: r.storage_location_id,
      storageName: r.storage_name,
      status: r.status,
      pgVersion: r.pg_version,
      kind: r.kind,
      createdAt: r.created_at,
      exists: (() => {
        try {
          return fs.existsSync(r.path)
        } catch {
          return false
        }
      })(),
    }))
    return NextResponse.json({ backups: records })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to load backups', details: err.message },
      { status: 500 }
    )
  }
}

/** Create a local backup (pg_dump) into a configured storage location. */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json().catch(() => ({}))
    let storageId = body.storage_location_id as string | undefined

    // Default: first Active storage with purpose Database Backups
    // (then any other backup-capable storage).
    if (!storageId) {
      const def = await dbQuery(
        `SELECT id FROM storage_locations WHERE status = 'Active'
         AND purpose IN ('Database Backups', 'Application Backups', 'General Storage')
         ORDER BY (purpose = 'Database Backups') DESC, created_at ASC LIMIT 1`
      )
      storageId = def.rows[0]?.id
    }
    if (!storageId) {
      return NextResponse.json(
        { error: 'No backup storage configured. Configure a local storage location first.' },
        { status: 400 }
      )
    }
    const loc = await dbQuery('SELECT * FROM storage_locations WHERE id = $1 LIMIT 1', [storageId])
    if (loc.rows.length === 0) {
      return NextResponse.json({ error: 'Storage location not found.' }, { status: 404 })
    }
    const storage = loc.rows[0]
    if (storage.status !== 'Active') {
      return NextResponse.json({ error: 'This storage location is disabled.' }, { status: 400 })
    }
    if (!['Database Backups', 'Application Backups', 'General Storage'].includes(storage.purpose)) {
      return NextResponse.json({ error: 'Select a backup-capable storage folder.' }, { status: 400 })
    }
    const backupsDir = path.join(storage.path, 'Backups')
    try {
      // Do not recreate a missing configured destination on a different drive.
      if (!fs.statSync(storage.path).isDirectory()) throw new Error('Storage unavailable')
      fs.accessSync(storage.path, fs.constants.W_OK)
      fs.mkdirSync(backupsDir, { recursive: true })
      fs.accessSync(backupsDir, fs.constants.W_OK)
    } catch {
      return NextResponse.json(
        { error: 'Storage offline or not writable. Connect the selected drive and retry. No alternative folder was used.' },
        { status: 400 }
      )
    }

    const result = await runPgBackup(backupsDir)
    const verification = await verifyBackupArchive(result.filePath)
    if (!verification.ok) throw new Error(`Backup verification failed: ${verification.message}`)
    const inserted = await dbQuery(
      `INSERT INTO backup_records (filename, path, size_bytes, storage_location_id, status, pg_version, kind)
       VALUES ($1, $2, $3, $4, 'Successful', $5, 'full') RETURNING *`,
      [result.filename, result.filePath, result.sizeBytes, storage.id, result.pgVersion]
    )
    await dbQuery('UPDATE storage_locations SET last_used_at = NOW() WHERE id = $1', [storage.id]).catch(
      () => {}
    )
    await dbQuery(
      "INSERT INTO audit_logs (action, entity_type, entity_id, details, user_id) VALUES ('backup', 'database', $1, $2, $3)",
      [inserted.rows[0].id, JSON.stringify({ filename: result.filename }), auth.user.userId]
    ).catch(() => {})
    {
      const meta = requestMeta(request)
      await recordAuditStandalone({
        action: 'BACKUP_CREATED',
        entityType: 'backup',
        entityId: inserted.rows[0].id,
        actor: actorFromAuthUser(auth.user),
        ipAddress: meta.ip,
        clientInfo: meta.client,
        result: 'SUCCESS',
        changes: [
          { field: 'filename', label: 'File', before: null, after: result.filename },
          { field: 'size', label: 'Size (bytes)', before: null, after: result.sizeBytes },
          { field: 'storage', label: 'Storage', before: null, after: storage.name },
        ],
        after: { filename: result.filename, size_bytes: result.sizeBytes, storage: storage.name },
      })
    }

    return NextResponse.json(
      {
        backup: {
          id: inserted.rows[0].id,
          filename: result.filename,
          sizeBytes: result.sizeBytes,
          storageName: storage.name,
          createdAt: inserted.rows[0].created_at,
        },
      },
      { status: 201 }
    )
  } catch (err: any) {
    const message = err?.message || 'Backup failed.'
    const status = /not found on this computer/i.test(message) ? 503 : 500
    try {
      await dbQuery(
        `INSERT INTO backup_records (filename, path, size_bytes, status, kind) VALUES ($1, $2, 0, 'Failed', 'full')`,
        ['failed-backup', '']
      ).catch(() => {})
    } catch {}
    return NextResponse.json({ error: message }, { status })
  }
}
