'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  X, Loader2, AlertTriangle, CheckCircle2, XCircle,
  Copy, Check, ShieldAlert, Database, RefreshCw, HardDrive,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import StorageWizard, { formatBytes } from './StorageWizard'

export class ApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.status = status
  }
}

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, { credentials: 'include', ...init })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    if (res.status === 403) {
      // Application authorization (not Windows): the caller's stored role
      // lacks the required permission. Never a filesystem issue at this
      // point — those return 400/500 with their own specific messages.
      throw new ApiError(
        'Forbidden — insufficient permission. This operation requires an owner or admin account. Account roles are managed directly in PostgreSQL, outside the app: promote the login email, then log out and back in.',
        403
      )
    }
    throw new ApiError((data as any).error || `Request failed (${res.status})`, res.status)
  }
  return data as T
}

export const ROLE_FIX_SQL = `UPDATE users SET role = 'admin',
  role_id = (SELECT role_id FROM roles WHERE role_name = 'admin'),
  updated_at = NOW()
WHERE email = 'your-login-email';
-- then log out and log back in so the new role takes effect`

interface MigStatus {
  version: string | null
  dataDirectory: string | null
  dataDirSizeBytes: number | null
  dbSizeBytes: number | null
  drive: { root: string; totalBytes: number; freeBytes: number; usedBytes: number } | null
  service: { name: string | null; displayName: string | null; state: string; binaryPath: string | null; dataDirFromService: string | null; available: boolean }
  pgToolsFound: boolean
}
interface Snapshot {
  version: string | null
  dataDirectory: string | null
  databases: string[]
  dbSizeBytes: number | null
  serverTime: string | null
  tables: Array<{ name: string; rows: number }>
  counts: Record<string, number>
}
interface Prep {
  ok: boolean
  error?: string
  normalizedPath?: string
  freeBytes?: number | null
  requiredBytes?: number | null
  sourceBytes?: number | null
}

function CodeBlock({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)
  return (
    <div className="relative rounded-xl bg-slate-900 text-slate-100 p-3 pr-11 text-[11.5px] font-mono break-all whitespace-pre-wrap">
      {text}
      <button
        onClick={() => {
          navigator.clipboard?.writeText(text).then(() => {
            setCopied(true)
            setTimeout(() => setCopied(false), 1500)
          }).catch(() => {})
        }}
        className="absolute top-2 right-2 w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center"
        title="Copy command"
      >
        {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
      </button>
    </div>
  )
}

function Warn({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-50 border border-amber-200 text-[13px] text-amber-800">
      <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" /> <span>{children}</span>
    </div>
  )
}

function CheckLine({ ok, label, detail }: { ok: boolean; label: string; detail?: string }) {
  return (
    <div className="flex items-start gap-2 py-1.5">
      {ok ? <CheckCircle2 size={16} className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" /> : <XCircle size={16} className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />}
      <div className="min-w-0">
        <p className="text-[13px] font-semibold text-slate-800">{label}</p>
        {detail && <p className="text-[11.5px] text-slate-500 break-all">{detail}</p>}
      </div>
    </div>
  )
}

type Phase = 'select' | 'running' | 'done' | 'error'

interface Progress {
  percent: number
  operation: string
  copiedBytes: number | null
  totalBytes: number | null
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

export default function MigrationWizard({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [phase, setPhase] = useState<Phase>('select')
  const [status, setStatus] = useState<MigStatus | null>(null)
  const [statusLoading, setStatusLoading] = useState(false)

  // destination + automatic validation
  const [destination, setDestination] = useState('D:\\PostgreSQL\\data')
  const [prep, setPrep] = useState<Prep | null>(null)
  const [validating, setValidating] = useState(false)
  const [drives, setDrives] = useState<Array<{ root: string; label: string; totalBytes: number; freeBytes: number; usedBytes: number }>>([])
  const [drivesLoading, setDrivesLoading] = useState(false)
  const [drivesError, setDrivesError] = useState<string | null>(null)
  const [driveRoot, setDriveRoot] = useState<string | null>(null)

  const [canMigrate, setCanMigrate] = useState<boolean | null>(null)

  // run
  const [progress, setProgress] = useState<Progress>({ percent: 0, operation: '', copiedBytes: null, totalBytes: null })
  const [error, setError] = useState<string | null>(null)
  const [doneInfo, setDoneInfo] = useState<{ oldDir: string; newDir: string } | null>(null)
  const [notice, setNotice] = useState<string | null>(null)

  const runId = useRef(0)
  const validateTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const loadStatus = useCallback(async () => {
    setStatusLoading(true)
    try {
      const s = await api<MigStatus>('/api/database/migration/status')
      setStatus(s)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setStatusLoading(false)
    }
  }, [])

  const probePermission = useCallback(async () => {
    try {
      await api<{ snapshot: Snapshot }>('/api/database/migration/verify')
      setCanMigrate(true)
    } catch (e: any) {
      if (e instanceof ApiError && e.status === 403) setCanMigrate(false)
      else setCanMigrate(null)
    }
  }, [])

  async function loadDrives() {
    setDrivesLoading(true)
    setDrivesError(null)
    try {
      const d = await api<{ drives: Array<{ root: string; label: string; totalBytes: number; freeBytes: number; usedBytes: number }> }>('/api/system/drives')
      setDrives(d.drives || [])
    } catch (e: any) {
      setDrivesError(e.message || 'Could not detect local drives.')
    } finally {
      setDrivesLoading(false)
    }
  }

  const validateDestination = useCallback(async (dest: string) => {
    setValidating(true)
    try {
      const r = await api<Prep>('/api/database/migration/prepare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ destination: dest }),
      })
      setPrep(r)
    } catch (e: any) {
      setPrep({ ok: false, error: e.message })
    } finally {
      setValidating(false)
    }
  }, [])

  useEffect(() => {
    if (open) {
      runId.current += 1
      setPhase('select')
      setError(null)
      setDoneInfo(null)
      setNotice(null)
      setPrep(null)
      setCanMigrate(null)
      setProgress({ percent: 0, operation: '', copiedBytes: null, totalBytes: null })
      loadStatus()
      probePermission()
      loadDrives()
    }
  }, [open, loadStatus, probePermission])

  // Automatic validation whenever the destination changes (debounced).
  useEffect(() => {
    if (!open || phase !== 'select') return
    if (validateTimer.current) clearTimeout(validateTimer.current)
    validateTimer.current = setTimeout(() => {
      if (destination.trim()) validateDestination(destination.trim())
      else setPrep(null)
    }, 500)
    return () => {
      if (validateTimer.current) clearTimeout(validateTimer.current)
    }
  }, [destination, open, phase, validateDestination])

  if (!open) return null

  const srcDir = status?.dataDirectory || null
  const destNorm = prep?.normalizedPath || destination.trim()
  const ready =
    prep?.ok === true &&
    !!srcDir &&
    !!status?.version &&
    canMigrate !== false &&
    !validating

  function fail(message: string): never {
    const err: any = new Error(message)
    throw err
  }

  async function serviceState(): Promise<string | null> {
    try {
      const s = await api<MigStatus['service']>('/api/database/migration/service')
      return s.state
    } catch {
      return null
    }
  }

  async function waitForService(want: 'stopped' | 'running', timeoutMs: number) {
    const start = Date.now()
    for (;;) {
      const state = await serviceState()
      if (state === want) return
      if (Date.now() - start > timeoutMs) {
        fail(`PostgreSQL did not reach "${want}" in time (last state: ${state || 'unknown'}). The original data was not modified.`)
      }
      await sleep(3000)
    }
  }

  async function waitForConnection(timeoutMs: number) {
    const start = Date.now()
    for (;;) {
      try {
        const s = await api<{ connected: boolean }>('/api/database/status')
        if (s.connected) return
      } catch {}
      if (Date.now() - start > timeoutMs) {
        fail('PostgreSQL restarted but is not accepting connections yet. The original data was not modified.')
      }
      await sleep(3000)
    }
  }

  /** Restore the original configuration and restart on it. Never throws. */
  async function rollback(originalDir: string, originalBytes: number | null): Promise<string> {
    try {
      await api('/api/database/migration/apply-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ destination: originalDir, source: originalDir, sourceBytes: originalBytes, rollback: true, confirmed: true }),
      })
    } catch {}
    try {
      const r = await api<{ ok: boolean }>('/api/database/migration/service', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'start' }),
      })
      if (!r.ok) return 'Automatic restore did not complete — restart PostgreSQL manually; your original data is untouched.'
    } catch {
      return 'Automatic restore did not complete — restart PostgreSQL manually; your original data is untouched.'
    }
    try {
      await waitForConnection(90000)
      return 'Previous configuration was restored and PostgreSQL is running on the original location.'
    } catch {
      return 'Configuration was restored but PostgreSQL is not accepting connections yet — check the service manually.'
    }
  }

  async function runMigration() {
    const id = ++runId.current
    const alive = () => runId.current === id
    const setP = (percent: number, operation: string, copiedBytes: number | null = null, totalBytes: number | null = null) => {
      if (alive()) setProgress({ percent, operation, copiedBytes, totalBytes })
    }
    setPhase('running')
    setError(null)
    setDoneInfo(null)
    setNotice(null)

    const originalDir = srcDir
    if (!originalDir) {
      setPhase('error')
      setError('Current data directory could not be detected.')
      return
    }
    const setOp = (operation: string) => {
      if (alive()) setProgress((prev) => ({ ...prev, operation }))
    }

    interface ElevatedState {
      status: string
      stage?: string
      operation?: string
      copiedBytes?: number | null
      totalBytes?: number | null
      error?: string
      elevationDenied?: boolean
      rolledBack?: boolean
      newDir?: string
    }

    async function pollElevated(jobId: string): Promise<ElevatedState> {
      return api<ElevatedState>(`/api/database/migration/elevated/progress?id=${encodeURIComponent(jobId)}`)
    }

    /**
     * Full privileged sequence (stop -> copy -> verify -> configure -> start)
     * inside the automatically elevated worker. Windows shows the UAC dialog
     * once; the user never opens a terminal. Progress stays REAL: the copy
     * portion is driven by actual bytes on disk.
     */
    async function runElevatedPrivileged(targetDir: string, totalBytes: number | null) {
      setP(8, 'Requesting Administrator permission...')
      const launched = await api<{ ok: boolean; jobId?: string; awaitingApproval?: boolean; elevationDenied?: boolean; error?: string }>(
        '/api/database/migration/elevated/start',
        { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ mode: 'migrate', source: originalDir, destination: targetDir }) }
      )
      if (!alive()) return
      if (!launched.ok || !launched.jobId) {
        if (launched.elevationDenied) fail('Administrator permission is required to move the PostgreSQL data directory.')
        fail(launched.error || 'Could not request Administrator permission.')
      }
      for (;;) {
        const p = await pollElevated(launched.jobId)
        if (!alive()) return
        if (p.status === 'failed') {
          if (p.elevationDenied) fail('Administrator permission is required to move the PostgreSQL data directory.')
          let msg = p.error || 'Automatic migration did not complete. The original data was not modified.'
          if (p.rolledBack) msg += ' Previous configuration was restored and PostgreSQL is running on the original location.'
          fail(msg)
        }
        if (p.status === 'done') {
          setP(94, 'PostgreSQL is running on the new location.')
          if (p.newDir && p.newDir.toLowerCase().replace(/\\$/, '') !== targetDir.toLowerCase().replace(/\\$/, '')) {
            fail('Migration finished on an unexpected directory. The original data was not modified.')
          }
          return
        }
        const copied = p.copiedBytes ?? null
        const denom = (p.totalBytes && p.totalBytes > 0 ? p.totalBytes : totalBytes) ?? null
        const frac = copied !== null && denom && denom > 0 ? Math.min(1, copied / denom) : 0
        switch (p.stage) {
          case 'validating': setP(6, p.operation || 'Detecting PostgreSQL installation...'); break
          case 'preparing': setP(7, p.operation || 'Preparing destination...'); break
          case 'stopping': setP(10, p.operation || 'Stopping PostgreSQL service...'); break
          case 'copying': setP(12 + Math.round(68 * frac), p.operation || 'Copying PostgreSQL data...', copied, denom); break
          case 'verifying': setP(82, p.operation || 'Verifying copied data...'); break
          case 'configuring': setP(87, p.operation || 'Updating PostgreSQL configuration...'); break
          case 'starting': setP(91, p.operation || 'Starting PostgreSQL...'); break
          default: setP(8, p.operation || 'Waiting for Administrator approval...');
        }
        await sleep(2000)
      }
    }

    /**
     * Restore the original location through the elevated worker (used when
     * the server itself lacks elevation). Never throws — returns a message.
     */
    async function runElevatedRestore(restoreDir: string): Promise<string> {
      try {
        const launched = await api<{ ok: boolean; jobId?: string; elevationDenied?: boolean; error?: string }>(
          '/api/database/migration/elevated/start',
          { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ mode: 'restore', destination: restoreDir }) }
        )
        if (!launched.ok || !launched.jobId) {
          if (launched.elevationDenied) return 'Administrator permission is required to restore the previous configuration.'
          return `Previous configuration could not be restored automatically (${launched.error || 'unknown error'}). Your original data is untouched.`
        }
        for (;;) {
          const p = await pollElevated(launched.jobId)
          if (!alive()) return 'Restore was interrupted. Your original data is untouched.'
          if (p.status === 'failed') {
            if (p.elevationDenied) return 'Administrator permission is required to restore the previous configuration.'
            let msg = p.error || 'Previous configuration could not be restored automatically.'
            if (p.rolledBack) msg += ' PostgreSQL is running on the original location.'
            return `${msg} Your original data is untouched.`
          }
          if (p.status === 'done') {
            try {
              await waitForConnection(90000)
              return 'Previous configuration was restored and PostgreSQL is running on the original location.'
            } catch {
              return 'Previous configuration was restored but PostgreSQL is not accepting connections yet.'
            }
          }
          setOp(p.operation || 'Restoring previous configuration...')
          await sleep(2000)
        }
      } catch {
        return 'Previous configuration could not be restored automatically. Your original data is untouched.'
      }
    }

    let configChanged = false
    let stoppedByUs = false
    let originalBytes: number | null = null
    let elevatedUsed = false

    try {
      // 1 — Validate destination (fresh, server-side).
      setP(2, 'Validating destination...')
      const v = await api<Prep>('/api/database/migration/prepare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ destination }),
      })
      if (!alive()) return
      if (!v.ok) fail(v.error || 'Destination validation failed.')
      setPrep(v)
      const target = v.normalizedPath || destination.trim()
      const total = v.sourceBytes ?? null
      originalBytes = total

      // 2 — Capture the "before" snapshot while PostgreSQL is still running.
      setP(5, 'Reading current database state...')
      const pre = await api<{ snapshot: Snapshot }>('/api/database/migration/verify')
      if (!alive()) return

      // 3 — Stop PostgreSQL cleanly (never kill processes). When the server
      // itself lacks elevation, Windows UAC appears automatically and the
      // whole privileged sequence runs elevated — never manual commands.
      setP(8, 'Stopping PostgreSQL service...')
      const stop = await api<{ ok: boolean; state: string; message: string; needsManual: boolean; manualCommand: string | null }>(
        '/api/database/migration/service',
        { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'stop' }) }
      )
      if (!alive()) return
      if (!stop.ok && stop.needsManual) {
        await runElevatedPrivileged(target, total)
        if (!alive()) return
        elevatedUsed = true
        configChanged = true
      } else {
        if (!stop.ok) fail(stop.message || 'Could not stop PostgreSQL.')
        await waitForService('stopped', 120000)
        if (!alive()) return
        stoppedByUs = true

        // 4 — Copy with REAL byte progress (destination bytes / measured source).
        setP(12, 'Copying PostgreSQL data...', 0, total)
        const started = await api<{ ok: boolean; jobId?: string; totalBytes?: number; error?: string }>(
          '/api/database/migration/copy/start',
          { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ destination: target, source: originalDir, sourceBytes: total }) }
        )
        if (!alive()) return
        if (!started.ok || !started.jobId) fail(started.error || 'Could not start the automatic copy.')
        const jobTotal = started.totalBytes && started.totalBytes > 0 ? started.totalBytes : total
        for (;;) {
          const p = await api<{ status: string; copiedBytes: number | null; totalBytes: number | null; percent: number | null; error?: string }>(
            `/api/database/migration/copy/progress?id=${encodeURIComponent(started.jobId)}`
          )
          if (!alive()) return
          if (p.status === 'failed' || p.status === 'cancelled') {
            fail(p.error || 'The copy did not complete. The original data was not modified.')
          }
          const denom = p.totalBytes && p.totalBytes > 0 ? p.totalBytes : jobTotal
          if (p.status === 'done') {
            setP(80, 'Copying PostgreSQL data...', denom, denom)
            break
          }
          const copied = p.copiedBytes ?? 0
          const frac = denom && denom > 0 ? Math.min(1, copied / denom) : 0
          setP(12 + Math.round(68 * frac), 'Copying PostgreSQL data...', copied, denom)
          await sleep(2000)
        }

        // 5 — Verify the copied data (read-only; original untouched).
        setP(82, 'Verifying copied data...')
        const vc = await api<{ ok: boolean; checks: Array<{ ok: boolean; label: string; detail: string }> }>(
          '/api/database/migration/verify-copy',
          { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ destination: target, source: originalDir, sourceBytes: total }) }
        )
        if (!alive()) return
        if (!vc.ok) fail('Destination copy did not fully verify. The original data was not modified.')

        // 6 — Point the service at the verified copy (location only).
        setP(87, 'Updating PostgreSQL configuration...')
        const cfg = await api<{ ok: boolean; applied?: boolean; needsManual?: boolean; manualCommand?: string | null; error?: string; message?: string }>(
          '/api/database/migration/apply-config',
          { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ destination: target, source: originalDir, sourceBytes: total, confirmed: true }) }
        )
        if (!alive()) return
        if (!cfg.ok || !cfg.applied) {
          if (cfg.needsManual) {
            await runElevatedPrivileged(target, total)
            if (!alive()) return
            elevatedUsed = true
          } else {
            fail(cfg.error || cfg.message || 'Configuration was not changed.')
          }
        }
        configChanged = true

        // 7 — Start PostgreSQL on the new location.
        if (!elevatedUsed) {
          setP(91, 'Starting PostgreSQL service...')
          const start = await api<{ ok: boolean; message: string; needsManual: boolean; manualCommand: string | null }>(
            '/api/database/migration/service',
            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'start' }) }
          )
          if (!alive()) return
          if (!start.ok) {
            const rb = await rollback(originalDir, total)
            fail(`${start.message || 'Could not start PostgreSQL.'} ${rb}`)
          }
          await waitForService('running', 120000)
          if (!alive()) return
        }
      }

      // 8 — Wait until PostgreSQL accepts connections.
      setP(95, 'Waiting for PostgreSQL to accept connections...')
      try {
        await waitForConnection(90000)
      } catch (e: any) {
        const rb = elevatedUsed ? await runElevatedRestore(originalDir) : await rollback(originalDir, total)
        fail(`${e.message} ${rb}`)
      }
      if (!alive()) return

      // 9 — Verify integrity: same version, databases, exact row counts, new location.
      setP(98, 'Verifying database integrity...')
      const post = await api<{ snapshot: Snapshot }>('/api/database/migration/verify')
      if (!alive()) return
      const keys = new Set([...Object.keys(pre.snapshot.counts), ...Object.keys(post.snapshot.counts)])
      const countsEqual = [...keys].every((k) => pre.snapshot.counts[k] === post.snapshot.counts[k] && pre.snapshot.counts[k] !== -1)
      const dbsEqual = JSON.stringify([...pre.snapshot.databases].sort()) === JSON.stringify([...post.snapshot.databases].sort())
      const major = (ver: string | null) => (ver?.match(/PostgreSQL\s+(\d+)/i) || [])[1] || ver
      const locationOk = (post.snapshot.dataDirectory || '').replace(/\//g, '\\').toLowerCase().replace(/\\$/, '') === target.toLowerCase().replace(/\\$/, '')
      if (!(countsEqual && dbsEqual && major(pre.snapshot.version) === major(post.snapshot.version) && locationOk)) {
        const rb = elevatedUsed ? await runElevatedRestore(originalDir) : await rollback(originalDir, total)
        fail(`Verification mismatch after the move — counts, version, or location differ. ${rb}`)
      }

      // Success — only now is the old directory considered removable (manually).
      // Record the completed migration in the audit trail (best-effort: the
      // endpoint re-verifies the live location before recording).
      try {
        await api('/api/database/migration/complete', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ destination: target, source: originalDir }),
        })
      } catch {}
      setP(100, 'Migration completed.')
      setDoneInfo({ oldDir: originalDir, newDir: target })
      setPhase('done')
    } catch (e: any) {
      if (!alive()) return
      // Never leave PostgreSQL permanently disconnected. Original data is
      // never deleted in any path. Failures are reported specifically:
      // permission vs PostgreSQL vs disk — never a generic blob.
      let msg: string = e?.message || 'Migration failed.'
      if (configChanged && originalDir) {
        if (elevatedUsed) {
          const rb = await runElevatedRestore(originalDir)
          msg = `${msg} ${rb}`
        } else {
          const rb = await rollback(originalDir, originalBytes)
          msg = `${msg} ${rb}`
        }
      } else if (stoppedByUs) {
        try {
          const r = await api<{ ok: boolean; message?: string }>(
            '/api/database/migration/service',
            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'start' }) }
          )
          if (r.ok) {
            try {
              await waitForService('running', 120000)
              await waitForConnection(90000)
              msg = `${msg} PostgreSQL was restarted on the original location and is accepting connections.`
            } catch {
              msg = `${msg} PostgreSQL was restarted but is not accepting connections yet — check the service manually.`
            }
          } else {
            msg = `${msg} PostgreSQL could not be restarted automatically (${r.message || 'access denied'}) — start the service manually; your original data is untouched.`
          }
        } catch {
          msg = `${msg} PostgreSQL could not be restarted automatically — start the service manually; your original data is untouched.`
        }
      }
      if (alive()) {
        setError(msg)
        setPhase('error')
      }
    }
  }

  const phaseLabel = phase === 'select' ? 'Migrate' : phase === 'running' ? 'Migrating' : phase === 'done' ? 'Completed' : 'Failed'

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4"
        onClick={phase === 'running' ? undefined : onClose}
      >
        <motion.div
          initial={{ opacity: 0, y: 24, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 24, scale: 0.98 }}
          transition={{ duration: 0.25 }} onClick={(e) => e.stopPropagation()}
          className="w-full max-w-[640px] max-h-[92vh] overflow-y-auto bg-white rounded-[22px] border border-slate-100 shadow-2xl"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 sticky top-0 bg-white rounded-t-[22px] z-10">
            <div>
              <h3 className="text-base font-bold text-slate-900">Move PostgreSQL Data Directory</h3>
              <p className="text-xs text-slate-500 mt-0.5">{phaseLabel}</p>
            </div>
            <button
              onClick={phase === 'running' ? undefined : onClose}
              disabled={phase === 'running'}
              className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500 disabled:opacity-40"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="p-6">
            {error && phase === 'error' && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-[13px] text-red-700 mb-4">
                <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" /> <span className="flex-1">{error}</span>
              </div>
            )}
            {notice && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-[13px] text-emerald-800 mb-4">
                <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" /> <span className="flex-1">{notice}</span>
              </div>
            )}

            {phase === 'select' && (
              <div className="space-y-3">
                <div className="rounded-2xl border border-slate-200 p-4 space-y-2">
                  <div className="flex justify-between gap-4">
                    <span className="text-[13px] text-slate-500">Current location</span>
                    <span className="text-[13px] font-semibold text-slate-900 font-mono text-right break-all">{srcDir || 'Detecting…'}</span>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="text-[13px] text-slate-500">PostgreSQL database size</span>
                    <span className="text-[13px] font-semibold text-slate-900 tabular-nums">
                      {status?.dataDirSizeBytes ? formatBytes(status.dataDirSizeBytes) : 'Unavailable'}
                    </span>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="text-[13px] text-slate-500">Available destination space</span>
                    <span className="text-[13px] font-semibold text-slate-900 tabular-nums">
                      {prep?.ok ? formatBytes(prep.freeBytes ?? null) : '—'}
                    </span>
                  </div>
                </div>

                <div>
                  <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">Destination disk</p>
                  {drivesLoading && (
                    <div className="flex items-center gap-2 text-sm text-slate-500 py-4 justify-center">
                      <Loader2 className="w-4 h-4 animate-spin" /> Detecting local disks…
                    </div>
                  )}
                  {drivesError && (
                    <div className="flex items-start gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-[13px] text-red-700">
                      <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" /> {drivesError}
                    </div>
                  )}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {drives.map((d) => (
                      <button
                        key={d.root}
                        onClick={() => {
                          setDriveRoot(d.root)
                          setDestination(`${d.root}PostgreSQL\\data`)
                        }}
                        className={cn(
                          'text-left px-3 py-3 rounded-2xl border transition-colors',
                          driveRoot === d.root
                            ? 'border-[var(--primary)] bg-[var(--primary-soft)]'
                            : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                        )}
                      >
                        <div className="flex items-center gap-2">
                          <HardDrive className="w-4 h-4 text-slate-600 flex-shrink-0" />
                          <p className="text-[13px] font-bold text-slate-900 truncate">{d.root} {d.label}</p>
                          {driveRoot === d.root && <Check className="w-3.5 h-3.5 text-[var(--primary)] ml-auto flex-shrink-0" />}
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1">{formatBytes(d.freeBytes)} free of {formatBytes(d.totalBytes)}</p>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">Destination folder</p>
                  <div className="flex gap-2">
                    <input
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      className="flex-1 min-w-0 px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-mono focus:ring-2 focus:ring-[var(--primary)]/30 focus:outline-none"
                    />
                    <button
                      onClick={() => validateDestination(destination.trim())}
                      disabled={validating}
                      className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium hover:bg-slate-50 disabled:opacity-50 inline-flex items-center gap-2 flex-shrink-0"
                    >
                      {validating && <Loader2 className="w-4 h-4 animate-spin" />} Re-check
                    </button>
                  </div>
                </div>

                <div className="rounded-2xl border border-slate-200 p-4">
                  <p className="text-[13px] font-bold text-slate-900 mb-1">
                    Validation {validating ? '— checking…' : '— automatic'}
                  </p>
                  {statusLoading && !status ? (
                    <p className="text-[13px] text-slate-500 py-2">Detecting PostgreSQL installation…</p>
                  ) : (
                    <>
                      <CheckLine ok={!!status?.version} label={`PostgreSQL installation detected${status?.version ? `: ${status.version.split(' ').slice(0, 2).join(' ')}` : ''}`} />
                      <CheckLine ok={!!srcDir} label="Current data directory detected" detail={srcDir || undefined} />
                      {prep ? (
                        prep.ok ? (
                          <>
                            <CheckLine ok label="Destination exists and is writable" detail={prep.normalizedPath} />
                            <CheckLine ok label={`Enough free space (${formatBytes(prep.freeBytes ?? null)} free, ${formatBytes(prep.requiredBytes ?? null)} required)`} />
                            <CheckLine ok label="Destination is suitable for PostgreSQL" />
                          </>
                        ) : (
                          <CheckLine ok={false} label={prep.error || 'Destination is not valid'} detail={prep.normalizedPath} />
                        )
                      ) : (
                        <p className="text-[13px] text-slate-500 py-1">{validating ? 'Validating destination…' : 'Waiting for a destination…'}</p>
                      )}
                      {canMigrate === false && (
                        <div className="rounded-xl border border-red-200 bg-red-50 p-3.5 space-y-2 mt-2">
                          <div className="flex items-start gap-2 text-[13px] text-red-800">
                            <ShieldAlert className="w-4 h-4 mt-0.5 flex-shrink-0" />
                            <span><b>Administrator access required.</b> Migration is administrator-only, and the signed-in account is not authorized. Ask the machine owner to run this once (roles live in PostgreSQL, outside the app), then log out and back in:</span>
                          </div>
                          <CodeBlock text={ROLE_FIX_SQL} />
                        </div>
                      )}
                    </>
                  )}
                </div>

                {ready && (
                  <div className="flex items-start gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-[13px] text-emerald-800">
                    <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" /> <span><b>Ready to migrate.</b> Everything will run automatically after you start.</span>
                  </div>
                )}
                <Warn>PostgreSQL will be stopped during the move. The original data is never deleted — it stays as a safety copy until you remove it manually after verification.</Warn>

                <button
                  onClick={runMigration}
                  disabled={!ready}
                  className="w-full px-5 py-3 rounded-xl bg-[var(--primary)] text-white text-sm font-semibold hover:bg-[#912222] disabled:opacity-40"
                >
                  Start Migration
                </button>
                {!ready && !validating && (
                  <p className="text-[11px] text-slate-400 text-center">Select a valid destination to continue.</p>
                )}
              </div>
            )}

            {phase === 'running' && (
              <div className="space-y-4">
                <div>
                  <p className="text-base font-bold text-slate-900">Moving PostgreSQL Data Directory</p>
                  <p className="text-xs text-slate-500 mt-0.5">Do not close this dialog or turn off the computer.</p>
                </div>
                <div>
                  <div className="h-3 w-full rounded-full bg-slate-200 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-[var(--primary)] to-[#B91C1C] transition-all duration-500"
                      style={{ width: `${Math.min(100, Math.max(0, progress.percent))}%` }}
                    />
                  </div>
                  <div className="flex justify-between mt-1.5">
                    <p className="text-[13px] font-bold text-slate-900 tabular-nums">{progress.percent}% complete</p>
                    {progress.totalBytes ? (
                      <p className="text-[12px] text-slate-500 tabular-nums">
                        Copied: {formatBytes(progress.copiedBytes)} / {formatBytes(progress.totalBytes)}
                      </p>
                    ) : null}
                  </div>
                </div>
                <div className="flex items-start gap-2 p-3 rounded-xl bg-slate-50 border border-slate-200 text-[13px] text-slate-700">
                  <Loader2 className="w-4 h-4 mt-0.5 flex-shrink-0 animate-spin text-[var(--primary)]" />
                  <span><span className="text-slate-500">Current operation:</span> <b>{progress.operation || 'Starting…'}</b></span>
                </div>
              </div>
            )}

            {phase === 'done' && (
              <div className="space-y-3">
                <div className="flex items-start gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-[13px] text-emerald-800">
                  <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span><b>Migration completed successfully.</b></span>
                </div>
                <div className="rounded-2xl border border-slate-200 p-4 space-y-2">
                  <div className="flex justify-between gap-4">
                    <span className="text-[13px] text-slate-500">Old location</span>
                    <span className="text-[13px] font-semibold text-slate-900 font-mono text-right break-all">{doneInfo?.oldDir}</span>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="text-[13px] text-slate-500">New location</span>
                    <span className="text-[13px] font-semibold text-slate-900 font-mono text-right break-all">{doneInfo?.newDir}</span>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="text-[13px] text-slate-500">Database</span>
                    <span className="text-[13px] font-semibold text-emerald-700">Connected</span>
                  </div>
                </div>
                <Warn>The old directory was kept as a safety copy. Remove it manually only after you have used the app normally on the new location.</Warn>
                {doneInfo && <CodeBlock text={`rmdir /S "${doneInfo.oldDir.replace(/\//g, '\\')}"`} />}
                <button
                  onClick={onClose}
                  className="w-full px-5 py-3 rounded-xl bg-[var(--primary)] text-white text-sm font-semibold hover:bg-[#912222]"
                >
                  Done
                </button>
              </div>
            )}

            {phase === 'error' && (
              <div className="space-y-3">
                <Warn>Migration did not complete. Your original data was not deleted. PostgreSQL was restored to the original location where possible.</Warn>
                <div className="flex gap-2">
                  <button
                    onClick={onClose}
                    className="px-5 py-2.5 rounded-xl border border-slate-200 text-sm font-medium hover:bg-slate-50"
                  >
                    Close
                  </button>
                  <div className="flex-1" />
                  <button
                    onClick={() => {
                      setError(null)
                      setPhase('select')
                      setNotice(null)
                      loadStatus()
                      if (destination.trim()) validateDestination(destination.trim())
                    }}
                    className="px-5 py-2.5 rounded-xl bg-[var(--primary)] text-white text-sm font-medium hover:bg-[#912222] inline-flex items-center gap-2"
                  >
                    <RefreshCw className="w-4 h-4" /> Retry Migration
                  </button>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

export function ManualMigrationGuide({ serviceName, dataDir }: { serviceName: string | null; dataDir: string | null }) {
  const src = (dataDir || '<current data directory>').replace(/\//g, '\\')
  const svc = serviceName || '<postgresql-service>'
  const pgCtl = dataDir
    ? `"${dataDir.replace(/\//g, '\\').replace(/\\data\\?$/, '')}\\bin\\pg_ctl.exe"`
    : '<pg_ctl.exe path>'
  const steps: Array<{ t: string; c?: string }> = [
    { t: 'Backup the database (pg_dump custom format) to a different location.', c: 'pg_dump -U postgres -Fc -d sakthi_finance -f D:\\PostgreSQL_Backup\\sakthi_finance.backup' },
    { t: 'Verify the backup is readable.', c: 'pg_restore --list D:\\PostgreSQL_Backup\\sakthi_finance.backup' },
    { t: 'Stop the PostgreSQL service cleanly (elevated terminal).', c: `net stop "${svc}"` },
    { t: 'Confirm it is fully stopped.', c: `sc.exe query "${svc}"` },
    { t: 'Copy the complete data directory (elevated terminal, preserves permissions).', c: `robocopy "${src}" "<new data directory>" /MIR /COPYALL /DCOPY:DAT /MT:32 /J /R:2 /W:2 /XJ /NP /NFL /NDL` },
    { t: 'Point the service at the new directory (elevated terminal).', c: `sc.exe config "${svc}" binPath= "${pgCtl} runservice -N \\"${svc}\\" -D \\"<new data directory>\\" -w"` },
    { t: 'Start the service.', c: `net start "${svc}"` },
    { t: 'Test the connection and verify SAKTHI FINANCE data (login, customers, payments, dashboard).' },
    { t: 'Keep the old directory until everything is confirmed. Only then remove it manually.', c: `rmdir /S "${src}"` },
  ]
  return (
    <div className="space-y-3">
      <p className="text-[13px] text-slate-600">Manual Windows procedure (same safety order as the wizard):</p>
      {steps.map((s, i) => (
        <div key={i} className="flex gap-3">
          <span className="w-6 h-6 rounded-full bg-[var(--primary-soft)] text-[var(--primary)] text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">{i + 1}</span>
          <div className="min-w-0 flex-1 space-y-1.5">
            <p className="text-[13px] text-slate-700">{s.t}</p>
            {s.c && <CodeBlock text={s.c} />}
          </div>
        </div>
      ))}
      <div className="flex items-start gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-[13px] text-red-800">
        <ShieldAlert className="w-4 h-4 mt-0.5 flex-shrink-0" />
        <span>Restore only if required: <span className="font-mono">pg_restore -U postgres --clean --if-exists -d sakthi_finance D:\PostgreSQL_Backup\sakthi_finance.backup</span>. Never mix major versions. Never delete the original directory automatically.</span>
      </div>
    </div>
  )
}

export function DatabaseSummaryCard() {
  const [s, setS] = useState<MigStatus | null>(null)
  useEffect(() => {
    api<MigStatus>('/api/database/migration/status').then(setS).catch(() => {})
  }, [])
  const rows: Array<[string, string]> = [
    ['Database', s ? 'Connected ✓' : 'Checking…'],
    ['PostgreSQL Version', s?.version ? s.version.split(' ').slice(0, 2).join(' ') : 'Unavailable'],
    ['Database', 'sakthi_finance'],
    ['Data Location', s?.dataDirectory || 'Unavailable'],
    ['Database Size', s?.dbSizeBytes ? formatBytes(s.dbSizeBytes) : 'Unavailable'],
    ['Connection', 'Local PostgreSQL'],
  ]
  return (
    <div className="rounded-2xl border border-slate-200 overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2.5 bg-slate-50 border-b border-slate-100">
        <Database className="w-4 h-4 text-[var(--primary)]" />
        <p className="text-xs font-bold text-slate-800 uppercase tracking-wider">Settings → Database</p>
      </div>
      {rows.map(([k, v]) => (
        <div key={k} className="flex justify-between gap-4 px-4 py-2 border-b border-slate-100 last:border-0">
          <span className="text-[12.5px] text-slate-500">{k}</span>
          <span className="text-[12.5px] font-bold text-slate-900 text-right break-all">{v}</span>
        </div>
      ))}
    </div>
  )
}
