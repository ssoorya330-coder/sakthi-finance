'use client'

import { useState } from 'react'
import AdminSectionShell, { AdminEmpty, AdminError, AdminLoading } from './AdminSectionShell'
import { useAdminApi } from './useAdminApi'
import { formatCurrency } from '@/features/dashboard/dashboard.styles'
import { isDeveloperEmail } from '@/config/developer-access'

interface Account {
  user_id: string
  email: string
  full_name: string
  role: string
  is_active: boolean
  customer_count: number
  active_customer_count: number
  completed_customer_count: number
  aborted_customer_count: number
  loan_count: number
  loan_amount: string
  total_amount: string
  paid_amount: string
  balance_amount: string
  last_login_at: string | null
  created_at: string | null
}

const date = (value: string | null) => value ? new Date(value).toLocaleDateString('en-IN') : '—'

export default function AccountMonitorContent() {
  const { data, state, retrying, retry } = useAdminApi<Account[]>('/api/admin/users', j => Array.isArray(j?.users) ? j.users : [])
  const [search, setSearch] = useState('')
  const accounts = data || []
  const shown = accounts.filter(a => `${a.full_name || ''} ${a.email || ''}`.toLowerCase().includes(search.trim().toLowerCase()))
  return (
    <AdminSectionShell title="Account Monitor" subtitle="Developer-only, read-only financial summaries for each account" icon="users">
      <div className="flex flex-wrap gap-3 items-center">
        <input aria-label="Search accounts" placeholder="Search account name or email" value={search} onChange={e => setSearch(e.target.value)} className="flex-1 min-w-48 rounded-xl border border-[#E8CFCF] bg-white px-4 py-3 text-sm" />
        <button onClick={retry} disabled={retrying || state === 'loading'} className="rounded-xl bg-[var(--primary)] text-white px-5 py-3 text-sm disabled:opacity-50">{retrying ? 'Refreshing…' : 'Refresh'}</button>
      </div>
      {state === 'loading' && <AdminLoading />}
      {(state === 'failed' || state === 'unauthorized') && <AdminError message={state === 'unauthorized' ? 'Developer access is required.' : 'Unable to load account summaries.'} onRetry={retry} retrying={retrying} />}
      {state === 'ready' && <>
        <p className="text-xs text-slate-500">{shown.length} of {accounts.length} accounts · Amounts include non-deleted Kanaku. Customer counts are customer records, not Kanaku counts. Active includes overdue Kanaku with a balance.</p>
        {shown.length === 0 && <AdminEmpty message="No matching accounts" />}
        {shown.map(a => <section key={a.user_id} className="rounded-2xl border border-[#E8CFCF] bg-white overflow-hidden shadow-sm">
          <header className="flex flex-wrap justify-between gap-3 bg-[#FFF8ED] p-5 border-b border-[#F1E4CE]">
            <div><h2 className="font-semibold text-[var(--primary)]">{a.full_name || a.email}</h2><p className="text-sm text-slate-600 break-all">{a.email}</p><p className="text-xs text-slate-500 mt-1">Joined {date(a.created_at)} · Last login {date(a.last_login_at)}</p></div>
            <div className="text-right text-sm"><p className="font-semibold capitalize">{isDeveloperEmail(a.email) ? 'Developer' : a.role}</p><p className={a.is_active ? 'text-emerald-700' : 'text-red-700'}>{a.is_active ? 'Account active' : 'Account disabled'}</p></div>
          </header>
          <div className="p-5 space-y-5">
            <div><h3 className="text-sm font-semibold mb-3">Customers & Kanaku</h3><div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              {Object.entries({ 'Total customers': a.customer_count, 'Active customers': a.active_customer_count, 'Completed customers': a.completed_customer_count, 'Aborted customers': a.aborted_customer_count, 'Total Kanaku': a.loan_count }).map(([label, value]) => <div key={label} className="rounded-xl bg-[var(--background)] p-3"><p className="text-xs text-slate-500">{label}</p><p className="text-xl font-semibold mt-1">{value ?? 0}</p></div>)}
            </div></div>
            <div><h3 className="text-sm font-semibold mb-3">Financial summary</h3><div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {Object.entries({ 'Loan amount': a.loan_amount, 'Total repayable': a.total_amount, 'Amount received': a.paid_amount, 'Outstanding balance': a.balance_amount }).map(([label, value]) => <div key={label} className="rounded-xl border border-[#F1E4CE] p-3"><p className="text-xs text-slate-500">{label}</p><p className="text-lg font-semibold text-[var(--primary)] mt-1 break-words">{formatCurrency(Number(value) || 0)}</p></div>)}
            </div></div>
          </div>
        </section>)}
      </>}
    </AdminSectionShell>
  )
}
