'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { Briefcase } from 'lucide-react'
import { PieChart, Pie, Cell, Sector, ResponsiveContainer } from 'recharts'
import WidgetCard from './WidgetCard'
import { useCustomerStore } from '@/store/customer-store'

const COLORS = ['var(--chart-1)', 'var(--chart-2)', 'var(--chart-3)', 'var(--chart-4)', '#10B981', '#F59E0B', '#EC4899', '#06B6D4', '#84CC16', '#F97316', '#6366F1', '#14B8A6']

const CX = 84
const CY = 84
const INNER_R = 50
const OUTER_R = 74

interface Slice {
  name: string
  value: number
  color: string
  pct: number
}

export default function BusinessTypeChart() {
  const customers = useCustomerStore((s) => s.customers)
  const [activeIndex, setActiveIndex] = useState(-1)

  const data = useMemo<Slice[]>(() => {
    const counts: Record<string, number> = {}
    for (const c of customers) {
      const key = (c.occupation || '').trim() || 'No Business'
      counts[key] = (counts[key] || 0) + 1
    }
    const total = customers.length
    const ordered: Slice[] = Object.entries(counts)
      .sort(([, a], [, b]) => b - a)
      .map(([name, value], i) => ({
        name,
        value,
        color: COLORS[i % COLORS.length],
        pct: total > 0 ? (value / total) * 100 : 0,
      }))
    return ordered
  }, [customers])

  const angles = useMemo(() => {
    const total = data.reduce((s, d) => s + d.value, 0)
    if (total <= 0) return []
    let cum = 0
    return data.map((d) => {
      const angle = (d.value / total) * 360
      const startAngle = 90 - cum
      const endAngle = startAngle - angle
      cum += angle
      return { startAngle, endAngle }
    })
  }, [data])

  const total = customers.length
  const max = Math.max(1, ...data.map((d) => d.value))
  const active = activeIndex >= 0 && activeIndex < data.length ? data[activeIndex] : null
  const activeAngle = activeIndex >= 0 && activeIndex < angles.length ? angles[activeIndex] : null

  return (
    <WidgetCard
      icon={Briefcase}
      title="Business Type Analysis"
      subtitle="By occupation"
    >
      <div className="flex items-center gap-3">
        <div className="relative w-[168px] h-[168px] flex-shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data.length > 0 ? data : [{ name: 'No Data', value: 1, color: '#F1F5F9', pct: 100 }]}
                cx={CX}
                cy={CY}
                innerRadius={INNER_R}
                outerRadius={OUTER_R}
                paddingAngle={data.length > 1 ? 3 : 0}
                dataKey="value"
                startAngle={90}
                endAngle={-270}
                onMouseEnter={(_: unknown, index: number) => setActiveIndex(index)}
                onMouseLeave={() => setActiveIndex(-1)}
                animationDuration={1200}
                animationEasing="ease-out"
              >
                {data.length > 0
                  ? data.map((entry, i) => (
                      <Cell
                        key={entry.name}
                        fill={entry.color}
                        stroke="none"
                        style={activeIndex === i ? { filter: 'brightness(1.08)' } : undefined}
                      />
                    ))
                  : <Cell fill="#F1F5F9" stroke="none" />}
              </Pie>
              {active && activeAngle && (
                <g>
                  <Sector
                    cx={CX}
                    cy={CY}
                    innerRadius={INNER_R}
                    outerRadius={OUTER_R + 9}
                    startAngle={activeAngle.startAngle}
                    endAngle={activeAngle.endAngle}
                    fill={active.color}
                    style={{ filter: 'drop-shadow(0 6px 14px rgba(127,29,29,0.35))' }}
                  />
                  <Sector
                    cx={CX}
                    cy={CY}
                    innerRadius={INNER_R}
                    outerRadius={OUTER_R + 4}
                    startAngle={activeAngle.startAngle}
                    endAngle={activeAngle.endAngle}
                    fill={active.color}
                    opacity={0.55}
                  />
                </g>
              )}
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <p className="text-2xl font-semibold text-[var(--text-primary)] tracking-tight">{total}</p>
              <p className="text-[10px] font-medium text-slate-400 uppercase tracking-wider">Business</p>
            </div>
        </div>

        <div className="flex-1 space-y-1.5">
          {data.map((item, idx) => (
            <motion.div
              key={item.name}
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, delay: 0.15 + idx * 0.06, ease: [0.16, 1, 0.3, 1] }}
              onMouseEnter={() => setActiveIndex(idx)}
              onMouseLeave={() => setActiveIndex(-1)}
              className="px-2.5 py-1.5 rounded-xl transition-colors duration-200 hover:bg-[var(--surface-secondary)] cursor-default"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className="w-3 h-3 rounded-full flex-shrink-0"
                    style={{ backgroundColor: item.color, boxShadow: `0 0 8px color-mix(in srgb, ${item.color} 27%, transparent)` }}
                  />
                  <span className="text-sm font-medium text-slate-700 truncate">{item.name}</span>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <span className="text-sm font-semibold text-[var(--text-primary)]">{item.value}</span>
                  <span className="text-xs font-medium text-slate-400 w-[38px] text-right">
                    {item.pct.toFixed(1)}%
                  </span>
                </div>
              </div>
              <div className="mt-1.5 h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
                <motion.div
                  className="h-full rounded-full"
                  style={{ background: `linear-gradient(90deg, ${item.color}, color-mix(in srgb, ${item.color} 80%, transparent))` }}
                  initial={{ width: 0 }}
                  animate={{ width: `${(item.value / max) * 100}%` }}
                  transition={{ duration: 0.8, delay: 0.2 + idx * 0.05, ease: [0.16, 1, 0.3, 1] }}
                />
              </div>
            </motion.div>
          ))}
          {data.length === 0 && (
            <p className="text-sm text-slate-400 text-center py-6">No business data yet</p>
          )}
        </div>
      </div>
    </WidgetCard>
  )
}
