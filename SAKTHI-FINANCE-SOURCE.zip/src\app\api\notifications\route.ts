import { NextRequest, NextResponse } from 'next/server'
import { requireAuth } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'

export async function GET(request: NextRequest) {
  const auth = await requireAuth()
  if (auth.error) return auth.error
  const page = Math.max(1, Math.min(100000, Number(request.nextUrl.searchParams.get('page')) || 1))
  if (!Number.isInteger(page)) return NextResponse.json({ error: 'Invalid page' }, { status: 400 })
  try {
    const result = await dbQuery(`SELECT id, title, message, type, is_read AS "isRead", created_at AS "createdAt"
      FROM notifications WHERE user_id = $1 ORDER BY created_at DESC, id DESC LIMIT 20 OFFSET $2`, [auth.user.userId, (page - 1) * 20])
    const counts = await dbQuery(`SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE is_read = false)::int AS unread
      FROM notifications WHERE user_id = $1`, [auth.user.userId])
    return NextResponse.json({ items: result.rows, ...counts.rows[0], page }, { headers: { 'Cache-Control': 'no-store' } })
  } catch {
    return NextResponse.json({ error: 'Unable to load notifications' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  const auth = await requireAuth()
  if (auth.error) return auth.error
  let body
  try { body = await request.json() } catch {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 })
  }
  if (!body || (body.all !== true && (typeof body.id !== 'string' || !/^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(body.id)))) {
    return NextResponse.json({ error: 'Select a notification' }, { status: 400 })
  }
  try {
    const result = body.all === true
      ? await dbQuery('UPDATE notifications SET is_read = true WHERE user_id = $1 AND is_read = false RETURNING id', [auth.user.userId])
      : await dbQuery('UPDATE notifications SET is_read = true WHERE user_id = $1 AND id = $2 RETURNING id', [auth.user.userId, body.id])
    if (body.all !== true && !result.rows.length) return NextResponse.json({ error: 'Notification not found' }, { status: 404 })
    await dbQuery("SELECT pg_notify('app_notifications', $1)", [JSON.stringify({ userId: auth.user.userId, kind: 'read' })])
    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json({ error: 'Unable to mark notifications as read' }, { status: 500 })
  }
}
