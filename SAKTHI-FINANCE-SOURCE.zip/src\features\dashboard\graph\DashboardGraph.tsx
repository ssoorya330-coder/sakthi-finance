'use client'

import { useCallback, useMemo, useState } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { TrendingUp } from 'lucide-react'
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'
import { useCustomerStore } from '@/store/customer-store'
import { formatINR } from '@/lib/dashboard-utils'
import { GRAPH_METRICS } from './graph.types'
import type { GraphDateRange, GraphVisible, MetricKey, RangeKey } from './graph.types'
import {
  buildGraphData,
  formatDayShort,
  getDefaultCustomRange,
  getPresetRanges,
  isGraphDataEmpty,
  resolveGranularity,
  sumMetric,
} from './graph-data'
import DateFilter from './DateFilter'
import GraphLegend from './GraphLegend'
import GraphLoader from './GraphLoader'
import GraphTooltip from './GraphTooltip'
import CustomDatePicker from './CustomDatePicker'
import EmptyStateGraph from './EmptyStateGraph'


function allVisible(): GraphVisible {
  return {
    amountGiven: true,
    amountReceived: true,
    interestEarned: true,
    remainingBalance: true,
    todayCollection: true,
  }
}

export default function DashboardGraph() {
  const reducedMotion = useReducedMotion()
  const customers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const loading = useCustomerStore((s) => s.loading)
  const initialized = useCustomerStore((s) => s.initialized)

  const [activeKey, setActiveKey] = useState<RangeKey>('last30')
  const [visible, setVisible] = useState<GraphVisible>(allVisible)
  const [customStart, setCustomStart] = useState<Date | null>(null)
  const [customEnd, setCustomEnd] = useState<Date | null>(null)
  const [pickerOpen, setPickerOpen] = useState(false)

  const range: GraphDateRange = useMemo(() => {
    if (activeKey === 'custom') {
      if (customStart && customEnd) return { start: customStart, end: customEnd }
      return getDefaultCustomRange()
    }
    return getPresetRanges()[activeKey as Exclude<RangeKey, 'custom'>]
  }, [activeKey, customStart, customEnd, customers, paymentHistory])

  const granularity = useMemo(
    () => resolveGranularity(activeKey, range),
    [activeKey, range]
  )

  const data = useMemo(
    () => buildGraphData(range, granularity, customers, paymentHistory),
    [range, granularity, customers, paymentHistory]
  )

  const empty = useMemo(() => !loading && isGraphDataEmpty(data), [data, loading])

  const totalReceived = useMemo(() => sumMetric(data, 'amountReceived'), [data])
  const totalGiven = useMemo(() => sumMetric(data, 'amountGiven'), [data])
  const collectionRate = useMemo(
    () => (totalGiven > 0 ? (totalReceived / totalGiven) * 100 : 0),
    [totalReceived, totalGiven]
  )

  const anyVisible = useMemo(
    () => Object.values(visible).some(Boolean),
    [visible]
  )

  const tickInterval = useMemo(
    () => Math.max(1, Math.ceil(data.length / 8)),
    [data.length]
  )

  const busy = loading || (!initialized && customers.length === 0 && paymentHistory.length === 0)

  const handleSelectFilter = useCallback((key: RangeKey) => {
    setActiveKey(key)
    if (key === 'custom') setPickerOpen(true)
  }, [])

  const handleToggleMetric = useCallback((key: MetricKey) => {
    setVisible((prev) => ({ ...prev, [key]: !prev[key] }))
  }, [])

  const handleApplyCustom = useCallback((start: Date, end: Date) => {
    setCustomStart(start)
    setCustomEnd(end)
    setActiveKey('custom')
    setPickerOpen(false)
  }, [])

  const handleResetCustom = useCallback(() => {
    setCustomStart(null)
    setCustomEnd(null)
    setActiveKey('last30')
  }, [])

  const handleClosePicker = useCallback(() => setPickerOpen(false), [])

  const customLabel = useMemo(() => {
    if (activeKey !== 'custom' || !customStart || !customEnd) return null
    return `${formatDayShort(customStart)} – ${formatDayShort(customEnd)}`
  }, [activeKey, customStart, customEnd])

  return (
    <motion.div initial={{ opacity: 0, y: reducedMotion ? 0 : 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: reducedMotion ? 0 : 0.65, ease: 'easeOut' }} className="relative bg-white/60 backdrop-blur-xl rounded-[22px] border border-white/20 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] p-5 sm:p-6 min-h-[480px] overflow-hidden">
      <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-[var(--primary)]/5 to-[var(--secondary)]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-[var(--secondary)]/5 to-[var(--primary)]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10">
        <div className="flex flex-col xl:flex-row xl:items-start justify-between gap-4 mb-5">
          <div className="flex items-start gap-2.5">
            <div className="w-9 h-9 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20 shrink-0">
              <TrendingUp className="w-[16px] h-[16px] text-white" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-900">Finance Analytics</h3>
              <div className="flex items-baseline gap-2 mt-1 flex-wrap">
                <span className="text-2xl font-bold text-slate-900 tracking-tight tabular-nums">
                  {formatINR(totalReceived)}
                </span>
                <span className="text-xs font-semibold text-emerald-600">
                  {collectionRate.toFixed(1)}% collected
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 tabular-nums">
                Given {formatINR(totalGiven)} · {data.length} point{data.length === 1 ? '' : 's'}
              </p>
            </div>
          </div>

          <div className="shrink-0">
            <DateFilter activeKey={activeKey} customLabel={customLabel} onSelect={handleSelectFilter} />
          </div>
        </div>

        <div className="mb-5">
          <GraphLegend visible={visible} onToggle={handleToggleMetric} />
        </div>

        {busy ? (
          <GraphLoader />
        ) : empty ? (
          <EmptyStateGraph />
        ) : (
          <div className="relative h-[320px]">
            <motion.div
              initial={{ opacity: 0.4 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="absolute inset-0"
            >
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
                  <defs>
                    {GRAPH_METRICS.map((m) => (
                      <linearGradient key={m.key} id={`grad-${m.key}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={m.color} stopOpacity={0.28} />
                        <stop offset="100%" stopColor={m.color} stopOpacity={0.02} />
                      </linearGradient>
                    ))}
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#EEF2F7" vertical={false} />
                  <XAxis
                    dataKey="label"
                    tick={{ fontSize: 11, fill: '#94A3B8' }}
                    axisLine={false}
                    tickLine={false}
                    interval={tickInterval}
                    minTickGap={14}
                  />
                  <YAxis
                    tick={{ fontSize: 11, fill: '#94A3B8' }}
                    axisLine={false}
                    tickLine={false}
                    width={52}
                    tickFormatter={(v: number) =>
                      `${v >= 1e7 ? `${(v / 1e7).toFixed(1)}Cr` : v >= 1e5 ? `${(v / 1e5).toFixed(1)}L` : v >= 1e3 ? `${(v / 1e3).toFixed(0)}k` : `${Math.round(v)}`}`
                    }
                  />
                  <Tooltip
                    content={<GraphTooltip />}
                    cursor={{ stroke: '#CBD5E1', strokeWidth: 1, strokeDasharray: '4 4' }}
                  />
                  {GRAPH_METRICS.map((m) =>
                    visible[m.key] ? (
                      <Area
                        key={m.key}
                        type="monotone"
                        dataKey={m.key}
                        name={m.label}
                        stroke={m.color}
                        strokeWidth={2.5}
                        fill={`url(#grad-${m.key})`}
                        dot={false}
                        activeDot={{ r: 5, strokeWidth: 2, stroke: '#fff' }}
                        isAnimationActive={!reducedMotion}
                        animationDuration={1200}
                        animationEasing="ease-out"
                      />
                    ) : null
                  )}
                </AreaChart>
              </ResponsiveContainer>
            </motion.div>

            {!anyVisible && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <p className="text-xs font-medium text-slate-400 bg-white/80 backdrop-blur-sm px-3 py-1.5 rounded-full border border-slate-100 shadow-sm">
                  All metrics hidden — click a metric above to show it
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      <CustomDatePicker
        open={pickerOpen}
        initialStart={customStart}
        initialEnd={customEnd}
        onApply={handleApplyCustom}
        onReset={handleResetCustom}
        onClose={handleClosePicker}
      />
    </motion.div>
  )
}
