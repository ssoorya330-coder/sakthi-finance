'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import UsersContent from '@/features/admin-access/UsersContent'

export default function UsersContentPage() {
  return (
    <ClientPageGate requireRole="owner">
      <UsersContent />
    </ClientPageGate>
  )
}
