// Backend startup instrumentation: logs once when the Next.js server boots.
// Satisfies the requirement that the backend shows a visible startup log.

let logged = false;

export async function register(): Promise<void> {
  if (process.env.NEXT_RUNTIME !== 'nodejs') return;
  const { validateSigningKeys } = await import('./lib/auth/signing-keys');
  validateSigningKeys();
  if (logged) return;
  logged = true;
  const { startKanakuRetention } = await import('./server/kanaku-retention');
  startKanakuRetention();

  const port = process.env.PORT || '3000';
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || '(same-origin)';

  console.log('══════════════════════════════════════════════════════');
  console.log(`  Sakthi Finance backend started — http://localhost:${port}`);
  console.log(`  API base:        ${apiUrl}`);
  console.log(`  Database:        PostgreSQL (offline client cache: SQLite)`);
  console.log(`  Node env:        ${process.env.NODE_ENV || 'development'}`);
  console.log('══════════════════════════════════════════════════════');
}
