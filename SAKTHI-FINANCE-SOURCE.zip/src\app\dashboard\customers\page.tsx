'use client'

import { matchesCustomerDateRange } from '@/lib/customer-collection-date'
import { customerSearchIndex } from '@/lib/device-sync/search'

import { useState, useCallback, useRef, memo, Suspense, useEffect, useMemo } from 'react'
import { useSearchParams, useRouter, usePathname } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { useQueryClient } from '@tanstack/react-query'
import {
  Users,
  Search,
  Save,
  CheckCircle2,
  Trash2,
  OctagonX,
  CalendarDays,
  CalendarRange,
  MoreHorizontal,
  PencilLine,
  HandCoins,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ChevronDown,
  Check,
} from 'lucide-react'
import { useCustomerStore } from '@/store/customer-store'
import { useSidebarStore } from '@/store/sidebar-store'
import { useToastStore } from '@/store/toast-store'
import { formatCurrency, formatDateDMY } from '@/features/dashboard/dashboard.styles'
import PaymentHistoryDrawer from '@/components/dashboard/PaymentHistoryDrawer'
import CustomerDetailDrawer from '@/components/dashboard/CustomerDetailDrawer'
import Popup from '@/components/ui/popup'
import VoiceMicButton from '@/components/ui/voice-mic-button'
import { Z_INDEX } from '@/lib/z-index'
import Link from 'next/link'
import type { Customer } from '@/types/customer.types'
import { deleteLoan } from '@/services/api-client'

const WINE = 'var(--primary)'
const WINE_HOVER = '#912222'
const GOLD = 'var(--secondary)'
const GOLD_HOVER = '#E6C55A'
const BG_LIGHT = 'var(--background)'
const TEXT_DARK = 'var(--text-primary)'
const BORDER_WINE = 'rgba(127,29,29,.12)'
const STICKY_LEFT_BG = '#FFF8E5'
const STICKY_RIGHT_BG = '#FDECEC'
const SCROLLABLE_BG = 'var(--background)'
const ROW_ALT = '#FCFBF4'
const ID_COL_W = 96
const NAME_COL_W = 180
const COL_W = {
  phone: 140,
  address: 200,
  area: 130,
  city: 130,
  business: 190,
  loanDate: 104,
  dueDate: 104,
  status: 96,
  cycle: 96,
  kanaku: 108,
  installment: 108,
  loanAmount: 108,
  interest: 88,
  totalAmount: 112,
  balance: 112,
  received: 140,
  paymentMode: 150,
  actions: 50,
}
const TABLE_MIN_W = ID_COL_W + NAME_COL_W + COL_W.phone + COL_W.address + COL_W.area + COL_W.city + COL_W.business + COL_W.loanDate + COL_W.dueDate + COL_W.status + COL_W.cycle + COL_W.kanaku + COL_W.installment + COL_W.loanAmount + COL_W.interest + COL_W.totalAmount + COL_W.balance + COL_W.received + COL_W.paymentMode + COL_W.actions
const COL_COUNT = 20
const ROW_ANIM_LIMIT = 20

const statusColor: Record<string, { bg: string; text: string; dot: string }> = {
  Active: { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  Completed: { bg: 'bg-[var(--primary-soft)]', text: 'text-[var(--primary)]', dot: 'bg-[var(--primary)]' },
  Overdue: { bg: 'bg-red-50', text: 'text-red-700', dot: 'bg-red-500' },
  Aborted: { bg: 'bg-red-50', text: 'text-[var(--primary)]', dot: 'bg-[var(--primary)]' },
}

function formatCurrencyInput(raw: string): string {
  if (!raw) return ''
  const [whole, fraction] = raw.split('.')
  return new Intl.NumberFormat('en-IN').format(Number(whole) || 0) + (fraction !== undefined ? `.${fraction}` : '')
}

const ReceivedPaymentInput = memo(function ReceivedPaymentInput({
  value,
  onChange,
  onEnter,
  onArrow,
  registerRef,
  error,
  index,
}: {
  value: string
  onChange: (v: string) => void
  onEnter?: () => void
  onArrow?: (dir: 1 | -1) => void
  registerRef?: (el: HTMLInputElement | null) => void
  error?: boolean
  index: number
}) {
  const inputRef = useRef<HTMLInputElement>(null)
  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value
    const digits = raw.replace(/,/g, '')
    if (!/^\d{0,12}(\.\d{0,2})?$/.test(digits)) return
    onChange(digits)
  }, [onChange])
  const handleFocus = useCallback(() => inputRef.current?.select(), [])
  useEffect(() => {
    registerRef?.(inputRef.current)
    return () => registerRef?.(null)
  }, [registerRef])
  const handleKeyDown = useCallback((e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      onEnter?.()
      return
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      onArrow?.(1)
      return
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      onArrow?.(-1)
    }
  }, [onEnter, onArrow])
  const displayValue = value ? formatCurrencyInput(value) : ''
  return (
    <input
      ref={inputRef}
      type="text"
      inputMode="decimal"
      data-payment-row-index={index}
      aria-label="Received amount"
      placeholder="0"
      value={displayValue}
      onChange={handleChange}
      onFocus={handleFocus}
      onKeyDown={handleKeyDown}
      title={error ? 'Entered amount is greater than the balance amount' : undefined}
      className={`w-[110px] h-9 px-2 rounded-[10px] border bg-white text-sm text-right font-semibold outline-none transition-all [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none ${
        error
          ? 'border-red-400 text-red-600 focus:border-red-500 focus:ring-2 focus:ring-red-100'
          : 'border-[rgba(127,29,29,.15)] text-[var(--text-primary)] focus:border-[var(--secondary)] focus:ring-2 focus-ring-[rgba(212,175,55,.15)]'
      }`}
    />
  )
})

function CustomerRowWithFocus({
  customer,
  index,
  isAlt,
  rpValue,
  onView,
  onDelete,
  onAbort,
  animateIn,
  receivedPayments,
  onEnter,
}: {
  customer: Customer
  index: number
  isAlt: boolean
  rpValue: string
  onView: (c: Customer) => void
  onDelete: (id: string) => void
  onAbort: (c: Customer) => void
  animateIn: boolean
  receivedPayments: Record<string, string>
  onEnter: (currentIdx: number) => void
}) {
  const c = customer
  const sc = statusColor[c.status] || statusColor.Active
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const paidTotal = paymentHistory.filter((p) => p.customerId === c.id).reduce((sum, p) => sum + (Number(p.paymentAmount) || 0), Number(c.offlinePaidAmount)||0)
  const outstanding = Math.max(0, (Number(c.totalAmount) || 0) - paidTotal)
  const getDisplayId = useCustomerStore((s) => s.getDisplayId)
  const updateReceivedPayment = useCustomerStore((s) => s.updateReceivedPayment)
  const paymentMode = useCustomerStore((s) => s.receivedPaymentModes[c.id] || 'Cash')
  const updatePaymentMode = useCustomerStore((s) => s.updateReceivedPaymentMode)
  const setPaymentMode = (mode: 'Cash' | 'PhonePe') => updatePaymentMode(c.id, mode)

  const handleEnter = useCallback(() => {
    onEnter(index)
  }, [onEnter, index])

  return (
    <motion.tr
      initial={animateIn ? { opacity: 0, y: 8 } : false}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: Math.min(index, 20) * 0.02, ease: [0.16, 1, 0.3, 1] }}
      className="group transition-all duration-200"
      style={{
        height: '52px',
        background: isAlt ? ROW_ALT : '#FFFFFF',
      }}
      onMouseEnter={(e) => {
        const tr = e.currentTarget
        tr.style.boxShadow = 'inset 0 0 0 1px rgba(212,175,55,.25), 0 2px 12px rgba(212,175,55,.1)'
        tr.style.transform = 'translateZ(0)'
        tr.style.willChange = 'transform'
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.boxShadow = 'none'
        e.currentTarget.style.transform = ''
        e.currentTarget.style.willChange = ''
      }}
    >
      {/* Sticky Left: ID */}
      <td
        className="px-3 py-2 text-sm font-semibold whitespace-nowrap z-20 border-r"
        style={{
          position: 'sticky',
          left: 0,
          color: TEXT_DARK,
          background: isAlt ? '#FDF8E0' : STICKY_LEFT_BG,
          minWidth: ID_COL_W,
          width: ID_COL_W,
          borderRightColor: `rgba(212,175,55,.25)`,
        }}
      >
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{ background: `${WINE}10` }}>
            <Users className="w-3 h-3" style={{ color: WINE }} />
          </div>
          {getDisplayId(c)}
        </div>
      </td>

      {/* Sticky Left: Name */}
      <td
        className="px-3 py-2 whitespace-nowrap z-20 border-r"
        style={{
          position: 'sticky',
          left: ID_COL_W,
          background: isAlt ? '#FDF8E0' : STICKY_LEFT_BG,
          minWidth: NAME_COL_W,
          width: NAME_COL_W,
          borderRightColor: `rgba(212,175,55,.25)`,
        }}
      >
        <span
          className="text-sm font-semibold"
          style={{ color: WINE }}
        >
          {c.fullName}
        </span>
      </td>

      {/* Scrollable Columns */}
      <td className="px-3 py-2 text-sm whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.phone }}>{c.mobileNumber}</td>
      <td className="px-3 py-2 text-sm" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.address, width: COL_W.address }}>{c.address || '—'}</td>
      <td className="px-3 py-2 text-sm whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.area }}>{c.area || '—'}</td>
      <td className="px-3 py-2 text-sm whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.city }}>{c.city || '—'}</td>
      <td className="px-3 py-2 text-sm whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', width: COL_W.business, minWidth: COL_W.business }}>
        <span className="block pr-2">{c.occupation || '—'}</span>
      </td>
      <td className="px-3 py-2 text-sm whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.loanDate }}>{c.loanDate ? formatDateDMY(c.loanDate) : '—'}</td>
      <td className="px-3 py-2 text-sm whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.dueDate }}>{c.dueDate ? formatDateDMY(c.dueDate) : '—'}</td>

      {/* Status */}
      <td className="px-3 py-2 text-center whitespace-nowrap" style={{ minWidth: COL_W.status }}>
        <span
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-semibold ${sc.bg} ${sc.text}`}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
          {c.status}
        </span>
      </td>

      <td className="px-3 py-2 text-center text-xs font-semibold text-[var(--primary)]" style={{ minWidth: COL_W.cycle }}>{c.cycleNumber ? `Cycle ${c.cycleNumber}` : '—'}</td>
      <td className="px-3 py-2 text-center text-xs font-semibold text-[var(--primary)]" style={{ minWidth: COL_W.kanaku }} title="Shown loan account; open View for all Kanaku">{c.kanakuNumber ? `Kanaku ${c.kanakuNumber}` : '—'}</td>

      <td className="px-3 py-2 text-sm font-semibold text-right whitespace-nowrap" style={{ color: TEXT_DARK, minWidth: COL_W.installment }}>
        {formatCurrency(c.installmentAmount || 0)}
      </td>
      <td className="px-3 py-2 text-sm font-semibold text-right whitespace-nowrap" style={{ color: TEXT_DARK, minWidth: COL_W.loanAmount }}>
        {formatCurrency(Number(c.loanAmount) || 0)}
      </td>
      <td className="px-3 py-2 text-sm text-right whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.interest }}>{Number(c.interestRate) || 0}%</td>
      <td className="px-3 py-2 text-sm font-semibold text-right whitespace-nowrap" style={{ color: TEXT_DARK, minWidth: COL_W.totalAmount }}>
        {formatCurrency(c.totalAmount || 0)}
      </td>
      <td className="px-3 py-2 text-sm font-semibold text-right whitespace-nowrap" style={{ color: TEXT_DARK, minWidth: COL_W.balance }}>
        {formatCurrency(outstanding)}
      </td>

      {/* Sticky Right: Received Amount */}
      <td
        className="px-3 py-2 z-20 border-l"
        style={{
          position: 'sticky',
          right: COL_W.actions + COL_W.paymentMode,
          background: isAlt ? '#FDE0E0' : STICKY_RIGHT_BG,
          borderLeftColor: `rgba(212,175,55,.25)`,
          boxShadow: '-2px 0 6px rgba(127,29,29,.06)',
          minWidth: COL_W.received,
        }}
      >
        <div className="flex justify-end">
          <ReceivedPaymentInput
            value={rpValue}
            onChange={(v) => updateReceivedPayment(c.id, v)}
            onEnter={() => handleEnter()}
            index={index}
          />
        </div>
      </td>

      {/* Sticky Right: Payment Mode */}
      <td
        className="px-2 py-2 z-30 text-center"
        style={{
          position: 'sticky', right: COL_W.actions,
          background: isAlt ? '#FDE0E0' : STICKY_RIGHT_BG,
          boxShadow: '-2px 0 6px rgba(127,29,29,.06)',
          minWidth: COL_W.paymentMode, width: COL_W.paymentMode,
        }}
      >
        <div className="flex items-center justify-center gap-1.5">
          {(['Cash', 'PhonePe'] as const).map((mode) => (
            <button key={mode} type="button" onClick={() => setPaymentMode(mode)} aria-pressed={paymentMode === mode}
              className="rounded-md px-2 py-1 text-[10px] font-semibold transition-colors"
              style={{ color: paymentMode === mode ? '#FFFFFF' : WINE, background: paymentMode === mode ? WINE : `${WINE}10` }}>
              {mode}
            </button>
          ))}
        </div>
      </td>

      {/* Sticky Right: View */}
      <td
        className="px-3 py-2 z-40 text-center"
        style={{
          position: 'sticky',
          right: 0,
          background: isAlt ? '#FDE0E0' : STICKY_RIGHT_BG,
          boxShadow: '-2px 0 6px rgba(127,29,29,.06)',
          minWidth: COL_W.actions,
          width: COL_W.actions,
        }}
      >
        <button
            onClick={() => onView(c)}
            aria-label={`View customer using ${paymentMode}`}
            className="w-8 h-8 rounded-lg flex items-center justify-center transition-all hover:scale-110"
            style={{ color: WINE, background: `${WINE}10` }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
              <circle cx="12" cy="12" r="3" />
            </svg>
        </button>
      </td>
    </motion.tr>
  )
}

function toISODateStr(d: Date): string {
  return d.toISOString().split('T')[0]
}

function pad2(n: number): string {
  return String(n).padStart(2, '0')
}

function toLocalDateKey(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`
}

function getTodayLocalKey(): string {
  return toLocalDateKey(new Date())
}

function getCustomerCreatedDate(c: Customer): Date {
  const raw = c.createdAt || c.updatedAt || c.loanDate || ''
  const d = raw ? new Date(raw) : new Date()
  return isNaN(d.getTime()) ? new Date() : d
}

function formatShortDate(key: string): string {
  const d = new Date(`${key}T00:00:00`)
  if (isNaN(d.getTime())) return key
  return new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }).format(d)
}

const MONTHS_FULL = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
]

const WEEKDAY_LABELS = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su']

type ViewMode = 'All' | 'Daily' | 'Weekly' | 'Monthly'

const VIEW_OPTIONS: { value: ViewMode; title: string }[] = [
  { value: 'All', title: 'Show all customers' },
  { value: 'Daily', title: 'Show daily loan customers' },
  { value: 'Weekly', title: 'Show weekly loan customers' },
  { value: 'Monthly', title: 'Show monthly loan customers' },
]

type DateRangeValue = { start: string | null; end: string | null }

function computePeriodRange(_anchor: Date, _view: string): DateRangeValue {
  return { start: null, end: null }
}

function getCollectionForDate(paymentHistory: any[], customers: Customer[], dateStr: string): number {
  const customerIds = new Set(customers.map((c) => c.id))
  return paymentHistory
    .filter((p) => p.customerId && customerIds.has(p.customerId))
    .filter((p) => {
      const pd = p.paymentDate || p.createdAt
      return pd && pd.startsWith(dateStr)
    })
    .reduce((sum, p) => sum + (Number(p.paymentAmount) || 0), 0)
}

function CountUpValue({ value }: { value: number }) {
  const [display, setDisplay] = useState(0)
  const fromRef = useRef(0)
  const rafRef = useRef<number>(0)

  useEffect(() => {
    const from = fromRef.current
    const to = value
    if (from === to) {
      setDisplay(to)
      return
    }
    const start = performance.now()
    const duration = 300
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration)
      const eased = 1 - Math.pow(1 - t, 3)
      setDisplay(Math.round(from + (to - from) * eased))
      if (t < 1) {
        rafRef.current = requestAnimationFrame(tick)
      } else {
        fromRef.current = to
      }
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(rafRef.current)
  }, [value])

  return <>{formatCurrency(display)}</>
}

const GOLD_BAR_GRADIENT = 'linear-gradient(180deg, var(--secondary), #F5D98B)'

function MiniGoldChart({ data }: { data: number[] }) {
  const max = Math.max(...data, 0)
  const heights =
    max > 0 ? data.map((v) => Math.max(8, (v / max) * 100)) : [38, 58, 46, 72, 88]
  return (
    <div className="flex items-end gap-[3px] h-[26px] w-[52px]">
      {heights.map((h, i) => (
        <motion.div
          key={i}
          className="flex-1 rounded-t-[3px] origin-bottom"
          initial={{ scaleY: 0 }}
          animate={{ scaleY: 1 }}
          transition={{ duration: 0.55, delay: 0.2 + i * 0.08, ease: [0.16, 1, 0.3, 1] }}
          style={{ height: `${h}%`, background: GOLD_BAR_GRADIENT }}
        />
      ))}
    </div>
  )
}

function TodayCollectionCard({
  today,
  yesterday,
  bars,
}: {
  today: number
  yesterday: number
  bars: number[]
}) {
  const isUp = today >= yesterday
  const pct = yesterday > 0 ? ((today - yesterday) / yesterday) * 100 : today > 0 ? 100 : 0
  const DiffIcon = isUp ? ArrowUpRight : ArrowDownRight
  const diffColor = isUp ? '#16A34A' : '#DC2626'

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0, boxShadow: '0 10px 30px rgba(127,29,29,0.08)' }}
      whileHover={{ y: -4, scale: 1.02, boxShadow: '0 18px 45px rgba(127,29,29,0.16), 0 6px 16px rgba(0,0,0,0.05)' }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className="relative flex-shrink-0 overflow-hidden rounded-[20px] bg-white w-[200px] sm:w-[220px] lg:w-[230px] h-24"
      style={{ border: '1px solid rgba(212,175,55,0.35)' }}
    >
      {/* Decorative layer */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute inset-0"
          style={{ background: 'radial-gradient(circle at 85% 5%, rgba(212,175,55,0.16), transparent 55%)' }}
        />
        <div
          className="absolute inset-0"
          style={{ backgroundImage: 'repeating-linear-gradient(135deg, rgba(212,175,55,0.045) 0 1px, transparent 1px 9px)' }}
        />
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 230 96" fill="none" preserveAspectRatio="none">
          <path d="M2 22 V2 H22" stroke="rgba(212,175,55,0.5)" strokeWidth="1.5" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
          <path d="M228 22 V2 H208" stroke="rgba(212,175,55,0.5)" strokeWidth="1.5" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
          <path d="M2 74 V94 H22" stroke="rgba(212,175,55,0.5)" strokeWidth="1.5" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
          <path d="M228 74 V94 H208" stroke="rgba(212,175,55,0.5)" strokeWidth="1.5" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
          <path d="M-10 92 C 55 80, 140 96, 240 78" stroke="rgba(212,175,55,0.22)" strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
          <path d="M-10 76 C 60 64, 150 84, 240 62" stroke="rgba(212,175,55,0.12)" strokeWidth="1" vectorEffect="non-scaling-stroke" />
        </svg>
      </div>

      <div className="relative h-full flex flex-col justify-between p-2.5 pr-12">
        {/* Header */}
        <div className="flex items-center gap-1.5 min-w-0">
          <div
            className="w-[20px] h-[20px] rounded-md flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(212,175,55,0.14)' }}
          >
            <Wallet className="w-[11px] h-[11px]" style={{ color: GOLD }} />
          </div>
          <span
            className="text-[15px] font-semibold truncate"
            style={{ color: TEXT_DARK, fontFamily: 'Inter, sans-serif' }}
          >
            Today's Collection
          </span>
        </div>

        {/* Main amount */}
        <p className="text-[34px] font-bold leading-none tracking-tight whitespace-nowrap" style={{ color: WINE }}>
          <CountUpValue value={today} />
        </p>

        {/* Comparison */}
        <div className="flex items-center gap-1 min-w-0">
          <DiffIcon className="w-3.5 h-3.5 flex-shrink-0" style={{ color: diffColor }} strokeWidth={2.5} />
          <span className="text-[11px] font-bold whitespace-nowrap" style={{ color: diffColor }}>
            {pct >= 0 ? '+' : ''}
            {pct.toFixed(1)}%
          </span>
          <span className="text-[11px] font-medium truncate" style={{ color: '#6B7280' }}>
            vs Yesterday
          </span>
        </div>

        {/* Mini chart */}
        <div className="absolute bottom-1.5 right-2">
          <MiniGoldChart data={bars} />
        </div>
      </div>
    </motion.div>
  )
}

const TodayCollectionCardLive = memo(function TodayCollectionCardLive({
  today,
  yesterday,
  bars,
}: {
  today: number
  yesterday: number
  bars: number[]
}) {
  return <TodayCollectionCard today={today} yesterday={yesterday} bars={bars} />
})

type SaveStatus = 'idle' | 'saving' | 'saved'

const SaveAllButton = memo(function SaveAllButton({
  status,
  onSave,
}: {
  status: SaveStatus
  onSave: () => void
}) {
  const hasUnsavedChanges = useCustomerStore((s) => Object.keys(s.receivedPayments).length > 0)
  return (
    <button
      onClick={onSave}
      disabled={status === 'saving' || !hasUnsavedChanges}
      className="h-10 px-5 rounded-xl text-sm font-semibold transition-all duration-200 active:scale-[0.97] flex items-center gap-2"
      style={{
        background: 'linear-gradient(135deg, var(--primary), #912222)',
        border: `1px solid ${GOLD}`,
        color: GOLD,
        boxShadow: '0 4px 20px rgba(212,29,29,.15)',
        opacity: !hasUnsavedChanges ? 0.5 : 1,
      }}
    >
      {status === 'saving' ? (
        <svg className="animate-spin w-4 h-4" viewBox="0 0 16 16" fill="none">
          <circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="2" opacity="0.25" />
          <path d="M15 8A7 7 0 1 1 1 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      ) : status === 'saved' ? (
        <CheckCircle2 className="w-4 h-4" />
      ) : (
        <Save className="w-4 h-4" />
      )}
      {status === 'saving' ? 'Saving...' : status === 'saved' ? 'Saved' : 'Save All'}
    </button>
  )
})

function CountUpNumber({ value }: { value: number }) {
  const [display, setDisplay] = useState(0)
  const fromRef = useRef(0)
  const rafRef = useRef<number>(0)

  useEffect(() => {
    const from = fromRef.current
    const to = value
    if (from === to) {
      setDisplay(to)
      return
    }
    const start = performance.now()
    const duration = 300
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration)
      const eased = 1 - Math.pow(1 - t, 3)
      setDisplay(Math.round(from + (to - from) * eased))
      if (t < 1) {
        rafRef.current = requestAnimationFrame(tick)
      } else {
        fromRef.current = to
      }
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(rafRef.current)
  }, [value])

  return <>{new Intl.NumberFormat('en-IN').format(display)}</>
}

const KpiCard = memo(function KpiCard({
  icon: Icon,
  title,
  value,
  subtitle,
  delay,
}: {
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>
  title: string
  value: React.ReactNode
  subtitle: string
  delay: number
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{
        backgroundColor: '#FFFFFF',
        boxShadow: 'inset 0 0 0 1.5px rgba(212,175,55,.45), 0 14px 34px rgba(127,29,29,.12)',
      }}
      transition={{ duration: 0.45, delay, ease: [0.16, 1, 0.3, 1] }}
      className="group relative flex-1 min-w-0 px-3 sm:px-4 py-0.5 flex flex-col justify-center gap-0.5 overflow-hidden"
      style={{ background: 'rgba(255,255,255,.42)' }}
    >
      <div
        className="absolute -top-8 -right-8 w-28 h-28 rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(212,175,55,.13), transparent 70%)' }}
      />
      <div className="flex items-center gap-2">
        <div
          className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 transition-transform duration-300 group-hover:scale-110"
          style={{
            background: 'linear-gradient(135deg, #F5D98B, var(--secondary))',
            boxShadow: '0 4px 12px rgba(212,175,55,.35)',
          }}
        >
          <Icon className="w-3.5 h-3.5" style={{ color: WINE }} />
        </div>
        <span className="text-[10px] font-semibold truncate" style={{ color: 'rgba(39,37,59,.55)' }}>
          {title}
        </span>
      </div>
      <p className="text-[16px] sm:text-[18px] font-bold leading-tight tracking-tight tabular-nums truncate" style={{ color: TEXT_DARK }}>
        {value}
      </p>
      <p className="text-[9px] sm:text-[10px] font-medium" style={{ color: 'rgba(39,37,59,.45)' }}>
        {subtitle}
      </p>
    </motion.div>
  )
})

const KpiSection = memo(function KpiSection({
  totalCustomers,
  rangeLabel,
  rangeWeekday,
  customersOnDate,
}: {
  totalCustomers: number
  rangeLabel: string
  rangeWeekday: string
  customersOnDate: number
}) {
  const divider = (
    <div
      className="h-px md:h-auto md:w-px flex-shrink-0"
      style={{ background: 'linear-gradient(90deg, transparent, rgba(212,175,55,.4), transparent)' }}
    />
  )
  return (
    <div
      className="h-[76px] w-full rounded-[18px] overflow-hidden flex flex-col md:flex-row"
      style={{
        background: 'rgba(255,255,255,.72)',
        backdropFilter: 'blur(14px)',
        WebkitBackdropFilter: 'blur(14px)',
        border: '1px solid rgba(212,175,55,.35)',
        boxShadow: '0 10px 28px rgba(127,29,29,.06), 0 2px 8px rgba(0,0,0,.02)',
      }}
    >
      <KpiCard icon={Users} title="Total Customers" value={<CountUpNumber value={totalCustomers} />} subtitle="All Customers" delay={0} />
      {divider}
      <KpiCard icon={CalendarDays} title="Date Range" value={rangeLabel} subtitle={rangeWeekday} delay={0.08} />
      {divider}
      <KpiCard icon={Users} title="Customers in Range" value={<CountUpNumber value={customersOnDate} />} subtitle="Customers" delay={0.16} />
    </div>
  )
})

const CustomerDateRangePicker = memo(function CustomerDateRangePicker({
  value,
  onApply,
  onReset,
  onToday,
  automaticToday,
}: {
  value: DateRangeValue
  onApply: (range: DateRangeValue) => void
  onReset: () => void
  onToday: () => void
  automaticToday: boolean
}) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const [viewYear, setViewYear] = useState(() => new Date().getFullYear())
  const [viewMonth, setViewMonth] = useState(() => new Date().getMonth())
  const [tempStart, setTempStart] = useState<string | null>(null)
  const [tempEnd, setTempEnd] = useState<string | null>(null)

  const today = new Date()
  const todayKey = getTodayLocalKey()
  const isCurrentMonth = viewYear === today.getFullYear() && viewMonth === today.getMonth()
  const isCurrentYear = viewYear === today.getFullYear()

  useEffect(() => {
    if (open) {
      setTempStart(value.start)
      setTempEnd(value.end)
      const base = value.start ? new Date(`${value.start}T00:00:00`) : new Date()
      if (!isNaN(base.getTime())) {
        setViewYear(base.getFullYear())
        setViewMonth(base.getMonth())
      }
    }
  }, [open, value.start, value.end])

  const goMonth = (delta: number) => {
    const d = new Date(viewYear, viewMonth + delta, 1)
    setViewYear(d.getFullYear())
    setViewMonth(d.getMonth())
  }

  const goYear = (delta: number) => {
    const ny = viewYear + delta
    setViewYear(ny)
  }

  const firstDayIndex = (new Date(viewYear, viewMonth, 1).getDay() + 6) % 7
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate()

  const handlePick = (key: string) => {
    if (!tempStart || tempEnd) {
      setTempStart(key)
      setTempEnd(null)
    } else {
      if (key < tempStart) {
        setTempEnd(tempStart)
        setTempStart(key)
      } else {
        setTempEnd(key)
      }
    }
  }

  const handleApply = () => {
    const s = tempStart
    const e = tempStart && !tempEnd ? tempStart : tempEnd
    onApply({ start: s, end: e })
    setOpen(false)
  }

  const hasSelection = value.start !== null && value.end !== null
  const label = automaticToday ? `Today · ${formatShortDate(todayKey)}` : hasSelection
    ? value.start === value.end ? formatShortDate(value.start!) : `${formatShortDate(value.start!)} - ${formatShortDate(value.end!)}`
    : 'All Dates'

  return (
    <div className="relative w-full sm:w-[220px]" ref={ref}>
      <motion.button
        type="button"
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2.5 w-full h-[46px] px-3.5 rounded-[16px] text-xs font-medium transition-shadow duration-200"
        style={{
          background: 'rgba(255,255,255,0.95)',
          border: `1px solid ${hasSelection ? GOLD : BORDER_WINE}`,
          color: 'rgba(39,37,59,.65)',
          boxShadow: hasSelection ? '0 4px 18px rgba(212,175,55,.24)' : '0 2px 10px rgba(127,29,29,.06)',
        }}
        aria-label="Choose collection dates"
      >
        <CalendarDays className="w-4 h-4 flex-shrink-0" style={{ color: GOLD }} />
        <span className="flex-1 min-w-0 truncate text-left">{label}</span>
        <CalendarDays className="w-4 h-4 flex-shrink-0" style={{ color: GOLD }} />
      </motion.button>

      <Popup
        open={open}
        onClose={() => setOpen(false)}
        anchorRef={ref}
        placement="bottom-start"
        minWidth={300}
        zIndex={Z_INDEX.calendar}
      >
        <motion.div
          initial={{ opacity: 0, y: 8, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
          className="w-[300px] bg-white/95 backdrop-blur-xl rounded-[18px] border border-[rgba(212,175,55,.3)] shadow-[0_16px_50px_rgba(127,29,29,.18),0_4px_12px_rgba(0,0,0,.05)] overflow-hidden"
        >
            <div className="px-4 pt-3 pb-2.5" style={{ background: 'linear-gradient(135deg, var(--primary), #912222)' }}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-0.5">
                  <button
                    onClick={() => goYear(-1)}
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-white/80 hover:bg-white/15 hover:text-white transition-colors"
                    aria-label="Previous year"
                  >
                    <ChevronsLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => goMonth(-1)}
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-white/80 hover:bg-white/15 hover:text-white transition-colors"
                    aria-label="Previous month"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-sm font-semibold text-white">
                  {MONTHS_FULL[viewMonth]} {viewYear}
                </p>
                <div className="flex items-center gap-0.5">
                  <button
                    onClick={() => goMonth(1)}
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-white/80 hover:bg-white/15 hover:text-white transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                    aria-label="Next month"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => goYear(1)}
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-white/80 hover:bg-white/15 hover:text-white transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                    aria-label="Next year"
                  >
                    <ChevronsRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <p className="text-[10px] font-semibold text-white/80 mt-1.5">
                {tempStart ? (tempEnd ? 'Select new range' : 'Select end date') : 'Select start date'}
              </p>
            </div>

            <div className="p-3">
              <p className="mb-2 text-xs font-semibold text-[var(--primary)]">Collection schedule</p>
              <div className="mb-3 grid grid-cols-2 gap-2">
                <button type="button" onClick={() => { onToday(); setOpen(false) }} aria-pressed={automaticToday} className={`rounded-xl px-3 py-2 text-xs font-semibold transition-colors ${automaticToday ? 'bg-[var(--primary)] text-white' : 'bg-rose-50 text-[var(--primary)] hover:bg-rose-100'}`}>Today</button>
                <button type="button" onClick={() => { onReset(); setOpen(false) }} aria-pressed={!hasSelection} className={`rounded-xl px-3 py-2 text-xs font-semibold transition-colors ${!hasSelection ? 'bg-[var(--primary)] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>All Dates</button>
              </div>
              <div className="grid grid-cols-7 gap-1 mb-1">
                {WEEKDAY_LABELS.map((d) => (
                  <div key={d} className="text-center text-[10px] font-semibold text-slate-400 py-1">
                    {d}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {Array.from({ length: firstDayIndex }).map((_, i) => (
                  <div key={`blank-${i}`} />
                ))}
                {Array.from({ length: daysInMonth }).map((_, i) => {
                  const day = new Date(viewYear, viewMonth, i + 1)
                  const key = toLocalDateKey(day)
                  const inRange = tempStart && tempEnd && key > tempStart && key < tempEnd
                  const isPicked = key === tempStart || key === tempEnd
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => handlePick(key)}
                      className={`h-8 rounded-[9px] text-[11px] font-medium transition-all duration-150 ${
                        'text-slate-700 hover:bg-[var(--primary-soft)] hover:text-[var(--primary)]'
                      } ${inRange ? '!bg-[rgba(212,175,55,.16)] !text-[var(--primary)] rounded-none' : ''} ${isPicked ? '!bg-[var(--primary)] !text-white shadow-[0_4px_10px_rgba(127,29,29,.3)]' : ''}`}
                    >
                      {i + 1}
                    </button>
                  )
                })}
              </div>
              <div className="flex items-center justify-between gap-2 mt-2 px-1 text-[10px] font-medium" style={{ color: 'rgba(39,37,59,.45)' }}>
                <span className="truncate">{tempStart ? formatShortDate(tempStart) : '—'}</span>
                <span className="flex-shrink-0">to</span>
                <span className="truncate">{tempEnd ? formatShortDate(tempEnd) : '—'}</span>
              </div>
            </div>

            <div className="flex items-center justify-between gap-2 px-4 pb-3 pt-1">
              <button
                onClick={handleApply}
                className="px-4 h-8 rounded-[10px] text-[11px] font-semibold text-white transition-colors"
                style={{ background: 'linear-gradient(135deg, var(--primary), #912222)' }}
              >
                Apply
              </button>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    onReset()
                    setOpen(false)
                  }}
                  className="px-3 h-8 rounded-[10px] text-[11px] font-semibold border transition-colors"
                  style={{ borderColor: BORDER_WINE, color: TEXT_DARK, background: '#FFFFFF' }}
                >
                  Reset
                </button>
                <button
                  onClick={() => setOpen(false)}
                  className="px-3 h-8 rounded-[10px] text-[11px] font-semibold text-slate-500 hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
        </motion.div>
      </Popup>
    </div>
  )
})

const ViewDropdown = memo(function ViewDropdown({
  value,
  onChange,
}: {
  value: ViewMode
  onChange: (v: ViewMode) => void
}) {
  const [open, setOpen] = useState(false)
  const [highlight, setHighlight] = useState(0)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (open) {
      const idx = VIEW_OPTIONS.findIndex((o) => o.value === value)
      setHighlight(idx === -1 ? 0 : idx)
    }
  }, [open, value])

  const select = useCallback((v: ViewMode) => {
    onChange(v)
    setOpen(false)
  }, [onChange])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>) => {
    if (!open) {
      if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
        e.preventDefault()
        setOpen(true)
      }
      return
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setHighlight((h) => Math.min(VIEW_OPTIONS.length - 1, h + 1))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setHighlight((h) => Math.max(0, h - 1))
    } else if (e.key === 'Home') {
      e.preventDefault()
      setHighlight(0)
    } else if (e.key === 'End') {
      e.preventDefault()
      setHighlight(VIEW_OPTIONS.length - 1)
    } else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault()
      const opt = VIEW_OPTIONS[highlight]
      if (opt) select(opt.value)
    }
  }

  return (
    <div className="relative w-full sm:w-[170px]" ref={ref}>
      <motion.button
        type="button"
        onClick={() => setOpen(!open)}
        onKeyDown={handleKeyDown}
        aria-haspopup="listbox"
        aria-expanded={open}
        whileHover={{ borderColor: GOLD }}
        whileTap={{ scale: 0.98 }}
        className="flex items-center gap-2.5 w-full h-[46px] px-3.5 rounded-[16px] text-left transition-shadow duration-200"
        style={{
          background: 'rgba(255,255,255,0.95)',
          backdropFilter: 'blur(12px)',
          WebkitBackdropFilter: 'blur(12px)',
          border: `1px solid ${BORDER_WINE}`,
          boxShadow: '0 2px 10px rgba(127,29,29,.06)',
        }}
      >
        <span
          className="w-8 h-8 rounded-[10px] flex items-center justify-center flex-shrink-0"
          style={{ background: 'rgba(212,175,55,.14)' }}
        >
          <CalendarRange className="w-4 h-4" style={{ color: GOLD }} />
        </span>
        <span className="flex-1 min-w-0">
          <span className="block text-[9px] font-bold uppercase tracking-widest leading-none mb-0.5" style={{ color: 'rgba(39,37,59,.45)' }}>
            Loan Type
          </span>
          <span className="block text-[13px] font-semibold truncate leading-none" style={{ color: TEXT_DARK }}>
            {value}
          </span>
        </span>
        <ChevronDown
          className="w-4 h-4 flex-shrink-0 transition-transform duration-200"
          style={{
            color: 'rgba(39,37,59,.45)',
            transform: open ? 'rotate(180deg)' : 'rotate(0deg)',
          }}
        />
      </motion.button>

      <Popup
        open={open}
        onClose={() => setOpen(false)}
        anchorRef={ref}
        placement="bottom-start"
        matchWidth
        minWidth={200}
        zIndex={Z_INDEX.dropdown}
      >
        <motion.div
          role="listbox"
          initial={{ opacity: 0, y: -6, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
          className="w-full min-w-[200px] bg-white/95 backdrop-blur-xl rounded-[16px] border border-[rgba(212,175,55,.3)] shadow-[0_16px_50px_rgba(127,29,29,.18),0_4px_12px_rgba(0,0,0,.05)] overflow-hidden"
        >
            <div className="p-1.5 space-y-0.5">
              {VIEW_OPTIONS.map((opt, i) => {
                const isSel = value === opt.value
                const isHl = highlight === i
                return (
                  <button
                    key={opt.value}
                    type="button"
                    role="option"
                    aria-selected={isSel}
                    onMouseEnter={() => setHighlight(i)}
                    onClick={() => select(opt.value)}
                    className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-[13px] font-medium transition-all duration-150"
                    style={{
                      color: isSel ? WINE : TEXT_DARK,
                      background: isHl
                        ? isSel
                          ? 'rgba(127,29,29,.10)'
                          : 'rgba(212,175,55,.12)'
                        : isSel
                          ? 'rgba(127,29,29,.05)'
                          : 'transparent',
                    }}
                  >
                    <span className="w-4 flex items-center justify-center flex-shrink-0">
                      {isSel && <Check className="w-3.5 h-3.5" style={{ color: WINE }} strokeWidth={2.5} />}
                    </span>
                    <span className="flex-1 truncate">{opt.value}</span>
                  </button>
                )
              })}
            </div>
        </motion.div>
      </Popup>
    </div>
  )
})

const CustomerRow = memo(function CustomerRow({
  customer,
  index,
  isAlt,
  rpValue,
  onView,
  onSelect,
  onDelete,
  onAbort,
  animateIn,
  isSelected,
  receivedPayments,
  onEnter,
  focusReceived,
  registerReceivedInput,
  paidTotal,
}: {
  customer: Customer
  index: number
  isAlt: boolean
  rpValue: string
  onView: (c: Customer) => void
  onSelect: (c: Customer) => void
  onDelete: (id: string) => void
  onAbort: (c: Customer) => void
  animateIn: boolean
  isSelected: boolean
  receivedPayments: Record<string, string>
  onEnter: (idx: number) => void
  focusReceived: (idx: number) => void
  registerReceivedInput: (id: string, el: HTMLInputElement | null) => void
  paidTotal: number
}) {
  const c = customer
  const sc = statusColor[c.status] || statusColor.Active
  const outstanding = Math.max(0, (Number(c.totalAmount) || 0) - paidTotal)
  const enteredAmount = rpValue ? Number(rpValue) || 0 : 0
  const paymentMode = useCustomerStore((s) => s.receivedPaymentModes[c.id] || 'Cash')
  const updatePaymentMode = useCustomerStore((s) => s.updateReceivedPaymentMode)
  const setPaymentMode = (mode: 'Cash' | 'PhonePe') => updatePaymentMode(c.id, mode)
  const getDisplayId = useCustomerStore((s) => s.getDisplayId)
  const updateReceivedPayment = useCustomerStore((s) => s.updateReceivedPayment)

  return (
    <motion.tr
      initial={animateIn ? { opacity: 0, y: 8 } : false}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: Math.min(index, 20) * 0.02, ease: [0.16, 1, 0.3, 1] }}
      className="group transition-all duration-200 cursor-pointer"
      onClick={() => onSelect(c)}
      style={{
        height: '52px',
        background: isSelected ? '#FDF3DC' : isAlt ? ROW_ALT : '#FFFFFF',
        boxShadow: isSelected ? 'inset 0 0 0 2px rgba(212,175,55,.55)' : undefined,
      }}
      onMouseEnter={(e) => {
        const tr = e.currentTarget
        tr.style.boxShadow = 'inset 0 0 0 1px rgba(212,175,55,.25), 0 2px 12px rgba(212,175,55,.1)'
        tr.style.transform = 'translateZ(0)'
        tr.style.willChange = 'transform'
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.boxShadow = isSelected ? 'inset 0 0 0 2px rgba(212,175,55,.55)' : 'none'
        e.currentTarget.style.transform = ''
        e.currentTarget.style.willChange = ''
      }}
    >
      {/* Sticky Left: ID */}
      <td
        className="px-3 py-2 text-sm font-semibold whitespace-nowrap z-20 border-r"
        style={{
          position: 'sticky',
          left: 0,
          color: TEXT_DARK,
          background: isAlt ? '#FDF8E0' : STICKY_LEFT_BG,
          minWidth: ID_COL_W,
          width: ID_COL_W,
          borderRightColor: `rgba(212,175,55,.25)`,
        }}
      >
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{ background: `${WINE}10` }}>
            <Users className="w-3 h-3" style={{ color: WINE }} />
          </div>
          {getDisplayId(c)}
        </div>
      </td>

      {/* Sticky Left: Name */}
      <td
        className="px-3 py-2 whitespace-nowrap z-20 border-r"
        style={{
          position: 'sticky',
          left: ID_COL_W,
          background: isAlt ? '#FDF8E0' : STICKY_LEFT_BG,
          minWidth: NAME_COL_W,
          width: NAME_COL_W,
          borderRightColor: `rgba(212,175,55,.25)`,
        }}
      >
        <span
          className="text-sm font-semibold"
          style={{ color: WINE }}
        >
          {c.fullName}
        </span>
      </td>

      {/* Scrollable Columns */}
      <td className="px-3 py-2 text-sm whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.phone }}>{c.mobileNumber}</td>
      <td className="px-3 py-2 text-sm" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.address, width: COL_W.address }}>{c.address || '—'}</td>
      <td className="px-3 py-2 text-sm whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.area }}>{c.area || '—'}</td>
      <td className="px-3 py-2 text-sm whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.city }}>{c.city || '—'}</td>
      <td className="px-3 py-2 text-sm whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', width: COL_W.business, minWidth: COL_W.business }}>
        <span className="block pr-2">{c.occupation || '—'}</span>
      </td>
      <td className="px-3 py-2 text-sm whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.loanDate }}>{c.loanDate ? formatDateDMY(c.loanDate) : '—'}</td>
      <td className="px-3 py-2 text-sm whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.dueDate }}>{c.dueDate ? formatDateDMY(c.dueDate) : '—'}</td>

      {/* Status */}
      <td className="px-3 py-2 text-center whitespace-nowrap" style={{ minWidth: COL_W.status }}>
        <span
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-semibold ${sc.bg} ${sc.text}`}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
          {c.status}
        </span>
      </td>

      <td className="px-3 py-2 text-center text-xs font-semibold text-[var(--primary)]" style={{ minWidth: COL_W.cycle }}>{c.cycleNumber ? `Cycle ${c.cycleNumber}` : '—'}</td>
      <td className="px-3 py-2 text-center text-xs font-semibold text-[var(--primary)]" style={{ minWidth: COL_W.kanaku }} title="Shown loan account; open View for all Kanaku">{c.kanakuNumber ? `Kanaku ${c.kanakuNumber}` : '—'}</td>

      <td className="px-3 py-2 text-sm font-semibold text-right whitespace-nowrap" style={{ color: TEXT_DARK, minWidth: COL_W.installment }}>
        {formatCurrency(c.installmentAmount || 0)}
      </td>
      <td className="px-3 py-2 text-sm font-semibold text-right whitespace-nowrap" style={{ color: TEXT_DARK, minWidth: COL_W.loanAmount }}>
        {formatCurrency(Number(c.loanAmount) || 0)}
      </td>
      <td className="px-3 py-2 text-sm text-right whitespace-nowrap" style={{ color: 'rgba(39,37,59,.7)', minWidth: COL_W.interest }}>{Number(c.interestRate) || 0}%</td>
      <td className="px-3 py-2 text-sm font-semibold text-right whitespace-nowrap" style={{ color: TEXT_DARK, minWidth: COL_W.totalAmount }}>
        {formatCurrency(c.totalAmount || 0)}
      </td>
      <td className="px-3 py-2 text-sm font-semibold text-right whitespace-nowrap" style={{ color: TEXT_DARK, minWidth: COL_W.balance }}>
        {formatCurrency(outstanding)}
      </td>

      {/* Sticky Right: Received Amount */}
      <td
        className="px-3 py-2 z-20 border-l"
        onClick={(e) => e.stopPropagation()}
        style={{
          position: 'sticky',
          right: COL_W.actions + COL_W.paymentMode,
          background: isAlt ? '#FDE0E0' : STICKY_RIGHT_BG,
          borderLeftColor: `rgba(212,175,55,.25)`,
          boxShadow: '-2px 0 6px rgba(127,29,29,.06)',
          minWidth: COL_W.received,
        }}
      >
        <div className="flex justify-end">
          <ReceivedPaymentInput
            value={rpValue}
            onChange={(v) => updateReceivedPayment(c.id, v)}
            onEnter={() => focusReceived(index + 1)}
            onArrow={(dir) => focusReceived(index + dir)}
            registerRef={(el) => registerReceivedInput(c.id, el)}
            error={enteredAmount > outstanding}
            index={index}
          />
        </div>
      </td>

      <td
        className="px-2 py-2 z-20 text-center"
        onClick={(e) => e.stopPropagation()}
        style={{ position: 'sticky', right: COL_W.actions, background: isAlt ? '#FDE0E0' : STICKY_RIGHT_BG, minWidth: COL_W.paymentMode, width: COL_W.paymentMode }}
      >
        <div className="flex items-center justify-center gap-2" role="group" aria-label={`Payment mode for ${c.fullName}`}>
          {(['Cash', 'PhonePe'] as const).map((mode) => (
            <button
              key={mode}
              type="button"
              aria-pressed={paymentMode === mode}
              onClick={() => setPaymentMode(mode)}
              className="h-9 rounded-lg border px-2 text-xs font-semibold whitespace-nowrap"
              style={{ background: paymentMode === mode ? WINE : '#FFFFFF', color: paymentMode === mode ? '#FFFFFF' : WINE, borderColor: WINE }}
            >
              {mode}
            </button>
          ))}
        </div>
      </td>

      {/* Sticky Right: View */}
      <td
        className="px-3 py-2 z-20 text-center"
        onClick={(e) => e.stopPropagation()}
        style={{
          position: 'sticky',
          right: 0,
          background: isAlt ? '#FDE0E0' : STICKY_RIGHT_BG,
          boxShadow: '-2px 0 6px rgba(127,29,29,.06)',
          minWidth: COL_W.actions,
          width: COL_W.actions,
        }}
      >
        <button
          onClick={() => onView(c)}
          title="Payment history"
          className="w-8 h-8 rounded-lg flex items-center justify-center transition-all hover:scale-110"
          style={{ color: WINE, background: `${WINE}10` }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
            <circle cx="12" cy="12" r="3" />
          </svg>
        </button>
      </td>
    </motion.tr>
  )
})

const CustomerRows = memo(function CustomerRows({
  rows,
  containerRef,
  onView,
  onSelect,
  onDelete,
  onAbort,
  onEnter,
  setFocusedIdx,
  selectedId,
  focusReceived,
  registerReceivedInput,
  paidByCustomer,
  offset = 0,
}: {
  rows: Customer[]
  containerRef: React.RefObject<HTMLDivElement | null>
  onView: (c: Customer) => void
  onSelect: (c: Customer) => void
  onDelete: (id: string) => void
  onAbort: (c: Customer) => void
  onEnter: (idx: number) => void
  setFocusedIdx: (idx: number) => void
  selectedId: string | null
  focusReceived: (idx: number) => void
  registerReceivedInput: (id: string, el: HTMLInputElement | null) => void
  paidByCustomer: Map<string, number>
  offset?: number
}) {
  const receivedPayments = useCustomerStore((s) => s.receivedPayments)
  // Text can wrap to any height; render real rows so scrolling never assumes
  // a fixed height and skips or overlaps customers with longer text.
  return (
    <tbody>
      {rows.map((c, realIdx) => {
        return (
          <CustomerRow
            key={c.id}
            customer={c}
            index={realIdx + offset}
            isAlt={realIdx % 2 === 1}
            rpValue={receivedPayments[c.id] ?? ''}
            onView={onView}
            onSelect={onSelect}
            onDelete={onDelete}
            onAbort={onAbort}
            animateIn={realIdx < ROW_ANIM_LIMIT}
            isSelected={selectedId === c.id}
            focusReceived={focusReceived}
            registerReceivedInput={registerReceivedInput}
            paidTotal={paidByCustomer.get(c.id) ?? 0}
            receivedPayments={receivedPayments}
            onEnter={(idx) => setFocusedIdx(idx + 1)}
          />
        )
      })}
    </tbody>
  )
})

function CustomersContent() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const pathname = usePathname()
  const statusFilter = searchParams.get('status')
  const queryClient = useQueryClient()
  const customers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const storeLoading = useCustomerStore((s) => s.loading)
  const getStats = useCustomerStore((s) => s.getStats)
  const todayCollection = useCustomerStore((s) => s.todayCollection)
  const receivedPayments = useCustomerStore((s) => s.receivedPayments)
  const saveAllReceivedPayments = useCustomerStore((s) => s.saveAllReceivedPayments)
  const abortCustomer = useCustomerStore((s) => s.abortCustomer)
  const getDisplayId = useCustomerStore((s) => s.getDisplayId)
  const addToast = useToastStore((s) => s.addToast)
  const { toggleSidebar } = useSidebarStore()
  const [search, setSearch] = useState(() => searchParams.get('q') || '')
  const [customerPage,setCustomerPage]=useState(0)
  const customerPageSize=100
  const [paymentCustomerId, setPaymentCustomerId] = useState<string | null>(null)
  const [automaticToday, setAutomaticToday] = useState(true)
  const [dateRange, setDateRange] = useState<DateRangeValue>(() => {
    const today = getTodayLocalKey()
    return { start: today, end: today }
  })
  useEffect(() => {
    if (!automaticToday) return
    const refreshToday = () => {
      const today = getTodayLocalKey()
      setDateRange(previous => previous.start === today && previous.end === today ? previous : { start: today, end: today })
    }
    refreshToday()
    const timer = window.setInterval(refreshToday, 60000)
    window.addEventListener('focus', refreshToday)
    return () => { window.clearInterval(timer); window.removeEventListener('focus', refreshToday) }
  }, [automaticToday])
  const [view, setView] = useState<ViewMode>('All')
  const [confirmDelete, setConfirmDelete] = useState<Customer | null>(null)
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle')
  const [viewingCustomer, setViewingCustomer] = useState<Customer | null>(null)
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null)
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null)
  const [confirmAbort, setConfirmAbort] = useState<Customer | null>(null)
  const [abortReason, setAbortReason] = useState('')
  const [overpayList, setOverpayList] = useState<{ customer: Customer; balance: number; entered: number }[] | null>(null)
  const [optionsOpen, setOptionsOpen] = useState(false)
  const optionsMenuRef = useRef<HTMLDivElement>(null)
  const [focusedIdx, setFocusedIdx] = useState(-1)

  const stats = getStats()

  const hasActiveFilters = search.trim() !== '' || (dateRange.start !== null && dateRange.end !== null) || view !== 'All'
  const searchIndex=useMemo(()=>customerSearchIndex(customers,c=>[c.id,c.customerCode,c.fullName,c.mobileNumber,c.area,c.city]),[customers])

  const filtered = useMemo(() => {
    const matched=searchIndex(search)
    return customers.filter((c) => {
      const matchesSearch = matched.has(c)
      // Default view shows only open loans — Completed/Aborted customers live
      // in their own sections, so a flip moves the row there automatically.
      // An explicit ?status= param still shows exactly that status.
      const matchesStatus = statusFilter
        ? c.status === statusFilter
        : c.status === 'Active' || c.status === 'Overdue'
      const matchesLoanType = view === 'All' || c.loanType === view
      const matchesDate = !dateRange.start || !dateRange.end || matchesCustomerDateRange(c, dateRange.start, dateRange.end)
      return matchesSearch && matchesStatus && matchesLoanType && matchesDate
    })
  }, [customers, search, statusFilter, view, dateRange, searchIndex])
  useEffect(()=>{setCustomerPage(0)},[search,statusFilter,view,dateRange])
  const visibleCount=Math.min(filtered.length,(customerPage+1)*customerPageSize)

  // Total paid per customer — drives the Balance Amount column so saved
  // payments are deducted (balance = totalAmount - totalPaid).
  const paidByCustomer = useMemo(() => {
    const map = new Map<string, number>(customers.map(c=>[c.id,Number(c.offlinePaidAmount)||0]))
    for (const p of paymentHistory) {
      if (!p.customerId) continue
      map.set(p.customerId, (map.get(p.customerId) ?? 0) + (Number(p.paymentAmount) || 0))
    }
    return map
  }, [paymentHistory, customers])

  const paymentCustomer = filtered.find(customer => customer.id === paymentCustomerId)
  const paymentDetails = paymentCustomer ? [
    ['Loan Date', paymentCustomer.loanDate ? formatDateDMY(paymentCustomer.loanDate) : '—'],
    ['Due Date', paymentCustomer.dueDate ? formatDateDMY(paymentCustomer.dueDate) : '—'],
    ['Status', paymentCustomer.status],
    ['Per Installment', formatCurrency(Number(paymentCustomer.installmentAmount) || 0)],
    ['Loan Amount', formatCurrency(Number(paymentCustomer.loanAmount) || 0)],
    ['Interest Rate', `${Number(paymentCustomer.interestRate) || 0}%`],
    ['Total Amount', formatCurrency(Number(paymentCustomer.totalAmount) || 0)],
    ['Balance Amount', formatCurrency(Math.max(0, (Number(paymentCustomer.totalAmount) || 0) - (paidByCustomer.get(paymentCustomer.id) || 0)))],
  ] : []

  // If the selected customer leaves this list (e.g. flips to Completed and
  // moves to its section, or is hidden by search), drop the selection so the
  // top-right Options menu never acts on an invisible customer.
  useEffect(() => {
    if (selectedCustomer && !filtered.some((c) => c.id === selectedCustomer.id)) {
      setSelectedCustomer(null)
    }
  }, [filtered, selectedCustomer])

  const rangeLabel = useMemo(() => {
    if (dateRange.start === null || dateRange.end === null) return 'All Dates'
    if (dateRange.start === dateRange.end) return `${automaticToday ? 'Today · ' : ''}${formatShortDate(dateRange.start)}`
    return `${formatShortDate(dateRange.start)} - ${formatShortDate(dateRange.end)}`
  }, [dateRange, automaticToday])

  const rangeWeekday = useMemo(() => {
    const d = dateRange.start ? new Date(`${dateRange.start}T00:00:00`) : new Date()
    return isNaN(d.getTime()) ? '' : new Intl.DateTimeFormat('en-IN', { weekday: 'long' }).format(d)
  }, [dateRange])

  const customersOnDate = useMemo(() => {
    return filtered.length
  }, [filtered])

  const yesterdayDate = new Date()
  yesterdayDate.setDate(yesterdayDate.getDate() - 1)
  const yesterdayStr = toISODateStr(yesterdayDate)

  const yesterdayCollection = getCollectionForDate(paymentHistory, filtered, yesterdayStr)

  const collectionBars = useMemo(() => {
    const customerIds = new Set(filtered.map((c) => c.id))
    const days: number[] = []
    for (let i = 4; i >= 0; i--) {
      const d = new Date()
      d.setDate(d.getDate() - i)
      const ds = toISODateStr(d)
      days.push(
        paymentHistory
          .filter((p) => p.customerId && customerIds.has(p.customerId))
          .filter((p) => (p.paymentDate || p.createdAt || '').startsWith(ds))
          .reduce((sum, p) => sum + (Number(p.paymentAmount) || 0), 0)
      )
    }
    return days
  }, [filtered, paymentHistory])

  const filteredTodayCollection = useMemo(() => {
    if (!hasActiveFilters) return todayCollection
    const ids = new Set(filtered.map((c) => c.id))
    // Pending (unsaved) entries only — resets to zero after Save All
    return Object.entries(receivedPayments)
      .filter(([id]) => ids.has(id))
      .reduce((sum, [, v]) => sum + (Number(v) || 0), 0)
  }, [hasActiveFilters, filtered, receivedPayments, todayCollection])

  const handleViewChange = useCallback((v: ViewMode) => {
    setView(v)
  }, [])

  const handleDateRangeApply = useCallback((range: DateRangeValue) => {
    setAutomaticToday(false)
    setDateRange(range)
  }, [])

  const handleDateRangeReset = useCallback(() => {
    setAutomaticToday(false)
    setDateRange({ start: null, end: null })
  }, [])

  const handleSearchChange = useCallback(
    (value: string) => {
      setSearch(value)
      const params = new URLSearchParams(searchParams.toString())
      if (value) params.set('q', value)
      else params.delete('q')
      router.replace(`${pathname}?${params.toString()}`, { scroll: false })
    },
    [searchParams, router, pathname]
  )

  const invalidateAll = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: ['dashboard'] })
    queryClient.invalidateQueries({ queryKey: ['customers'] })
    queryClient.invalidateQueries({ queryKey: ['loans'] })
    queryClient.invalidateQueries({ queryKey: ['payments'] })
  }, [queryClient])

  const executeSaveAll = useCallback(async () => {
    if (saveStatus === 'saving') return
    setSaveStatus('saving')
    try {
      const result = await saveAllReceivedPayments()
      if (result.savedCount > 0) await useCustomerStore.getState().refresh()
      invalidateAll()
      if (result.success) {
        setSaveStatus('saved')
        addToast(result.savedCount > 0 ? `Payments updated successfully. ${result.savedCount} payment${result.savedCount === 1 ? '' : 's'} saved.` : 'No payments to save.', result.savedCount > 0 ? 'success' : 'info')
        setTimeout(() => setSaveStatus('idle'), 2000)
      } else {
        setSaveStatus('idle')
        addToast(result.error || 'Failed to save payments.', 'error')
      }
    } catch (err) {
      setSaveStatus('idle')
      addToast(err instanceof Error ? err.message : 'Failed to save payments.', 'error')
    }
  }, [saveAllReceivedPayments, invalidateAll, saveStatus, addToast])

  // Warn when any entered amount is greater than that customer's balance.
  const handleSaveAll = useCallback(() => {
    if (saveStatus === 'saving') return
    const flags: { customer: Customer; balance: number; entered: number }[] = []
    for (const c of customers) {
      const raw = receivedPayments[c.id]
      const entered = raw ? Number(raw) || 0 : 0
      if (entered <= 0) continue
      const balance = Math.max(0, (Number(c.totalAmount) || 0) - (paidByCustomer.get(c.id) ?? 0))
      if (entered > balance) flags.push({ customer: c, balance, entered })
    }
    if (flags.length > 0) {
      setOverpayList(flags)
    }
    executeSaveAll()
  }, [saveStatus, customers, receivedPayments, paidByCustomer, executeSaveAll])

  const handleDelete = useCallback(async (customer: Customer) => {
    try {
      if (!customer?.loanId) throw new Error('Select the customer row containing the Kanaku to delete.')
      await deleteLoan(customer.loanId)
      await useCustomerStore.getState().refresh()
      invalidateAll()
      setConfirmDelete(null)
      setSelectedCustomer((prev) => (prev && prev.id === customer.id ? null : prev))
      addToast(`Kanaku ${customer.kanakuNumber || ''} moved to Recently Deleted for 30 days. Other Kanaku are unchanged.`)
    } catch (error) {
      addToast(error instanceof Error ? error.message : 'Customer could not be deleted.', 'error')
    }
  }, [invalidateAll, addToast])

  const handleView = useCallback((c: Customer) => setViewingCustomer(c), [])
  const handleSelectCustomer = useCallback((c: Customer) => {
    setSelectedCustomer((prev) => (prev && prev.id === c.id ? null : c))
  }, [])
  const handleAbort = useCallback((c: Customer) => setConfirmAbort(c), [])

  const tableContainerRef = useRef<HTMLDivElement>(null)

  const revealPaymentDetails = useCallback((target: HTMLElement) => {
    const cell = target.closest('td')
    const input = cell?.querySelector<HTMLInputElement>('input[data-payment-row-index]')
    if (!input) return
    const index = Number(input.dataset.paymentRowIndex)
    const customer = filtered[index]
    if (!customer) return
    setPaymentCustomerId(customer.id)
    const container = tableContainerRef.current
    if (container) {
      // Loan fields are the final scrollable columns; the payment inputs stay
      // pinned on the right. Reveal these fields whenever payment entry starts.
      container.scrollTo({ left: container.scrollWidth - container.clientWidth, behavior: 'smooth' })
    }
  }, [filtered])

  // Registry of mounted Received Amount inputs (keyed by customer id) so
  // Enter / ArrowUp / ArrowDown can jump between variable-height customer rows.
  const receivedInputRefs = useRef(new Map<string, HTMLInputElement>())
  const registerReceivedInput = useCallback((id: string, el: HTMLInputElement | null) => {
    if (el) receivedInputRefs.current.set(id, el)
    else receivedInputRefs.current.delete(id)
  }, [])
  const focusReceived = useCallback((idx: number) => {
    if (idx < 0 || idx >= filtered.length) return
    setFocusedIdx(idx)
    setCustomerPage(page=>Math.max(page,Math.floor(idx/customerPageSize)))
    const id = filtered[idx].id
    const attempt = (tries: number) => {
      const el = receivedInputRefs.current.get(id)
      if (el) {
        el.scrollIntoView({ block: 'nearest', inline: 'nearest' })
        el.focus()
        el.select()
        return
      }
      if (tries <= 0) return
      setTimeout(() => attempt(tries - 1), 60)
    }
    attempt(6)
  }, [filtered])

  return (
    <div className="h-full min-h-0 flex flex-col" style={{ background: BG_LIGHT }}>
      {/* ===== TOP ACTION HEADER ===== */}
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="flex-shrink-0 relative overflow-hidden"
        style={{
          background: BG_LIGHT,
          borderBottom: `1px solid ${BORDER_WINE}`,
        }}
      >
        {/* Gold glow accent */}
        <div className="absolute top-0 left-1/4 w-1/2 h-[1px]" style={{ background: 'linear-gradient(90deg, transparent, rgba(212,175,55,.4), transparent)' }} />
        <div className="absolute -top-8 right-[20%] w-40 h-40 bg-[rgba(212,175,55,.05)] rounded-full blur-3xl pointer-events-none" />

        <div className="relative px-6 py-3">
          {/* SINGLE ROW: Left (Menu+Back+Search+Week+Date) | Center (KPI) | Right (Save All+Today's Collection+Options) */}
          <div className="flex flex-wrap items-center gap-3 xl:gap-4">
            {/* LEFT SECTION */}
            <div className="order-1 flex flex-wrap items-center gap-3 flex-1 min-w-0">
              {/* Menu + Back */}
              <div className="flex items-center gap-2.5 flex-shrink-0">
                <button
                  onClick={toggleSidebar}
                  className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-all active:scale-95"
                  style={{ background: '#FFFFFF', border: `1px solid ${BORDER_WINE}`, color: TEXT_DARK }}
                >
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                    <path d="M3 5h12" /><path d="M3 9h12" /><path d="M3 13h12" />
                  </svg>
                </button>
              </div>

              {/* Search Customer — consumes most left width */}
              <div className="flex items-center gap-2 flex-1 min-w-[200px] max-w-[500px]" style={{ flexGrow: 2 }}>
                <div className="relative min-w-0 flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-[18px] h-[18px] pointer-events-none" style={{ color: 'rgba(39,37,59,.35)' }} />
                <input
                  type="text"
                  placeholder="Search Customer..."
                  aria-label="Search customers"
                  value={search}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  className="w-full h-[46px] pl-12 pr-4 rounded-[16px] text-sm outline-none transition-all duration-200 placeholder:text-slate-400 focus:ring-2 focus:ring-[rgba(212,175,55,.2)]"
                  style={{
                    background: 'rgba(255,255,255,.95)',
                    border: `1px solid rgba(212,175,55,.35)`,
                    color: TEXT_DARK,
                    boxShadow: '0 4px 18px rgba(127,29,29,.05)',
                  }}
                />
                </div>
                <VoiceMicButton
                  inputType="search"
                  value={search}
                  onPreview={handleSearchChange}
                  className="shrink-0"
                  onResult={(text) => {
                    const query = text.replace(/\./g, '').trim()
                    if (query) handleSearchChange(query)
                  }}
                />
              </div>

              {/* Week/View Dropdown */}
              <ViewDropdown value={view} onChange={handleViewChange} />

              {/* Date Range Picker */}
              <CustomerDateRangePicker value={dateRange} onApply={handleDateRangeApply} onReset={handleDateRangeReset} automaticToday={automaticToday} onToday={() => { const today = getTodayLocalKey(); setDateRange({ start: today, end: today }); setAutomaticToday(true) }} />
              <p className="text-xs text-slate-500">{automaticToday ? 'Showing customers added today, loans dated today, and collections due today' : dateRange.start ? 'Showing customers added, loans dated, or collections due in the selected period' : 'Showing customers across all dates'}. Choose All Dates to search everyone.</p>
            </div>

            {/* CENTER SECTION: KPI */}
            <div className="order-2 w-full xl:flex-1 xl:min-w-0 xl:w-auto 2xl:px-2">
              <KpiSection
                totalCustomers={filtered.length}
                rangeLabel={rangeLabel}
                rangeWeekday={rangeWeekday}
                customersOnDate={customersOnDate}
              />
            </div>

            {/* RIGHT SECTION: Save All + Today's Collection + Options */}
            <div className="order-3 flex flex-col sm:flex-row items-end sm:items-center sm:justify-end gap-3 flex-shrink-0">
              {/* Save All Button */}
              <SaveAllButton status={saveStatus} onSave={handleSaveAll} />

              {/* Today's Collection Card */}
              <TodayCollectionCardLive
                today={filteredTodayCollection}
                yesterday={yesterdayCollection}
                bars={collectionBars}
              />

              {/* Options Menu */}
              <div className="relative" ref={optionsMenuRef}>
                <button
                  onClick={() => setOptionsOpen(!optionsOpen)}
                  title={selectedCustomer ? `Options for ${selectedCustomer.fullName}` : 'Select a customer first'}
                  className="h-10 px-4 rounded-xl text-sm font-semibold transition-all duration-200 flex items-center gap-2"
                  style={{
                    background: '#FFFFFF',
                    border: `1px solid ${selectedCustomer ? GOLD : BORDER_WINE}`,
                    color: TEXT_DARK,
                    boxShadow: selectedCustomer ? '0 4px 18px rgba(212,175,55,.25)' : undefined,
                  }}
                >
                  Options
                  <MoreHorizontal className="w-4 h-4" />
                </button>
                
                <Popup
                  open={optionsOpen}
                  onClose={() => setOptionsOpen(false)}
                  anchorRef={optionsMenuRef}
                  placement="bottom-end"
                  minWidth={224}
                  zIndex={Z_INDEX.dropdown}
                >
                  <motion.div
                    initial={{ opacity: 0, y: 6, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
                    className="w-56 bg-white/95 backdrop-blur-xl rounded-[14px] border border-[rgba(127,29,29,.1)] shadow-[0_12px_40px_rgba(127,29,29,.15),0_4px_12px_rgba(0,0,0,.04)] overflow-hidden"
                  >
                      <div className="p-2 space-y-1">
                        {selectedCustomer && (
                          <p className="px-3 pt-1.5 pb-1 text-[11px] font-bold uppercase tracking-wider truncate" style={{ color: 'rgba(39,37,59,.45)' }}>
                            {selectedCustomer.fullName}
                          </p>
                        )}
                        {!selectedCustomer && (
                          <p className="px-3 py-2 text-xs font-medium" style={{ color: 'rgba(39,37,59,.5)' }}>
                            Click a customer row to select it first.
                          </p>
                        )}
                        <Link
                          href="/dashboard/customer-entries"
                          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 hover:bg-[rgba(127,29,29,.06)]"
                          style={{ color: TEXT_DARK }}
                          onClick={() => setOptionsOpen(false)}
                        >
                          <HandCoins className="w-4 h-4" />
                          Entries Customer
                        </Link>
                        <button
                          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 hover:bg-[rgba(127,29,29,.06)] disabled:opacity-40 disabled:cursor-not-allowed"
                          style={{ color: TEXT_DARK }}
                          disabled={!selectedCustomer}
                          onClick={() => {
                            setOptionsOpen(false)
                            if (selectedCustomer) {
                              setEditingCustomer(selectedCustomer)
                            }
                          }}
                        >
                          <PencilLine className="w-4 h-4" />
                          Edit Customer
                        </button>
                        <button
                          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 hover:bg-red-50 disabled:opacity-40 disabled:cursor-not-allowed"
                          style={{ color: '#DC2626' }}
                          disabled={!selectedCustomer?.loanId}
                          onClick={() => {
                            setOptionsOpen(false)
                            if (selectedCustomer?.loanId) setConfirmDelete(selectedCustomer)
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                          Delete Customer
                        </button>
                        <button
                          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 hover:bg-red-50 disabled:opacity-40 disabled:cursor-not-allowed"
                          style={{ color: '#DC2626' }}
                          disabled={!selectedCustomer}
                          onClick={() => {
                            setOptionsOpen(false)
                            if (selectedCustomer) {
                              setConfirmAbort(selectedCustomer)
                            }
                          }}
                        >
                          <OctagonX className="w-4 h-4" />
                          Abort Customer
                        </button>
                    </div>
                  </motion.div>
                </Popup>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ===== TABLE SECTION ===== */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        className="flex-1 px-6 pb-0 min-h-0 pt-4 flex flex-col"
      >
        {/* ===== CUSTOMER TABLE ===== */}
        <div
          className="rounded-[18px] overflow-hidden flex flex-col flex-1 min-h-0 mt-4"
          style={{
            border: `1px solid ${BORDER_WINE}`,
            boxShadow: '0 18px 45px rgba(127,29,29,.08), 0 4px 12px rgba(0,0,0,.02)',
          }}
        >
          {storeLoading && customers.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center gap-3 px-6 py-16" style={{ background: '#FFFFFF' }}>
              <svg className="animate-spin w-9 h-9" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" stroke="rgba(212,175,55,.25)" strokeWidth="3" />
                <path d="M22 12a10 10 0 0 0-10-10" stroke={GOLD} strokeWidth="3" strokeLinecap="round" />
              </svg>
              <p className="text-sm font-medium" style={{ color: 'rgba(39,37,59,.55)' }}>
                Loading customers…
              </p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center px-6 py-16" style={{ background: '#FFFFFF' }}>
              <motion.div
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                className="relative w-24 h-24 flex items-center justify-center mb-5"
              >
                <div
                  className="absolute inset-0 rounded-full"
                  style={{ background: 'radial-gradient(circle, rgba(212,175,55,.2), transparent 70%)' }}
                />
                <div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center"
                  style={{ background: `${WINE}08`, border: `1px dashed rgba(212,175,55,.45)` }}
                >
                  <CalendarDays className="w-8 h-8" style={{ color: 'rgba(127,29,29,.35)' }} />
                </div>
                <span
                  className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center"
                  style={{ background: GOLD, boxShadow: '0 4px 12px rgba(212,175,55,.4)' }}
                >
                  <Users className="w-3.5 h-3.5 text-white" />
                </span>
              </motion.div>
              <h3 className="text-lg font-bold mb-1 text-center" style={{ color: TEXT_DARK }}>
                {customers.length === 0
                  ? 'No customers yet'
                  : !hasActiveFilters && search.trim() === '' && !statusFilter
                    ? 'All caught up!'
                    : dateRange.start !== null
                      ? 'No customers found for the selected date range.'
                      : 'No matching customers'}
              </h3>
              <p className="text-sm text-center" style={{ color: 'rgba(39,37,59,.5)' }}>
                {customers.length === 0
                  ? 'Add your first customer to get started.'
                  : !hasActiveFilters && search.trim() === '' && !statusFilter
                    ? 'Every customer is completed or aborted. Check those sections.'
                    : dateRange.start !== null
                      ? 'Try selecting a different range or resetting the date filter.'
                      : 'Try adjusting your search criteria.'}
              </p>
              {customers.length === 0 && (
                <Link
                  href="/dashboard/add-customer"
                  className="inline-flex items-center gap-2 mt-4 px-5 py-2.5 rounded-full text-sm font-semibold transition-all"
                  style={{
                    background: 'linear-gradient(135deg, var(--primary), #912222)',
                    border: `1px solid ${GOLD}`,
                    color: GOLD,
                    boxShadow: '0 4px 20px rgba(212,175,55,.2)',
                  }}
                >
                  Add Customer
                </Link>
              )}
            </div>
          ) : (
            <>
              {paymentCustomer && (
                <section aria-label="Current customer payment details" className="shrink-0 border-b border-[var(--primary)]/20 bg-[#FFF8E5] px-4 py-3">
                  <div className="mb-2 flex items-center justify-between gap-3">
                    <p className="text-sm font-semibold text-[var(--primary)] break-words">Receiving payment · {paymentCustomer.fullName} · {paymentCustomer.customerCode || paymentCustomer.id}</p>
                    <button type="button" onClick={() => setPaymentCustomerId(null)} className="shrink-0 rounded px-2 py-1 text-xs text-[var(--primary)] hover:bg-white">Hide details</button>
                  </div>
                  <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4 xl:grid-cols-8">
                    {paymentDetails.map(([label, value]) => (
                      <div key={label} className="min-w-0 border-l border-[var(--primary)]/15 pl-3">
                        <dt className="text-xs font-medium text-slate-600">{label}</dt>
                        <dd className="mt-1 text-sm font-semibold text-[var(--text-primary)] [overflow-wrap:anywhere]">{value}</dd>
                      </div>
                    ))}
                  </dl>
                </section>
              )}
              {/* Vertical scroll container — sticky header lives here */}
              <div
                ref={tableContainerRef}
                onBlurCapture={(event) => {
                  const index = (event.target as HTMLElement).getAttribute('data-payment-row-index')
                  if (index === null) return
                  const customer = filtered[Number(index)]
                  if (!customer) return
                  const entered = Number(useCustomerStore.getState().receivedPayments[customer.id]) || 0
                  const balance = Math.max(0, (Number(customer.totalAmount) || 0) - (paidByCustomer.get(customer.id) || 0))
                  if (Math.round(entered * 100) > Math.round(balance * 100)) setOverpayList([{ customer, balance, entered }])
                }}
                onClickCapture={(event) => {
                  const target = event.target as HTMLElement
                  revealPaymentDetails(target)
                  const input = target.closest('td')?.querySelector<HTMLInputElement>('input[data-payment-row-index]')
                  if (input && target !== input) input.focus({ preventScroll: true })
                }}
                onFocusCapture={(event) => {
                  revealPaymentDetails(event.target as HTMLElement)
                }}
                onScroll={(event) => {
                  const box=event.currentTarget
                  if(box.scrollHeight-box.scrollTop-box.clientHeight<250&&visibleCount<filtered.length)setCustomerPage(page=>page+1)
                }}
                className="flex-1 min-h-0 overflow-auto"
                style={{ overscrollBehavior: 'auto' }}
              >
                {/* Horizontal scroll container — only center columns scroll */}
                <div>
                  <table className="w-full table-fixed [&_th]:border-r [&_th]:border-white/20 [&_td:not([colspan])]:border-r [&_td:not([colspan])]:border-b [&_td:not([colspan])]:border-[var(--primary)]/15 [&_td]:whitespace-normal [&_td]:[overflow-wrap:anywhere] [&_td]:leading-5 [&_td]:py-3 [&_th]:whitespace-normal [&_th]:py-3 [&_th]:leading-4 [&_td:nth-child(n+8):nth-child(-n+17)]:px-1.5 [&_th:nth-child(n+8):nth-child(-n+17)]:px-1.5" style={{ minWidth: TABLE_MIN_W }}>
                    {/* ===== TABLE HEADER (Wine Gradient) ===== */}
                    <thead className="sticky top-0 z-50 [&_th]:text-center [&_th]:align-middle">
                      <tr
                        className="h-[48px]"
                        style={{ background: 'linear-gradient(135deg, var(--primary), #912222)' }}
                      >
                        <th
                          className="text-left text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap z-40"
                          style={{
                            position: 'sticky',
                            left: 0,
                            color: GOLD,
                            background: 'linear-gradient(135deg, var(--primary), #912222)',
                            boxShadow: '2px 0 8px rgba(127,29,29,.2)',
                            width: ID_COL_W,
                            minWidth: ID_COL_W,
                          }}
                        >
                          ID
                        </th>
                        <th
                          className="text-left text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap z-40"
                          style={{
                            position: 'sticky',
                            left: ID_COL_W,
                            color: GOLD,
                            background: 'linear-gradient(135deg, var(--primary), #912222)',
                            boxShadow: '2px 0 8px rgba(127,29,29,.2)',
                            width: NAME_COL_W,
                            minWidth: NAME_COL_W,
                          }}
                        >
                          Name
                        </th>
                        <th className="text-left text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.phone, minWidth: COL_W.phone }}>Phone Number</th>
                        <th className="text-left text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.address, minWidth: COL_W.address }}>Address</th>
                        <th className="text-left text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.area, minWidth: COL_W.area }}>Area</th>
                        <th className="text-left text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.city, minWidth: COL_W.city }}>City</th>
                        <th className="text-left text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.business, minWidth: COL_W.business }}>Business</th>
                        <th className="text-left text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.loanDate, minWidth: COL_W.loanDate }}>Loan Date</th>
                        <th className="text-left text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.dueDate, minWidth: COL_W.dueDate }}>Due Date</th>
                        <th className="text-center text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.status, minWidth: COL_W.status }}>Status</th>
                        <th className="text-center text-[10px] font-bold uppercase tracking-wider px-3" style={{ color: GOLD, width: COL_W.cycle, minWidth: COL_W.cycle }}>Cycle</th>
                        <th className="text-center text-[10px] font-bold uppercase tracking-wider px-3" style={{ color: GOLD, width: COL_W.kanaku, minWidth: COL_W.kanaku }}>Kanaku</th>
                        <th className="text-right text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.installment, minWidth: COL_W.installment }}>Per Installment</th>
                        <th className="text-right text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.loanAmount, minWidth: COL_W.loanAmount }}>Loan Amount</th>
                        <th className="text-right text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.interest, minWidth: COL_W.interest }}>Interest Rate</th>
                        <th className="text-right text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.totalAmount, minWidth: COL_W.totalAmount }}>Total Amount</th>
                        <th className="text-right text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap" style={{ color: GOLD, width: COL_W.balance, minWidth: COL_W.balance }}>Balance Amount</th>
                        <th
                          className="text-center text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap z-40"
                          style={{
                            position: 'sticky',
                            right: COL_W.actions + COL_W.paymentMode,
                            color: GOLD,
                            background: 'linear-gradient(135deg, var(--primary), #912222)',
                            boxShadow: '-2px 0 8px rgba(127,29,29,.2)',
                            width: COL_W.received,
                            minWidth: COL_W.received,
                          }}
                        >
                          Received Amount
                        </th>
                        <th
                          className="text-center text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap z-40"
                          style={{
                            position: 'sticky',
                            right: COL_W.actions,
                            color: GOLD,
                            background: 'linear-gradient(135deg, var(--primary), #912222)',
                            boxShadow: '-2px 0 8px rgba(127,29,29,.2)',
                            width: COL_W.paymentMode,
                            minWidth: COL_W.paymentMode,
                          }}
                        >
                          Payment Mode
                        </th>
                        <th
                          className="text-center text-[10px] font-bold uppercase tracking-wider px-3 whitespace-nowrap z-40"
                          style={{ position: 'sticky', right: 0, color: GOLD, background: 'linear-gradient(135deg, var(--primary), #912222)', boxShadow: '-2px 0 8px rgba(127,29,29,.2)', width: COL_W.actions, minWidth: COL_W.actions }}
                        >
                          View
                        </th>
                      </tr>
                    </thead>

                    {/* ===== TABLE BODY ===== */}
<CustomerRows
                      rows={filtered.slice(0,visibleCount)}
                      containerRef={tableContainerRef}
                      onView={handleView}
                      onSelect={handleSelectCustomer}
                      onDelete={(id) => setConfirmDelete(customers.find(c => c.id === id) || null)}
                      onAbort={handleAbort}
                      onEnter={(idx) => setFocusedIdx(idx)}
                      setFocusedIdx={setFocusedIdx}
                      selectedId={selectedCustomer?.id ?? null}
                      focusReceived={focusReceived}
                      registerReceivedInput={registerReceivedInput}
                      paidByCustomer={paidByCustomer}
/>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      </motion.div>

      {/* ===== DELETE CONFIRMATION MODAL ===== */}
      <AnimatePresence>
        {confirmDelete && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[var(--z-modal)] flex items-center justify-center p-4"
            onClick={() => setConfirmDelete(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 16 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
              className="bg-white rounded-[16px] shadow-2xl w-full max-w-sm p-6"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-12 h-12 rounded-xl bg-red-50 flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-6 h-6 text-red-500" />
              </div>
              <h3 className="text-lg font-bold text-center mb-1" style={{ color: TEXT_DARK }}>Delete Selected Kanaku</h3>
              <p className="text-sm text-center mb-6" style={{ color: 'rgba(39,37,59,.5)' }}>
                {confirmDelete.customerCode} · {confirmDelete.fullName} — Cycle {confirmDelete.cycleNumber}, Kanaku {confirmDelete.kanakuNumber} only.
                Its payments will be kept in Recently Deleted for 30 days, then permanently removed. Other Kanaku and the customer profile stay unchanged.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setConfirmDelete(null)}
                  className="flex-1 h-10 rounded-xl border text-sm font-medium transition-colors"
                  style={{ borderColor: BORDER_WINE, color: TEXT_DARK, background: '#FFFFFF' }}
                >
                  Cancel
                </button>
                <button
                  onClick={() => confirmDelete && handleDelete(confirmDelete)}
                  className="flex-1 h-10 rounded-xl text-white text-sm font-medium transition-colors"
                  style={{ background: 'linear-gradient(135deg, #DC2626, #B91C1C)' }}
                >
                  Delete
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== ABORT CONFIRMATION MODAL ===== */}
      <AnimatePresence>
        {confirmAbort && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[var(--z-modal)] flex items-center justify-center p-4"
            onClick={() => { setConfirmAbort(null); setAbortReason('') }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 16 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
              className="bg-white rounded-[16px] shadow-2xl w-full max-w-md p-6"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-12 h-12 rounded-xl bg-red-50 flex items-center justify-center mx-auto mb-4">
                <OctagonX className="w-6 h-6 text-red-500" />
              </div>
              <h3 className="text-lg font-bold text-center mb-1" style={{ color: TEXT_DARK }}>Abort Customer</h3>
              <p className="text-sm text-center mb-4" style={{ color: 'rgba(39,37,59,.5)' }}>
                This will mark <span className="font-semibold" style={{ color: TEXT_DARK }}>{confirmAbort?.fullName}</span> as aborted.
                All payment history will be preserved.
              </p>
              <div className="mb-4">
                <label className="block text-sm font-medium mb-1.5" style={{ color: TEXT_DARK }}>Abort Reason (optional)</label>
                <textarea
                  value={abortReason}
                  onChange={(e) => setAbortReason(e.target.value)}
                  placeholder="Enter reason for aborting this loan..."
                  rows={3}
                  className="w-full px-3.5 py-2.5 rounded-xl border text-sm outline-none transition-all resize-none"
                  style={{ borderColor: BORDER_WINE, color: TEXT_DARK, background: '#FFFFFF' }}
                />
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => { setConfirmAbort(null); setAbortReason('') }}
                  className="flex-1 h-10 rounded-xl border text-sm font-medium transition-colors"
                  style={{ borderColor: BORDER_WINE, color: TEXT_DARK, background: '#FFFFFF' }}
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (confirmAbort) {
                      abortCustomer(confirmAbort.id, abortReason || undefined)
                      invalidateAll()
                      setConfirmAbort(null)
                      setAbortReason('')
                    }
                  }}
                  className="flex-1 h-10 rounded-xl text-white text-sm font-medium transition-colors"
                  style={{ background: 'linear-gradient(135deg, var(--primary), #912222)' }}
                >
                  Abort Customer
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== OVERPAYMENT WARNING MODAL ===== */}
      <AnimatePresence>
        {overpayList && overpayList.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[var(--z-modal)] flex items-center justify-center p-4"
            onClick={() => setOverpayList(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 16 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
              className="bg-white rounded-[16px] shadow-2xl w-full max-w-md p-6"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6 text-amber-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
                  <path d="M12 9v4" />
                  <path d="M12 17h.01" />
                </svg>
              </div>
              <h3 className="text-lg font-bold text-center mb-1" style={{ color: TEXT_DARK }}>Amount Exceeds Balance</h3>
              <p className="text-sm text-center mb-4" style={{ color: 'rgba(39,37,59,.5)' }}>
                These amounts exceed the remaining balance and will not be saved. Other valid payments can still be saved. Correct these entries and click Save All again.
              </p>
              <div className="mb-5 space-y-2 max-h-[240px] overflow-y-auto">
                {overpayList.map(({ customer, balance, entered }) => (
                  <div
                    key={customer.id}
                    className="rounded-xl border border-amber-200 bg-amber-50/60 px-4 py-3"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-bold truncate" style={{ color: TEXT_DARK }}>{customer.fullName}</p>
                      <p className="text-xs font-semibold text-slate-500 flex-shrink-0">{getDisplayId(customer)}</p>
                    </div>
                    <div className="flex items-center justify-between gap-2 mt-1.5 text-sm">
                      <span style={{ color: 'rgba(39,37,59,.6)' }}>
                        Balance: <span className="font-bold" style={{ color: TEXT_DARK }}>{formatCurrency(balance)}</span>
                      </span>
                      <span style={{ color: 'rgba(39,37,59,.6)' }}>
                        Received: <span className="font-bold text-red-600">{formatCurrency(entered)}</span>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setOverpayList(null)}
                  className="flex-1 h-10 rounded-xl border text-sm font-medium transition-colors"
                  style={{ borderColor: BORDER_WINE, color: TEXT_DARK, background: '#FFFFFF' }}
                >
                  Go Back
                </button>
                <button
                  onClick={() => {
                    setOverpayList(null)
                    executeSaveAll()
                  }}
                  className="flex-1 h-10 rounded-xl text-white text-sm font-medium transition-colors"
                  style={{ background: 'linear-gradient(135deg, var(--primary), #912222)' }}
                >
                  Save Valid Payments Only
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== PAYMENT HISTORY DRAWER ===== */}
      <PaymentHistoryDrawer
        customer={viewingCustomer}
        isOpen={!!viewingCustomer}
        onClose={() => setViewingCustomer(null)}
      />

      {/* ===== CUSTOMER DETAIL DRAWER (view + edit) ===== */}
      <CustomerDetailDrawer
        customer={editingCustomer}
        isOpen={!!editingCustomer}
        onClose={() => setEditingCustomer(null)}
        onSaved={invalidateAll}
        initialMode="edit"
      />
    </div>
  )
}

export default function CustomersPage() {
  return (
    <Suspense fallback={null}>
      <CustomersContent />
    </Suspense>
  )
}
