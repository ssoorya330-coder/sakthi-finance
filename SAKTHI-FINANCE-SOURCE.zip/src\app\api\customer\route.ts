import { NextRequest, NextResponse } from 'next/server'
import { dbQuery, dbTransaction } from '@/server/database'
import { normalizePhone } from '@/lib/phone'
import { requireAuthWithPermission } from '@/lib/api-utils'
import {
  actorFromAuthUser,
  requestMeta,
  recordAuditEvent,
  CUSTOMER_LABELS,
  LOAN_LABELS,
} from '@/server/audit'
import {
  DISBURSAL_MODES,
  checkDisbursalCompliance,
  getCashThreshold,
  recordCashFlagEvent,
} from '@/server/cash-compliance'

async function resolveLookupId(table: string, name: string | null | undefined): Promise<number | null> {
  if (!name || !name.trim()) return null
  const trimmed = name.trim()
  const existing = await dbQuery(`SELECT id FROM ${table} WHERE name = $1`, [trimmed])
  if (existing.rows.length > 0) return existing.rows[0].id
  const inserted = await dbQuery(`INSERT INTO ${table} (name) VALUES ($1) ON CONFLICT (name) DO UPDATE SET name = EXCLUDED.name RETURNING id`, [trimmed])
  return inserted.rows[0].id
}

async function generateNextCode(userId: string): Promise<string> {
  // Per-account sequence: only the caller's own rows determine the next ID,
  // so every account starts at 001 independently. Uniqueness within the
  // account is enforced by UNIQUE(user_id, customer_code); concurrent
  // requests that collide retry via the MAX_RETRIES loop below.
  const maxResult = await dbQuery(
    `SELECT customer_code FROM customers WHERE user_id = $1 AND customer_code ~ '^[0-9]+$' ORDER BY (customer_code::int) DESC LIMIT 1`,
    [userId]
  )
  const maxCode = maxResult.rows[0]?.customer_code
  const nextNum = maxCode ? parseInt(maxCode, 10) + 1 : 1
  return String(nextNum).padStart(3, '0')
}

export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('customers:create');
  if (auth.error) return auth.error;
  const { user } = auth;

  const MAX_RETRIES = 5
  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    try {
      const userId = user.userId
      const body = await request.json()
      const {
        full_name, phone_number, alternate_phone, address,
        area, city, business, income, status,
        loan_date, due_date, loan_amount, interest_rate, interest_amount,
        total_amount, installment_amount, remaining_days, duration,
        loan_type, notes, abort_reason, disbursal_mode,
      } = body

      if (!full_name) {
        return NextResponse.json({ error: 'Full name is required' }, { status: 400 })
      }
      const disbursalMode = disbursal_mode === undefined || disbursal_mode === null || disbursal_mode === ''
        ? 'Cash'
        : String(disbursal_mode)
      if (!(DISBURSAL_MODES as readonly string[]).includes(disbursalMode)) {
        return NextResponse.json({ error: 'Disbursal mode must be Cash or Bank.' }, { status: 400 })
      }

      // Server-authoritative per-account ID: never trust a customer_code sent
      // by the frontend — the next code always comes from the caller's own rows.
      const code = await generateNextCode(userId)

      // Resolve lookup IDs
      const [areaId, cityId, businessId] = await Promise.all([
        resolveLookupId('ref_area', area),
        resolveLookupId('ref_city', city),
        resolveLookupId('ref_business', business),
      ])

      // Insert customer + loan + audit events in ONE transaction: a customer
      // must never exist without its creation audit events (and vice versa).
      const meta = requestMeta(request)
      const actor = actorFromAuthUser(user)
      const threshold = await getCashThreshold()
      const disbursalCheck = checkDisbursalCompliance(
        { disbursal_mode: disbursalMode, loan_amount: loan_amount || 0 },
        threshold
      )
      const { customer, loan } = await dbTransaction(async (tx) => {
        // Canonical lookup number, computed at write time (primary, else
        // alternate) so mobile matching never depends on a later backfill.
        const canonicalPhone =
          normalizePhone(phone_number) || normalizePhone(alternate_phone) || null
        const custResult = await tx.query(
          `INSERT INTO customers (customer_code, full_name, phone_number, alternate_phone, address,
            area_id, city_id, business_id, income, status, user_id, phone_normalized)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
          [
            code, full_name,
            phone_number || null, alternate_phone || null, address || null,
            areaId, cityId, businessId,
            income || 0, status || 'Active', userId,
            canonicalPhone,
          ]
        )
        const cust = custResult.rows[0]

        const loanResult = await tx.query(
          `INSERT INTO loans (customer_id, loan_date, due_date, loan_amount, interest_rate,
            interest_amount, total_amount, installment_amount, remaining_days, duration,
            loan_type, notes, abort_reason, status, user_id, disbursal_mode, is_flagged, flag_reason)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18) RETURNING *`,
          [
            cust.id,
            loan_date || null, due_date || null,
            loan_amount || 0, interest_rate || 0,
            interest_amount || 0, total_amount || 0,
            installment_amount || 0, remaining_days || 0,
            duration || 0, loan_type || 'Daily',
            notes || null, abort_reason || null,
            status || 'Active', userId,
            disbursalMode, disbursalCheck.flagged, disbursalCheck.reason,
          ]
        )
        const ln = loanResult.rows[0]

        const custAfter = {
          full_name, customer_code: code,
          phone_number: phone_number || null, address: address || null,
          area: area || null, city: city || null, business: business || null,
          income: income || 0, status: status || 'Active',
        }
        await recordAuditEvent(tx, {
          action: 'CUSTOMER_CREATED',
          entityType: 'customer',
          entityId: cust.id,
          customerId: cust.id,
          actor,
          ipAddress: meta.ip,
          clientInfo: meta.client,
          result: 'SUCCESS',
          changes: Object.entries(custAfter)
            .filter(([, v]) => v !== null)
            .map(([field, v]) => ({ field, label: CUSTOMER_LABELS[field] || field, before: null, after: v })),
          after: custAfter,
        })
        const loanAfter = {
          loan_amount: loan_amount || 0, interest_rate: interest_rate || 0,
          interest_amount: interest_amount || 0, total_amount: total_amount || 0,
          duration: duration || 0, loan_type: loan_type || 'Daily',
          loan_date: loan_date || null, status: status || 'Active',
          disbursal_mode: disbursalMode,
        }
        await recordAuditEvent(tx, {
          action: 'LOAN_CREATED',
          entityType: 'loan',
          entityId: ln.loan_id,
          customerId: cust.id,
          loanId: ln.loan_id,
          actor,
          ipAddress: meta.ip,
          clientInfo: meta.client,
          result: 'SUCCESS',
          changes: Object.entries(loanAfter)
            .filter(([, v]) => v !== null)
            .map(([field, v]) => ({ field, label: LOAN_LABELS[field] || field, before: null, after: v })),
          after: loanAfter,
        })
        if (disbursalCheck.flagged) {
          await recordCashFlagEvent(tx, {
            action: 'CASH_DISBURSAL_FLAGGED',
            entityType: 'loan',
            entityId: ln.loan_id,
            customerId: cust.id,
            loanId: ln.loan_id,
            paymentId: null,
            actor,
            ip: meta.ip,
            client: meta.client,
            threshold,
            amount: Number(loan_amount) || 0,
            reason: disbursalCheck.reason as string,
            after: { ...loanAfter, is_flagged: true },
          })
        }
        return { customer: cust, loan: ln }
      })

      await dbQuery(
        `INSERT INTO audit_logs (action, entity_type, entity_id, details, user_id) VALUES ($1,$2,$3,$4,$5)`,
        ['create', 'customer', customer.id, JSON.stringify({ full_name, customer_code: code }), userId]
      ).catch(() => {})

      // Return customer with loan data and lookup names
      const [areaName, cityName, businessName] = await Promise.all([
        areaId ? dbQuery('SELECT name FROM ref_area WHERE id = $1', [areaId]).then(r => r.rows[0]?.name || '') : Promise.resolve(''),
        cityId ? dbQuery('SELECT name FROM ref_city WHERE id = $1', [cityId]).then(r => r.rows[0]?.name || '') : Promise.resolve(''),
        businessId ? dbQuery('SELECT name FROM ref_business WHERE id = $1', [businessId]).then(r => r.rows[0]?.name || '') : Promise.resolve(''),
      ])

      return NextResponse.json({
        ...customer,
        area_name: areaName,
        city_name: cityName,
        business_name: businessName,
        ...loan,
        // Customer activity dates must not be replaced by the loan's timestamps.
        created_at: customer.created_at,
        updated_at: customer.updated_at,
        cashCompliance: disbursalCheck.flagged
          ? { flagged: true, kind: 'disbursal', threshold, reason: disbursalCheck.reason }
          : { flagged: false, kind: 'disbursal', threshold },
      }, { status: 201 })
    } catch (err: any) {
      if (err.code === '23505' && attempt < MAX_RETRIES - 1) {
        continue
      }
      // Detailed server-side log (identifiers only — never secrets or tokens)
      // so the real database cause is visible in the terminal during dev.
      console.error('[POST /api/customer] Error:', {
        message: err.message,
        code: err.code,
        detail: err.detail,
        constraint: err.constraint,
        table: err.table,
        column: err.column,
        attempt: attempt + 1,
      })
      return NextResponse.json(
        {
          error: 'Failed to create customer',
          details: err.message,
          ...(process.env.NODE_ENV !== 'production' && err.code ? { pgCode: err.code } : {}),
        },
        { status: 500 }
      )
    }
  }
  return NextResponse.json({ error: 'Failed to create customer after retries' }, { status: 500 })
}
