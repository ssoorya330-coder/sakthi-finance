'use client'

import { useMemo, useState } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { PieChart as PieIcon } from 'lucide-react'
import { PieChart, Pie, Cell, ResponsiveContainer, Sector } from 'recharts'
import { useCustomerStore } from '@/store/customer-store'
import { computeLoanStatus } from './dashboard-data'
import { pieAnimationProps } from './dashboard-animations'
import { useQuery } from '@tanstack/react-query'
import { useAuthStore } from '@/store/auth-store'

export default function LoanStatusChart() {
  const [activeName, setActiveName] = useState<string | null>(null)
  const reducedMotion = useReducedMotion()
  const customers = useCustomerStore((s) => s.customers)
  const userId=useAuthStore(s=>s.userId)
  const deleted=useQuery({queryKey:['dashboard','deleted-customers',userId],enabled:!!userId,staleTime:0,retry:false,queryFn:async()=>{
    const response=await fetch('/api/dashboard/deleted-count',{cache:'no-store'})
    if(!response.ok)throw new Error('Count unavailable')
    return (await response.json()).count as number
  }})
  const data = useMemo(() => [...computeLoanStatus(customers), ...(deleted.data!==undefined?[{name:'Deleted Customers',value:deleted.data,color:'#8B5CF6'}]:[])], [customers,deleted.data])
  const total = data.reduce((s, d) => s + d.value, 0)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.5 }}
      className="relative bg-white/70 backdrop-blur-xl rounded-[20px] border border-white/20 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] p-6 overflow-hidden h-full"
    >
      <div className="absolute inset-0 sf-pattern-dots opacity-40 pointer-events-none" />
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-blue-500 via-emerald-400 to-rose-500" />
      <div aria-hidden="true" className="pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full border-[18px] border-blue-400/10" />
      <div aria-hidden="true" className="pointer-events-none absolute -bottom-16 -left-12 h-40 w-40 rounded-full bg-emerald-300/10" />
      <div className="flex items-center justify-between mb-4 relative">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
            <PieIcon className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-slate-900">Loan Status</h3>
            <p className="text-xs text-slate-500">{total} status records · deleted includes recoverable records</p>
            {deleted.isError && <p className="text-xs text-amber-700">Deleted count unavailable offline</p>}
          </div>
        </div>
      </div>
      <div className="flex flex-wrap items-center justify-center gap-5 relative">
        <div className="w-[162px] h-[162px] flex-shrink-0 relative">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data.length > 0 ? data : [{ name: 'No Data', value: 1, color: '#F1F5F9' }]}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={72}
                cornerRadius={6}
                paddingAngle={data.length > 1 ? 4 : 0}
                dataKey="value"
                {...pieAnimationProps}
                onMouseEnter={(entry: any) => setActiveName(entry.name)}
                onMouseLeave={() => setActiveName(null)}
                shape={(props: any) => <Sector {...props} outerRadius={props.outerRadius + (props.name === activeName ? 7 : 0)} style={{ filter: props.name === activeName ? 'brightness(1.08) drop-shadow(0 2px 3px rgba(0,0,0,0.15))' : 'none', transition: reducedMotion ? 'none' : 'filter 180ms ease' }} />}
                isAnimationActive={!reducedMotion}
              >
                {data.length > 0
                  ? data.map((entry, i) => <Cell key={i} fill={entry.color} stroke="none" />)
                  : <Cell fill="#F1F5F9" stroke="none" />
                }
              </Pie>

            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center">
              <p className="text-2xl font-bold text-slate-900">{total}</p>
              <p className="text-[9px] text-slate-400 font-medium -mt-0.5">Total</p>
            </div>
          </div>
        </div>
        <div className="flex-1 min-w-[170px] space-y-3">
          {data.map((item, idx) => (
            <motion.div
              key={item.name}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: 0.5 + idx * 0.06 }}
              className="relative overflow-hidden flex items-center justify-between gap-3 rounded-xl border px-3 py-3"
              style={{ borderColor: `${item.color}30`, background: `linear-gradient(110deg, ${item.color}15, #ffffff)` }}
            >
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full ring-4" style={{ backgroundColor: item.color, boxShadow: `0 0 0 4px ${item.color}20` }} />
                <span className="text-sm text-slate-600">{item.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-slate-900">{item.value}</span>
                <span className="text-xs text-slate-600">
                  {total > 0 ? ((item.value / total) * 100).toFixed(0) : 0}%
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  )
}
