const { app, BrowserWindow } = require('electron')
const path = require('node:path')
const fs = require('node:fs')
app.setPath('userData', path.resolve('test-reports/voice-ui-profile'))
app.whenReady().then(async () => {
  const window = new BrowserWindow({show: false, webPreferences: {contextIsolation: true, nodeIntegration: false, sandbox: true}})
  let report
  try {
    await window.loadURL('file://' + path.resolve('test-reports/voice-ui.html').replaceAll('\\', '/'))
    await window.webContents.executeJavaScript(fs.readFileSync('test-reports/voice-ui-bundle.js', 'utf8'))
    const passed = await window.webContents.executeJavaScript('window.runVoiceChecks()')
    report = {runtime: process.versions.electron, provider: 'Synthetic IPC events; actual shared React component/hook/adapter', passed, status:'PASS'}
  } catch (error) { report = {status:'FAIL', error: String(error)} }
  fs.writeFileSync('test-reports/VOICE_ELECTRON_UI_TEST.json', JSON.stringify(report, null, 2))
  window.destroy(); app.exit(report.status === 'PASS' ? 0 : 1)
})
