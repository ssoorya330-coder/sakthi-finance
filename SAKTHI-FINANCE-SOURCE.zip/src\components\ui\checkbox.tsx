'use client'

import { forwardRef, useCallback } from 'react'
import { cn } from '@/lib/utils'

interface CheckboxProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string
  onCheckedChange?: (checked: boolean) => void
}

const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(
  ({ className, label, id, onCheckedChange, onChange, ...props }, ref) => {
    const handleChange = useCallback(
      (e: React.ChangeEvent<HTMLInputElement>) => {
        onChange?.(e)
        onCheckedChange?.(e.target.checked)
      },
      [onChange, onCheckedChange]
    )

    return (
      <div className="flex items-center gap-2">
        <input
          ref={ref}
          type="checkbox"
          id={id}
          onChange={handleChange}
          className={cn(
            'h-4 w-4 rounded border-slate-300 bg-white',
            'text-gold-400 focus:ring-gold-400/30 focus:ring-offset-0',
            'accent-gold-400',
            className
          )}
          {...props}
        />
        {label && (
          <label htmlFor={id} className="text-[14px] text-text-secondary cursor-pointer select-none">
            {label}
          </label>
        )}
      </div>
    )
  }
)

Checkbox.displayName = 'Checkbox'

export { Checkbox }
