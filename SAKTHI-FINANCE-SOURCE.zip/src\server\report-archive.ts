import { createHash } from 'node:crypto';
import { buildFinancialSheets, type FinancialReportData } from './financial-report';
import { buildXlsx, buildZip, x, XS_TITLE, XS_HEADER, XS_CURRENCY, type XlsxSheet } from './audit-excel';

export interface ArchiveFile { name: string; data: Buffer }
const escapeHtml = (v: unknown) => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

function readableReport(sheet: XlsxSheet, period: string): Buffer {
  const rows = sheet.rows.map(row => `<tr>${row.map(cell => {
    const tag = cell.t !== 'e' && cell.s === XS_HEADER ? 'th' : 'td';
    const value = cell.t === 'e' ? '' : cell.v;
    return `<${tag}>${escapeHtml(value)}</${tag}>`;
  }).join('')}</tr>`).join('');
  return Buffer.from(`<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(sheet.name)}</title><style>body{font:14px system-ui,sans-serif;color:#1e293b;margin:32px}h1{color:#7f1d1d}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:8px;text-align:left;overflow-wrap:anywhere}th{background:#7f1d1d;color:white}tr:nth-child(even){background:#faf6f6}@media print{@page{size:A4 landscape;margin:10mm}body{margin:0;font-size:9px}tr{break-inside:avoid}}</style></head><body><h1>Sakthi Finance — ${escapeHtml(sheet.name)}</h1><p>${escapeHtml(period)} · Currency: INR</p><table>${rows}</table></body></html>`, 'utf8');
}

export function yearlyReportFiles(d: FinancialReportData): ArchiveFile[] {
  const groups: Record<string, string> = {
    'Overall Summary': '01_Finance_Report', 'Customer Summary': '02_Customer_Report',
    'Loan Details': '03_Loan_Report', 'Transaction Ledger': '07_Ledger_Report',
    'Reconciliation': '08_Reconciliation', 'Data Quality Checks': '08_Reconciliation',
    'Cash Transactions': '06_Cash_Transaction_Report', 'Flagged Cash Transactions': '06_Cash_Transaction_Report',
  };
  const sheets = buildFinancialSheets(d);
  sheets.push({ name: 'Profit Report', cols: [48, 35], rows: [
    [x.ST(`Sakthi Finance - Income / Profit Review - FY ${d.fy.label}`, XS_TITLE)],
    [x.ST('Metric', XS_HEADER), x.ST('Value', XS_HEADER)],
    [x.ST('Interest received (gross income, before expenses)'), x.NM(d.overall.interestReceived, XS_CURRENCY)],
    [x.ST('Principal recovered (not income)'), x.NM(d.overall.principalRecovered, XS_CURRENCY)],
    [x.ST('Operating expenses / funding costs / tax'), x.ST('Not available in this reporting source')],
    [x.ST('Net profit'), x.ST('Cannot be determined from the available records')],
    [x.ST('Basis'), x.ST('Interest uses the existing principal-first payment allocation. This is not a complete profit-and-loss statement.')],
  ] });
  sheets.push({ name: 'Loss Report', cols: [48, 35], rows: [
    [x.ST(`Sakthi Finance - Loss / Exposure Review - FY ${d.fy.label}`, XS_TITLE)],
    [x.ST('Metric', XS_HEADER), x.ST('Value', XS_HEADER)],
    [x.ST('Recognized losses / write-offs'), x.ST('Not available in this reporting source')],
    [x.ST('Outstanding principal (not a booked loss)'), x.NM(d.overall.outstandingPrincipal, XS_CURRENCY)],
    [x.ST('Outstanding interest (not a booked loss)'), x.NM(d.overall.outstandingInterest, XS_CURRENCY)],
    [x.ST('Net loss'), x.ST('Cannot be determined from the available records')],
    [x.ST('Basis'), x.ST('Outstanding balances and aborted loans must not automatically be treated as realized losses.')],
  ] });
  groups['Profit Report'] = '04_Profit_Report'; groups['Loss Report'] = '05_Loss_Report';
  const files: ArchiveFile[] = [];
  for (const sheet of sheets) {
    const path = `FY_${d.fy.startYear}-${d.fy.startYear + 1}/${groups[sheet.name]}/${sheet.name.replace(/ /g, '_')}`;
    files.push({ name: `${path}.xlsx`, data: buildXlsx([sheet]) });
    files.push({ name: `${path}.html`, data: readableReport(sheet, d.period) });
  }
  return files;
}

export function buildReportArchive(files: ArchiveFile[], fromYear: number, toYear: number, generatedAt: string) {
  const root = `SakthiFinance_${fromYear}-${toYear}_Reports`;
  const readme = `SAKTHI FINANCE REPORT ARCHIVE\nFinancial-year coverage: April ${fromYear} through March ${toYear}.\nGenerated: ${generatedAt}\n\nExtract the ZIP, then open START_HERE.html. Each report has an Excel (.xlsx) file and a readable/printable HTML file.\nReports cover the signed-in account's business records for all available financial years; Audit Log table filters do not apply.\nFigures reuse the Financial Audit calculations. Outstanding balances use lifetime payments at export time, not historical year-end balances. The current financial year may be incomplete.\nProfit and loss reports disclose missing expense and write-off data; unavailable figures are not zero.\nThis is a report pack, not a database backup or a lossless audit-event archive.\nReports are queried during generation; pause concurrent editing when a fixed accounting cut-off is required.\nNo raw JSON files are included. SHA256SUMS.txt checks file integrity.\n`;
  const links = files.filter(f => f.name.endsWith('.html')).map(f => `<li><a href="${escapeHtml(f.name)}">${escapeHtml(f.name.replace(/_/g, ' ').replace(/\.html$/, ''))}</a></li>`).join('');
  const contents = [...files,
    { name: 'README.txt', data: Buffer.from(readme) },
    { name: 'START_HERE.html', data: Buffer.from(`<!doctype html><html><head><meta charset="utf-8"><title>Sakthi Finance Reports ${fromYear}-${toYear}</title><style>body{font:15px system-ui;margin:40px;color:#1e293b}h1,a{color:#7f1d1d}li{margin:12px 0}pre{white-space:pre-wrap;line-height:1.6}</style></head><body><h1>Sakthi Finance · ${fromYear}–${toYear}</h1><pre>${escapeHtml(readme)}</pre><ul>${links}</ul></body></html>`) },
  ];
  contents.push({ name: 'SHA256SUMS.txt', data: Buffer.from(contents.map(f => `${createHash('sha256').update(f.data).digest('hex')}  ${f.name}`).join('\n')) });
  return { filename: `${root}.zip`, bytes: buildZip(contents.map(f => ({ ...f, name: `${root}/${f.name}` }))) };
}
