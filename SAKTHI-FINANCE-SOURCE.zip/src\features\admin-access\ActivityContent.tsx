'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'
import AdminSectionShell, {
  AdminEmpty,
  AdminError,
  AdminLoading,
  type AdminSectionIcon,
} from './AdminSectionShell'

interface ActivityRow {
  created_at?: string | null
  action?: string | null
  performed_by?: string | null
  user_role?: string | null
  result?: string | null
}

type LoadState = 'loading' | 'ready' | 'unauthorized' | 'failed'

const fmtDT = (iso: string | null | undefined) => {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true,
    })
  } catch {
    return '—'
  }
}

interface ActivityContentProps {
  kind: 'login' | 'system'
  title: string
  subtitle: string
  icon: AdminSectionIcon
  emptyMessage: string
}

export default function ActivityContent({ kind, title, subtitle, icon, emptyMessage }: ActivityContentProps) {
  const [events, setEvents] = useState<ActivityRow[]>([])
  const [state, setState] = useState<LoadState>('loading')
  const [retrying, setRetrying] = useState(false)
  const mountedRef = useRef(true)

  const load = useCallback(
    async (isRetry = false) => {
      if (isRetry) setRetrying(true)
      else setState('loading')
      try {
        const res = await fetch(`/api/admin/activity?kind=${kind}`, { credentials: 'include' })
        if (res.status === 401 || res.status === 403) {
          if (mountedRef.current) setState('unauthorized')
          return
        }
        if (!res.ok) throw new Error(`Request failed (${res.status})`)
        const data = await res.json().catch(() => null)
        const rows = Array.isArray(data?.events) ? (data.events as ActivityRow[]) : []
        if (mountedRef.current) {
          setEvents(rows)
          setState('ready')
        }
      } catch {
        if (mountedRef.current) setState('failed')
      } finally {
        if (mountedRef.current) setRetrying(false)
      }
    },
    [kind]
  )

  useEffect(() => {
    mountedRef.current = true
    load()
    return () => {
      mountedRef.current = false
    }
  }, [load])

  return (
    <AdminSectionShell title={title} subtitle={subtitle} icon={icon}>
      {state === 'loading' && <AdminLoading />}
      {state === 'unauthorized' && (
        <AdminError message="You are not authorized to access this page." onRetry={() => load(true)} retrying={retrying} />
      )}
      {state === 'failed' && (
        <AdminError message="Unable to connect to the database. Please try again." onRetry={() => load(true)} retrying={retrying} />
      )}
      {state === 'ready' &&
        (events.length === 0 ? (
          <AdminEmpty message={emptyMessage} />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-bold text-slate-900">
                Recent Activity <span className="text-slate-400 font-semibold">({events.length})</span>
              </p>
            </div>
            <div className="divide-y divide-slate-100">
              {events.map((e, i) => (
                <div key={i} className="px-4 py-3 flex flex-wrap items-center gap-x-4 gap-y-1">
                  <span className="text-[13px] font-bold text-slate-900">
                    {(e.action || '—').replace(/_/g, ' ')}
                  </span>
                  <span className="text-xs text-slate-500 tabular-nums">{fmtDT(e.created_at)}</span>
                  <span className="text-xs text-slate-500">
                    By <b>{e.performed_by || '—'}</b>
                    {e.user_role ? ` (${e.user_role})` : ''}
                  </span>
                  <span className="ml-auto">
                    <span className={cn(
                      'inline-flex items-center px-2 py-0.5 rounded-lg text-[11px] font-bold border whitespace-nowrap',
                      e.result === 'FAILED'
                        ? 'bg-red-50 text-red-700 border-red-200'
                        : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    )}>
                      {e.result || '—'}
                    </span>
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
    </AdminSectionShell>
  )
}
