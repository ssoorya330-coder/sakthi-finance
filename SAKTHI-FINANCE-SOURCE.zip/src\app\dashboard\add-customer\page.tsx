'use client'

import React, { useState, useMemo, useCallback, useEffect, useRef } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { motion } from 'framer-motion'
import { useQueryClient } from '@tanstack/react-query'
import {
  User,
  Phone,
  Smartphone,
  MapPin,
  Building2,
  IndianRupee,
  Home,
  Percent,
  Timer,
  CalendarDays,
  ListOrdered,
  TrendingUp,
  CreditCard,
  Clock,
  Hourglass,
  X,
} from 'lucide-react'
import Link from 'next/link'
import { useSidebarStore } from '@/store/sidebar-store'
import { addDays, addWeeks, addMonths, addYears, format, differenceInCalendarDays } from 'date-fns'
import { IconInput, IconSelect, IconTextarea } from '@/components/ui/icon-input'
import BusinessSelect, { BUSINESS_OPTIONS } from '@/components/ui/business-select'
import CustomerNameAutocomplete, { type SuggestCustomer } from '@/components/ui/customer-name-autocomplete'
import { DateInput } from '@/components/ui/date-input'
import VoiceMicButton from '@/components/ui/voice-mic-button'
import { Briefcase } from 'lucide-react'
import { useCustomerStore } from '@/store/customer-store'
import { useToastStore } from '@/store/toast-store'
import type { Customer } from '@/types/customer.types'

const addCustomerSchema = z.object({
  fullName: z.string().min(1, 'Full name is required'),
  mobileNumber: z
    .string()
    .min(1, 'Mobile number is required')
    .regex(/^\d{10}$/, 'Must be exactly 10 digits'),
  alternateMobile: z
    .string()
    .regex(/^\d{10}$/, 'Must be exactly 10 digits')
    .or(z.literal(''))
    .optional(),
  area: z.string().optional(),
  city: z.string().optional(),
  occupation: z.string().min(1, 'Business is required'),
  customBusiness: z.string().optional(),
  monthlyIncome: z
    .string()
    .refine((v) => v === '' || (!isNaN(Number(v)) && Number(v) >= 0), 'Must be a valid amount')
    .optional(),
  address: z.string().optional(),
  loanAmount: z
    .string()
    .min(1, 'Loan amount is required')
    .refine((val) => !isNaN(Number(val)) && Number(val) > 0, 'Must be a positive number'),
  interestRate: z
    .string()
    .min(1, 'Interest rate is required')
    .refine((val) => !isNaN(Number(val)) && Number(val) >= 0, 'Must be 0 or more'),
  loanType: z.string().min(1, 'Loan type is required'),
  duration: z
    .string()
    .min(1, 'Duration is required')
    .refine((val) => !isNaN(Number(val)) && Number(val) > 0, 'Must be positive'),
  loanDate: z.string().min(1, 'Loan date is required'),
}).refine(
  (data) => {
    if (data.occupation === 'Other (\u0BAE\u0BB1\u0BCD\u0BB1\u0BB5\u0BC8)') {
      return data.customBusiness && data.customBusiness.trim().length > 0
    }
    return true
  },
  { message: 'Business name is required', path: ['customBusiness'] },
)

type FormData = z.infer<typeof addCustomerSchema>

const INTEREST_RATE_STORAGE_KEY = 'sakthi-finance:last-interest-rate'

function isValidInterestRate(value: string) {
  return value.trim() !== '' && Number.isFinite(Number(value)) && Number(value) >= 0
}

const labelBase = 'block text-xs font-medium text-[#1E1B14] mb-1 tracking-wide'

const errorText = 'text-xs text-red-500 mt-1.5 flex items-center gap-1'

function Field({
  label,
  required,
  error,
  children,
}: {
  label: string
  required?: boolean
  error?: string
  children: React.ReactNode
}) {
  return (
    <div>
      <label className={labelBase}>
        {label}
        {required && <span className="text-[#BA7517] ml-0.5">*</span>}
      </label>
      {children}
      {error && (
        <motion.p
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className={errorText}
        >
          <X className="w-3 h-3" />
          {error}
        </motion.p>
      )}
    </div>
  )
}

const InfoBox = React.memo(function InfoBox({
  icon,
  label,
  value,
  accent,
  tint,
  delay,
}: {
  icon: React.ReactNode
  label: string
  value: React.ReactNode
  accent: string
  tint: string
  delay: number
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.3, delay, ease: [0.16, 1, 0.3, 1] }}
      className={`relative rounded-2xl border p-3 shadow-sm overflow-hidden group hover:shadow-lg hover:-translate-y-1 hover:scale-[1.02] transition-all duration-300 ${tint}`}
    >
      <div className={`absolute inset-x-0 top-0 h-[3px] rounded-t-2xl ${accent}`} />
      <div className="flex items-center gap-3 pt-1">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center bg-white/80 shrink-0 group-hover:rotate-6 transition-transform duration-300">
          {icon}
        </div>
        <div className="min-w-0">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">{label}</span>
          <motion.p
            key={String(value)}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className="text-[20px] font-bold text-slate-900 tracking-tight mt-0.5 leading-tight"
          >
            {value}
          </motion.p>
        </div>
      </div>
    </motion.div>
  )
})

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.06 },
  },
}

const cardVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] },
  },
}

export default function AddCustomerPage() {
  const lastInterestRate = useRef('')
  const voiceLanguage = 'en-IN'
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toggleSidebar } = useSidebarStore()
  const queryClient = useQueryClient()
  const addCustomer = useCustomerStore((s) => s.addCustomer)
  const customers = useCustomerStore((s) => s.customers)
  const getDisplayId = useCustomerStore((s) => s.getDisplayId)
  const addToast = useToastStore((s) => s.addToast)
  const [addedCustomerId, setAddedCustomerId] = useState<string | null>(null)
  const [provisionalCustomer, setProvisionalCustomer] = useState<Customer | null>(null)

  useEffect(() => {
    if (process.env.NODE_ENV === 'development') {
      console.log('[Dashboard] Customer Add page loaded')
    }
  }, [])

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
    setValue,
  } = useForm<FormData>({
    resolver: zodResolver(addCustomerSchema),
    defaultValues: {
      fullName: '',
      mobileNumber: '',
      alternateMobile: '',
      area: '',
      city: '',
      occupation: '',
      customBusiness: '',
      monthlyIncome: '',
      address: '',
      loanAmount: '',
      interestRate: '',
      loanType: '',
      duration: '',
      loanDate: '',
    },
  })

  useEffect(() => {
    try {
      const savedRate = localStorage.getItem(INTEREST_RATE_STORAGE_KEY)
      if (savedRate !== null && isValidInterestRate(savedRate)) {
        lastInterestRate.current = savedRate
        setValue('interestRate', savedRate)
      }
    } catch {
      // The form remains usable when browser storage is unavailable.
    }
  }, [setValue])

  const watched = watch()
  const {
    loanAmount,
    interestRate,
    loanType,
    duration,
    loanDate,
  } = watched

  useEffect(() => {
    if (!isValidInterestRate(interestRate)) return
    lastInterestRate.current = interestRate
    try {
      localStorage.setItem(INTEREST_RATE_STORAGE_KEY, interestRate)
    } catch {
      // Keep the rate in memory for the next customer in this session.
    }
  }, [interestRate])

  const durationLabel = useMemo(() => {
    switch (loanType) {
      case 'Daily': return 'Number of Days'
      case 'Weekly': return 'Number of Weeks'
      case 'Monthly': return 'Number of Months'
      default: return 'Duration'
    }
  }, [loanType])

  const durationOptions = useMemo(() => {
    switch (loanType) {
      case 'Daily':
        return Array.from({ length: 365 }, (_, i) => ({
          value: String(i + 1),
          label: `${i + 1} ${i === 0 ? 'Day' : 'Days'}`,
        }))
      case 'Weekly':
        return Array.from({ length: 52 }, (_, i) => ({
          value: String(i + 1),
          label: `${i + 1} ${i === 0 ? 'Week' : 'Weeks'}`,
        }))
      case 'Monthly':
        return Array.from({ length: 60 }, (_, i) => ({
          value: String(i + 1),
          label: `${i + 1} ${i === 0 ? 'Month' : 'Months'}`,
        }))
      default:
        return []
    }
  }, [loanType])

  useEffect(() => {
    setValue('duration', '')
  }, [loanType, setValue])

  const computed = useMemo(() => {
    const amount = Number(loanAmount) || 0
    const rate = Number(interestRate) || 0
    const dur = Number(duration) || 0

    const interestAmount = (amount * rate) / 100
    const totalAmount = amount + interestAmount
    const perInstallment = dur > 0 ? totalAmount / dur : 0

    const fmtAmount = (v: number) =>
      new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(v)

    const fmtDateDisplay = (d: Date) => format(d, 'dd-MM-yyyy')

    let dueDateStr = '�'
    let nextCollectionStr = '�'
    let remainingDays = 0
    let isOverdue = false

    if (loanDate && dur > 0 && loanType) {
      const startDate = new Date(loanDate + 'T00:00:00')

      let dueDate: Date
      if (loanType === 'Daily') dueDate = addDays(startDate, dur)
      else if (loanType === 'Weekly') dueDate = addWeeks(startDate, dur)
      else if (loanType === 'Monthly') dueDate = addMonths(startDate, dur)
      else dueDate = addYears(startDate, dur)

      dueDateStr = fmtDateDisplay(dueDate)

      let nextCollection: Date
      if (loanType === 'Daily') nextCollection = addDays(startDate, 1)
      else if (loanType === 'Weekly') nextCollection = addWeeks(startDate, 1)
      else if (loanType === 'Monthly') nextCollection = addMonths(startDate, 1)
      else nextCollection = addYears(startDate, 1)
      nextCollectionStr = fmtDateDisplay(nextCollection)

      const diff = differenceInCalendarDays(dueDate, new Date())
      remainingDays = diff
      isOverdue = diff < 0
    }

    const periodLabel = loanType === 'Daily' ? 'day' : loanType === 'Weekly' ? 'week' : loanType === 'Yearly' ? 'year' : 'month'

    const status = !loanDate || !duration || !loanType ? '�' : isOverdue ? 'Overdue' : 'Active'

    const showPlaceholder = !loanDate || !duration || !loanType

    return {
      interestAmount,
      interestAmountStr: fmtAmount(interestAmount),
      totalAmount,
      totalAmountStr: fmtAmount(totalAmount),
      perInstallment,
      perInstallmentStr: dur > 0 ? `${fmtAmount(Math.round(perInstallment))} / ${periodLabel}` : '-',
      dueDateStr: showPlaceholder ? '-' : dueDateStr,
      nextCollectionStr: showPlaceholder ? '-' : nextCollectionStr,
      remainingDays,
      isOverdue,
      remainingDaysStr: isOverdue
        ? `Overdue by ${Math.abs(remainingDays)} Day${Math.abs(remainingDays) !== 1 ? 's' : ''}`
        : `${remainingDays} Day${remainingDays !== 1 ? 's' : ''} Remaining`,
      rateStr: `${rate}%`,
      amountStr: fmtAmount(amount),
      loanDateStr: showPlaceholder ? '-' : loanDate ? fmtDateDisplay(new Date(loanDate + 'T00:00:00')) : '-',
      status,
    }
  }, [loanAmount, interestRate, loanType, duration, loanDate])

  const dueDateValue = useMemo(() => {
    if (!loanDate || !duration || !loanType) return ''
    const startDate = new Date(loanDate + 'T00:00:00')
    const dur = Number(duration) || 0
    if (dur <= 0) return ''
    let dueDate: Date
    if (loanType === 'Daily') dueDate = addDays(startDate, dur)
    else if (loanType === 'Weekly') dueDate = addWeeks(startDate, dur)
    else if (loanType === 'Monthly') dueDate = addMonths(startDate, dur)
    else if (loanType === 'Yearly') dueDate = addYears(startDate, dur)
    else return ''
    return format(dueDate, 'yyyy-MM-dd')
  }, [loanDate, duration, loanType])

  const handleReset = useCallback(() => {
    reset()
    setValue('interestRate', lastInterestRate.current)
    setAddedCustomerId(null)
    setProvisionalCustomer(null)
  }, [reset, setValue])

  /**
   * Fill the form from an autocomplete recommendation. Only populates fields —
   * never submits or creates a customer. Missing info stays empty (no fake
   * values). The user can edit everything before manually saving.
   */
  const handleCustomerPick = useCallback(
    (customer: SuggestCustomer) => {
      const opts = { shouldValidate: true, shouldDirty: true } as const
      setValue('fullName', customer.full_name || '', opts)
      setValue('mobileNumber', customer.phone_number || '', opts)
      setValue('alternateMobile', customer.alternate_phone || '', opts)
      setValue('address', customer.address || '', opts)
      setValue('area', customer.area || '', opts)
      setValue('city', customer.city || '', opts)

      // Map the saved business onto the Business dropdown options. Options
      // carry a Tamil suffix (e.g. "Tea Shop (தேநீர் கடை)") while saved values
      // may be the plain name, so match with and without the suffix.
      const business = (customer.business || '').trim()
      if (business) {
        const lowered = business.toLowerCase()
        const matched =
          BUSINESS_OPTIONS.find((o) => o.toLowerCase() === lowered) ??
          BUSINESS_OPTIONS.find(
            (o) => o.replace(/\s*\(.*\)\s*$/, '').trim().toLowerCase() === lowered
          )
        if (matched) {
          setValue('occupation', matched, opts)
          setValue('customBusiness', '', opts)
        } else {
          const other =
            BUSINESS_OPTIONS.find((o) => o.startsWith('Other (')) ?? 'Other (மற்றவை)'
          setValue('occupation', other, opts)
          setValue('customBusiness', business, opts)
        }
      } else {
        setValue('occupation', '', opts)
        setValue('customBusiness', '', opts)
      }
    },
    [setValue]
  )

  const addedCustomer = useMemo(
    () => customers.find((c) => c.id === addedCustomerId) || provisionalCustomer,
    [customers, addedCustomerId, provisionalCustomer],
  )

  const onSubmit = async (data: FormData) => {
    if (isSubmitting) return
    setIsSubmitting(true)
    await saveCustomer(data)
  }

  const saveCustomer = async (data: FormData) => {
    if (process.env.NODE_ENV === 'development') {
      console.log('[AddCustomer] submitting payload:', {
        fullName: data.fullName,
        mobileNumber: data.mobileNumber,
        loanAmount: data.loanAmount,
        interestRate: data.interestRate,
        loanType: data.loanType,
        duration: data.duration,
        loanDate: data.loanDate,
        status: computed.isOverdue ? 'Overdue' : 'Active',
      })
    }

    const occupation =
      data.occupation === 'Other (\u0BAE\u0BB1\u0BCD\u0BB1\u0BB5\u0BC8)' && data.customBusiness
        ? data.customBusiness.trim()
        : data.occupation

    const now = new Date().toISOString()
    const provisionalId = `temp-${Date.now()}`
    let nextNum = 0
    for (const c of customers) {
      const n = Number(String(c.customerCode || c.id).match(/\d+/)?.[0] || 0) || Number(String(c.id).split('-')[0]) || 0
      if (n > nextNum) nextNum = n
    }
    const provisional: Customer = {
      id: provisionalId,
      customerCode: `CUST-${String(nextNum + 1).padStart(4, '0')}`,
      fullName: data.fullName,
      mobileNumber: data.mobileNumber,
      alternateMobile: data.alternateMobile || '',
      address: data.address || '',
      areaId: null,
      areaName: data.area || '',
      cityName: data.city || '',
      businessName: occupation,
      area: data.area || '',
      city: data.city || '',
      occupation,
      monthlyIncome: data.monthlyIncome || '',
      loanAmount: data.loanAmount,
      interestRate: data.interestRate,
      loanType: data.loanType as 'Daily' | 'Weekly' | 'Monthly',
      duration: data.duration,
      loanDate: data.loanDate,
      dueDate: dueDateValue,
      totalAmount: computed.totalAmount,
      interestAmount: String(computed.interestAmount),
      installmentAmount: computed.perInstallment,
      remainingDays: computed.remainingDays,
      status: computed.isOverdue ? 'Overdue' : 'Active',
      loanNotes: '',
      createdAt: now,
      updatedAt: now,
    }

    setProvisionalCustomer(provisional)
    setAddedCustomerId(null)

    const result = await addCustomer({
      customerCode: provisional.customerCode,
      fullName: data.fullName,
      mobileNumber: data.mobileNumber,
      alternateMobile: data.alternateMobile || '',
      address: data.address || '',
      areaId: null,
      areaName: data.area || '',
      cityName: data.city || '',
      businessName: occupation,
      area: data.area || '',
      city: data.city || '',
      occupation,
      monthlyIncome: data.monthlyIncome || '',
      loanAmount: data.loanAmount,
      interestRate: data.interestRate,
      loanType: data.loanType as 'Daily' | 'Weekly' | 'Monthly',
      duration: data.duration,
      loanDate: data.loanDate,
      dueDate: dueDateValue,
      totalAmount: computed.totalAmount,
      interestAmount: String(computed.interestAmount),
      installmentAmount: computed.perInstallment,
      remainingDays: computed.remainingDays,
      status: computed.isOverdue ? 'Overdue' : 'Active',
      loanNotes: '',
    })

    if (!result.success) {
      if (process.env.NODE_ENV === 'development') {
        console.error('[Dashboard] Customer save failed:', result.error)
      }
      setProvisionalCustomer(null)
      setAddedCustomerId(null)
      setIsSubmitting(false)
      addToast(result.error || 'Failed to create customer. Please try again.', 'error')
      return
    }

    queryClient.invalidateQueries({ queryKey: ['dashboard'] })
    queryClient.invalidateQueries({ queryKey: ['customers'] })
    queryClient.invalidateQueries({ queryKey: ['loans'] })

    if (process.env.NODE_ENV === 'development') {
      console.log('[Dashboard] Customer added, queries invalidated')
    }

    setIsSubmitting(false)
    addToast('Customer created successfully.', 'success')
    setAddedCustomerId(result.id || null)
    setProvisionalCustomer(null)
    reset()
    setValue('interestRate', lastInterestRate.current)
  }

  const loanTypeOptions = [
    { value: 'Daily', label: 'Day' },
    { value: 'Weekly', label: 'Week' },
    { value: 'Monthly', label: 'Month' },
  ]

  return (
    <div className="min-h-screen bg-[var(--background)]">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-8 py-4">
        <div className="flex items-center gap-4">
          <button
            onClick={toggleSidebar}
            className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center hover:bg-slate-100 transition-colors flex-shrink-0 active:scale-95"
          >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="#475569" strokeWidth="2" strokeLinecap="round">
              <path d="M3 5h14" /><path d="M3 10h14" /><path d="M3 15h14" />
            </svg>
          </button>
          <div>
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
                <User className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Add Customer</h1>
                <p className="text-sm text-slate-500 mt-0.5">
                  Create a new customer and loan details.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="max-w-[1320px] mx-auto px-8 py-6 space-y-5 pb-24"
        >
        {/* Customer + Loan Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Customer Information */}
          <motion.div
            variants={cardVariants}
            className="bg-white rounded-[18px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] transition-all duration-300 hover:shadow-[0_4px_16px_rgba(0,0,0,0.06),0_8px_24px_rgba(0,0,0,0.04)] hover:-translate-y-0.5"
          >
            <div className="px-4 py-2.5 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[var(--primary-soft)] flex items-center justify-center">
                  <User className="w-4 h-4 text-[var(--primary)]" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-slate-900">Customer Information</h2>
                  <p className="text-xs text-slate-500 mt-0.5">Personal and contact details</p>
                </div>
              </div>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-3 gap-y-3">
                <div className="md:col-span-2">
                  <div className="flex items-start gap-2.5">
                    <div className="flex-1 min-w-0">
                      <Field label="Full Name" required error={errors.fullName?.message}>
                        <CustomerNameAutocomplete
                          value={watched.fullName ?? ''}
                          onChange={(v) =>
                            setValue('fullName', v, { shouldValidate: true, shouldDirty: true })
                          }
                          onPick={handleCustomerPick}
                          error={errors.fullName?.message}
                          placeholder="Enter full name"
                        />
                      </Field>
                    </div>
                    <div className="pt-[15px] shrink-0">
                      <VoiceMicButton
                        value={watched.fullName ?? ''}
                        onPreview={text => setValue('fullName', text, { shouldValidate: false })}
                      phrases={['Soorya', ...customers.map(customer => customer.fullName)]}
                      lang={voiceLanguage}
                        onResult={(text: string) => setValue('fullName', text, { shouldValidate: true, shouldDirty: true })}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="flex-1 min-w-0">
                    <Field label="Mobile Number" required error={errors.mobileNumber?.message}>
                      <IconInput
                        icon={<Phone className="w-5 h-5 text-slate-400" />}
                        type="tel"
                        placeholder="10-digit number"
                        maxLength={10}
                        error={errors.mobileNumber?.message}
                        {...register('mobileNumber')}
                      />
                    </Field>
                  </div>
                  <div className="pt-[15px] shrink-0">
                    <VoiceMicButton
                      inputType="phone"
                      value={watched.mobileNumber ?? ''}
                      onPreview={text => setValue('mobileNumber', text, { shouldValidate: false })}
                      lang={voiceLanguage}
                      onResult={(text: string) => {
                        setValue('mobileNumber', text, { shouldValidate: true, shouldDirty: true })
                      }}
                    />
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="flex-1 min-w-0">
                    <Field label="Alternate Mobile" error={errors.alternateMobile?.message}>
                      <IconInput
                        icon={<Smartphone className="w-5 h-5 text-slate-400" />}
                        type="tel"
                        placeholder="Alternate number"
                        maxLength={10}
                        error={errors.alternateMobile?.message}
                        {...register('alternateMobile')}
                      />
                    </Field>
                  </div>
                  <div className="pt-[15px] shrink-0">
                    <VoiceMicButton
                      inputType="phone"
                      value={watched.alternateMobile ?? ''}
                      onPreview={text => setValue('alternateMobile', text, { shouldValidate: false })}
                      lang={voiceLanguage}
                      onResult={(text: string) => {
                        setValue('alternateMobile', text, { shouldValidate: true, shouldDirty: true })
                      }}
                    />
                  </div>
                </div>

                <div className="flex items-start gap-2.5 md:max-w-[95%]">
                  <div className="flex-1 min-w-0">
                    <Field label="Address" error={errors.address?.message}>
                    <IconTextarea
                      icon={<Home className="w-5 h-5 text-slate-400" />}
                      placeholder="Enter full address"
                      maxHeight={220}
                      error={errors.address?.message}
                      {...register('address')}
                    />
                    </Field>
                  </div>
                  <div className="pt-[15px] shrink-0">
                    <VoiceMicButton
                      lang={voiceLanguage}
                      value={watched.address ?? ''}
                      onPreview={text => setValue('address', text, { shouldValidate: false })}
                      onResult={(text: string) => setValue('address', text, { shouldValidate: true, shouldDirty: true })}
                    />
                  </div>
                </div>

                <div className="flex items-start gap-2.5 md:max-w-[80%]">
                  <div className="flex-1 min-w-0">
                    <Field label="Area" error={errors.area?.message}>
                    <IconTextarea
                      icon={<MapPin className="w-5 h-5 text-slate-400" />}
                      placeholder="Area / Locality"
                      maxHeight={180}
                      error={errors.area?.message}
                      {...register('area')}
                    />
                    </Field>
                  </div>
                  <div className="pt-[15px] shrink-0">
                    <VoiceMicButton
                      lang={voiceLanguage}
                      value={watched.area ?? ''}
                      onPreview={text => setValue('area', text, { shouldValidate: false })}
                      onResult={(text: string) => setValue('area', text, { shouldValidate: true, shouldDirty: true })}
                    />
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="flex-1 min-w-0">
                    <Field label="City" error={errors.city?.message}>
                      <IconInput
                        icon={<Building2 className="w-5 h-5 text-slate-400" />}
                        type="text"
                        placeholder="Enter city"
                        error={errors.city?.message}
                        {...register('city')}
                      />
                    </Field>
                  </div>
                  <div className="pt-[15px] shrink-0">
                    <VoiceMicButton
                      lang={voiceLanguage}
                      value={watched.city ?? ''}
                      onPreview={text => setValue('city', text, { shouldValidate: false })}
                      onResult={(text: string) => setValue('city', text, { shouldValidate: true, shouldDirty: true })}
                    />
                  </div>
                </div>

                <Field label="Business" required error={errors.occupation?.message}>
                  <BusinessSelect
                    value={watched.occupation || ''}
                    onChange={(val: string) => {
                      setValue('occupation', val, { shouldValidate: true })
                      if (val !== 'Other (\u0BAE\u0BB1\u0BCD\u0BB1\u0BB5\u0BC8)') {
                        setValue('customBusiness', '', { shouldValidate: true })
                      }
                    }}
                    error={errors.occupation?.message}
                  />
                  {watched.occupation === 'Other (\u0BAE\u0BB1\u0BCD\u0BB1\u0BB5\u0BC8)' && (
                    <div className="mt-3">
                      <label className={labelBase}>
                        Business Name
                        <span className="text-red-400 ml-0.5">*</span>
                      </label>
                      <IconInput
                        icon={<Briefcase className="w-5 h-5 text-slate-400" />}
                        type="text"
                        placeholder="Enter Business Name"
                        error={errors.customBusiness?.message}
                        {...register('customBusiness')}
                      />
                    </div>
                  )}
                </Field>
              </div>
            </div>
          </motion.div>

          {/* Loan Information */}
          <motion.div
            variants={cardVariants}
            className="bg-white rounded-[18px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] transition-all duration-300 hover:shadow-[0_4px_16px_rgba(0,0,0,0.06),0_8px_24px_rgba(0,0,0,0.04)] hover:-translate-y-0.5"
          >
            <div className="px-4 py-2.5 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[var(--primary-soft)] flex items-center justify-center">
                  <IndianRupee className="w-4 h-4 text-[var(--primary)]" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-slate-900">Loan Details</h2>
                  <p className="text-xs text-slate-500 mt-0.5">Loan amount, interest and schedule</p>
                </div>
              </div>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-3 gap-y-3">
                <Field label="Loan Amount" required error={errors.loanAmount?.message}>
                  <IconInput
                    icon={<IndianRupee className="w-5 h-5 text-slate-400" />}
                    type="number"
                    placeholder="0"
                    min="0"
                    error={errors.loanAmount?.message}
                    {...register('loanAmount')}
                  />
                </Field>

                <Field label="Interest Rate (%)" required error={errors.interestRate?.message}>
                  <IconInput
                    icon={<Percent className="w-5 h-5 text-slate-400" />}
                    type="number"
                    placeholder="0"
                    min="0"
                    step="0.1"
                    error={errors.interestRate?.message}
                    {...register('interestRate')}
                  />
                </Field>

                <Field label="Loan Type" required error={errors.loanType?.message}>
                  <IconSelect
                    icon={<ListOrdered className="w-5 h-5 text-slate-400" />}
                    error={errors.loanType?.message}
                    {...register('loanType')}
                  >
                    {loanTypeOptions.map((opt) => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </IconSelect>
                </Field>

                <Field label={durationLabel} required error={errors.duration?.message}>
                  <IconSelect
                    icon={<Timer className="w-5 h-5 text-slate-400" />}
                    error={errors.duration?.message}
                    {...register('duration')}
                  >
                    {durationOptions.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </IconSelect>
                </Field>

                <Field label="Loan Date" required error={errors.loanDate?.message}>
                  <div className="rounded-2xl bg-gradient-to-br from-[#EAC5A0] via-[#F6DFD8] to-[#C98F9B] p-px shadow-[0_4px_14px_rgba(127,29,29,0.08)]">
                    <div className="rounded-[15px] bg-gradient-to-br from-[#FFFCF5] via-white to-[#FFF0F1] p-1.5">
                  <DateInput
                    className="rounded-xl bg-white/80 font-semibold shadow-sm hover:bg-rose-50 [&>span:first-child>span]:bg-gradient-to-br [&>span:first-child>span]:from-[#A33B45] [&>span:first-child>span]:to-[var(--primary)] [&_svg]:text-[#FFE4B5]"
                    error={errors.loanDate?.message}
                    {...register('loanDate')}
                  />
                    </div>
                  </div>
                </Field>

                <Field label="Due Date">
                  <div className="rounded-2xl bg-gradient-to-br from-[#EAC5A0] via-[#F6DFD8] to-[#C98F9B] p-px shadow-[0_4px_14px_rgba(127,29,29,0.06)]">
                    <div className="rounded-[15px] bg-gradient-to-br from-[#FFFCF5] via-white to-[#FFF0F1] p-1.5">
                  <DateInput
                    className="rounded-xl bg-white/60 font-semibold [&>span:first-child>span]:bg-[#87545D] [&_svg]:text-[#FFE4B5]"
                    value={dueDateValue}
                    disabled
                  />
                    </div>
                  </div>
                </Field>
              </div>
            </div>
          </motion.div>
        </div>

          {/* Loan Summary */}
        <motion.div
          variants={cardVariants}
          className="bg-white rounded-[18px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] transition-all duration-300 hover:shadow-[0_4px_16px_rgba(0,0,0,0.06),0_8px_24px_rgba(0,0,0,0.04)] hover:-translate-y-0.5"
        >
            <div className="px-4 py-2.5 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[var(--primary-soft)] flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-[var(--secondary)]" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-slate-900">Loan Summary</h2>
                <p className="text-xs text-slate-500 mt-0.5">Real-time loan calculations</p>
              </div>
            </div>
          </div>
          <div className="p-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-2.5">
              <InfoBox
                icon={<IndianRupee className="w-[22px] h-[22px] text-blue-700" />}
                label="Loan Amount"
                value={computed.amountStr}
                accent="bg-blue-500"
                tint="bg-blue-50 border-blue-200"
                delay={0}
              />
              <InfoBox
                icon={<Percent className="w-[22px] h-[22px] text-violet-700" />}
                label="Interest Rate"
                value={computed.rateStr}
                accent="bg-violet-500"
                tint="bg-violet-50 border-violet-200"
                delay={0.06}
              />
              <InfoBox
                icon={<IndianRupee className="w-[22px] h-[22px] text-emerald-700" />}
                label="Interest Amount"
                value={computed.interestAmountStr}
                accent="bg-emerald-500"
                tint="bg-emerald-50 border-emerald-200"
                delay={0.12}
              />
              <InfoBox
                icon={<TrendingUp className="w-[22px] h-[22px] text-amber-700" />}
                label="Total Amount"
                value={computed.totalAmountStr}
                accent="bg-amber-500"
                tint="bg-amber-50 border-amber-200"
                delay={0.18}
              />
              <InfoBox
                icon={<CreditCard className="w-[22px] h-[22px] text-cyan-700" />}
                label="Per Installment"
                value={computed.perInstallmentStr}
                accent="bg-cyan-500"
                tint="bg-cyan-50 border-cyan-200"
                delay={0.24}
              />
              <InfoBox
                icon={<CalendarDays className="w-[22px] h-[22px] text-indigo-700" />}
                label="Loan Date"
                value={computed.loanDateStr}
                accent="bg-indigo-500"
                tint="bg-indigo-50 border-indigo-200"
                delay={0.3}
              />
              <InfoBox
                icon={<CalendarDays className="w-[22px] h-[22px] text-rose-700" />}
                label="Due Date"
                value={computed.dueDateStr}
                accent="bg-rose-500"
                tint="bg-rose-50 border-rose-200"
                delay={0.36}
              />
              <InfoBox
                icon={<Clock className="w-[22px] h-[22px] text-orange-700" />}
                label="Next Collection"
                value={computed.nextCollectionStr}
                accent="bg-orange-500"
                tint="bg-orange-50 border-orange-200"
                delay={0.42}
              />
              <InfoBox
                icon={<Hourglass className="w-[22px] h-[22px] text-teal-700" />}
                label="Remaining Days"
                value={
                  computed.isOverdue ? (
                    <span className="text-red-600">{computed.remainingDaysStr}</span>
                  ) : (
                    computed.remainingDaysStr
                  )
                }
                accent="bg-teal-500"
                tint="bg-teal-50 border-teal-200"
                delay={0.48}
              />
            </div>
          </div>
        </motion.div>

        {/* Added Customer Details */}
        {addedCustomer && (
          <motion.div
            variants={cardVariants}
            initial="hidden"
            animate="visible"
            className="bg-white rounded-[18px] border border-emerald-200 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] overflow-hidden"
          >
            <div className="px-4 py-3 border-b border-emerald-100 bg-gradient-to-r from-emerald-50 to-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <User className="w-5 h-5 text-emerald-700" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-slate-900">Customer Added</h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {addedCustomer.fullName} - Customer details saved successfully
                  </p>
                </div>
              </div>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-100 text-emerald-700 text-xs font-semibold">
                <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M13 4.5L6 11.5L3 8.5" />
                </svg>
                Added
              </span>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Customer Code</span>
                  <p className="text-sm font-bold text-slate-900 mt-0.5">{getDisplayId(addedCustomer)}</p>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Name</span>
                  <p className="text-sm font-semibold text-slate-900 mt-0.5">{addedCustomer.fullName}</p>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Mobile</span>
                  <p className="text-sm font-semibold text-slate-900 mt-0.5">{addedCustomer.mobileNumber}</p>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Business</span>
                  <p className="text-sm font-semibold text-slate-900 mt-0.5">{addedCustomer.occupation || '-'}</p>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Loan Amount</span>
                  <p className="text-sm font-bold text-slate-900 mt-0.5">₹{Number(addedCustomer.loanAmount || 0).toLocaleString('en-IN')}</p>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Loan Type</span>
                  <p className="text-sm font-semibold text-slate-900 mt-0.5">{addedCustomer.loanType || '-'}</p>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Total Amount</span>
                  <p className="text-sm font-bold text-slate-900 mt-0.5">₹{(addedCustomer.totalAmount || 0).toLocaleString('en-IN')}</p>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Per Installment</span>
                  <p className="text-sm font-bold text-slate-900 mt-0.5">₹{Math.round(addedCustomer.installmentAmount || 0).toLocaleString('en-IN')}</p>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Loan Date</span>
                  <p className="text-sm font-semibold text-slate-900 mt-0.5">{addedCustomer.loanDate || '-'}</p>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Due Date</span>
                  <p className="text-sm font-semibold text-slate-900 mt-0.5">{addedCustomer.dueDate || '-'}</p>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Area</span>
                  <p className="text-sm font-semibold text-slate-900 mt-0.5">{addedCustomer.area || '-'}</p>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">City</span>
                  <p className="text-sm font-semibold text-slate-900 mt-0.5">{addedCustomer.city || '-'}</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Footer Actions */}
        <motion.div
          variants={cardVariants}
          className="flex items-center justify-end gap-3"
        >
          <button
            type="button"
            onClick={handleReset}
            className="h-[44px] px-6 rounded-xl border border-slate-200 text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 transition-all duration-200 active:scale-[0.97] shadow-[0_1px_2px_rgba(0,0,0,0.03)]"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            onClick={handleSubmit(onSubmit)}
            className="h-[44px] px-8 rounded-xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] text-white text-sm font-medium transition-all duration-200 active:scale-[0.97] shadow-lg shadow-[var(--primary)]/25 hover:shadow-xl hover:shadow-[var(--primary)]/30 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100 flex items-center gap-2.5"
          >
            {isSubmitting ? (
              <>
                <svg className="animate-spin w-4 h-4" viewBox="0 0 16 16" fill="none">
                  <circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="2" opacity="0.25" />
                  <path d="M15 8A7 7 0 1 1 1 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
                Saving...
              </>
            ) : (
              <>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M13 4.5L6 11.5L3 8.5" />
                </svg>
                Add Customer
              </>
            )}
          </button>
        </motion.div>
      </motion.div>
    </div>
  )
}
