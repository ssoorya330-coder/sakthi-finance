import { build } from 'esbuild'
await build({entryPoints: ['scripts/desktop-electron/voice-ui-fixture.tsx'], bundle: true, platform: 'browser', format: 'iife', jsx: 'automatic', define: {'process.env.NODE_ENV': '"production"'}, outfile: 'test-reports/voice-ui-bundle.js'})
