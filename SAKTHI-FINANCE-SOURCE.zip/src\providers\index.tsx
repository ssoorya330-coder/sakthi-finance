'use client'

import { QueryClient, QueryClientProvider, keepPreviousData } from '@tanstack/react-query'
import { useState, useMemo } from 'react'
import { PostHogProvider } from './posthog-provider'
import { SentryProvider } from './sentry-provider'
import { DatabaseProvider } from '@/providers/database-provider'
import { AuthProvider } from '@/components/auth/auth-provider'
import { AuthSync } from '@/components/auth/auth-sync'
import AppStartup from '@/components/ui/app-startup'
import { installDesktopFetchBridge } from '@/lib/desktop/bridge'
import { AppearanceProvider } from './appearance-provider'

export function Providers({ children }: { children: React.ReactNode }) {
  // Desktop (Electron): same-origin /api fetches are routed to the main
  // process over IPC — no HTTP server exists in production.
  installDesktopFetchBridge()
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 5 * 60 * 1000,
            gcTime: 30 * 60 * 1000,
            refetchOnWindowFocus: false,
            refetchOnReconnect: false,
            retry: 1,
            placeholderData: keepPreviousData,
          },
          mutations: {
            retry: 0,
          },
        },
      })
  )

  return (
    <AppearanceProvider><QueryClientProvider client={queryClient}>
      <AuthSync />
      <AuthProvider>
        <DatabaseProvider>
          <PostHogProvider>
            <SentryProvider><AppStartup>{children}</AppStartup></SentryProvider>
          </PostHogProvider>
        </DatabaseProvider>
      </AuthProvider>
    </QueryClientProvider></AppearanceProvider>
  )
}
