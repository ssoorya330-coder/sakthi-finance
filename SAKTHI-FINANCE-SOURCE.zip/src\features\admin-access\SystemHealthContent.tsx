'use client'

import { Activity, CheckCircle2, Database, FileCheck2, MonitorSmartphone, XCircle } from 'lucide-react'
import { cn } from '@/lib/utils'
import AdminSectionShell, { AdminError, AdminLoading } from './AdminSectionShell'
import { useAdminApi } from './useAdminApi'

interface HealthData {
  app: { status: string }
  database: { status: string; latencyMs: number; sizeBytes: number; connections: number }
  sessions: { active: number }
  auditLogging: { status: string; lastEventAt: string | null; totalEvents: number }
}

const fmtBytes = (n: number) => {
  if (!Number.isFinite(n) || n <= 0) return '—'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let v = n
  let u = 0
  while (v >= 1024 && u < units.length - 1) {
    v /= 1024
    u += 1
  }
  return `${v.toFixed(v >= 100 ? 0 : 1)} ${units[u]}`
}

const fmtDT = (iso: string | null) => {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: true,
    })
  } catch {
    return '—'
  }
}

export default function SystemHealthContent() {
  const { data, state, retrying, retry } = useAdminApi<HealthData | null>('/api/admin/system-health', (j) =>
    j && typeof j === 'object' && j.database ? (j as HealthData) : null
  )

  const ok = (good: boolean) =>
    good ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> : <XCircle className="w-5 h-5 text-red-500" />

  return (
    <AdminSectionShell title="System Health" subtitle="Application, database, and audit status" icon="system">
      {state === 'loading' && <AdminLoading />}
      {state === 'unauthorized' && (
        <AdminError message="You are not authorized to access this page." onRetry={retry} retrying={retrying} />
      )}
      {state === 'failed' && (
        <AdminError message="Unable to connect to the database. Please try again." onRetry={retry} retrying={retrying} />
      )}
      {state === 'ready' &&
        (!data ? (
          <AdminError message="Unable to read system status. Please try again." onRetry={retry} retrying={retrying} />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex items-center justify-between">
                <p className="text-sm font-bold text-slate-900">Application Status</p>
                {ok(data.app.status === 'operational')}
              </div>
              <p className="text-xs text-slate-500 mt-1 capitalize">{data.app.status}</p>
            </div>
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex items-center justify-between">
                <p className="text-sm font-bold text-slate-900 flex items-center gap-2"><Database className="w-4 h-4 text-[var(--primary)]" /> PostgreSQL Connection</p>
                {ok(data.database.status === 'connected')}
              </div>
              <p className="text-xs text-slate-500 mt-1 tabular-nums">
                {data.database.status} · {data.database.latencyMs} ms latency
              </p>
            </div>
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <p className="text-sm font-bold text-slate-900">Database Storage</p>
              <p className="text-xl font-extrabold text-slate-900 tabular-nums mt-1">{fmtBytes(data.database.sizeBytes)}</p>
              <p className="text-[11px] text-slate-500 mt-0.5 tabular-nums">{data.database.connections} active connections</p>
            </div>
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <p className="text-sm font-bold text-slate-900 flex items-center gap-2"><MonitorSmartphone className="w-4 h-4 text-[var(--primary)]" /> Current Session Count</p>
              <p className="text-xl font-extrabold text-slate-900 tabular-nums mt-1">{data.sessions.active.toLocaleString('en-IN')}</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Active refresh sessions</p>
            </div>
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm sm:col-span-2">
              <div className="flex items-center justify-between">
                <p className="text-sm font-bold text-slate-900 flex items-center gap-2"><FileCheck2 className="w-4 h-4 text-[var(--primary)]" /> Audit Logging Status</p>
                {ok(data.auditLogging.status === 'active')}
              </div>
              <p className={cn(
                'text-xs mt-1',
                data.auditLogging.status === 'active' ? 'text-slate-500' : 'text-amber-700'
              )}>
                {data.auditLogging.status === 'active'
                  ? `Active · last event ${fmtDT(data.auditLogging.lastEventAt)} · ${data.auditLogging.totalEvents.toLocaleString('en-IN')} events`
                  : 'No audit events recorded yet.'}
              </p>
              <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5"><Activity className="w-3.5 h-3.5" /> Tamper-evident hash-chained log</p>
            </div>
          </div>
        ))}
    </AdminSectionShell>
  )
}
