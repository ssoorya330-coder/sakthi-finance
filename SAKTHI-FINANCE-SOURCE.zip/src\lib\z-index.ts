export const Z_INDEX = {
  content: 1,
  stickyTable: 10,
  stickyHeader: 20,
  topNav: 100,
  sidebar: 200,
  dropdown: 1000,
  calendar: 1100,
  modal: 2000,
  toast: 3000,
} as const

export type ZIndexKey = keyof typeof Z_INDEX
