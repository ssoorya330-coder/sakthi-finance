import {readFile,open,writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import yaml from 'js-yaml'

const base='https://strixg16.tailb58398.ts.net/'
const {version}=JSON.parse(await readFile('package.json','utf8'))
const filename=`SAKTHI FINANCE Setup ${version}.exe`
const expected=yaml.load(await readFile('release/electron/latest.yml','utf8'))
const response=await fetch(base+'latest.yml',{cache:'no-store',signal:AbortSignal.timeout(30000)})
if(!response.ok)throw Error(`Public metadata HTTP ${response.status}`)
const actual=yaml.load(await response.text())
if(JSON.stringify(actual)!==JSON.stringify(expected) || actual.version!==version || actual.path!==filename)throw Error('Public metadata differs from the current build')
const installerURL=base+encodeURIComponent(filename)
const head=await fetch(installerURL,{method:'HEAD',signal:AbortSignal.timeout(30000)})
if(!head.ok || Number(head.headers.get('content-length'))!==actual.files[0].size)throw Error('Public installer size/status mismatch')
const range=await fetch(installerURL,{headers:{Range:'bytes=0-65535'},signal:AbortSignal.timeout(30000)})
if(range.status!==206 || range.headers.get('content-range')!==`bytes 0-65535/${actual.files[0].size}`){await range.body?.cancel();throw Error('Public installer byte-range response invalid')}
const bytes=Buffer.from(await range.arrayBuffer())
const handle=await open('release/electron/'+filename)
let local
try{local=Buffer.alloc(65536);await handle.read(local,0,local.length,0)}finally{await handle.close()}
if(!bytes.equals(local))throw Error('Public installer content mismatch')
const block=await fetch(installerURL+'.blockmap',{signal:AbortSignal.timeout(30000)})
if(!block.ok)throw Error('Public blockmap unavailable')
const blockBytes=Buffer.from(await block.arrayBuffer())
if(!blockBytes.equals(await readFile('release/electron/'+filename+'.blockmap')))throw Error('Public blockmap differs from build')
const result={date:new Date().toISOString(),version,url:base,metadata:'PASS',installerHead:'PASS',installerSize:actual.files[0].size,installerRange:'PASS',rangeSha256:createHash('sha256').update(bytes).digest('hex'),blockmap:'PASS',metadataCacheControl:response.headers.get('cache-control'),fullInstallerDownload:'NOT TESTED: reserved for the installed baseline upgrade test'}
await writeFile('test-reports/FUNNEL_PUBLIC_UPDATE_TEST.json',JSON.stringify(result,null,2))
console.log(JSON.stringify(result))
