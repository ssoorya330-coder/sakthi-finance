import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { verifyCopiedDataDir } from '@/server/storage'

export const dynamic = 'force-dynamic'

/**
 * STEP 5 (verify) — Check the user-copied destination WITHOUT touching the
 * original: version marker, config files, base/, size comparison.
 *
 * Accepts the previously detected `source`/`sourceBytes`: while PostgreSQL
 * is stopped, SHOW data_directory is unavailable, so the source must come
 * from the caller (detected before the stop), not from a live SQL lookup.
 */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const destination = (body.destination || '').trim()
    if (!destination) return NextResponse.json({ error: 'Destination is required.' }, { status: 400 })
    const source = (body.source || '').trim() || null
    const sourceBytes =
      typeof body.sourceBytes === 'number' && body.sourceBytes > 0 ? body.sourceBytes : null
    const result = await verifyCopiedDataDir(destination, { sourceBytes, source })
    return NextResponse.json(result)
  } catch (err: any) {
    return NextResponse.json(
      { ok: false, error: 'Copy verification failed', details: err.message },
      { status: 500 }
    )
  }
}
