export interface InitStatus {
  database: boolean
  cache: boolean
  connection: boolean
  store: boolean
  session: boolean
}

export async function runInitialization(): Promise<InitStatus> {
  const status: InitStatus = {
    database: false,
    cache: false,
    connection: false,
    store: false,
    session: false,
  }

  const tasks: Promise<void>[] = []

  tasks.push(
    (async () => {
      try {
        if (typeof caches !== 'undefined') {
          await caches.keys()
          status.cache = true
        }
      } catch {
        status.cache = false
      }
    })()
  )

  tasks.push(
    (async () => {
      try {
        const envUrl =
          typeof process !== 'undefined'
            ? process.env.NEXT_PUBLIC_API_URL
            : null
        if (envUrl) {
          const controller = new AbortController()
          const timeout = setTimeout(() => controller.abort(), 3000)
          const res = await fetch(`${envUrl}/database/status`, {
            signal: controller.signal,
          })
          clearTimeout(timeout)
          if (res.ok) {
            const data = await res.json()
            status.database = data.connected === true
            status.connection = true
          }
        }
      } catch {
        status.connection = false
        status.database = false
      }
    })()
  )

  tasks.push(
    (async () => {
      try {
        const store = await import('@/store/auth-store')
        store.useAuthStore.getState()
        status.store = true
      } catch {
        status.store = false
      }
    })()
  )

  tasks.push(
    (async () => {
      try {
        const token = localStorage.getItem('sf_access_token')
        const user = localStorage.getItem('sf_user')
        status.session = !!(token && user)
      } catch {
        status.session = false
      }
    })()
  )

  await Promise.allSettled(tasks)

  return status
}
