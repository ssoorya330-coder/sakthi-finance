import { dbQuery } from './database';

/**
 * Financial audit over real business tables (customers / loans / payments).
 *
 * Financial Year = April–March (FY 2026–27 runs 2026-04-01 .. 2027-03-31).
 * All figures are scoped to the caller's own rows (user_id), consistent
 * with the rest of the application.
 *
 * Authoritative definitions (single calculation source for UI/Excel/CSV/PDF):
 * - Total Amount Given   = SUM(loan_amount) of FY loans (principal disbursed)
 * - Total Interest       = SUM(interest_amount) of FY loans (per loan terms;
 *                          the app always books total = principal + interest)
 * - Total Receivable     = Given + Interest
 * - Total Received       = SUM of FY payments (actual money in)
 * - Principal Recovered  = principal portion of FY payments (principal-first
 *                          allocation against lifetime loan history)
 * - Interest Received    = Received − PrincipalRecovered
 * - Outstanding          = point-in-time, per FY loan, from LIFETIME payments:
 *                          outPrincipal = max(loan − lifetimePrincipal, 0),
 *                          outInterest  = max(interest − lifetimeInterest, 0),
 *                          outTotal     = outPrincipal + outInterest
 *
 * Received always equals principal + interest, so every view reconciles.
 */

export interface FinancialYear {
  startYear: number;
  label: string;
  from: string; // inclusive ISO date
  to: string; // exclusive ISO date
}

export function fyOf(date: Date = new Date()): FinancialYear {
  const y = date.getFullYear();
  const startYear = date.getMonth() + 1 >= 4 ? y : y - 1;
  return fy(startYear);
}

export function fy(startYear: number): FinancialYear {
  const pad = (n: number) => String(n).padStart(4, '0');
  return {
    startYear,
    label: `${startYear}–${String((startYear + 1) % 100).padStart(2, '0')}`,
    from: `${pad(startYear)}-04-01`,
    to: `${pad(startYear + 1)}-04-01`,
  };
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function fyPeriodLabel(f: FinancialYear): string {
  const fmt = (iso: string) => {
    const [y, m, d] = iso.split('-').map(Number);
    return `${String(d).padStart(2, '0')}-${MONTHS[m - 1]}-${y}`;
  };
  const end = new Date(f.to);
  end.setDate(end.getDate() - 1);
  const endIso = end.toISOString().slice(0, 10);
  return `${fmt(f.from)} to ${fmt(endIso)}`;
}

/** FY options derived from actual data (loan/payment/customer dates). */
export async function availableFinancialYears(userId: string): Promise<FinancialYear[]> {
  const r = await dbQuery(
    `SELECT MIN(d) AS min_d, MAX(d) AS max_d FROM (
       SELECT loan_date::date AS d FROM loans WHERE user_id = $1 AND loan_date IS NOT NULL
       UNION ALL
       SELECT payment_date::date FROM payments WHERE user_id = $1 AND payment_date IS NOT NULL
       UNION ALL
       SELECT created_at::date FROM customers WHERE user_id = $1
     ) t`,
    [userId]
  );
  const isoDay = (v: any): string | null => {
    if (!v) return null;
    if (v instanceof Date) return v.toISOString().slice(0, 10);
    return String(v).slice(0, 10);
  };
  const minD = isoDay(r.rows[0]?.min_d);
  const maxD = isoDay(r.rows[0]?.max_d);
  if (!minD || !maxD) return [fyOf()];
  const toStartYear = (iso: string) => {
    const [y, m] = iso.split('-').map(Number);
    return m >= 4 ? y : y - 1;
  };
  const from = toStartYear(minD);
  const to = Math.max(toStartYear(maxD), fyOf().startYear);
  const out: FinancialYear[] = [];
  for (let y = from; y <= to; y += 1) out.push(fy(y));
  return out.reverse();
}

export interface OverallSummary {
  totalCustomers: number;
  activeCustomers: number;
  completedCustomers: number;
  totalLoans: number;
  activeLoans: number;
  completedLoans: number;
  totalGiven: number;
  totalInterest: number;
  totalReceivable: number;
  totalReceived: number;
  principalRecovered: number;
  interestReceived: number;
  outstandingPrincipal: number;
  outstandingInterest: number;
  outstanding: number;
}

/** A review item which must be resolved before relying on the FY report. */
export interface DataQualityCheck {
  key: string;
  label: string;
  severity: 'warning' | 'critical';
  count: number;
  amount: number;
  status: 'OK' | 'REVIEW';
  detail: string;
}

export interface CustomerSummaryRow {
  customerId: string;
  customerCode: string;
  customerName: string;
  phone: string | null;
  address: string | null;
  city: string | null;
  business: string | null;
  status: string;
  loans: number;
  given: number;
  interest: number;
  receivable: number;
  received: number;
  principal: number;
  interestReceived: number;
  outPrincipal: number;
  outInterest: number;
  outstanding: number;
  activeLoans: number;
  completedLoans: number;
  cashDisbursed: number;
  cashPayments: number;
  flaggedCount: number;
}

export interface LoanDetailRow {
  loanId: string;
  customerId: string;
  customerCode: string;
  customerName: string;
  loanDate: string | null;
  principal: number;
  interestRate: number;
  interest: number;
  receivable: number;
  frequency: string | null;
  installment: number;
  received: number;
  principalRecovered: number;
  interestReceived: number;
  outPrincipal: number;
  outInterest: number;
  outstanding: number;
  status: string;
  disbursalMode: string | null;
}

export interface LedgerRow {
  date: string | null;
  txnId: string;
  customerCode: string;
  customerName: string;
  loanId: string | null;
  paymentId: string | null;
  type: string;
  amount: number;
  principal: number;
  interest: number;
  prevOutstanding: number;
  balance: number;
  mode: string;
  performedBy: string | null;
  result: string;
  notes: string | null;
  reference: string | null;
}

/**
 * Cash-mode predicates shared with the cash-compliance reports.
 * Payments: explicit column, else legacy method, else Cash. Unknown loan
 * disbursal modes are NOT treated as cash (never invent history).
 */
export const CASH_PAYMENT_PRED =
  `UPPER(COALESCE(NULLIF(p.payment_mode, ''), p.payment_method, 'Cash')) = 'CASH'`;
export const CASH_DISBURSAL_PRED =
  `UPPER(COALESCE(NULLIF(l.disbursal_mode, ''), '')) = 'CASH'`;

/**
 * Per-payment principal portion as a scalar SQL expression over aliases
 * p (payments) and l (left-joined loans). Unlinked payments (no loan) count
 * fully as principal. Interest is always (amount − principal).
 */
export const SPLIT = `
  LEAST(p.amount, GREATEST(COALESCE(l.loan_amount, p.amount) - COALESCE((
    SELECT SUM(p2.amount) FROM payments p2
    WHERE p2.loan_id = p.loan_id AND p2.user_id = p.user_id
      AND (p2.payment_date < p.payment_date
        OR (p2.payment_date = p.payment_date AND p2.payment_id < p.payment_id))
  ), 0), 0))
`;

const num = (v: any): number => {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};

/**
 * Lifetime principal/interest recovered per loan (all payments ever, same
 * principal-first rule). Shared by every outstanding computation so all
 * levels agree.
 */
const LIFETIME_SPLIT = `
  lifetime_split AS (
    SELECT loan_id,
           SUM(princ) AS p_paid,
           SUM(amount) - SUM(princ) AS i_paid
    FROM (
      SELECT p.loan_id, p.amount,
        LEAST(p.amount, GREATEST(l.loan_amount - COALESCE(SUM(p.amount) OVER (
          PARTITION BY p.loan_id ORDER BY p.payment_date, p.payment_id
          ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING), 0), 0)) AS princ
      FROM payments p
      JOIN loans l ON l.loan_id = p.loan_id AND l.user_id = p.user_id
      WHERE p.user_id = $1 AND p.loan_id IS NOT NULL
    ) s
    GROUP BY loan_id
  )
`;

export async function overallSummary(userId: string, f: FinancialYear): Promise<OverallSummary> {
  const [cust, loans, pay, out] = await Promise.all([
    dbQuery(
      `SELECT COUNT(*) AS total,
              COUNT(*) FILTER (WHERE status = 'Active') AS active,
              COUNT(*) FILTER (WHERE status = 'Completed') AS completed
       FROM customers
       WHERE user_id = $1 AND created_at >= $2 AND created_at < $3`,
      [userId, f.from, f.to]
    ),
    dbQuery(
      `SELECT COUNT(*) AS total,
              COUNT(*) FILTER (WHERE status = 'Active') AS active,
              COUNT(*) FILTER (WHERE status = 'Completed') AS completed,
              COALESCE(SUM(loan_amount), 0) AS given,
              COALESCE(SUM(interest_amount), 0) AS interest
       FROM loans
       WHERE user_id = $1 AND loan_date >= $2 AND loan_date < $3`,
      [userId, f.from, f.to]
    ),
    dbQuery(
      `SELECT COALESCE(SUM(p.amount), 0) AS received,
              COALESCE(SUM(${SPLIT}), 0) AS principal
       FROM payments p
       LEFT JOIN loans l ON l.loan_id = p.loan_id AND l.user_id = p.user_id
       WHERE p.user_id = $1 AND p.payment_date >= $2 AND p.payment_date < $3`,
      [userId, f.from, f.to]
    ),
    dbQuery(
      `WITH ${LIFETIME_SPLIT}
       SELECT COALESCE(SUM(GREATEST(l.loan_amount - COALESCE(ls.p_paid, 0), 0)), 0) AS out_p,
              COALESCE(SUM(GREATEST(l.interest_amount - COALESCE(ls.i_paid, 0), 0)), 0) AS out_i
       FROM loans l
       LEFT JOIN lifetime_split ls ON ls.loan_id = l.loan_id
       WHERE l.user_id = $1 AND l.loan_date >= $2 AND l.loan_date < $3`,
      [userId, f.from, f.to]
    ),
  ]);
  const given = num(loans.rows[0]?.given);
  const interest = num(loans.rows[0]?.interest);
  const received = num(pay.rows[0]?.received);
  const principal = num((pay.rows[0] as any)?.principal);
  const outP = num(out.rows[0]?.out_p);
  const outI = num(out.rows[0]?.out_i);
  return {
    totalCustomers: Number(cust.rows[0]?.total) || 0,
    activeCustomers: Number(cust.rows[0]?.active) || 0,
    completedCustomers: Number(cust.rows[0]?.completed) || 0,
    totalLoans: Number(loans.rows[0]?.total) || 0,
    activeLoans: Number(loans.rows[0]?.active) || 0,
    completedLoans: Number(loans.rows[0]?.completed) || 0,
    totalGiven: given,
    totalInterest: interest,
    totalReceivable: given + interest,
    totalReceived: received,
    principalRecovered: principal,
    interestReceived: received - principal,
    outstandingPrincipal: outP,
    outstandingInterest: outI,
    outstanding: outP + outI,
  };
}

/**
 * Detect records that would make a financial-year report incomplete or
 * unsuitable for review. These checks do not alter financial data; they make
 * exceptions visible to the owner and in the exported audit workbook.
 */
export async function dataQualityChecks(userId: string, f: FinancialYear): Promise<DataQualityCheck[]> {
  const r = await dbQuery(
    `WITH checks AS (
       SELECT 'customers_without_loans' AS key, COUNT(*)::int AS count, 0::numeric AS amount
       FROM customers c
       WHERE c.user_id = $1 AND c.created_at >= $2 AND c.created_at < $3
         AND NOT EXISTS (SELECT 1 FROM loans l WHERE l.customer_id = c.id AND l.user_id = c.user_id)
       UNION ALL
       SELECT 'loans_missing_date', COUNT(*)::int, COALESCE(SUM(loan_amount), 0)
       FROM loans WHERE user_id = $1 AND loan_date IS NULL
       UNION ALL
       SELECT 'loan_total_mismatch', COUNT(*)::int, COALESCE(SUM(ABS(COALESCE(total_amount, 0) - (COALESCE(loan_amount, 0) + COALESCE(interest_amount, 0)))), 0)
       FROM loans
       WHERE user_id = $1 AND loan_date >= $2 AND loan_date < $3
         AND ABS(COALESCE(total_amount, 0) - (COALESCE(loan_amount, 0) + COALESCE(interest_amount, 0))) > 0.01
       UNION ALL
       SELECT 'invalid_payment_amount', COUNT(*)::int, COALESCE(SUM(amount), 0)
       FROM payments WHERE user_id = $1 AND payment_date >= $2 AND payment_date < $3 AND amount <= 0
       UNION ALL
       SELECT 'payments_without_loan', COUNT(*)::int, COALESCE(SUM(amount), 0)
       FROM payments WHERE user_id = $1 AND payment_date >= $2 AND payment_date < $3 AND loan_id IS NULL
       UNION ALL
       SELECT 'payment_link_mismatch', COUNT(*)::int, COALESCE(SUM(p.amount), 0)
       FROM payments p LEFT JOIN loans l ON l.loan_id = p.loan_id AND l.user_id = p.user_id
       WHERE p.user_id = $1 AND p.payment_date >= $2 AND p.payment_date < $3
         AND p.loan_id IS NOT NULL AND (l.loan_id IS NULL OR l.customer_id <> p.customer_id)
       UNION ALL
       SELECT 'overpaid_loans', COUNT(*)::int, COALESCE(SUM(paid - total_amount), 0)
       FROM (
         SELECT l.loan_id, l.total_amount, COALESCE(SUM(p.amount), 0) AS paid
         FROM loans l LEFT JOIN payments p ON p.loan_id = l.loan_id AND p.user_id = l.user_id
         WHERE l.user_id = $1 AND l.loan_date >= $2 AND l.loan_date < $3
         GROUP BY l.loan_id, l.total_amount
       ) x WHERE paid > total_amount + 0.01
     ) SELECT key, count, amount FROM checks`,
    [userId, f.from, f.to]
  );
  const definitions: Record<string, Omit<DataQualityCheck, 'key' | 'count' | 'amount' | 'status'>> = {
    customers_without_loans: { label: 'Customers without a loan record', severity: 'warning', detail: 'Customer records created in this FY that have no linked loan.' },
    loans_missing_date: { label: 'Loans missing disbursal date', severity: 'critical', detail: 'These loans cannot be assigned reliably to a financial year.' },
    loan_total_mismatch: { label: 'Loan total mismatch', severity: 'critical', detail: 'Loan total must equal principal plus interest.' },
    invalid_payment_amount: { label: 'Invalid payment amount', severity: 'critical', detail: 'Payments must be greater than zero.' },
    payments_without_loan: { label: 'Payments without a loan link', severity: 'warning', detail: 'These receipts are included in collections but need a loan reference for complete tracing.' },
    payment_link_mismatch: { label: 'Payment/customer link mismatch', severity: 'critical', detail: 'A payment is linked to a loan belonging to a different customer or account.' },
    overpaid_loans: { label: 'Overpaid loans', severity: 'warning', detail: 'Lifetime receipts exceed the loan total and require review or a correction entry.' },
  };
  return r.rows.map((row: any) => {
    const count = Number(row.count) || 0;
    const definition = definitions[row.key];
    return { key: row.key, ...definition, count, amount: num(row.amount), status: count === 0 ? 'OK' : 'REVIEW' };
  });
}

export async function customerSummary(userId: string, f: FinancialYear): Promise<CustomerSummaryRow[]> {
  const r = await dbQuery(
    `WITH fy_loans AS (
       SELECT * FROM loans WHERE user_id = $1 AND loan_date >= $2 AND loan_date < $3
     ),
     fy_payers AS (
       SELECT DISTINCT customer_id FROM payments WHERE user_id = $1 AND payment_date >= $2 AND payment_date < $3
     ),
     in_scope AS (
       SELECT c.id, c.customer_code, c.full_name, rb.name AS business,
              c.phone_number, c.address, rc.name AS city_name, c.status AS cust_status
       FROM customers c
       LEFT JOIN ref_business rb ON rb.id = c.business_id
       LEFT JOIN ref_city rc ON rc.id = c.city_id
       WHERE c.user_id = $1 AND (EXISTS (SELECT 1 FROM fy_loans l WHERE l.customer_id = c.id)
          OR c.id IN (SELECT customer_id FROM fy_payers))
     ),
     ${LIFETIME_SPLIT},
     fy_split AS (
       SELECT p.customer_id,
              SUM(p.amount) AS received,
              SUM(${SPLIT}) AS principal
       FROM payments p
       LEFT JOIN loans l ON l.loan_id = p.loan_id AND l.user_id = p.user_id
       WHERE p.user_id = $1 AND p.payment_date >= $2 AND p.payment_date < $3
       GROUP BY p.customer_id
     )
     SELECT s.id, s.customer_code, s.full_name, s.business,
            s.phone_number, s.address, s.city_name, s.cust_status,
            (SELECT COUNT(*) FROM fy_loans l WHERE l.customer_id = s.id) AS loans,
            COALESCE((SELECT SUM(loan_amount) FROM fy_loans l WHERE l.customer_id = s.id), 0) AS given,
            COALESCE((SELECT SUM(interest_amount) FROM fy_loans l WHERE l.customer_id = s.id), 0) AS interest,
            COALESCE(fs.received, 0) AS received,
            COALESCE(fs.principal, 0) AS principal,
            COALESCE((
              SELECT SUM(GREATEST(l.loan_amount - COALESCE(ls.p_paid, 0), 0))
              FROM fy_loans l LEFT JOIN lifetime_split ls ON ls.loan_id = l.loan_id
              WHERE l.customer_id = s.id
            ), 0) AS out_p,
            COALESCE((
              SELECT SUM(GREATEST(l.interest_amount - COALESCE(ls.i_paid, 0), 0))
              FROM fy_loans l LEFT JOIN lifetime_split ls ON ls.loan_id = l.loan_id
              WHERE l.customer_id = s.id
            ), 0) AS out_i,
            (SELECT COUNT(*) FROM fy_loans l WHERE l.customer_id = s.id AND l.status = 'Active') AS active_loans,
            (SELECT COUNT(*) FROM fy_loans l WHERE l.customer_id = s.id AND l.status = 'Completed') AS completed_loans,
            COALESCE((
              SELECT SUM(l.loan_amount) FROM fy_loans l
              WHERE l.customer_id = s.id AND UPPER(COALESCE(NULLIF(l.disbursal_mode, ''), '')) = 'CASH'
            ), 0) AS cash_disbursed,
            COALESCE((
              SELECT SUM(p.amount) FROM payments p
              WHERE p.user_id = $1 AND p.customer_id = s.id
                AND p.payment_date >= $2 AND p.payment_date < $3
                AND UPPER(COALESCE(NULLIF(p.payment_mode, ''), p.payment_method, 'Cash')) = 'CASH'
            ), 0) AS cash_payments,
            COALESCE((
              SELECT COUNT(*) FROM fy_loans l WHERE l.customer_id = s.id AND l.is_flagged = true
            ), 0) + COALESCE((
              SELECT COUNT(*) FROM payments p
              WHERE p.user_id = $1 AND p.customer_id = s.id
                AND p.payment_date >= $2 AND p.payment_date < $3 AND p.is_flagged = true
            ), 0) AS flagged_count
     FROM in_scope s
     LEFT JOIN fy_split fs ON fs.customer_id = s.id
     ORDER BY s.customer_code ASC`,
    [userId, f.from, f.to]
  );
  return r.rows.map((x: any) => {
    const given = num(x.given);
    const interest = num(x.interest);
    const received = num(x.received);
    const principal = num(x.principal);
    const outP = num(x.out_p);
    const outI = num(x.out_i);
    return {
      customerId: String(x.id),
      customerCode: x.customer_code || '',
      customerName: x.full_name || '',
      phone: x.phone_number || null,
      address: x.address || null,
      city: x.city_name || null,
      business: x.business || null,
      status: x.cust_status || '',
      loans: Number(x.loans) || 0,
      given,
      interest,
      receivable: given + interest,
      received,
      principal,
      interestReceived: received - principal,
      outPrincipal: outP,
      outInterest: outI,
      outstanding: outP + outI,
      activeLoans: Number(x.active_loans) || 0,
      completedLoans: Number(x.completed_loans) || 0,
      cashDisbursed: num(x.cash_disbursed),
      cashPayments: num(x.cash_payments),
      flaggedCount: Number(x.flagged_count) || 0,
    };
  });
}

export async function loanDetails(userId: string, f: FinancialYear): Promise<LoanDetailRow[]> {
  const r = await dbQuery(
    `WITH fy_loans AS (
       SELECT * FROM loans WHERE user_id = $1 AND loan_date >= $2 AND loan_date < $3
     ),
     ${LIFETIME_SPLIT},
     fy_split AS (
       SELECT p.loan_id, SUM(p.amount) AS received,
              SUM(${SPLIT}) AS principal
       FROM payments p
       LEFT JOIN loans l ON l.loan_id = p.loan_id AND l.user_id = p.user_id
       WHERE p.user_id = $1 AND p.payment_date >= $2 AND p.payment_date < $3
       GROUP BY p.loan_id
     )
     SELECT l.loan_id, l.customer_id, c.customer_code, c.full_name,
            l.loan_date, l.loan_amount, l.interest_rate, l.interest_amount,
            l.loan_type, l.installment_amount, l.status, l.disbursal_mode,
            COALESCE(fs.received, 0) AS received,
            COALESCE(fs.principal, 0) AS principal,
            GREATEST(l.loan_amount - COALESCE(ls.p_paid, 0), 0) AS out_p,
            GREATEST(l.interest_amount - COALESCE(ls.i_paid, 0), 0) AS out_i
     FROM fy_loans l
     JOIN customers c ON c.id = l.customer_id AND c.user_id = l.user_id
     LEFT JOIN fy_split fs ON fs.loan_id = l.loan_id
     LEFT JOIN lifetime_split ls ON ls.loan_id = l.loan_id
     ORDER BY l.loan_date ASC, c.customer_code ASC`,
    [userId, f.from, f.to]
  );
  const isoDay = (v: any): string | null => {
    if (!v) return null;
    if (v instanceof Date) return v.toISOString().slice(0, 10);
    return String(v).slice(0, 10);
  };
  return r.rows.map((x: any) => {
    const principal = num(x.loan_amount);
    const interest = num(x.interest_amount);
    const received = num(x.received);
    const princRec = num(x.principal);
    const outP = num(x.out_p);
    const outI = num(x.out_i);
    return {
      loanId: String(x.loan_id),
      customerId: String(x.customer_id),
      customerCode: x.customer_code || '',
      customerName: x.full_name || '',
      loanDate: isoDay(x.loan_date),
      principal,
      interestRate: num(x.interest_rate),
      interest,
      receivable: principal + interest,
      frequency: x.loan_type || null,
      installment: num(x.installment_amount),
      received,
      principalRecovered: princRec,
      interestReceived: received - princRec,
      outPrincipal: outP,
      outInterest: outI,
      outstanding: outP + outI,
      status: x.status || '',
      disbursalMode: x.disbursal_mode || null,
    };
  });
}

export async function transactionLedger(
  userId: string,
  f: FinancialYear,
  page: number,
  limit: number
): Promise<{ rows: LedgerRow[]; total: number }> {
  const params: any[] = [userId, f.from, f.to];
  const base = `
    FROM (
      SELECT l.loan_date::date AS dt, l.loan_id AS txn_id,
             c.customer_code, c.full_name AS customer_name, l.loan_id,
             CAST(NULL AS TEXT) AS payment_id,
             'Loan Disbursal' AS txn_type, l.loan_amount AS amount,
             l.loan_amount AS principal, l.interest_amount AS interest,
             0::numeric AS prev_out, l.total_amount AS balance,
             COALESCE(NULLIF(l.disbursal_mode, ''), 'Unknown') AS mode,
             COALESCE(u.full_name, u.email, '') AS performed_by,
             'SUCCESS' AS result, l.notes AS notes,
             l.loan_type AS reference,
             l.loan_date AS sort_key, 0 AS seq, l.created_at AS created_sort
      FROM loans l
      JOIN customers c ON c.id = l.customer_id AND c.user_id = l.user_id
      LEFT JOIN users u ON u.user_id = l.user_id
      WHERE l.user_id = $1 AND l.loan_date >= $2 AND l.loan_date < $3
      UNION ALL
      SELECT p.payment_date::date, p.payment_id, c.customer_code, c.full_name, p.loan_id,
             p.payment_id::text AS payment_id,
             'Payment' AS txn_type, p.amount, s.principal_part, s.interest_part,
             (COALESCE(l.total_amount, p.amount) - s.cum_before) AS prev_out,
             (COALESCE(l.total_amount, p.amount) - (s.cum_before + p.amount)) AS balance,
             COALESCE(NULLIF(p.payment_mode, ''), p.payment_method, 'Cash') AS mode,
             COALESCE(u.full_name, u.email, '') AS performed_by,
             'SUCCESS' AS result, p.remarks AS notes,
             p.payment_method, p.payment_date, 1, p.created_at
      FROM payments p
      JOIN customers c ON c.id = p.customer_id AND c.user_id = p.user_id
      LEFT JOIN loans l ON l.loan_id = p.loan_id AND l.user_id = p.user_id
      LEFT JOIN users u ON u.user_id = p.user_id
      LEFT JOIN LATERAL (
        SELECT cb AS cum_before,
               LEAST(p.amount, GREATEST(COALESCE(l.loan_amount, p.amount) - cb, 0)) AS principal_part,
               (p.amount - LEAST(p.amount, GREATEST(COALESCE(l.loan_amount, p.amount) - cb, 0))) AS interest_part
        FROM (
          SELECT COALESCE((
            SELECT SUM(p2.amount) FROM payments p2
            WHERE p2.loan_id = p.loan_id AND p2.user_id = p.user_id
              AND (p2.payment_date < p.payment_date
                OR (p2.payment_date = p.payment_date AND p2.payment_id < p.payment_id))
          ), 0) AS cb
        ) q
      ) s ON true
      WHERE p.user_id = $1 AND p.payment_date >= $2 AND p.payment_date < $3
      UNION ALL
      SELECT l.completed_at::date, l.loan_id, c.customer_code, c.full_name, l.loan_id,
             CAST(NULL AS TEXT) AS payment_id,
             'Loan Completed', l.total_amount, l.loan_amount, l.interest_amount,
             0::numeric, 0::numeric,
             COALESCE(NULLIF(l.disbursal_mode, ''), 'Unknown'),
             COALESCE(u.full_name, u.email, '') AS performed_by,
             'SUCCESS' AS result, CAST(NULL AS TEXT) AS notes,
             l.loan_type, l.completed_at, 2, l.updated_at
      FROM loans l
      JOIN customers c ON c.id = l.customer_id AND c.user_id = l.user_id
      LEFT JOIN users u ON u.user_id = l.user_id
      WHERE l.user_id = $1 AND l.status = 'Completed'
        AND l.completed_at >= $2 AND l.completed_at < $3
    ) t
  `;
  const count = await dbQuery(`SELECT COUNT(*) AS c ${base}`, params);
  const total = Number(count.rows[0]?.c) || 0;
  const offset = (Math.max(page, 1) - 1) * limit;
  const rows = await dbQuery(
    `SELECT dt AS date, txn_id, customer_code, customer_name, loan_id, payment_id, txn_type,
            amount, principal, interest, prev_out, balance, mode, performed_by, result, notes, reference
     ${base}
     ORDER BY sort_key ASC, seq ASC, created_sort ASC, txn_id ASC
     LIMIT $4 OFFSET $5`,
    [...params, limit, offset]
  );
  const isoDay = (v: any): string | null => {
    if (!v) return null;
    if (v instanceof Date) return v.toISOString().slice(0, 10);
    return String(v).slice(0, 10);
  };
  return {
    rows: rows.rows.map((r: any) => ({
      date: isoDay(r.date),
      txnId: String(r.txn_id),
      customerCode: r.customer_code || '',
      customerName: r.customer_name || '',
      loanId: r.loan_id ? String(r.loan_id) : null,
      paymentId: r.payment_id ? String(r.payment_id) : null,
      type: r.txn_type,
      amount: num(r.amount),
      principal: num(r.principal),
      interest: num(r.interest),
      prevOutstanding: num(r.prev_out),
      balance: num(r.balance),
      mode: r.mode || '',
      performedBy: r.performed_by || null,
      result: r.result || 'SUCCESS',
      notes: r.notes || null,
      reference: r.reference || null,
    })),
    total,
  };
}

export interface ReconciliationCheck {
  name: string;
  levels: { overall: number; customer: number; loans: number; ledger: number | null };
  ok: boolean;
  difference: number;
}

/**
 * Four-level reconciliation: Overall = Customer sums = Loan sums =
 * Ledger sums (ledger carries no outstanding figures).
 */
export function reconcile(
  overall: OverallSummary,
  customers: CustomerSummaryRow[],
  loans: LoanDetailRow[],
  ledger: LedgerRow[]
): { ok: boolean; checks: ReconciliationCheck[] } {
  const sum = (rows: any[], k: string) => rows.reduce((a, r) => a + (Number(r[k]) || 0), 0);
  const ledGiven = ledger.filter((r) => r.type === 'Loan Disbursal');
  const ledPay = ledger.filter((r) => r.type === 'Payment');
  const s = (a: number) => (Number.isFinite(a) ? a : 0);
  const defs: Array<{ name: string; overall: number; customer: number; loans: number; ledger: number | null }> = [
    {
      name: 'Total Amount Given',
      overall: overall.totalGiven,
      customer: s(sum(customers, 'given')),
      loans: s(sum(loans, 'principal')),
      ledger: s(ledGiven.reduce((a, r) => a + r.amount, 0)),
    },
    {
      name: 'Total Interest Amount',
      overall: overall.totalInterest,
      customer: s(sum(customers, 'interest')),
      loans: s(sum(loans, 'interest')),
      ledger: s(ledGiven.reduce((a, r) => a + r.interest, 0)),
    },
    {
      name: 'Total Amount Received',
      overall: overall.totalReceived,
      customer: s(sum(customers, 'received')),
      loans: s(sum(loans, 'received')),
      ledger: s(ledPay.reduce((a, r) => a + r.amount, 0)),
    },
    {
      name: 'Principal Recovered',
      overall: overall.principalRecovered,
      customer: s(sum(customers, 'principal')),
      loans: s(sum(loans, 'principalRecovered')),
      ledger: s(ledPay.reduce((a, r) => a + r.principal, 0)),
    },
    {
      name: 'Interest Received',
      overall: overall.interestReceived,
      customer: s(sum(customers, 'interestReceived')),
      loans: s(sum(loans, 'interestReceived')),
      ledger: s(ledPay.reduce((a, r) => a + r.interest, 0)),
    },
    {
      name: 'Outstanding Principal',
      overall: overall.outstandingPrincipal,
      customer: s(sum(customers, 'outPrincipal')),
      loans: s(sum(loans, 'outPrincipal')),
      ledger: null,
    },
    {
      name: 'Outstanding Interest',
      overall: overall.outstandingInterest,
      customer: s(sum(customers, 'outInterest')),
      loans: s(sum(loans, 'outInterest')),
      ledger: null,
    },
    {
      name: 'Total Outstanding',
      overall: overall.outstanding,
      customer: s(sum(customers, 'outstanding')),
      loans: s(sum(loans, 'outstanding')),
      ledger: null,
    },
  ];
  const checks: ReconciliationCheck[] = defs.map((d) => {
    const vals = [d.overall, d.customer, d.loans, ...(d.ledger === null ? [] : [d.ledger])];
    const max = Math.max(...vals);
    const min = Math.min(...vals);
    const agreed = max - min < 0.01;
    return {
      name: d.name,
      levels: { overall: d.overall, customer: d.customer, loans: d.loans, ledger: d.ledger },
      ok: agreed,
      // Spec: Difference = Summary − Ledger (signed); no ledger level → —.
      difference: d.ledger === null ? 0 : d.overall - d.ledger,
    };
  });
  return { ok: checks.every((c) => c.ok), checks };
}
