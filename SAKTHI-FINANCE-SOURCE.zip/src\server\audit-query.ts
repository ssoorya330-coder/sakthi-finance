/**
 * Shared server-side filtering/sorting for audit_events list + export.
 * Keeps list and export results identical for the same filters.
 */

export interface AuditListFilters {
  dateFrom?: string | null;
  dateTo?: string | null;
  customerId?: string | null;
  action?: string | null;
  entityType?: string | null;
  performedBy?: string | null;
  result?: string | null;
  search?: string | null;
  sort?: string | null;
  dir?: string | null;
}

export const AUDIT_CUSTOMER_CODE = `COALESCE(
  (SELECT c.customer_code FROM customers c WHERE c.id::text = audit_events.customer_id),
  (SELECT m.customer_code FROM customer_id_mappings m WHERE m.legacy_id::text = audit_events.customer_id),
  CASE WHEN audit_events.entity_type = 'customer' THEN
    COALESCE(audit_events.after_data->>'customer_code', audit_events.before_data->>'customer_code') END
)`;

export const AUDIT_CURRENT_CUSTOMER_ID = `COALESCE(
  (SELECT m.customer_id::text FROM customer_id_mappings m WHERE m.legacy_id::text = audit_events.customer_id),
  audit_events.customer_id
)`;

export const AUDIT_COLUMNS = `
  seq, audit_id, created_at, action, entity_type, entity_id,
  customer_id, loan_id, payment_id, performed_by, user_id, user_role,
  ip_address, client_info, source, reason, result, changes,
  before_data, after_data, prev_hash, event_hash, ${AUDIT_CUSTOMER_CODE} AS customer_code
`;

export function buildAuditWhere(f: AuditListFilters, params: any[], startIdx: number): { clause: string; nextIdx: number } {
  let clause = '';
  let i = startIdx;
  const and = (sql: string, val: any) => {
    clause += ` AND ${sql}`;
    params.push(val);
    i += 1;
  };
  if (f.dateFrom) and(`created_at >= $${i}`, new Date(f.dateFrom));
  if (f.dateTo) {
    const end = new Date(f.dateTo);
    // Inclusive whole day when only a date part was supplied.
    if (/^\d{4}-\d{2}-\d{2}$/.test(f.dateTo)) end.setDate(end.getDate() + 1);
    and(`created_at < $${i}`, end);
  }
  if (f.customerId) and(`(customer_id = $${i} OR ${AUDIT_CURRENT_CUSTOMER_ID} = $${i} OR ${AUDIT_CUSTOMER_CODE} = LPAD($${i}, GREATEST(3, LENGTH($${i})), '0'))`, f.customerId);
  if (f.action) and(`action = $${i}`, f.action);
  if (f.entityType) and(`entity_type = $${i}`, f.entityType);
  if (f.result) and(`result = $${i}`, f.result);
  if (f.performedBy) and(`(performed_by ILIKE $${i} OR user_id ILIKE $${i})`, `%${f.performedBy}%`);
  if (f.search) {
    clause += ` AND (audit_id ILIKE $${i} OR action ILIKE $${i} OR entity_type ILIKE $${i} OR entity_id ILIKE $${i} OR customer_id ILIKE $${i} OR performed_by ILIKE $${i} OR reason ILIKE $${i})`;
    params.push(`%${f.search}%`);
    i += 1;
  }
  return { clause, nextIdx: i };
}

const SORTABLE: Record<string, string> = {
  created_at: 'created_at',
  audit_id: 'audit_id',
  action: 'action',
  entity_type: 'entity_type',
  performed_by: 'performed_by',
  result: 'result',
};

export function auditOrderBy(sort?: string | null, dir?: string | null): string {
  const col = (sort && SORTABLE[sort]) || 'created_at';
  const direction = dir && dir.toLowerCase() === 'asc' ? 'ASC' : 'DESC';
  return `ORDER BY ${col} ${direction}, seq ${direction}`;
}

export function readFilters(searchParams: URLSearchParams): AuditListFilters {
  const pick = (k: string) => searchParams.get(k) || null;
  return {
    dateFrom: pick('dateFrom'),
    dateTo: pick('dateTo'),
    customerId: pick('customerId'),
    action: pick('action'),
    entityType: pick('entityType'),
    performedBy: pick('performedBy'),
    result: pick('result'),
    search: pick('search'),
    sort: pick('sort'),
    dir: pick('dir'),
  };
}
