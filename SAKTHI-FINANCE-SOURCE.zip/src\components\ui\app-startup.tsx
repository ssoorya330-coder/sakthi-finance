'use client'

import { useEffect, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { useAuthStore } from '@/store/auth-store'
import { useCustomerStore } from '@/store/customer-store'
import AppLoading from './app-loading'

/** One splash per application load; client-side navigation does not restart it. */
export default function AppStartup({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false)
  const [finished, setFinished] = useState(false)
  const [completed, setCompleted] = useState(false)
  const [progress, setProgress] = useState(0)
  const isLoading = useAuthStore(state => state.isLoading)
  const authenticated = useAuthStore(state => state.isAuthenticated)
  const dataLoading = useCustomerStore(state => state.loading)
  const startupBusy = isLoading || (authenticated && dataLoading)
  const reducedMotion = useReducedMotion()
  const showSplash = !completed && !finished
  useEffect(() => {
    if (ready || finished) return
    const started = performance.now()
    const timer = window.setInterval(() => {
      setProgress(Math.min(90, ((performance.now() - started) / 2700) * 90))
    }, 50)
    return () => window.clearInterval(timer)
  }, [ready, finished])
  useEffect(() => {
    if (!ready || startupBusy || finished) return
    setProgress(100)
    // Fallback for browsers that suppress transition events; normal exit is
    // triggered by the bar finishing its own transition.
    const timer = window.setTimeout(() => setCompleted(true), reducedMotion ? 0 : 800)
    return () => window.clearTimeout(timer)
  }, [ready, startupBusy, finished, reducedMotion])
  useEffect(() => {
    // Allow the shorter logo and sketch cycle to finish before fading.
    // Reduced-motion users do not need to wait for decorative animation.
    const timer = window.setTimeout(() => setReady(true), reducedMotion ? 0 : 2700)
    return () => window.clearTimeout(timer)
  }, [reducedMotion])
  return <>
    <div inert={!finished} aria-hidden={!finished || undefined}>{children}</div>
    <AnimatePresence onExitComplete={() => setFinished(true)}>
      {showSplash && <motion.div key="startup-splash" initial={false} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: reducedMotion ? 0 : 0.4, ease: [0.22, 1, 0.36, 1] }} className="fixed inset-0 z-[9999] overflow-y-auto bg-[#faf8ed]">
        <AppLoading fullScreen progress={progress} onProgressComplete={() => { if (ready && !startupBusy) setCompleted(true) }} />
      </motion.div>}
    </AnimatePresence>
  </>
}
