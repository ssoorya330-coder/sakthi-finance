import axios from 'axios';
import { useDesktopAdapter } from '@/lib/desktop/axios-adapter';

const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 1500;

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || '',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Cache for the token
let cachedToken: string | null = null;

// Function to get token from our exchange endpoint
async function getTokenForBackend(): Promise<string | null> {
  if (cachedToken) {
    return cachedToken;
  }

  try {
    // Use relative URL to avoid hardcoding domain
    const response = await axios.get('/api/auth/exchange-token');
    const { token } = response.data;
    cachedToken = token;
    return token;
  } catch (error) {
    console.error('Failed to get token for backend:', error);
    return null;
  }
}

api.interceptors.request.use(async (config) => {
  if (typeof window !== 'undefined' && window.sakthi) return useDesktopAdapter(config);
  // Skip if the request is to our own exchange token endpoint to avoid infinite loop
  if (config.url?.includes('/api/auth/exchange-token')) {
    return config;
  }

  if (typeof window !== 'undefined') {
    const token = await getTokenForBackend();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }

  return config;
});

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // If we get a 401 and we haven't retried yet, try to refresh the token
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      // Clear the cached token so we fetch a new one
      cachedToken = null;

      // Try to get a new token and retry the original request
      const token = await getTokenForBackend();
      if (token) {
        originalRequest.headers.Authorization = `Bearer ${token}`;
        return api(originalRequest);
      }
    }

    const status = error.response?.status;
    const isRetryable = ['get', 'head'].includes(originalRequest?.method || 'get') && (!status || (status >= 500 && status < 600));
    if (isRetryable && !originalRequest._retryCount) {
      originalRequest._retryCount = originalRequest._retryCount || 0;
    }
    if (isRetryable && originalRequest._retryCount < MAX_RETRIES) {
      originalRequest._retryCount += 1;
      const attempt = originalRequest._retryCount;
      console.warn(
        `[API] Request failed (${status || 'network error'}), retrying (${attempt}/${MAX_RETRIES})...`,
        originalRequest.url
      );
      await new Promise((r) => setTimeout(r, RETRY_DELAY_MS * attempt));
      return api(originalRequest);
    }

    // Clear local auth state on 401 (no login page to redirect to)
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const authKeys = ['sf-auth', 'sf-sync', 'sf-sidebar', 'sf-toast', 'sf_access_token', 'sf_refresh_token', 'sf_user', 'sf_active_user_id'];
        authKeys.forEach((k) => {
          try { localStorage.removeItem(k) } catch {}
          try { sessionStorage.removeItem(k) } catch {}
        });
      } catch {}
    }

    return Promise.reject(error);
  }
);

export default api;
