import type { Customer, PaymentRecord } from '@/types/customer.types'
import { formatCustomerCode } from '@/utils/customer-id'

const escapeHtml = (value: unknown) => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]!)
const csvCell = (value: unknown) => {
  let text = String(value ?? '')
  // Customer-provided text must not become an Excel formula.
  if (/^[\s]*[=+@-]/.test(text)) text = `'${text}`
  return `"${text.replace(/"/g, '""')}"`
}
const headers = ['S.No', 'Customer ID', 'Customer Name', 'Receipt ID', 'Payment Date', 'Amount Paid', 'Payment Method', 'Collected By', 'Remaining Balance', 'Remarks']

function dateLabel(value: string) {
  const match = value.match(/^(\d{4})-(\d{2})-(\d{2})/)
  return match ? `${match[3]}-${match[2]}-${match[1]}` : value
}

function reportRows(customer: Customer, payments: PaymentRecord[]) {
  return payments.map((payment, index) => [index + 1, formatCustomerCode(customer.customerCode), customer.fullName, payment.id, dateLabel(payment.paymentDate), payment.paymentAmount, payment.paymentMethod, payment.collectedBy, payment.remainingBalance, payment.remarks])
}

export function customerPaymentCsv(customer: Customer, payments: PaymentRecord[]): string {
  const rows = [
    ['SAKTHI FINANCE - Payment History'],
    ['Customer ID', formatCustomerCode(customer.customerCode)],
    ['Customer Name', customer.fullName],
    ['Currency', 'INR'],
    [], headers, ...reportRows(customer, payments),
  ]
  return '\uFEFF' + rows.map(row => row.map(csvCell).join(',')).join('\r\n')
}

/** A standalone report avoids printing the clipped, paginated app drawer. */
export function customerPaymentPrintHtml(customer: Customer, payments: PaymentRecord[], options: { includeReceiptId?: boolean } = {}): string {
  const id = escapeHtml(formatCustomerCode(customer.customerCode))
  const name = escapeHtml(customer.fullName)
  const reportHeaders = headers.filter((_, index) => options.includeReceiptId !== false || index !== 3)
  const rows = reportRows(customer, payments).map(row => `<tr>${row.filter((_, index) => options.includeReceiptId !== false || index !== 3).map(cell => `<td>${escapeHtml(cell)}</td>`).join('')}</tr>`).join('')
  return `<!doctype html><html><head><meta charset="utf-8"><title>Payment History - ${id} - ${name}</title>
    <style>
      @page { size: A4 landscape; margin: 12mm; }
      body { font-family: Arial, sans-serif; color: #172033; margin: 24px; }
      h1 { font-size: 20px; color: #7f1d1d; margin: 0 0 8px; }
      p { margin: 5px 0; font-size: 12px; }
      table { border-collapse: collapse; width: 100%; font-size: 10px; }
      thead { display: table-header-group; }
      th, td { border: 1px solid #dce0e5; padding: 7px; text-align: left; overflow-wrap: anywhere; }
      th { background: #f9eeee; }
      .identity { border: 0; padding: 0 0 16px; background: white; }
      tr { break-inside: avoid; }
      .toolbar { margin-bottom: 20px; font-size: 13px; }
      @media print { body { margin: 0; } .toolbar { display: none; } }
    </style></head><body>
      <p class="toolbar">Use the print dialog to print this report or select Save as PDF. All filtered payment records are included.</p>
      <table><thead><tr><th class="identity" colspan="${reportHeaders.length}">
        <h1>SAKTHI FINANCE · Payment History</h1>
        <p>Customer ID: ${id}</p><p>Customer Name: ${name}</p>
        <p>Mobile: ${escapeHtml(customer.mobileNumber)} · Records: ${payments.length} · Currency: INR</p>
      </th></tr><tr>${reportHeaders.map(header => `<th>${header}</th>`).join('')}</tr></thead>
      <tbody>${rows || `<tr><td colspan="${reportHeaders.length}">No payments match the selected filters.</td></tr>`}</tbody></table>
    </body></html>`
}
