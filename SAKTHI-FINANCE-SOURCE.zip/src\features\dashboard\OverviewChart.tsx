'use client'

import { motion } from 'framer-motion'
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts'
const overviewData: { month: string; amountGiven: number; amountCollected: number; interest: number }[] = []

const CustomTooltip = ({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: Array<{ value: number; name: string; color: string }>
  label?: string
}) => {
  if (!active || !payload) return null
  return (
    <div className="bg-white rounded-xl border border-slate-100 shadow-lg p-3 min-w-[180px]">
      <p className="text-xs font-semibold text-slate-900 mb-2">{label}</p>
      {payload.map((entry, i) => (
        <div key={i} className="flex items-center justify-between gap-4 py-0.5">
          <div className="flex items-center gap-2">
            <span
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-xs text-slate-500">{entry.name}</span>
          </div>
          <span className="text-xs font-semibold text-slate-700">
            ₹{(entry.value / 100000).toFixed(1)}L
          </span>
        </div>
      ))}
    </div>
  )
}

export default function OverviewChart() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="relative bg-white/70 backdrop-blur-xl rounded-[20px] border border-white/20 p-6 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] overflow-hidden"
    >
      <div className="absolute inset-0 sf-pattern-dots opacity-40 pointer-events-none" />
      <div className="flex items-center justify-between mb-6 relative">
        <div>
          <h3 className="text-lg font-bold text-slate-900">Loan & Collection Overview</h3>
          <p className="text-sm text-slate-500 mt-0.5">Monthly financial performance</p>
        </div>
        <div className="flex gap-2">
          {['6M', '1Y', 'All'].map((period) => (
            <button
              key={period}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                period === '6M'
                  ? 'bg-[var(--primary-soft)] text-[var(--primary)] border border-[var(--primary)]/20'
                  : 'text-slate-500 hover:bg-slate-50'
              }`}
            >
              {period}
            </button>
          ))}
        </div>
      </div>

      <div className="h-[288px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={overviewData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="colorGiven" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.15} />
                <stop offset="95%" stopColor="var(--primary)" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="colorCollected" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--secondary)" stopOpacity={0.15} />
                <stop offset="95%" stopColor="var(--secondary)" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="colorInterest" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--primary-hover)" stopOpacity={0.15} />
                <stop offset="95%" stopColor="var(--primary-hover)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
            <XAxis
              dataKey="month"
              axisLine={false}
              tickLine={false}
              tick={{ fill: '#94A3B8', fontSize: 12 }}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fill: '#94A3B8', fontSize: 12 }}
              tickFormatter={(v: number) => `${(v / 100000).toFixed(0)}L`}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend
              verticalAlign="top"
              height={36}
              iconType="circle"
              iconSize={8}
              formatter={(value: string) => (
                <span className="text-xs text-slate-600 ml-1">{value}</span>
              )}
            />
            <Area
              type="monotone"
              dataKey="amountGiven"
              name="Amount Given"
              stroke="var(--primary)"
              strokeWidth={2.5}
              fill="url(#colorGiven)"
              dot={false}
              activeDot={{ r: 5, strokeWidth: 2, stroke: '#fff' }}
            />
            <Area
              type="monotone"
              dataKey="amountCollected"
              name="Amount Collected"
              stroke="var(--secondary)"
              strokeWidth={2.5}
              fill="url(#colorCollected)"
              dot={false}
              activeDot={{ r: 5, strokeWidth: 2, stroke: '#fff' }}
            />
            <Area
              type="monotone"
              dataKey="interest"
              name="Interest"
              stroke="var(--primary-hover)"
              strokeWidth={2.5}
              fill="url(#colorInterest)"
              dot={false}
              activeDot={{ r: 5, strokeWidth: 2, stroke: '#fff' }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  )
}
