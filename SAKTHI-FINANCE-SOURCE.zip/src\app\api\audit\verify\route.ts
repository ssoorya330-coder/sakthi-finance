import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { verifyAuditChain } from '@/server/audit'

export const dynamic = 'force-dynamic'

/**
 * Authorized audit-integrity verification: recomputes the hash chain.
 * Tamper-EVIDENT (detects modification/deletion); no claim of
 * immutability against a database superuser.
 */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('audit:read')
  if (auth.error) return auth.error

  try {
    const body = await request.json().catch(() => ({}))
    const maxEvents =
      typeof body.maxEvents === 'number' && body.maxEvents > 0
        ? Math.min(Math.floor(body.maxEvents), 200000)
        : 200000
    const result = await verifyAuditChain({ maxEvents })
    return NextResponse.json({ ...result, verifiedAt: new Date().toISOString() })
  } catch (err: any) {
    return NextResponse.json({ error: 'Integrity verification failed', details: err.message }, { status: 500 })
  }
}
