import { NextRequest, NextResponse } from 'next/server'
import { dbQuery } from '@/server/database'
import { requireAuthWithPermission } from '@/lib/api-utils'

export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('customers:read');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const userId = user.userId
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const search = searchParams.get('search')
    const page = parseInt(searchParams.get('page') || '1', 10)
    const limit = parseInt(searchParams.get('limit') || '50', 10)
    const offset = (page - 1) * limit

    const effectiveStatus = `CASE WHEN c.status = 'Aborted' THEN c.status WHEN totals.all_paid THEN 'Completed' WHEN c.status = 'Completed' AND totals.has_balance THEN 'Active' ELSE c.status END`
    const selectCols = `
      c.id, c.customer_code, c.full_name, c.phone_number, c.alternate_phone,
      c.address, c.area_id, c.city_id, c.business_id, c.income, ${effectiveStatus} AS status,
      c.user_id, c.created_at, c.updated_at,
      ra.name AS area_name, rc.name AS city_name, rb.name AS business_name,
      l.loan_id, l.cycle_number, l.kanaku_number, l.loan_date, l.due_date, totals.loan_amount, l.interest_rate,
      totals.interest_amount, totals.total_amount, totals.loan_count, totals.schedules, l.installment_amount, l.remaining_days,
      l.duration, l.loan_type, l.completed_at, l.aborted_at, l.abort_reason,
      l.notes AS loan_notes
    `

    let whereClause = `WHERE (l.loan_id IS NOT NULL OR NOT EXISTS (SELECT 1 FROM kanaku_trash t WHERE t.customer_id=c.id::text AND t.user_id=c.user_id::text))`
    const params: any[] = []
    let paramIdx = 1

    if (userId) { whereClause += ` AND c.user_id = $${paramIdx++}`; params.push(userId) }
    if (status && status !== 'all') { whereClause += ` AND (${effectiveStatus}) = $${paramIdx++}`; params.push(status) }
    if (search) {
      whereClause += ` AND (c.full_name ILIKE $${paramIdx} OR c.phone_number ILIKE $${paramIdx} OR c.customer_code ILIKE $${paramIdx} OR ra.name ILIKE $${paramIdx} OR rc.name ILIKE $${paramIdx} OR rb.name ILIKE $${paramIdx})`
      params.push(`%${search}%`)
      paramIdx++
    }

    const baseQuery = `
      FROM customers c
      LEFT JOIN ref_area ra ON c.area_id = ra.id
      LEFT JOIN ref_city rc ON c.city_id = rc.id
      LEFT JOIN ref_business rb ON c.business_id = rb.id
      LEFT JOIN LATERAL (SELECT * FROM kanaku_loan_balances WHERE customer_id = c.id AND user_id = c.user_id
        ORDER BY (outstanding > 0 AND status IN ('Active','Overdue')) DESC, cycle_number DESC, kanaku_number ASC LIMIT 1) l ON true
      LEFT JOIN LATERAL (SELECT SUM(total_amount) AS total_amount, SUM(loan_amount) AS loan_amount, SUM(interest_amount) AS interest_amount, COUNT(*) AS loan_count,
        BOOL_AND(outstanding = 0 AND status <> 'Aborted') AS all_paid, BOOL_OR(outstanding > 0) AS has_balance,
        json_agg(json_build_object('loanDate',loan_date,'dueDate',due_date,'loanType',loan_type,'duration',duration)) AS schedules
        FROM kanaku_loan_balances WHERE customer_id = c.id AND user_id = c.user_id) totals ON true
      ${whereClause}
    `

    const countResult = await dbQuery(`SELECT COUNT(*) as total ${baseQuery}`, params)
    const total = parseInt(countResult.rows[0].total, 10)

    const dataQuery = `SELECT ${selectCols} ${baseQuery} ORDER BY c.created_at DESC LIMIT $${paramIdx++} OFFSET $${paramIdx++}`
    params.push(limit, offset)

    const result = await dbQuery(dataQuery, params)
    return NextResponse.json({
      data: result.rows,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    })
  } catch (err: any) {
    console.error('[GET /api/customers] Error:', err.message)
    return NextResponse.json(
      { error: 'Failed to fetch customers', details: err.message },
      { status: 500 }
    )
  }
}
