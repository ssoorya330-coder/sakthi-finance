import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { runPgRestore } from '@/server/storage'
import { actorFromAuthUser, requestMeta, recordAuditStandalone } from '@/server/audit'

export const dynamic = 'force-dynamic'

/**
 * Restore the LOCAL PostgreSQL database from a local backup file.
 * Overwrites current data — the UI must confirm before calling.
 */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const backupId = body.backup_id as string | undefined
    const confirmed = body.confirmed === true
    if (!backupId) return NextResponse.json({ error: 'Backup is required.' }, { status: 400 })
    if (!confirmed) {
      return NextResponse.json(
        { error: 'Restore must be explicitly confirmed. This overwrites current data.' },
        { status: 400 }
      )
    }
    const rec = await dbQuery('SELECT * FROM backup_records WHERE id = $1 LIMIT 1', [backupId])
    if (rec.rows.length === 0) {
      return NextResponse.json({ error: 'Backup record not found.' }, { status: 404 })
    }
    await runPgRestore(rec.rows[0].path)
    await dbQuery(
      "INSERT INTO audit_logs (action, entity_type, entity_id, details, user_id) VALUES ('restore', 'database', $1, $2, $3)",
      [backupId, JSON.stringify({ filename: rec.rows[0].filename }), auth.user.userId]
    ).catch(() => {})
    {
      const meta = requestMeta(request)
      await recordAuditStandalone({
        action: 'BACKUP_RESTORED',
        entityType: 'backup',
        entityId: backupId,
        actor: actorFromAuthUser(auth.user),
        ipAddress: meta.ip,
        clientInfo: meta.client,
        reason: 'Database restored from backup (overwrites current data)',
        result: 'SUCCESS',
        changes: [{ field: 'filename', label: 'Restored File', before: null, after: rec.rows[0].filename }],
        after: { filename: rec.rows[0].filename },
      })
    }
    return NextResponse.json({ success: true })
  } catch (err: any) {
    const message = err?.message || 'Restore failed.'
    const status = /not found on this computer/i.test(message) ? 503 : 500
    return NextResponse.json({ error: message }, { status })
  }
}
