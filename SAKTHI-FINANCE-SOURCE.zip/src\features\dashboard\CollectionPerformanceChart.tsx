'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'
import { Activity } from 'lucide-react'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts'
import { formatINR } from '@/lib/dashboard-utils'
import { useCustomerStore } from '@/store/customer-store'
import { computeCollectionPerformance } from './dashboard-data'
import { axisProps, gridLineProps } from './dashboard-animations'

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
      className="bg-white/95 backdrop-blur-sm rounded-xl border border-slate-100 shadow-xl px-4 py-3"
    >
      <p className="text-xs font-medium text-slate-500 mb-2">{label}</p>
      {payload.map((entry: any, i: number) => (
        <div key={i} className="flex items-center gap-2 text-sm">
          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
          <span className="text-slate-600 capitalize">{entry.name}:</span>
          <span className="font-semibold text-slate-900">{formatINR(entry.value)}</span>
        </div>
      ))}
    </motion.div>
  )
}

function EmptyState() {
  return (
    <div className="h-[270px] flex items-center justify-center">
      <div className="text-center">
        <Activity className="w-10 h-10 text-slate-300 mx-auto mb-3" />
        <p className="text-sm text-slate-400 font-medium">No collection data available</p>
        <p className="text-xs text-slate-300 mt-1">Record payments to see performance</p>
      </div>
    </div>
  )
}

export default function CollectionPerformanceChart() {
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const data = useMemo(() => computeCollectionPerformance(paymentHistory), [paymentHistory])
  const hasData = data.some((d) => d.actual > 0)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.5 }}
      className="relative bg-white/70 backdrop-blur-xl rounded-[20px] border border-white/20 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] p-6 overflow-hidden"
    >
      <div className="absolute inset-0 sf-pattern-dots opacity-40 pointer-events-none" />
      <div className="flex items-center justify-between mb-6 relative">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
            <Activity className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-slate-900">Collection Performance</h3>
            <p className="text-xs text-slate-500">Target vs actual collections</p>
          </div>
        </div>
      </div>
      {!hasData ? (
        <EmptyState />
      ) : (
        <div className="h-[270px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
              <CartesianGrid {...gridLineProps} />
              <XAxis dataKey="day" {...axisProps} />
              <YAxis {...axisProps} tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`} />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                iconType="circle"
                iconSize={8}
                wrapperStyle={{ fontSize: '12px', paddingTop: '16px' }}
              />
              <Line
                type="monotone"
                dataKey="target"
                stroke="#94A3B8"
                strokeWidth={2}
                strokeDasharray="6 4"
                dot={false}
                name="Target"
                isAnimationActive
                animationDuration={1200}
                animationEasing="ease-out"
                animationBegin={200}
              />
              <Line
                type="monotone"
                dataKey="actual"
                stroke="var(--primary)"
                strokeWidth={2.5}
                dot={{ r: 4, fill: 'var(--primary)', strokeWidth: 2, stroke: '#fff' }}
                activeDot={{ r: 6 }}
                name="Actual"
                isAnimationActive
                animationDuration={1200}
                animationEasing="ease-out"
                animationBegin={400}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </motion.div>
  )
}
