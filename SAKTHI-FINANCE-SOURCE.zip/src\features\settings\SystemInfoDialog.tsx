'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  X,
  Monitor,
  Code2,
  Server,
  Shield,
  Globe,
  Clock,
  HardDrive,
  Cpu,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAppVersion } from '@/hooks/use-app-version'

interface SystemInfoDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

function getBrowserInfo(): string {
  if (typeof navigator === 'undefined') return 'Unknown'
  const ua = navigator.userAgent
  if (ua.includes('Chrome')) return 'Chrome'
  if (ua.includes('Firefox')) return 'Firefox'
  if (ua.includes('Safari')) return 'Safari'
  if (ua.includes('Edge')) return 'Edge'
  return 'Unknown'
}

function getOSInfo(): string {
  if (typeof navigator === 'undefined') return 'Unknown'
  const ua = navigator.userAgent
  if (ua.includes('Windows')) return 'Windows'
  if (ua.includes('Mac')) return 'macOS'
  if (ua.includes('Linux')) return 'Linux'
  if (ua.includes('Android')) return 'Android'
  if (ua.includes('iOS')) return 'iOS'
  return 'Unknown'
}

function getMemoryInfo(): string {
  if (typeof performance === 'undefined' || !('memory' in performance)) {
    return 'Not available'
  }
  const mem = (performance as { memory?: { usedJSHeapSize: number } }).memory
  if (!mem) return 'Not available'
  const used = mem.usedJSHeapSize / (1024 * 1024)
  return `${used.toFixed(1)} MB`
}

export default function SystemInfoDialog({ open, onOpenChange }: SystemInfoDialogProps) {
  const appVersion = useAppVersion()
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleString())
  const [memory, setMemory] = useState('Not available')

  useEffect(() => {
    if (!open) return
    const interval = setInterval(() => {
      setCurrentTime(new Date().toLocaleString())
      setMemory(getMemoryInfo())
    }, 1000)
    setMemory(getMemoryInfo())
    return () => clearInterval(interval)
  }, [open])

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onOpenChange(false)
    }
    if (open) {
      document.addEventListener('keydown', handleEscape)
      document.body.style.overflow = 'hidden'
    }
    return () => {
      document.removeEventListener('keydown', handleEscape)
      document.body.style.overflow = ''
    }
  }, [open, onOpenChange])

  const sysInfo = [
    { label: 'Application Version', value: `${appVersion} (Production)`, icon: Code2 },
    { label: 'React Version', value: '19.0.0', icon: Code2 },
    { label: 'Next.js Version', value: '16.x', icon: Server },
    { label: 'Database Status', value: 'SQLite Connected', icon: HardDrive },
    { label: 'Authentication Status', value: 'Authenticated', icon: Shield },
    { label: 'Browser', value: getBrowserInfo(), icon: Globe },
    { label: 'Operating System', value: getOSInfo(), icon: Monitor },
    { label: 'Current Time', value: currentTime, icon: Clock },
    { label: 'Memory Usage', value: memory, icon: Cpu },
  ]

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[var(--z-modal)]"
            onClick={() => onOpenChange(false)}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-[var(--z-modal)] w-full max-w-lg"
          >
            <div className="bg-white rounded-[20px] border border-slate-100 shadow-[0_20px_60px_rgba(0,0,0,0.15)] mx-4 overflow-hidden">
              <div className="flex items-center justify-between p-6 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
                    <Monitor className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">System Information</h2>
                    <p className="text-xs text-slate-500">Detailed system diagnostics</p>
                  </div>
                </div>
                <button
                  onClick={() => onOpenChange(false)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="px-6 pb-6">
                <div className="space-y-2">
                  {sysInfo.map((item) => {
                    const Icon = item.icon as React.ComponentType<{ className?: string }>
                    return (
                      <div
                        key={item.label}
                        className="flex items-center justify-between p-3 rounded-xl bg-slate-50/80 hover:bg-slate-50 transition-colors"
                      >
                        <div className="flex items-center gap-2.5">
                          <Icon className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-600">{item.label}</span>
                        </div>
                        <span className="text-sm font-semibold text-slate-900">{item.value}</span>
                      </div>
                    )
                  })}
                </div>
              </div>

              <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/50">
                <button
                  onClick={() => onOpenChange(false)}
                  className="w-full py-2.5 rounded-xl bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 transition-colors active:scale-[0.98]"
                >
                  Close
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
