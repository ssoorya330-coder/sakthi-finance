'use client'

import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { motion } from 'framer-motion'
import { CheckCircle, ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { useAuthActions } from '@/hooks/use-auth'
import { useAuthStore } from '@/store/auth-store'
import { forgotPasswordSchema, type ForgotPasswordFormData } from '@/utils/validators'
import { STAGGER_CONTAINER, STAGGER_CHILD } from '@/animations/variants'
import { AnimatedInput } from '@/components/ui/animated-input'
import { AnimatedButton } from '@/components/ui/animated-button'

export default function ForgotPasswordForm() {
  const { error, success, setError, setSuccess } = useAuthActions()
  const { isLoading } = useAuthStore()
  const [sent, setSent] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ForgotPasswordFormData>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: { username: '' },
  })

  const onSubmit = async (data: ForgotPasswordFormData) => {
    setError('')
    setSuccess('If the username exists, a password reset link will be sent to your email.')
    setSent(true)
  }

  if (sent) {
    return (
      <motion.div
        variants={STAGGER_CONTAINER}
        initial="hidden"
        animate="visible"
        className="space-y-6 text-center"
      >
        <motion.div variants={STAGGER_CHILD} className="flex justify-center">
          <div className="w-16 h-16 rounded-2xl bg-success/10 border border-success/20 flex items-center justify-center">
            <CheckCircle className="w-8 h-8 text-success" />
          </div>
        </motion.div>

        <motion.div variants={STAGGER_CHILD} className="space-y-2">
          <h2 className="text-[26px] font-bold text-white tracking-tight">
            Check Your Email
          </h2>
          <p className="text-[14px] text-text-secondary leading-relaxed">
            We&apos;ve sent a password reset link to your email address. Please check your inbox.
          </p>
        </motion.div>

        <motion.div variants={STAGGER_CHILD}>
          <AnimatedButton
            variant="secondary"
            fullWidth
            onClick={() => setSent(false)}
          >
            <ArrowLeft className="w-4 h-4" />
            Back to reset
          </AnimatedButton>
        </motion.div>

        <motion.p variants={STAGGER_CHILD} className="text-[13px] text-text-secondary">
          Didn&apos;t receive the email?{' '}
          <button
            onClick={() => setSent(false)}
            className="font-medium text-gold-400 hover:text-gold-300 transition-colors"
          >
            Try again
          </button>
        </motion.p>
      </motion.div>
    )
  }

  return (
    <motion.div
      variants={STAGGER_CONTAINER}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <motion.div variants={STAGGER_CHILD} className="space-y-2">
        <h2 className="text-[26px] font-bold text-white tracking-tight">
          Reset Password
        </h2>
        <p className="text-[14px] text-text-secondary leading-relaxed">
          Enter your username and we&apos;ll help you reset your password
        </p>
      </motion.div>

      {error && (
        <motion.div
          variants={STAGGER_CHILD}
          className="px-4 py-3 rounded-xl bg-error/10 border border-error/20 text-[13px] text-error"
        >
          {error}
        </motion.div>
      )}

      {success && (
        <motion.div
          variants={STAGGER_CHILD}
          className="px-4 py-3 rounded-xl bg-success/10 border border-success/20 text-[13px] text-success"
        >
          {success}
        </motion.div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
        <motion.div variants={STAGGER_CHILD}>
          <AnimatedInput
            label="Username"
            type="text"
            placeholder="Enter your username"
            icon="user"
            error={errors.username?.message}
            {...register('username')}
          />
        </motion.div>

        <motion.div variants={STAGGER_CHILD}>
          <AnimatedButton
            type="submit"
            variant="primary"
            fullWidth
            loading={isLoading}
          >
            {isLoading ? 'Sending...' : 'Send Reset Link'}
          </AnimatedButton>
        </motion.div>
      </form>

      <motion.p
        variants={STAGGER_CHILD}
        className="text-center text-[13px] text-text-secondary"
      >
        <Link
          href="/"
          className="font-semibold text-gold-400 hover:text-gold-300 transition-colors"
        >
          Go back to home
        </Link>
      </motion.p>
    </motion.div>
  )
}
