import {app,safeStorage} from 'electron'
import {readFile,open,rename,mkdir} from 'node:fs/promises'
import path from 'node:path'
import {randomUUID,X509Certificate} from 'node:crypto'
import {networkInterfaces,hostname} from 'node:os'
import {generate} from 'selfsigned'
import {OAuth2Client} from 'google-auth-library'
import {callTablet} from './api-bridge'
import {TabletPairing,PairingError,type PairingScope,type TabletEnvironment} from './tablet-pairing'
import {TabletGrantStore} from './tablet-grant-store'
import {TabletHttpsHost} from './tablet-https'
import {tabletAddresses} from './tablet-addresses'

type Identity = {id:string;key:string;cert:string;environment:TabletEnvironment}
export class TabletService {
  private host?:TabletHttpsHost
  private pairing?:TabletPairing
  private store?:TabletGrantStore
  private identity?:Identity
  private port=0
  private changing=false
  constructor(private session:()=>number|null) {}
  private async scope():Promise<PairingScope> {
    if(!this.identity)throw new PairingError(503,'Tablet connection is not enabled')
    const result=await callTablet(this.session(),'identity')
    if(!result.ok)throw new PairingError(result.status,'Sign in on the laptop and check its configured storage')
    return {...result.data as Pick<PairingScope,'ownerId'|'googleSubject'|'databaseId'>,laptopId:this.identity.id,environment:this.identity.environment}
  }
  async enable(environment:TabletEnvironment) {
    if(!['development','production'].includes(environment))throw Error('Choose an environment')
    if(this.changing)throw Error('Connection change in progress')
    this.changing=true
    try {
      if(this.host) {
        if(this.identity?.environment!==environment)throw Error('Disable the current connection before switching environments')
        return await this.status()
      }
      if(!safeStorage.isEncryptionAvailable())throw Error('Secure storage unavailable')
      const root=path.join(app.getPath('userData'),'tablet-connection')
      await mkdir(root,{recursive:true})
      const file=path.join(root,`${environment}.encrypted`)
      let identity:Identity
      try {identity=JSON.parse(safeStorage.decryptString(await readFile(file)))}
      catch(e) {
        if((e as NodeJS.ErrnoException).code!=='ENOENT')throw e
        const certificate=await generate([{name:'commonName',value:'Sakthi Finance Laptop'}],{keySize:2048,algorithm:'sha256',notAfterDate:new Date(Date.now()+365*86400000)})
        identity={id:randomUUID(),key:certificate.private,cert:certificate.cert,environment}
        const temporary=file+'.'+randomUUID()+'.tmp'
        const handle=await open(temporary,'wx')
        try {await handle.writeFile(safeStorage.encryptString(JSON.stringify(identity)));await handle.sync()}finally{await handle.close()}
        await rename(temporary,file)
      }
      if(identity.environment!==environment||!identity.id||Date.parse(new X509Certificate(identity.cert).validTo)<=Date.now())throw Error('Laptop certificate needs renewal; existing trust was kept')
      this.identity=identity
      await this.scope()
      this.store=new TabletGrantStore(path.join(root,'devices.encrypted'),{encrypt:s=>safeStorage.encryptString(s),decrypt:b=>safeStorage.decryptString(b)})
      this.pairing=new TabletPairing(this.store)
      const google=new OAuth2Client()
      const host=new TabletHttpsHost({key:identity.key,cert:identity.cert,pairing:this.pairing,scope:()=>this.scope(),
        verifyGoogle:async idToken=>{
          const audience=process.env.GOOGLE_CLIENT_ID
          if(!audience)throw new PairingError(503,'Google configuration is unavailable')
          try {
            const ticket=await google.verifyIdToken({idToken,audience})
            const payload=ticket.getPayload()
            if(!payload?.sub||!payload.email_verified)throw new PairingError(401,'Google identity was not verified')
            return {subject:payload.sub}
          }catch(error){
            if(error instanceof PairingError)throw error
            const code=(error as {code?:string}).code
            if(code&&['ENOTFOUND','ETIMEDOUT','ECONNRESET','ECONNREFUSED','EAI_AGAIN'].includes(code))throw new PairingError(503,'Google verification is temporarily unreachable')
            throw new PairingError(401,'Google sign-in expired or does not match this application')
          }
        },
        execute:async(grant,action,body)=>{
          const result=await callTablet(this.session(),action,{...(body as object),ownerId:grant.ownerId,databaseId:grant.databaseId,deviceId:grant.deviceId})
          if(!result.ok)throw new PairingError(result.status,(result.data as {error?:string}).error||'Tablet operation failed')
          return result.data
        }})
      this.port=await host.start('0.0.0.0',48763)
      this.host=host
      return await this.status()
    }finally{this.changing=false}
  }
  async stop(){await this.host?.stop();this.host=undefined;this.pairing=undefined;this.port=0}
  async status() {
    if(!this.host)return {enabled:false,laptopName:hostname(),addresses:[],pending:[],devices:[]}
    const scope=await this.scope()
    const addresses=tabletAddresses(networkInterfaces(),this.port)
    return {enabled:true,laptopName:hostname(),environment:scope.environment,fingerprint:this.host.fingerprint(),addresses,pending:this.pairing!.list(scope),devices:await this.store!.list(scope)}
  }
  async code(){return this.pairing!.generate(await this.scope())}
  async decide(requestId:string,approve:boolean){await this.pairing!.decide(await this.scope(),requestId,approve);return this.status()}
  async revoke(deviceId:string){await this.pairing!.revoke(await this.scope(),deviceId);return this.status()}
}
