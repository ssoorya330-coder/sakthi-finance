import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/api-utils'
import {
  getPgServiceInfo,
  getDataDirectory,
  getDataDirSizeBytes,
  getServerVersion,
  getDatabaseSizeBytes,
  getDiskUsageForPath,
  findPgBin,
} from '@/server/storage'

export const dynamic = 'force-dynamic'

/**
 * STEP 1 — Detect: installed version, current data directory (+ size),
 * Windows service (name/state/binary path), and pg tool availability.
 * Read-only. No passwords are ever returned.
 */
export async function GET() {
  const auth = await requireAuth()
  if (auth.error) return auth.error

  try {
    const [service, dataDirectory, dataDirSizeBytes, version, dbSizeBytes] = await Promise.all([
      getPgServiceInfo(),
      getDataDirectory(),
      getDataDirSizeBytes(),
      getServerVersion(),
      getDatabaseSizeBytes(),
    ])
    const drive = dataDirectory ? getDiskUsageForPath(dataDirectory) : null
    return NextResponse.json({
      version,
      dataDirectory,
      dataDirSizeBytes,
      dbSizeBytes,
      drive,
      service,
      pgToolsFound: findPgBin() !== null,
    })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to detect PostgreSQL installation', details: err.message },
      { status: 500 }
    )
  }
}
