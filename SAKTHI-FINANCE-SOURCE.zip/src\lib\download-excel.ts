'use client'

import { useToastStore } from '@/store/toast-store'

export async function downloadExcel(filename: string, title: string, headers: string[], rows: Array<Array<string | number | null | undefined>>, metadata: string[] = []) {
  try {
    const response = await fetch('/api/reports/workbook', {
      method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, headers, rows, metadata }),
    })
    if (!response.ok) {
      const error = await response.json().catch(() => ({}))
      throw new Error(error.error || 'Excel export failed. Please try again.')
    }
    const url = URL.createObjectURL(await response.blob())
    const link = document.createElement('a')
    link.href = url
    link.download = filename.replace(/\.(xlsx?|csv)$/i, '') + '.xlsx'
    document.body.appendChild(link)
    link.click()
    link.remove()
    setTimeout(() => URL.revokeObjectURL(url), 2000)
  } catch (error) {
    useToastStore.getState().addToast(error instanceof Error ? error.message : 'Excel export failed.', 'error')
  }
}
