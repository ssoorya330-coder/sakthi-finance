import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { fy, fyOf, availableFinancialYears } from '@/server/financial-audit'
import { cashSummary, cashTransactions, type CashFilters } from '@/server/cash-audit'
import { getCashThreshold } from '@/server/cash-compliance'

export const dynamic = 'force-dynamic'

/**
 * Cash-transaction compliance data for the selected Financial Year:
 * summary + server-paginated transaction list. Real PostgreSQL aggregates.
 */
export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('audit:read')
  if (auth.error) return auth.error

  try {
    const searchParams = new URL(request.url).searchParams
    const years = await availableFinancialYears(auth.user.userId)
    const fyParam = parseInt(searchParams.get('fy') || '', 10)
    const selected = years.some((y) => y.startYear === fyParam) ? fy(fyParam) : fyOf()

    const page = Math.max(parseInt(searchParams.get('page') || '1', 10) || 1, 1)
    const limit = Math.min(Math.max(parseInt(searchParams.get('limit') || '25', 10) || 25, 1), 200)
    const flagParam = (searchParams.get('flagged') || 'all').toLowerCase()
    const filters: CashFilters = {
      customerId: searchParams.get('customerId'),
      customerCode: searchParams.get('customerCode'),
      dateFrom: searchParams.get('dateFrom'),
      dateTo: searchParams.get('dateTo'),
      type: searchParams.get('type'),
      flagged: flagParam === 'flagged' ? 'flagged' : flagParam === 'notflagged' ? 'notflagged' : 'all',
      mode: searchParams.get('mode'),
    }

    const [summary, txns] = await Promise.all([
      cashSummary(auth.user.userId, selected),
      cashTransactions(auth.user.userId, selected, filters, page, limit),
    ])

    return NextResponse.json({
      years: years.map((y) => ({ startYear: y.startYear, label: y.label })),
      fy: { startYear: selected.startYear, label: selected.label },
      threshold: await getCashThreshold(),
      summary,
      transactions: txns.rows,
      total: txns.total,
      page,
      totalPages: Math.max(Math.ceil(txns.total / limit), 1),
    })
  } catch (err: any) {
    console.error('[GET /api/audit/cash] Error:', err.message)
    return NextResponse.json({ error: 'Failed to load cash transactions' }, { status: 500 })
  }
}
