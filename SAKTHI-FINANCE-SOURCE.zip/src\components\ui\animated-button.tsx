'use client'

import { useRef, useState, useCallback } from 'react'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'
import { Loader2 } from 'lucide-react'

type ButtonAttributes = Omit<
  React.ButtonHTMLAttributes<HTMLButtonElement>,
  'onDrag' | 'onDragEnd' | 'onDragStart' | 'onDrop' | 'onAnimationStart' | 'onAnimationEnd'
>

interface AnimatedButtonProps extends ButtonAttributes {
  variant?: 'primary' | 'secondary' | 'ghost' | 'gold'
  loading?: boolean
  fullWidth?: boolean
  children: React.ReactNode
}

function AnimatedButton({
  variant = 'primary',
  loading,
  fullWidth,
  children,
  className,
  disabled,
  ...props
}: AnimatedButtonProps) {
  const [ripples, setRipples] = useState<{ x: number; y: number; id: number }[]>([])
  const buttonRef = useRef<HTMLButtonElement>(null)
  const idRef = useRef(0)

  const handleClick = useCallback(
    (e: React.MouseEvent<HTMLButtonElement>) => {
      const rect = buttonRef.current?.getBoundingClientRect()
      if (rect) {
        const x = e.clientX - rect.left
        const y = e.clientY - rect.top
        const id = idRef.current++
        setRipples((prev) => [...prev, { x, y, id }])
        setTimeout(() => {
          setRipples((prev) => prev.filter((r) => r.id !== id))
        }, 600)
      }
      props.onClick?.(e)
    },
    [props.onClick]
  )

  const variantStyles = {
    primary: cn(
      'bg-gradient-to-r from-gold-400 to-gold-300 text-bg-primary',
      'shadow-[0_4px_20px_rgba(232,193,90,0.25)]',
      'hover:shadow-[0_8px_32px_rgba(232,193,90,0.35)]',
      'hover:brightness-110',
      'disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:brightness-100 disabled:hover:shadow-[0_4px_20px_rgba(232,193,90,0.25)]'
    ),
    secondary: cn(
      'bg-white text-slate-700 border border-slate-200',
      'hover:bg-slate-50 hover:border-slate-300',
      'disabled:opacity-40 disabled:cursor-not-allowed'
    ),
    ghost: cn(
      'text-text-secondary hover:text-text-primary',
      'disabled:opacity-40 disabled:cursor-not-allowed'
    ),
    gold: cn(
      'bg-gradient-to-r from-gold-400/20 to-gold-300/10',
      'border border-gold-400/30 text-gold-300',
      'hover:bg-gold-400/30 hover:border-gold-400/50',
      'disabled:opacity-40 disabled:cursor-not-allowed'
    ),
  }

  return (
    <motion.button
      ref={buttonRef as React.Ref<HTMLButtonElement>}
      whileHover={!disabled && !loading ? { scale: 1.01, y: -1 } : undefined}
      whileTap={!disabled && !loading ? { scale: 0.98 } : undefined}
      onClick={handleClick}
      disabled={disabled || loading}
      className={cn(
        'relative overflow-hidden will-change-transform',
        'h-[52px] rounded-[18px] px-8',
        'text-[15px] font-semibold tracking-wide',
        'flex items-center justify-center gap-2.5',
        fullWidth && 'w-full',
        variantStyles[variant],
        className
      )}
      {...props}
    >
      {loading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1, rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          <Loader2 className="w-[18px] h-[18px]" />
        </motion.div>
      )}
      <span className={cn(loading && 'opacity-70')}>{children}</span>
      {ripples.map((ripple) => (
        <span
          key={ripple.id}
          className="absolute rounded-full bg-white/20 pointer-events-none"
          style={{
            left: ripple.x - 10,
            top: ripple.y - 10,
            width: 20,
            height: 20,
            animation: 'sf-ripple 0.6s ease-out forwards',
          }}
        />
      ))}
    </motion.button>
  )
}

export { AnimatedButton }
export default AnimatedButton
