'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'
import { Wallet } from 'lucide-react'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts'
import { formatINR } from '@/lib/dashboard-utils'
import { useCustomerStore } from '@/store/customer-store'
import { computePaymentDistribution } from './dashboard-data'
import { pieAnimationProps } from './dashboard-animations'

const CustomTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
      className="bg-white/95 backdrop-blur-sm rounded-xl border border-slate-100 shadow-xl px-4 py-3"
    >
      <div className="flex items-center gap-2">
        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: payload[0].payload.color }} />
        <span className="text-sm font-semibold text-slate-900">{payload[0].name}</span>
      </div>
      <p className="text-lg font-bold text-slate-900 mt-1">{formatINR(payload[0].value)}</p>
    </motion.div>
  )
}

function EmptyState() {
  return (
    <div className="flex items-center justify-center h-[162px]">
      <div className="text-center">
        <Wallet className="w-8 h-8 text-slate-300 mx-auto mb-2" />
        <p className="text-sm text-slate-400 font-medium">No payments recorded</p>
      </div>
    </div>
  )
}

export default function PaymentDistributionChart() {
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const data = useMemo(() => computePaymentDistribution(paymentHistory), [paymentHistory])
  const total = data.reduce((s, d) => s + d.value, 0)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.6 }}
      className="relative bg-white/70 backdrop-blur-xl rounded-[20px] border border-white/20 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] p-6 overflow-hidden"
    >
      <div className="absolute inset-0 sf-pattern-dots opacity-40 pointer-events-none" />
      <div className="flex items-center justify-between mb-4 relative">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
            <Wallet className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-slate-900">Payment Distribution</h3>
            <p className="text-xs text-slate-500">Total: {formatINR(total)}</p>
          </div>
        </div>
      </div>
      {data.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="flex items-center gap-6">
          <div className="w-[162px] h-[162px] flex-shrink-0">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={72}
                  paddingAngle={4}
                  dataKey="value"
                  {...pieAnimationProps}
                >
                  {data.map((entry, i) => (
                    <Cell key={i} fill={entry.color} stroke="none" />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex-1 space-y-3">
            {data.map((item, idx) => (
              <motion.div
                key={item.name}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.6 + idx * 0.06 }}
                className="flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-sm text-slate-600">{item.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-slate-900">{formatINR(item.value)}</span>
                  <span className="text-xs text-slate-400">
                    {total > 0 ? ((item.value / total) * 100).toFixed(0) : 0}%
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  )
}
