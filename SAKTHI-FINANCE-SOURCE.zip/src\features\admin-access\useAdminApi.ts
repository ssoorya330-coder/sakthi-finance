'use client'

import { useCallback, useEffect, useRef, useState } from 'react'

export type AdminLoadState = 'loading' | 'ready' | 'unauthorized' | 'failed'

/**
 * Shared GET helper for Admin Access pages: loading → data / empty /
 * unauthorized / failed, with mounted guards and a working retry.
 */
export function useAdminApi<T>(url: string | null, parse: (data: any) => T) {
  const [data, setData] = useState<T | null>(null)
  const [state, setState] = useState<AdminLoadState>('loading')
  const [retrying, setRetrying] = useState(false)
  const mountedRef = useRef(true)
  const urlRef = useRef(url)
  urlRef.current = url

  const load = useCallback(
    async (isRetry = false) => {
      const u = urlRef.current
      if (!u) return
      if (isRetry) setRetrying(true)
      else if (mountedRef.current) setState('loading')
      try {
        const res = await fetch(u, { credentials: 'include' })
        if (res.status === 401 || res.status === 403) {
          if (mountedRef.current) setState('unauthorized')
          return
        }
        if (!res.ok) throw new Error(`Request failed (${res.status})`)
        const json = await res.json().catch(() => null)
        if (mountedRef.current) {
          setData(parse(json))
          setState('ready')
        }
      } catch {
        if (mountedRef.current) setState('failed')
      } finally {
        if (mountedRef.current) setRetrying(false)
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  )

  useEffect(() => {
    mountedRef.current = true
    load()
    return () => {
      mountedRef.current = false
    }
  }, [load, url])

  return { data, state, retrying, retry: () => load(true) }
}

export async function adminMutate(
  url: string,
  init: RequestInit
): Promise<{ ok: boolean; status: number; message: string }> {
  try {
    const res = await fetch(url, { credentials: 'include', ...init })
    const json = await res.json().catch(() => null)
    if (res.status === 401 || res.status === 403) {
      return {
        ok: false,
        status: res.status,
        message:
          (json as any)?.error || 'You do not have permission to perform this action.',
      }
    }
    if (res.status === 429) {
      return { ok: false, status: res.status, message: 'Too many requests. Please slow down.' }
    }
    if (!res.ok) {
      return {
        ok: false,
        status: res.status,
        message: (json as any)?.error || 'Request failed. Please try again.',
      }
    }
    return { ok: true, status: res.status, message: '' }
  } catch {
    return { ok: false, status: 0, message: 'Unable to connect. Please try again.' }
  }
}
