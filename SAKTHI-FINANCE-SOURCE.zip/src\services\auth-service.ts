import { useCallback, useMemo } from 'react';
import { useAuthStore } from '@/store/auth-store';
import type { UserRole } from '@/store/auth-store';

export type { UserRole };

export function useAuth() {
  const user = useAuthStore((s) => s.user);
  const session = useAuthStore((s) => s.session);
  const userId = useAuthStore((s) => s.userId);
  const role = useAuthStore((s) => s.role);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const isAdmin = useAuthStore((s) => s.isAdmin);

  const getAuthHeaders = useCallback(async (): Promise<Record<string, string>> => {
    const token = session?.accessToken || null;
    return {
      Authorization: token ? `Bearer ${token}` : '',
      'X-User-Id': userId || '',
    };
  }, [session, userId]);

  const getToken = useCallback(async () => session?.accessToken || null, [session]);

  return {
    isSignedIn: isAuthenticated,
    isAuthenticated,
    userId: userId || '',
    sessionId: session?.accessToken || '',
    role,
    isAdmin,
    user,
    session,
    getToken,
    getAuthHeaders,
    userName: user?.name || useAuthStore.getState().userName || '',
    userEmail: user?.email || useAuthStore.getState().userEmail || '',
  };
}

// Backwards-compat alias
export const useSupabaseAuth = useAuth;

export function useUserScopedQuery<T>(
  queryFn: (userId: string, isAdmin: boolean) => Promise<T>,
  deps: unknown[] = []
) {
  const { userId, isAdmin } = useSupabaseAuth();

  return useCallback(async (): Promise<T> => {
    if (!userId) throw new Error('Not authenticated');
    return queryFn(userId, isAdmin);
  }, [userId, isAdmin, ...deps]);
}
