import fs from 'fs'
import path from 'path'
import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/api-utils'
import { getDataDirectory } from '@/server/storage'
import { dbQuery } from '@/server/database'

const MAX_TAIL_LINES = 200
const MAX_FILE_BYTES = 5 * 1024 * 1024

/** Recent PostgreSQL log lines, or {available:false} when logs are unreachable. */
export async function GET() {
  const auth = await requireAuth()
  if (auth.error) return auth.error

  try {
    const dataDir = await getDataDirectory()
    let logDir: string | null = null
    try {
      const r = await dbQuery<{ log_directory: string }>('SHOW log_directory')
      const raw = r.rows[0]?.log_directory || 'log'
      logDir = path.isAbsolute(raw) ? raw : dataDir ? path.join(/* turbopackIgnore: true */ dataDir, raw) : null
    } catch {
      logDir = dataDir ? path.join(/* turbopackIgnore: true */ dataDir, 'log') : null
    }
    if (!logDir) return NextResponse.json({ available: false })

    let entries: fs.Dirent[]
    try {
      entries = fs.readdirSync(/* turbopackIgnore: true */ logDir, { withFileTypes: true })
    } catch {
      return NextResponse.json({ available: false })
    }
    const files = entries
      .filter((e) => e.isFile())
      .map((e) => {
        const full = path.join(/* turbopackIgnore: true */ logDir as string, e.name)
        try {
          const st = fs.statSync(/* turbopackIgnore: true */ full)
          return { name: e.name, sizeBytes: st.size, mtime: st.mtime.toISOString() }
        } catch {
          return null
        }
      })
      .filter((f): f is { name: string; sizeBytes: number; mtime: string } => f !== null)
      .sort((a, b) => (a.mtime < b.mtime ? 1 : -1))

    if (files.length === 0) return NextResponse.json({ available: false, files: [] })

    // Tail the newest log file (read last chunk, split lines).
    let tail: string[] = []
    try {
      const latest = path.join(/* turbopackIgnore: true */ logDir, files[0].name)
      const st = fs.statSync(/* turbopackIgnore: true */ latest)
      const start = Math.max(0, st.size - MAX_FILE_BYTES)
      const fd = fs.openSync(/* turbopackIgnore: true */ latest, 'r')
      try {
        const buf = Buffer.alloc(st.size - start)
        fs.readSync(fd, buf, 0, buf.length, start)
        tail = buf.toString('utf8').split(/\r?\n/).slice(-MAX_TAIL_LINES)
      } finally {
        fs.closeSync(fd)
      }
    } catch {
      tail = []
    }
    return NextResponse.json({ available: true, files: files.slice(0, 10), latest: files[0].name, tail })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to load database logs', details: err.message },
      { status: 500 }
    )
  }
}
