import { dbQuery } from './database';
import { CASH_PAYMENT_PRED, CASH_DISBURSAL_PRED, SPLIT, type FinancialYear } from './financial-audit';
import { getCashThreshold } from './cash-compliance';

/**
 * Cash-transaction compliance reporting over real tables.
 * Server-side aggregation throughout; the browser never computes totals.
 */

export interface CashSummary {
  threshold: number;
  disbursals: number;
  disbursed: number;
  payments: number;
  received: number;
  flagged: number;
  customersFlagged: number;
}

export interface CashTxn {
  date: string | null;
  txnId: string;
  kind: 'disbursal' | 'payment';
  type: string;
  customerId: string;
  customerCode: string;
  customerName: string;
  loanId: string | null;
  paymentId: string | null;
  mode: string;
  amount: number;
  principal: number;
  interest: number;
  outstanding: number;
  cumulative: number;
  flagged: boolean;
  complianceStatus: string;
  reason: string | null;
}

export interface CashFilters {
  customerId?: string | null;
  customerCode?: string | null;
  dateFrom?: string | null;
  dateTo?: string | null;
  type?: string | null; // 'disbursal' | 'payment'
  flagged?: 'all' | 'flagged' | 'notflagged';
  flaggedOnly?: boolean; // legacy alias for flagged === 'flagged'
  mode?: string | null; // 'Cash' | 'Bank' | ...
}

const num = (v: any): number => {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};

const isoDay = (v: any): string | null => {
  if (!v) return null;
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  return String(v).slice(0, 10);
};

export async function cashSummary(userId: string, f: FinancialYear): Promise<CashSummary> {
  const [d, p, fl] = await Promise.all([
    dbQuery(
      `SELECT COUNT(*) AS n, COALESCE(SUM(loan_amount), 0) AS s FROM loans
       WHERE user_id = $1 AND loan_date >= $2 AND loan_date < $3 AND ${CASH_DISBURSAL_PRED.replaceAll('l.', 'loans.')}`,
      [userId, f.from, f.to]
    ),
    dbQuery(
      `SELECT COUNT(*) AS n, COALESCE(SUM(p.amount), 0) AS s FROM payments p
       WHERE p.user_id = $1 AND p.payment_date >= $2 AND p.payment_date < $3 AND ${CASH_PAYMENT_PRED}`,
      [userId, f.from, f.to]
    ),
    dbQuery(
      `SELECT
         (SELECT COUNT(*) FROM loans WHERE user_id = $1 AND loan_date >= $2 AND loan_date < $3 AND is_flagged = true) +
         (SELECT COUNT(*) FROM payments WHERE user_id = $1 AND payment_date >= $2 AND payment_date < $3 AND is_flagged = true) AS flagged,
         (SELECT COUNT(DISTINCT customer_id) FROM (
            SELECT customer_id FROM loans WHERE user_id = $1 AND loan_date >= $2 AND loan_date < $3 AND is_flagged = true
            UNION
            SELECT customer_id FROM payments WHERE user_id = $1 AND payment_date >= $2 AND payment_date < $3 AND is_flagged = true
          ) t) AS customers`,
      [userId, f.from, f.to]
    ),
  ]);
  return {
    threshold: await getCashThreshold(),
    disbursals: Number(d.rows[0]?.n) || 0,
    disbursed: num(d.rows[0]?.s),
    payments: Number(p.rows[0]?.n) || 0,
    received: num(p.rows[0]?.s),
    flagged: Number(fl.rows[0]?.flagged) || 0,
    customersFlagged: Number(fl.rows[0]?.customers) || 0,
  };
}

function cashUnionWhere(filters: CashFilters, params: any[], alias: 'l' | 'p'): string {
  // Per-branch predicates over the union aliases below (d = disbursal/payment date).
  let clause = '';
  if (filters.type === 'disbursal' || filters.type === 'payment') {
    clause += ` AND kind = '${filters.type === 'disbursal' ? 'disbursal' : 'payment'}'`;
  }
  const flaggedMode = filters.flagged || (filters.flaggedOnly ? 'flagged' : 'all');
  if (flaggedMode === 'flagged') clause += ` AND flagged = true`;
  if (flaggedMode === 'notflagged') clause += ` AND flagged = false`;
  if (filters.mode) {
    params.push(filters.mode);
    clause += ` AND mode = $${params.length}`;
  }
  if (filters.customerId) {
    params.push(filters.customerId);
    clause += ` AND customer_id = $${params.length}`;
  }
  if (filters.customerCode) {
    params.push(`%${filters.customerCode}%`);
    clause += ` AND customer_code ILIKE $${params.length}`;
  }
  if (filters.dateFrom) {
    params.push(filters.dateFrom);
    clause += ` AND d >= $${params.length}::date`;
  }
  if (filters.dateTo) {
    params.push(filters.dateTo);
    clause += ` AND d < $${params.length}::date`;
  }
  void alias;
  return clause;
}

export async function cashTransactions(
  userId: string,
  f: FinancialYear,
  filters: CashFilters,
  page: number,
  limit: number
): Promise<{ rows: CashTxn[]; total: number }> {
  const params: any[] = [userId, f.from, f.to];
  const base = `
    FROM (
      SELECT l.loan_date::date AS d, l.loan_id AS txn_id, 'disbursal' AS kind,
             'Loan Disbursal' AS txn_type, l.customer_id,
             c.customer_code, c.full_name AS customer_name, l.loan_id,
             COALESCE(NULLIF(l.disbursal_mode, ''), 'Unknown') AS mode,
             l.loan_amount AS amount, l.loan_amount AS principal, 0::numeric AS interest,
             (l.total_amount - COALESCE(rec.paid, 0)) AS outstanding,
             l.is_flagged AS flagged, l.flag_reason AS reason,
             l.loan_date AS sort_key, 0 AS seq, l.created_at AS created_sort
      FROM loans l
      JOIN customers c ON c.id = l.customer_id AND c.user_id = l.user_id
      LEFT JOIN (SELECT loan_id, SUM(amount) AS paid FROM payments WHERE user_id = $1 GROUP BY loan_id) rec
        ON rec.loan_id = l.loan_id
      WHERE l.user_id = $1 AND l.loan_date >= $2 AND l.loan_date < $3
        AND ${CASH_DISBURSAL_PRED}
      UNION ALL
      SELECT p.payment_date::date, p.payment_id, 'payment' AS kind,
             'Installment Payment' AS txn_type, p.customer_id,
             c.customer_code, c.full_name, p.loan_id,
             COALESCE(NULLIF(p.payment_mode, ''), p.payment_method, 'Cash') AS mode,
             p.amount, (${SPLIT}) AS principal, (p.amount - (${SPLIT})) AS interest,
             (COALESCE(l.total_amount, p.amount) - COALESCE((
               SELECT SUM(p2.amount) FROM payments p2
               WHERE p2.loan_id = p.loan_id AND p2.user_id = p.user_id
                 AND (p2.payment_date < p.payment_date
                   OR (p2.payment_date = p.payment_date AND p2.payment_id <= p.payment_id))
             ), 0)) AS outstanding,
             p.is_flagged AS flagged, p.flag_reason AS reason,
             p.payment_date, 1, p.created_at
      FROM payments p
      JOIN customers c ON c.id = p.customer_id AND c.user_id = p.user_id
      LEFT JOIN loans l ON l.loan_id = p.loan_id AND l.user_id = p.user_id
      WHERE p.user_id = $1 AND p.payment_date >= $2 AND p.payment_date < $3
        AND ${CASH_PAYMENT_PRED}
    ) t
  `;
  const where = cashUnionWhere(filters, params, 'l');
  const count = await dbQuery(`SELECT COUNT(*) AS c ${base} WHERE 1=1${where}`, params);
  const total = Number(count.rows[0]?.c) || 0;
  const offset = (Math.max(page, 1) - 1) * limit;
  const rows = await dbQuery(
    `SELECT d AS date, txn_id, kind, txn_type, customer_id, customer_code, customer_name,
            loan_id, mode, amount, principal, interest, outstanding, flagged, reason,
            SUM(amount) OVER (
              PARTITION BY customer_id ORDER BY sort_key ASC, seq ASC, created_sort ASC, txn_id ASC
              ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
            ) AS cumulative
     ${base}
     WHERE 1=1${where}
     ORDER BY sort_key ASC, seq ASC, created_sort ASC, txn_id ASC
     LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, limit, offset]
  );
  return {
    rows: rows.rows.map((r: any) => {
      const flagged = r.flagged === true;
      return {
        date: isoDay(r.date),
        txnId: String(r.txn_id),
        kind: r.kind as 'disbursal' | 'payment',
        type: r.txn_type,
        customerId: String(r.customer_id),
        customerCode: r.customer_code || '',
        customerName: r.customer_name || '',
        loanId: r.loan_id ? String(r.loan_id) : null,
        paymentId: r.kind === 'payment' ? String(r.txn_id) : null,
        mode: r.mode || 'Cash',
        amount: num(r.amount),
        principal: num(r.principal),
        interest: num(r.interest),
        outstanding: num(r.outstanding),
        cumulative: num(r.cumulative),
        flagged,
        complianceStatus: flagged ? 'Threshold Reached — Review Required' : 'Compliant',
        reason: r.reason || null,
      };
    }),
    total,
  };
}

export interface CashDetail {
  kind: 'disbursal' | 'payment';
  customer: any;
  loan: any;
  payment: any;
  compliance: {
    threshold: number;
    cashAmount: number;
    fyCashBefore: number | null;
    fyCashAfter: number | null;
    outstandingBefore: number | null;
    flagged: boolean;
    reason: string | null;
    checkedAt: string;
  };
  audit: any;
}

export async function cashDetail(
  userId: string,
  kind: 'disbursal' | 'payment',
  id: string
): Promise<CashDetail | null> {
  const threshold = await getCashThreshold();
  if (kind === 'disbursal') {
    const r = await dbQuery(
      `SELECT l.*, c.customer_code, c.full_name, c.business_id, rb.name AS business_name,
              c.phone_number, c.address
       FROM loans l
       JOIN customers c ON c.id = l.customer_id AND c.user_id = l.user_id
       LEFT JOIN ref_business rb ON rb.id = c.business_id
       WHERE l.loan_id = $1 AND l.user_id = $2`,
      [id, userId]
    );
    if (r.rows.length === 0) return null;
    const loan = r.rows[0];
    const { checkDisbursalCompliance } = await import('./cash-compliance');
    const chk = checkDisbursalCompliance(
      { disbursal_mode: loan.disbursal_mode, loan_amount: loan.loan_amount },
      threshold
    );
    const audit = await dbQuery(
      `SELECT audit_id, action, created_at, performed_by, user_role, source, result, reason
       FROM audit_events
       WHERE entity_id = $1 AND action IN ('LOAN_CREATED', 'CASH_DISBURSAL_FLAGGED')
       ORDER BY seq DESC LIMIT 1`,
      [id]
    );
    return {
      kind,
      customer: {
        name: loan.full_name, code: loan.customer_code, business: loan.business_name,
        phone: loan.phone_number, address: loan.address,
      },
      loan: {
        id: loan.loan_id, date: isoDay(loan.loan_date), principal: num(loan.loan_amount),
        rate: num(loan.interest_rate), duration: loan.duration, total: num(loan.total_amount),
        mode: loan.disbursal_mode || null,
      },
      payment: null,
      compliance: {
        threshold, cashAmount: num(loan.loan_amount),
        fyCashBefore: null, fyCashAfter: null, outstandingBefore: null,
        flagged: loan.is_flagged === true, reason: loan.flag_reason || chk.reason,
        checkedAt: new Date().toISOString(),
      },
      audit: audit.rows[0] || null,
    };
  }
  const r = await dbQuery(
    `SELECT p.*, c.customer_code, c.full_name, c.business_id, rb.name AS business_name,
            c.phone_number, c.address,
            l.loan_date, l.loan_amount, l.interest_rate, l.duration, l.total_amount,
            l.disbursal_mode, l.balance_amount,
            COALESCE(l.total_amount, p.amount) - COALESCE((
              SELECT SUM(p2.amount) FROM payments p2
              WHERE p2.loan_id = p.loan_id AND p2.user_id = p.user_id
                AND (p2.payment_date < p.payment_date
                  OR (p2.payment_date = p.payment_date AND p2.payment_id < p.payment_id))
            ), 0) AS prev_outstanding
     FROM payments p
     JOIN customers c ON c.id = p.customer_id AND c.user_id = p.user_id
     LEFT JOIN ref_business rb ON rb.id = c.business_id
     LEFT JOIN loans l ON l.loan_id = p.loan_id AND l.user_id = p.user_id
     WHERE p.payment_id = $1 AND p.user_id = $2`,
    [id, userId]
  );
  if (r.rows.length === 0) return null;
  const pay = r.rows[0];
  const audit = await dbQuery(
    `SELECT audit_id, action, created_at, performed_by, user_role, source, result, reason
     FROM audit_events
     WHERE entity_id = $1 AND action IN ('PAYMENT_RECORDED', 'PAYMENT_CORRECTED', 'CASH_PAYMENT_FLAGGED')
     ORDER BY seq DESC LIMIT 1`,
    [id]
  );
  return {
    kind,
    customer: {
      name: pay.full_name, code: pay.customer_code, business: pay.business_name,
      phone: pay.phone_number, address: pay.address,
    },
    loan: pay.loan_id
      ? {
          id: pay.loan_id, date: isoDay(pay.loan_date), principal: num(pay.loan_amount),
          rate: num(pay.interest_rate), duration: pay.duration, total: num(pay.total_amount),
          mode: pay.disbursal_mode || null,
        }
      : null,
    payment: {
      id: pay.payment_id, date: isoDay(pay.payment_date), amount: num(pay.amount),
      mode: pay.payment_mode || pay.payment_method || 'Cash',
      prevOutstanding: num(pay.prev_outstanding),
      newOutstanding: Math.max(num(pay.prev_outstanding) - num(pay.amount), 0),
    },
    compliance: {
      threshold, cashAmount: num(pay.amount),
      fyCashBefore: null, fyCashAfter: null, outstandingBefore: num(pay.prev_outstanding),
      flagged: pay.is_flagged === true, reason: pay.flag_reason,
      checkedAt: new Date().toISOString(),
    },
    audit: audit.rows[0] || null,
  };
}
