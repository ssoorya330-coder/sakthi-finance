export type MetricKey =
  | 'amountGiven'
  | 'amountReceived'
  | 'interestEarned'
  | 'remainingBalance'
  | 'todayCollection'

export interface GraphMetric {
  key: MetricKey
  label: string
  color: string
}

export const GRAPH_METRICS: readonly GraphMetric[] = [
  { key: 'amountGiven', label: 'Amount Given', color: '#3B82F6' },
  { key: 'amountReceived', label: 'Amount Received', color: '#22C55E' },
  { key: 'interestEarned', label: 'Interest Earned', color: '#F97316' },
  { key: 'remainingBalance', label: 'Remaining Balance', color: '#EF4444' },
  { key: 'todayCollection', label: "Today's Collection", color: '#A855F7' },
] as const

export type RangeKey =
  | 'today'
  | 'yesterday'
  | 'last7'
  | 'last30'
  | 'last3m'
  | 'last6m'
  | 'last1y'
  | 'custom'

export interface GraphDateRange {
  start: Date
  end: Date
}

export type Granularity = 'daily' | 'monthly'

export interface GraphDataPoint {
  date: string
  label: string
  fullLabel: string
  amountGiven: number
  amountReceived: number
  interestEarned: number
  remainingBalance: number
  todayCollection: number
}

export interface GraphVisible {
  amountGiven: boolean
  amountReceived: boolean
  interestEarned: boolean
  remainingBalance: boolean
  todayCollection: boolean
}
