import { resolveCustomerId } from '@/server/customer-identity'
import { NextRequest, NextResponse } from 'next/server'
import { dbQuery, dbTransaction, ensureSchema } from '@/server/database'
import { normalizePhone } from '@/lib/phone'
import { requireAuthWithPermission, isCustomerOwnedBy } from '@/lib/api-utils'
import {
  actorFromAuthUser,
  requestMeta,
  recordAuditEvent,
  recordAuditStandalone,
  diffRecords,
  CUSTOMER_LABELS,
  LOAN_LABELS,
} from '@/server/audit'

async function resolveLookupId(table: string, name: string | null | undefined): Promise<number | null> {
  if (!name || !name.trim()) return null
  const trimmed = name.trim()
  const existing = await dbQuery(`SELECT id FROM ${table} WHERE name = $1`, [trimmed])
  if (existing.rows.length > 0) return existing.rows[0].id
  const inserted = await dbQuery(`INSERT INTO ${table} (name) VALUES ($1) ON CONFLICT (name) DO UPDATE SET name = EXCLUDED.name RETURNING id`, [trimmed])
  return inserted.rows[0].id
}

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuthWithPermission('customers:read');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const id = await resolveCustomerId((await params).id)
    // Owner-scoped: one account can never read another account's customer,
    // even by guessing its id. 404 (not 403) avoids leaking existence.
    if (!(await isCustomerOwnedBy(id, user.userId))) {
      return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
    }
    const result = await dbQuery(
      `SELECT c.*,
        ra.name AS area_name, rc.name AS city_name, rb.name AS business_name,
        l.loan_id, l.loan_date, l.due_date, l.loan_amount, l.interest_rate,
        l.interest_amount, l.total_amount, l.installment_amount, l.remaining_days,
        l.duration, l.loan_type, l.completed_at, l.aborted_at, l.abort_reason,
        l.notes AS loan_notes, l.status AS loan_status
      FROM customers c
      LEFT JOIN ref_area ra ON c.area_id = ra.id
      LEFT JOIN ref_city rc ON c.city_id = rc.id
      LEFT JOIN ref_business rb ON c.business_id = rb.id
      LEFT JOIN LATERAL (SELECT * FROM kanaku_loan_balances WHERE customer_id = c.id AND user_id = c.user_id ORDER BY cycle_number DESC, kanaku_number DESC LIMIT 1) l ON true
      WHERE c.id = $1`, [id]
    )
    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
    }
    return NextResponse.json(result.rows[0])
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to fetch customer', details: err.message },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuthWithPermission('customers:update');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const id = await resolveCustomerId((await params).id)
    const userId = user.userId
    // Owner-scoped: updates apply only to the caller's own customer.
    if (!(await isCustomerOwnedBy(id, userId))) {
      return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
    }
    const body = await request.json()
    const loanCount = await dbQuery('SELECT COUNT(*) AS count, (SELECT status FROM customers WHERE id=$1 AND user_id=$2) AS customer_status FROM loans WHERE customer_id = $1 AND user_id = $2', [id, userId])
    const multipleKanaku = Number(loanCount.rows[0].count) > 1
    if (multipleKanaku && body.status && body.status !== loanCount.rows[0].customer_status) {
      return NextResponse.json({ error: 'Manage statuses through the individual Kanaku; a customer status cannot complete or abort multiple loans.' }, { status: 409 })
    }
    if (multipleKanaku) delete body.status

    // Customer columns (customers table has no loan/status-timestamp columns;
    // those live on loans. customer_code is server-authoritative and immutable
    // after creation — never accept it from the client).
    const customerCols: Record<string, (v: any) => any> = {
      full_name: (v) => v,
      phone_number: (v) => v || null,
      alternate_phone: (v) => v || null,
      address: (v) => v || null,
      income: (v) => (v === '' || v === undefined ? null : Number(v) || 0),
      status: (v) => v,
    }

    // Loan columns
    const loanCols: Record<string, (v: any) => any> = {
      loan_date: (v) => v || null,
      due_date: (v) => v || null,
      loan_amount: (v) => (v === '' || v === undefined ? null : Number(v) || 0),
      interest_rate: (v) => (v === '' || v === undefined ? null : Number(v) || 0),
      interest_amount: (v) => (v === '' || v === undefined ? null : Number(v) || 0),
      total_amount: (v) => (v === '' || v === undefined ? null : Number(v) || 0),
      installment_amount: (v) => (v === '' || v === undefined ? null : Number(v) || 0),
      remaining_days: (v) => (v === '' || v === undefined ? null : Number(v) || 0),
      duration: (v) => (v === '' || v === undefined ? null : Number(v) || 0),
      loan_type: (v) => v || null,
      notes: (v) => v || null,
      abort_reason: (v) => v || null,
      completed_at: (v) => v || null,
      aborted_at: (v) => v || null,
    }

    // Build customer SET
    // The legacy customer editor is a profile editor for multi-Kanaku customers.
    // Never broadcast its single-loan form across historical loans.
    if (multipleKanaku) for (const field of Object.keys(loanCols)) delete body[field]
    const custSets: string[] = []
    const custValues: any[] = []
    let cIdx = 1
    for (const [col, normalize] of Object.entries(customerCols)) {
      if (Object.prototype.hasOwnProperty.call(body, col)) {
        custSets.push(`${col}=$${cIdx++}`)
        custValues.push(normalize(body[col]))
      }
    }

    // Handle lookup fields (area, city, business as strings → FK IDs)
    if (Object.prototype.hasOwnProperty.call(body, 'area') || Object.prototype.hasOwnProperty.call(body, 'area_name')) {
      const areaName = body.area_name || body.area
      const areaId = await resolveLookupId('ref_area', areaName)
      custSets.push(`area_id=$${cIdx++}`)
      custValues.push(areaId)
    }
    if (Object.prototype.hasOwnProperty.call(body, 'city') || Object.prototype.hasOwnProperty.call(body, 'city_name')) {
      const cityName = body.city_name || body.city
      const cityId = await resolveLookupId('ref_city', cityName)
      custSets.push(`city_id=$${cIdx++}`)
      custValues.push(cityId)
    }
    if (Object.prototype.hasOwnProperty.call(body, 'business') || Object.prototype.hasOwnProperty.call(body, 'business_name')) {
      const bizName = body.business_name || body.business
      const bizId = await resolveLookupId('ref_business', bizName)
      custSets.push(`business_id=$${cIdx++}`)
      custValues.push(bizId)
    }

    // Auto-stamp lives on loans.completed_at/aborted_at only (customers has
    // no such columns). Status itself is stored on both tables.

    // Before snapshot (owner-scoped) for the audit diff. Read just before
    // the write so the recorded before-values are accurate.
    const beforeRes = await dbQuery(
      `SELECT c.*,
        ra.name AS area_name, rc.name AS city_name, rb.name AS business_name,
        l.loan_id, l.loan_date, l.due_date, l.loan_amount, l.interest_rate,
        l.interest_amount, l.total_amount, l.installment_amount, l.remaining_days,
        l.duration, l.loan_type, l.completed_at, l.aborted_at, l.abort_reason,
        l.notes AS loan_notes, l.status AS loan_status
      FROM customers c
      LEFT JOIN ref_area ra ON c.area_id = ra.id
      LEFT JOIN ref_city rc ON c.city_id = rc.id
      LEFT JOIN ref_business rb ON c.business_id = rb.id
      LEFT JOIN LATERAL (SELECT * FROM kanaku_loan_balances WHERE customer_id = c.id AND user_id = c.user_id ORDER BY cycle_number DESC, kanaku_number DESC LIMIT 1) l ON true
      WHERE c.id = $1 AND c.user_id = $2`, [id, userId]
    )
    if (beforeRes.rows.length === 0) {
      return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
    }
    const beforeRow = beforeRes.rows[0]
    // Keep the canonical lookup number in sync whenever either phone field
    // changes; otherwise mobile matching would go stale after an edit.
    if (
      Object.prototype.hasOwnProperty.call(body, 'phone_number') ||
      Object.prototype.hasOwnProperty.call(body, 'alternate_phone')
    ) {
      const nextPrimary = Object.prototype.hasOwnProperty.call(body, 'phone_number')
        ? body.phone_number
        : beforeRow.phone_number
      const nextAlt = Object.prototype.hasOwnProperty.call(body, 'alternate_phone')
        ? body.alternate_phone
        : beforeRow.alternate_phone
      custSets.push(`phone_normalized=$${cIdx++}`)
      custValues.push(normalizePhone(nextPrimary) || normalizePhone(nextAlt) || null)
    }
    const customerBefore = {
      full_name: beforeRow.full_name, customer_code: beforeRow.customer_code,
      phone_number: beforeRow.phone_number, alternate_phone: beforeRow.alternate_phone,
      address: beforeRow.address, area_name: beforeRow.area_name,
      city_name: beforeRow.city_name, business_name: beforeRow.business_name,
      income: beforeRow.income, status: beforeRow.status,
    }
    const loanBefore = beforeRow.loan_id ? {
      loan_date: beforeRow.loan_date, due_date: beforeRow.due_date,
      loan_amount: beforeRow.loan_amount, interest_rate: beforeRow.interest_rate,
      interest_amount: beforeRow.interest_amount, total_amount: beforeRow.total_amount,
      installment_amount: beforeRow.installment_amount, remaining_days: beforeRow.remaining_days,
      duration: beforeRow.duration, loan_type: beforeRow.loan_type,
      notes: beforeRow.loan_notes, abort_reason: beforeRow.abort_reason,
      status: beforeRow.loan_status,
    } : null

    const meta = requestMeta(request)
    const actor = actorFromAuthUser(user)

    // Customer update + its audit event commit atomically: the change never
    // exists without its audit record.
    if (custSets.length > 0) {
      custSets.push(`updated_at=NOW()`)
      custValues.push(id, userId)
      await dbTransaction(async (tx) => {
        await tx.query(
          `UPDATE customers SET ${custSets.join(', ')} WHERE id=$${cIdx} AND user_id=$${cIdx + 1}`,
          custValues
        )
        const afterRes = await tx.query(
          `SELECT c.*,
            ra.name AS area_name, rc.name AS city_name, rb.name AS business_name
          FROM customers c
          LEFT JOIN ref_area ra ON c.area_id = ra.id
          LEFT JOIN ref_city rc ON c.city_id = rc.id
          LEFT JOIN ref_business rb ON c.business_id = rb.id
          WHERE c.id = $1 AND c.user_id = $2`, [id, userId]
        )
        const a = afterRes.rows[0]
        const customerAfter = {
          full_name: a.full_name, customer_code: a.customer_code,
          phone_number: a.phone_number, alternate_phone: a.alternate_phone,
          address: a.address, area_name: a.area_name,
          city_name: a.city_name, business_name: a.business_name,
          income: a.income, status: a.status,
        }
        const changes = diffRecords(customerBefore, customerAfter, Object.keys(customerBefore), CUSTOMER_LABELS)
        if (changes.length > 0) {
          const statusChanged = changes.some((c) => c.field === 'status')
          await recordAuditEvent(tx, {
            action: statusChanged ? 'CUSTOMER_STATUS_CHANGED' : 'CUSTOMER_UPDATED',
            entityType: 'customer',
            entityId: id,
            customerId: id,
            actor,
            ipAddress: meta.ip,
            clientInfo: meta.client,
            result: 'SUCCESS',
            changes,
            before: customerBefore,
            after: customerAfter,
          })
        }
      })
    }

    // Build loan SET
    const loanSets: string[] = []
    const loanValues: any[] = []
    let lIdx = 1
    for (const [col, normalize] of Object.entries(loanCols)) {
      if (Object.prototype.hasOwnProperty.call(body, col)) {
        loanSets.push(`${col}=$${lIdx++}`)
        loanValues.push(normalize(body[col]))
      }
    }
    if (body.status === 'Completed' && !Object.prototype.hasOwnProperty.call(body, 'completed_at')) {
      loanSets.push(`completed_at=COALESCE(completed_at, NOW())`)
    }
    if (body.status === 'Aborted' && !Object.prototype.hasOwnProperty.call(body, 'aborted_at')) {
      loanSets.push(`aborted_at=COALESCE(aborted_at, NOW())`)
    }
    if (body.status) {
      loanSets.push(`status=$${lIdx++}`)
      loanValues.push(body.status)
    }

    // Update loan (scoped to the caller's own loan for this customer)
    if (loanSets.length > 0) {
      loanSets.push(`updated_at=NOW()`)
      loanValues.push(id, userId)
      await dbQuery(
        `UPDATE loans SET ${loanSets.join(', ')} WHERE customer_id=$${lIdx} AND user_id=$${lIdx + 1} AND loan_id = (SELECT loan_id FROM kanaku_loan_balances WHERE customer_id=$${lIdx} AND user_id=$${lIdx + 1} ORDER BY cycle_number DESC, kanaku_number DESC LIMIT 1)`,
        loanValues
      ).catch(() => {})
    }

    // Fetch updated customer with joins (owner-scoped)
    const result = await dbQuery(
      `SELECT c.*,
        ra.name AS area_name, rc.name AS city_name, rb.name AS business_name,
        l.loan_id, l.loan_date, l.due_date, l.loan_amount, l.interest_rate,
        l.interest_amount, l.total_amount, l.installment_amount, l.remaining_days,
        l.duration, l.loan_type, l.completed_at, l.aborted_at, l.abort_reason,
        l.notes AS loan_notes, l.status AS loan_status
      FROM customers c
      LEFT JOIN ref_area ra ON c.area_id = ra.id
      LEFT JOIN ref_city rc ON c.city_id = rc.id
      LEFT JOIN ref_business rb ON c.business_id = rb.id
      LEFT JOIN LATERAL (SELECT * FROM kanaku_loan_balances WHERE customer_id = c.id AND user_id = c.user_id ORDER BY cycle_number DESC, kanaku_number DESC LIMIT 1) l ON true
      WHERE c.id = $1 AND c.user_id = $2`, [id, userId]
    )

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
    }

    // Loan-side audit (best-effort, standalone): the loan update above keeps
    // its original best-effort semantics, so its audit event is recorded
    // separately and can never break the customer update.
    if (loanSets.length > 0) {
      const r = result.rows[0]
      const loanAfter = r.loan_id ? {
        loan_date: r.loan_date, due_date: r.due_date,
        loan_amount: r.loan_amount, interest_rate: r.interest_rate,
        interest_amount: r.interest_amount, total_amount: r.total_amount,
        installment_amount: r.installment_amount, remaining_days: r.remaining_days,
        duration: r.duration, loan_type: r.loan_type,
        notes: r.loan_notes, abort_reason: r.abort_reason,
        status: r.loan_status,
      } : null
      const loanChanges = diffRecords(loanBefore, loanAfter, Object.keys(LOAN_LABELS), LOAN_LABELS)
      if (loanChanges.length > 0) {
        const st = loanChanges.find((c) => c.field === 'status')
        const action = st
          ? (String(st.after) === 'Completed' ? 'LOAN_COMPLETED' : 'LOAN_STATUS_CHANGED')
          : 'LOAN_UPDATED'
        await recordAuditStandalone({
          action,
          entityType: 'loan',
          entityId: r.loan_id,
          customerId: id,
          loanId: r.loan_id,
          actor,
          ipAddress: meta.ip,
          clientInfo: meta.client,
          result: 'SUCCESS',
          changes: loanChanges,
          before: loanBefore,
          after: loanAfter,
        })
      }
    }

    await dbQuery(
      `INSERT INTO audit_logs (action, entity_type, entity_id, details, user_id) VALUES ($1,$2,$3,$4,$5)`,
      ['update', 'customer', id, JSON.stringify({ full_name: body.full_name ?? result.rows[0]?.full_name }), userId]
    ).catch(() => {})

    return NextResponse.json(result.rows[0])
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to update customer', details: err.message },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuthWithPermission('customers:delete');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const id = await resolveCustomerId((await params).id)
    const userId = user.userId
    // Owner-scoped delete: 404 unless the row belongs to the caller, so one
    // account can neither delete nor probe another account's customers.
    const before = await dbQuery(
      `SELECT c.*, ra.name AS area_name, rc.name AS city_name, rb.name AS business_name
       FROM customers c
       LEFT JOIN ref_area ra ON c.area_id = ra.id
       LEFT JOIN ref_city rc ON c.city_id = rc.id
       LEFT JOIN ref_business rb ON c.business_id = rb.id
       WHERE c.id = $1 AND c.user_id = $2`, [id, userId]
    )
    if (before.rows.length === 0) {
      return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
    }
    const b = before.rows[0]
    const meta = requestMeta(request)
    const actor = actorFromAuthUser(user)
    // Delete + deletion audit commit atomically.
    await dbTransaction(async (tx) => {
      const result = await tx.query('DELETE FROM customers WHERE id = $1 AND user_id = $2 RETURNING id, full_name', [id, userId])
      if (result.rows.length === 0) {
        throw Object.assign(new Error('Customer not found'), { statusCode: 404 })
      }
      await recordAuditEvent(tx, {
        action: 'CUSTOMER_DELETED',
        entityType: 'customer',
        entityId: id,
        customerId: id,
        actor,
        ipAddress: meta.ip,
        clientInfo: meta.client,
        result: 'SUCCESS',
        changes: [{ field: 'customer', label: 'Customer', before: `${b.full_name} (${b.customer_code})`, after: null }],
        before: {
          full_name: b.full_name, customer_code: b.customer_code,
          phone_number: b.phone_number, address: b.address,
          area_name: b.area_name, city_name: b.city_name,
          business_name: b.business_name, income: b.income, status: b.status,
        },
        after: null,
      })
    })
    await dbQuery(
      `INSERT INTO audit_logs (action, entity_type, entity_id, user_id) VALUES ($1,$2,$3,$4)`,
      ['delete', 'customer', id, userId]
    ).catch(() => {})
    return NextResponse.json({ success: true, id })
  } catch (err: any) {
    if ((err as any)?.statusCode === 404) {
      return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
    }
    return NextResponse.json(
      { error: /history cannot be deleted/i.test(err.message || '')
        ? 'This customer has protected loan or payment history and cannot be permanently deleted. No records were removed.'
        : 'Failed to delete customer. No records were removed.', details: err.message },
      { status: /history cannot be deleted/i.test(err.message || '') ? 409 : 500 }
    )
  }
}

