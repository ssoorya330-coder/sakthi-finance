'use client';

import { cn } from '@/lib/utils';

interface AuthDividerProps {
  text?: string;
  className?: string;
}

export default function AuthDivider({ text = 'or', className }: AuthDividerProps) {
  return (
    <div className={cn('flex items-center gap-4', className)}>
      <div className="flex-1 h-px bg-border-subtle" />
      <span className="text-[12px] font-medium text-text-muted uppercase tracking-wider">
        {text}
      </span>
      <div className="flex-1 h-px bg-border-subtle" />
    </div>
  );
}
