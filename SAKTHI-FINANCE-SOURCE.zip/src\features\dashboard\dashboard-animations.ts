import type { Variants, Transition } from 'framer-motion'

export const chartTransition: Transition = {
  duration: 1.2,
  ease: [0.16, 1, 0.3, 1],
}

export const staggerContainer: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.06,
      delayChildren: 0.1,
    },
  },
}

export const staggerItem: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] },
  },
}

export const fadeInUp: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] },
  },
}

export const scaleIn: Variants = {
  hidden: { opacity: 0, scale: 0.96 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.15, ease: [0.16, 1, 0.3, 1] },
  },
}

export const microInteraction = {
  whileHover: { scale: 1.05, y: -2 },
  whileTap: { scale: 0.97 },
  transition: { duration: 0.18, ease: [0.16, 1, 0.3, 1] },
}

export const cardHover = {
  whileHover: {
    boxShadow: '0 4px 16px rgba(0,0,0,0.06), 0 8px 24px rgba(0,0,0,0.04)',
    y: -2,
  },
  transition: { duration: 0.3, ease: [0.16, 1, 0.3, 1] },
}

export const chartAnimationProps = {
  isAnimationActive: true,
  animationDuration: 1200,
  animationEasing: 'ease-out' as const,
  animationBegin: 300,
}

export const barAnimationProps = {
  isAnimationActive: true,
  animationDuration: 1200,
  animationEasing: 'ease-out' as const,
  animationBegin: 200,
}

export const pieAnimationProps = {
  isAnimationActive: true,
  animationDuration: 1200,
  animationEasing: 'ease-out' as const,
  animationBegin: 200,
}

export const tooltipVariants: Variants = {
  hidden: { opacity: 0, scale: 0.96 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.15, ease: [0.16, 1, 0.3, 1] },
  },
  exit: {
    opacity: 0,
    scale: 0.96,
    transition: { duration: 0.1 },
  },
}

export const filterButtonTransition = 'all 180ms ease'

export const gridLineProps = {
  stroke: '#F1F5F9',
  strokeDasharray: '3 3',
  vertical: false,
}

export const axisProps = {
  tick: { fontSize: 11, fill: '#94A3B8' },
  axisLine: false,
  tickLine: false,
}
