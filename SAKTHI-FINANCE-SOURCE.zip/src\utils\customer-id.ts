export function generateCustomerId(number: number): string {
  return String(number).padStart(3, '0')
}

/** Human-facing number; never expose a database UUID as a fallback. */
export function formatCustomerCode(code?: string | null): string {
  const match = String(code || '').match(/^(?:CUST-)?(\d+)$/i)
  return match ? match[1].replace(/^0+(?=\d)/, '').padStart(3, '0') : '—'
}
