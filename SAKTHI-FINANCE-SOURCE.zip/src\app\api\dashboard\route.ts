import { NextRequest, NextResponse } from 'next/server'
import { dbQuery } from '@/server/database'
import { requireAuthWithPermission } from '@/lib/api-utils'

export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('dashboard:read');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const userId = user.userId
    const today = new Date().toISOString().split('T')[0]

    const userFilter = userId ? ' AND user_id = $1' : ''
    const userParams = userId ? [userId] : []

    const [customers, todayCollection, loanAgg] = await Promise.all([
      dbQuery(
        `SELECT COUNT(*) as total,
          COUNT(*) FILTER (WHERE status = 'Active') as active,
          COUNT(*) FILTER (WHERE status = 'Completed') as completed,
          COUNT(*) FILTER (WHERE status = 'Aborted') as aborted
        FROM customers WHERE 1=1${userFilter}`,
        userParams
      ),
      dbQuery(
        `SELECT COALESCE(SUM(amount), 0) as today_total FROM daily_collection WHERE collection_date = $1${userId ? ' AND user_id = $2' : ''}`,
        userId ? [today, userId] : [today]
      ),
      dbQuery(
        `SELECT
          COALESCE(SUM(loan_amount), 0) as total_loan_amount,
          COALESCE(SUM(interest_amount), 0) as total_interest,
          COALESCE(SUM(total_amount), 0) as total_amount,
          COALESCE(SUM(balance_amount), 0) as pending,
          COALESCE(SUM(received_amount), 0) as received
        FROM kanaku_loan_balances WHERE 1=1${userFilter}`,
        userParams
      ),
    ])

    return NextResponse.json({
      totalCustomers: parseInt(customers.rows[0].total, 10),
      activeCustomers: parseInt(customers.rows[0].active, 10),
      completedCustomers: parseInt(customers.rows[0].completed, 10),
      abortedCustomers: parseInt(customers.rows[0].aborted, 10),
      totalLoanAmount: parseFloat(loanAgg.rows[0].total_loan_amount),
      totalInterest: parseFloat(loanAgg.rows[0].total_interest),
      totalAmount: parseFloat(loanAgg.rows[0].total_amount),
      todayCollection: parseFloat(todayCollection.rows[0].today_total),
      pendingCollection: parseFloat(loanAgg.rows[0].pending),
      receivedAmount: parseFloat(loanAgg.rows[0].received),
    })
  } catch (err: any) {
    console.error('[GET /api/dashboard] Error:', err.message)
    return NextResponse.json(
      { error: 'Failed to fetch dashboard data', details: err.message },
      { status: 500 }
    )
  }
}
