import { cp, mkdir, access } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..')

// Exported separately so exclusion rules can be regression-tested without copying data.
export function allowedResource(relative) {
  return !relative.split(/[\\/]/).some(part =>
    part.startsWith('.env') || part.startsWith('__recovery') || ['.git', '.backups', 'certificates', 'src-tauri', 'desktop-staging', 'test-reports', '.codex', '.claude'].includes(part) ||
    /\.(pem|key|pfx|p12|sql|dump|backup)$/i.test(part))
}

export async function stageServer() {
  const source = path.join(root, '.next/standalone')
  await access(path.join(source, 'server.js'))
  await access(path.join(root, '.next/BUILD_ID'))
  // Always a new folder: never overwrite a previous release or the live application.
  const destination = path.join(root, 'desktop-staging', new Date().toISOString().replace(/[:.]/g, '-'))
  await mkdir(path.dirname(destination), { recursive: true })
  await mkdir(destination, { recursive: false })
  await cp(source, path.join(destination, 'server'), {
    recursive: true,
    dereference: true,
    filter: sourcePath => allowedResource(path.relative(source, sourcePath)),
  })
  await cp(path.join(root, '.next/static'), path.join(destination, 'server/.next/static'), { recursive: true })
  await cp(path.join(root, 'public'), path.join(destination, 'server/public'), {
    recursive: true,
    filter: sourcePath => allowedResource(path.relative(path.join(root, 'public'), sourcePath)),
  })
  console.log(`Staged application files at ${destination}. Not a validated desktop release.`)
  return destination
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  await mkdir(path.join(root, 'desktop-staging'), { recursive: true })
  await stageServer()
}
