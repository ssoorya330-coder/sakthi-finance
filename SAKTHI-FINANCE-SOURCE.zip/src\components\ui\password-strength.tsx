'use client';

import { cn } from '@/lib/utils';

interface PasswordStrengthProps {
  password: string;
}

const segments = [
  { label: 'Weak', min: 0, color: 'bg-error' },
  { label: 'Fair', min: 1, color: 'bg-warning' },
  { label: 'Good', min: 2, color: 'bg-gold-400' },
  { label: 'Strong', min: 3, color: 'bg-success' },
];

function getStrength(pw: string): number {
  if (!pw) return 0;
  let s = 0;
  if (pw.length >= 8) s++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return s;
}

export default function PasswordStrength({ password }: PasswordStrengthProps) {
  const strength = getStrength(password);
  const active = segments.filter((_, i) => i < strength);
  const seg = strength > 0 ? segments[strength - 1] : null;

  return (
    <div className="space-y-1.5">
      <div className="flex gap-1.5">
        {segments.map((s, i) => (
          <div
            key={s.label}
            className={cn(
              'h-[3px] flex-1 rounded-full transition-all duration-500',
              i < strength ? s.color : 'bg-border-subtle',
            )}
          />
        ))}
      </div>
      {strength > 0 && seg && (
        <p
          className={cn(
            'text-[11px] font-medium transition-colors',
            seg.color === 'bg-error' && 'text-error',
            seg.color === 'bg-warning' && 'text-warning',
            seg.color === 'bg-gold-400' && 'text-gold-400',
            seg.color === 'bg-success' && 'text-success',
          )}
        >
          {seg.label}
        </p>
      )}
    </div>
  );
}
