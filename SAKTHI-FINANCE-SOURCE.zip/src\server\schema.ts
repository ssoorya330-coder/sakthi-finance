﻿import { getPool } from './database';

export async function initializeDatabase(): Promise<void> {
  console.log('[Schema] Initializing database tables...');

  await getPool().query(`CREATE EXTENSION IF NOT EXISTS "pgcrypto";`);
  await getPool().query(`CREATE EXTENSION IF NOT EXISTS "uuid-ossp";`);

  // ───────── ENUMS ─────────
  await getPool().query(`DO $$ BEGIN
    CREATE TYPE customer_status AS ENUM ('Active','Completed','Overdue','Aborted');
  EXCEPTION WHEN duplicate_object THEN null; END $$;`);

  await getPool().query(`DO $$ BEGIN
    CREATE TYPE loan_type_enum AS ENUM ('Daily','Weekly','Monthly','Yearly');
  EXCEPTION WHEN duplicate_object THEN null; END $$;`);

  await getPool().query(`DO $$ BEGIN
    CREATE TYPE payment_method_enum AS ENUM ('Cash','UPI','Bank Transfer','Cheque','Other');
  EXCEPTION WHEN duplicate_object THEN null; END $$;`);

  // ───────── LOOKUP TABLES ─────────
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS ref_area (
      id SMALLSERIAL PRIMARY KEY,
      name VARCHAR(60) UNIQUE NOT NULL
    );
  `);
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS ref_city (
      id SMALLSERIAL PRIMARY KEY,
      name VARCHAR(60) UNIQUE NOT NULL
    );
  `);
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS ref_business (
      id SMALLSERIAL PRIMARY KEY,
      name VARCHAR(80) UNIQUE NOT NULL
    );
  `);

  // ───────── ROLES ─────────
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS roles (
      role_id SERIAL PRIMARY KEY,
      role_name VARCHAR(20) UNIQUE NOT NULL
    );
  `);

  // Seed roles (idempotent). Canonical roles: owner, admin, employee,
  // viewer, customer. `manager` is legacy (kept, user asked to leave it
  // as-is). `collector` is legacy and migrated to `employee` below — never
  // seed new collector rows, the value must not survive in the database.
  await getPool().query(`
    INSERT INTO roles (role_name) VALUES ('owner'), ('admin'), ('manager'), ('employee'), ('viewer'), ('customer')
    ON CONFLICT (role_name) DO NOTHING;
  `);

  // Migrate legacy `collector` → `employee` in roles + users (real DB value
  // change, not a UI label). Idempotent: safe to run on every boot.
  try {
    const collectorRole = await getPool().query(
      "SELECT role_id FROM roles WHERE role_name = 'collector'"
    );
    if (collectorRole.rows.length > 0) {
      const employeeRole = await getPool().query(
        "SELECT role_id FROM roles WHERE role_name = 'employee'"
      );
      const employeeId = employeeRole.rows[0]?.role_id;
      if (employeeId) {
        await getPool().query('UPDATE users SET role_id = $1 WHERE role_id = $2', [
          employeeId,
          collectorRole.rows[0].role_id,
        ]).catch(() => {});
        await getPool().query(
          'DELETE FROM role_permissions WHERE role_id = $1',
          [collectorRole.rows[0].role_id]
        ).catch(() => {});
        await getPool().query("DELETE FROM roles WHERE role_name = 'collector'").catch(() => {});
        console.log('[Schema] Migrated role collector -> employee');
      }
    }
    await getPool().query("UPDATE users SET role = 'employee' WHERE role = 'collector'").catch(() => {});
  } catch (e: any) {
    console.warn('[Schema] collector->employee migration failed:', e.message);
  }

  // ───────── PERMISSIONS ─────────
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS permissions (
      permission_id SERIAL PRIMARY KEY,
      permission_name VARCHAR(50) UNIQUE NOT NULL
    );
  `);

  // Seed all permissions (idempotent). `security:manage` is Owner-only and
  // is deliberately NOT granted to admin by the blanket admin seed below.
  const allPermissions = [
    'dashboard:read',
    'customers:read', 'customers:create', 'customers:update', 'customers:delete', 'customers:read_all',
    'loans:read', 'loans:create', 'loans:update', 'loans:delete',
    'payments:read', 'payments:create', 'payments:update', 'payments:delete',
    'collections:read', 'collections:create',
    'reports:read', 'reports:export',
    'users:manage', 'audit:read', 'settings:manage', 'security:manage',
  ];
  for (const perm of allPermissions) {
    await getPool().query(
      'INSERT INTO permissions (permission_name) VALUES ($1) ON CONFLICT (permission_name) DO NOTHING',
      [perm]
    );
  }

  // ───────── ROLE_PERMISSIONS (join table) ─────────
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS role_permissions (
      role_id INTEGER REFERENCES roles(role_id) ON DELETE CASCADE,
      permission_id INTEGER REFERENCES permissions(permission_id) ON DELETE CASCADE,
      PRIMARY KEY (role_id, permission_id)
    );
  `);

  // Seed role_permissions (idempotent). Admin receives every permission
  // EXCEPT Owner-only `security:manage`.
  await getPool().query(`
    WITH role_ids AS (SELECT role_id FROM roles),
    perm_ids AS (SELECT permission_id, permission_name FROM permissions)
    INSERT INTO role_permissions (role_id, permission_id)
    SELECT r.role_id, p.permission_id
    FROM role_ids r, perm_ids p
    WHERE r.role_id = (SELECT role_id FROM roles WHERE role_name = 'admin')
      AND p.permission_name <> 'security:manage'
    ON CONFLICT DO NOTHING;
  `);
  // Manager permissions
  const managerPerms = [
    'dashboard:read', 'customers:read', 'customers:create', 'customers:update', 'customers:read_all',
    'loans:read', 'loans:create', 'loans:update',
    'payments:read', 'payments:create',
    'collections:read', 'collections:create',
    'reports:read',
  ];
  for (const perm of managerPerms) {
    await getPool().query(`
      INSERT INTO role_permissions (role_id, permission_id)
      SELECT r.role_id, p.permission_id FROM roles r, permissions p
      WHERE r.role_name = 'manager' AND p.permission_name = $1
      ON CONFLICT DO NOTHING;
    `, [perm]);
  }
  // Owner permissions = full access (same set as admin seed below).
  await getPool().query(`
    WITH role_ids AS (SELECT role_id FROM roles),
    perm_ids AS (SELECT permission_id, permission_name FROM permissions)
    INSERT INTO role_permissions (role_id, permission_id)
    SELECT r.role_id, p.permission_id
    FROM role_ids r, perm_ids p
    WHERE r.role_id = (SELECT role_id FROM roles WHERE role_name = 'owner')
    ON CONFLICT DO NOTHING;
  `);
  // Employee permissions (field staff can add customers; the Add Customer
  // page is visible to employees. New self-registered Google accounts
  // provision as customer; staff accounts are pre-provisioned by an admin.
  // update/delete are safe to grant because every route enforces
  // user_id = session user (own records only).
  // Idempotent: ON CONFLICT DO NOTHING backfills existing databases on restart.
  const collectorPerms = [
    'dashboard:read', 'customers:read', 'customers:create', 'customers:update', 'customers:delete',
    'loans:read', 'loans:create', 'loans:update',
    'payments:create', 'payments:read',
    'collections:read', 'collections:create',
    'reports:read',
  ];
  for (const perm of collectorPerms) {
    await getPool().query(`
      INSERT INTO role_permissions (role_id, permission_id)
      SELECT r.role_id, p.permission_id FROM roles r, permissions p
      WHERE r.role_name = 'employee' AND p.permission_name = $1
      ON CONFLICT DO NOTHING;
    `, [perm]);
  }
  // Viewer permissions: read-only.
  const viewerPerms = [
    'dashboard:read', 'customers:read',
    'loans:read', 'payments:read',
    'collections:read', 'reports:read',
  ];
  for (const perm of viewerPerms) {
    await getPool().query(`
      INSERT INTO role_permissions (role_id, permission_id)
      SELECT r.role_id, p.permission_id FROM roles r, permissions p
      WHERE r.role_name = 'viewer' AND p.permission_name = $1
      ON CONFLICT DO NOTHING;
    `, [perm]);
  }
  // Customer permissions: own-data read-only (same scope as viewer; every
  // business route additionally enforces user_id = session user).
  for (const perm of viewerPerms) {
    await getPool().query(`
      INSERT INTO role_permissions (role_id, permission_id)
      SELECT r.role_id, p.permission_id FROM roles r, permissions p
      WHERE r.role_name = 'customer' AND p.permission_name = $1
      ON CONFLICT DO NOTHING;
    `, [perm]);
  }

  // ───────── USERS ─────────
  // Local application users. Supabase Auth is the identity provider; the
  // local row links via supabase_user_id (Supabase auth.users.id). Email is
  // NOT the permanent identity key.
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS users (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id VARCHAR(100) UNIQUE,
      supabase_user_id VARCHAR(100) UNIQUE,
      email VARCHAR(255) UNIQUE,
      full_name VARCHAR(100),
      role VARCHAR(20) DEFAULT 'employee',
      role_id INTEGER REFERENCES roles(role_id),
      is_active BOOLEAN DEFAULT true,
      avatar_url TEXT,
      google_id VARCHAR(255) UNIQUE,
      google_email VARCHAR(255),
      provider VARCHAR(20) DEFAULT 'email',
      last_login_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // Non-destructive migration: add new columns if they don't exist
  try {
    const cols = await getPool().query(
      "SELECT column_name FROM information_schema.columns WHERE table_name = 'users'"
    );
    const existing = new Set(cols.rows.map((r: any) => r.column_name));
    if (!existing.has('google_id')) {
      await getPool().query('ALTER TABLE users ADD COLUMN google_id VARCHAR(255) UNIQUE');
    }
    if (!existing.has('google_email')) {
      await getPool().query('ALTER TABLE users ADD COLUMN google_email VARCHAR(255)');
    }
    if (!existing.has('provider')) {
      await getPool().query("ALTER TABLE users ADD COLUMN provider VARCHAR(20) DEFAULT 'email'");
    }
    if (!existing.has('role_id')) {
      await getPool().query('ALTER TABLE users ADD COLUMN role_id INTEGER REFERENCES roles(role_id)');
    }
    if (!existing.has('is_active')) {
      await getPool().query('ALTER TABLE users ADD COLUMN is_active BOOLEAN DEFAULT true');
    }
    if (!existing.has('last_login_at')) {
      await getPool().query('ALTER TABLE users ADD COLUMN last_login_at TIMESTAMPTZ');
    }
    if (!existing.has('supabase_user_id')) {
      await getPool().query('ALTER TABLE users ADD COLUMN supabase_user_id VARCHAR(100) UNIQUE');
    }
    if (!existing.has('customer_id')) {
      // Links a customer-role login to exactly one customers.id row.
      await getPool().query('ALTER TABLE users ADD COLUMN customer_id VARCHAR(100)');
    }
  } catch (e: any) {
    console.warn('[Schema] Users migration check failed:', e.message);
  }

  // Migrate existing role values to role_id
  try {
    await getPool().query(`
      UPDATE users SET role_id = (SELECT role_id FROM roles WHERE role_name = users.role)
      WHERE role_id IS NULL
    `);
  } catch (e: any) {
    console.warn('[Schema] Role migration failed:', e.message);
  }

  // ───────── CUSTOMERS (optimized) ─────────
  // NOTE: customer_code is unique PER ACCOUNT (user_id, customer_code), not
  // globally — every account has its own 001, 002, ... sequence. Databases
  // created by older schema versions are migrated just below.
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS customers (
      id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
      customer_code VARCHAR(6) NOT NULL,
      full_name VARCHAR(100) NOT NULL,
      phone_number VARCHAR(15),
      alternate_phone VARCHAR(15),
      address TEXT,
      area_id SMALLINT REFERENCES ref_area(id),
      city_id SMALLINT REFERENCES ref_city(id),
      business_id SMALLINT REFERENCES ref_business(id),
      income NUMERIC(10,2) DEFAULT 0,
      status VARCHAR(20) DEFAULT 'Active',
      user_id VARCHAR(100),
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW(),
      CONSTRAINT customers_user_code_key UNIQUE (user_id, customer_code)
    );
  `);

  // Customer OTP login support (idempotent, non-destructive).
  // UUID databases are converted explicitly by the verified migration script.
  // Keep startup compatible until that migration commits.
  const customerIdType = (await getPool().query(`SELECT data_type FROM information_schema.columns
    WHERE table_schema='public' AND table_name='customers' AND column_name='id'`)).rows[0]?.data_type === 'uuid' ? 'UUID' : 'BIGINT';
  await getPool().query(`CREATE TABLE IF NOT EXISTS customer_id_mappings (
    legacy_id UUID PRIMARY KEY, customer_id BIGINT NOT NULL UNIQUE, customer_code TEXT, user_id TEXT
  )`);
  try {
    const ccols = await getPool().query(
      "SELECT column_name FROM information_schema.columns WHERE table_name = 'customers'"
    );
    const cexisting = new Set(ccols.rows.map((r: any) => r.column_name));
    if (!cexisting.has('phone_normalized')) {
      await getPool().query('ALTER TABLE customers ADD COLUMN phone_normalized VARCHAR(15)');
    }
    if (!cexisting.has('phone_verified')) {
      await getPool().query('ALTER TABLE customers ADD COLUMN phone_verified BOOLEAN DEFAULT false');
    }
    // Backfill canonical 10-digit numbers from phone_number (fallback:
    // alternate_phone). Pure formatting — no data loss.
    await getPool().query(`
      UPDATE customers SET phone_normalized = (
        SELECT CASE
          WHEN LENGTH(REGEXP_REPLACE(COALESCE(phone_number, ''), '\\D', '', 'g')) = 12
               AND REGEXP_REPLACE(COALESCE(phone_number, ''), '\\D', '', 'g') LIKE '91%'
            THEN RIGHT(REGEXP_REPLACE(COALESCE(phone_number, ''), '\\D', '', 'g'), 10)
          WHEN LENGTH(REGEXP_REPLACE(COALESCE(phone_number, ''), '\\D', '', 'g')) = 11
               AND REGEXP_REPLACE(COALESCE(phone_number, ''), '\\D', '', 'g') LIKE '0%'
            THEN RIGHT(REGEXP_REPLACE(COALESCE(phone_number, ''), '\\D', '', 'g'), 10)
          WHEN REGEXP_REPLACE(COALESCE(phone_number, ''), '\\D', '', 'g') ~ '^[6-9][0-9]{9}$'
            THEN REGEXP_REPLACE(COALESCE(phone_number, ''), '\\D', '', 'g')
          WHEN REGEXP_REPLACE(COALESCE(alternate_phone, ''), '\\D', '', 'g') ~ '^[6-9][0-9]{9}$'
            THEN REGEXP_REPLACE(COALESCE(alternate_phone, ''), '\\D', '', 'g')
          ELSE NULL END
      ) WHERE phone_normalized IS NULL
    `).catch(() => {});
    await getPool().query(
      'CREATE INDEX IF NOT EXISTS idx_customers_phone_normalized ON customers(phone_normalized)'
    ).catch(() => {});
    await getPool().query(
      'CREATE INDEX IF NOT EXISTS idx_users_customer_id ON users(customer_id)'
    ).catch(() => {});
  } catch (e: any) {
    console.warn('[Schema] Customer OTP columns check failed:', e.message);
  }

  // OTP was removed from the customer flow (Google auth + mobile-number
  // linking instead). Drop the never-shipped one-time table if present.
  await getPool().query(`DROP TABLE IF EXISTS customer_otps;`).catch((e: any) => {
    console.warn('[Schema] customer_otps drop check failed:', e.message);
  });
  try {
    await getPool().query(
      'DROP INDEX IF EXISTS idx_customer_otps_phone'
    );
  } catch {}

  // ───────── LOANS (normalized) ─────────
  // NOTE: this is the full column union used by the API. Databases created by
  // older schema versions are patched by the migration just below.
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS loans (
      loan_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      customer_id ${customerIdType} NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
      loan_date DATE,
      due_date DATE,
      loan_amount NUMERIC(10,2) NOT NULL DEFAULT 0,
      interest_rate NUMERIC(4,2) DEFAULT 0,
      interest_amount NUMERIC(10,2) DEFAULT 0,
      total_amount NUMERIC(10,2) DEFAULT 0,
      installment NUMERIC(10,2) DEFAULT 0,
      installment_amount NUMERIC(10,2) DEFAULT 0,
      balance_amount NUMERIC(10,2) DEFAULT 0,
      received_amount NUMERIC(10,2) DEFAULT 0,
      remaining_days SMALLINT DEFAULT 0,
      duration SMALLINT DEFAULT 0,
      loan_type VARCHAR(20) DEFAULT 'Daily',
      status VARCHAR(20) DEFAULT 'Active',
      completed_at TIMESTAMPTZ,
      aborted_at TIMESTAMPTZ,
      abort_reason TEXT,
      notes TEXT,
      disbursal_mode VARCHAR(10),
      is_flagged BOOLEAN NOT NULL DEFAULT false,
      flag_reason TEXT,
      user_id VARCHAR(100),
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // Migration: older databases have a loans table missing detail columns
  // (loan_date, interest_amount, notes, ...). Without them every Add Customer
  // save fails with HTTP 500 (Postgres 42703 undefined_column). Add-only and
  // idempotent — existing rows are never modified or deleted.
  try {
    const loansNeeded: Array<[string, string]> = [
      ['loan_date', 'DATE'],
      ['due_date', 'DATE'],
      ['interest_amount', 'NUMERIC(10,2) DEFAULT 0'],
      ['installment', 'NUMERIC(10,2) DEFAULT 0'],
      ['installment_amount', 'NUMERIC(10,2) DEFAULT 0'],
      ['balance_amount', 'NUMERIC(10,2) DEFAULT 0'],
      ['received_amount', 'NUMERIC(10,2) DEFAULT 0'],
      ['remaining_days', 'SMALLINT DEFAULT 0'],
      ['completed_at', 'TIMESTAMPTZ'],
      ['aborted_at', 'TIMESTAMPTZ'],
      ['abort_reason', 'TEXT'],
      ['notes', 'TEXT'],
      ['status', "VARCHAR(20) DEFAULT 'Active'"],
      ['user_id', 'VARCHAR(100)'],
      ['disbursal_mode', 'VARCHAR(10)'],
      ['is_flagged', 'BOOLEAN NOT NULL DEFAULT false'],
      ['flag_reason', 'TEXT'],
    ];
    for (const [col, def] of loansNeeded) {
      await getPool().query(`ALTER TABLE loans ADD COLUMN IF NOT EXISTS ${col} ${def}`);
    }
  } catch (e: any) {
    console.warn('[Schema] Loans column migration failed:', e.message);
  }

  // ───────── PAYMENTS (compact) ─────────
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS payments (
      payment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      loan_id UUID,
      customer_id ${customerIdType} NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
      amount NUMERIC(10,2) NOT NULL DEFAULT 0,
      payment_date DATE NOT NULL,
      payment_time TIME,
      payment_method VARCHAR(20) DEFAULT 'Cash',
      payment_mode VARCHAR(10),
      is_flagged BOOLEAN NOT NULL DEFAULT false,
      flag_reason TEXT,
      remarks TEXT,
      user_id VARCHAR(100),
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // Cash-compliance columns on existing databases. Add-only and idempotent;
  // existing rows keep NULL modes (reported as Cash for payments via
  // COALESCE, Unknown for loan disbursals — never fabricated).
  try {
    const cashCols: Array<[string, string, string]> = [
      ['payments', 'payment_mode', 'VARCHAR(10)'],
      ['payments', 'is_flagged', 'BOOLEAN NOT NULL DEFAULT false'],
      ['payments', 'flag_reason', 'TEXT'],
    ];
    for (const [table, col, def] of cashCols) {
      await getPool().query(`ALTER TABLE ${table} ADD COLUMN IF NOT EXISTS ${col} ${def}`);
    }
  } catch (e: any) {
    console.warn('[Schema] Cash-compliance column migration failed:', e.message);
  }

  // Make payments.loan_id nullable if needed
  try {
    await getPool().query('ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_loan_id_fkey');
    const loanCol = await getPool().query(
      "SELECT is_nullable FROM information_schema.columns WHERE table_name='payments' AND column_name='loan_id'"
    );
    if (loanCol.rows.length > 0 && loanCol.rows[0].is_nullable === 'NO') {
      await getPool().query('ALTER TABLE payments ALTER COLUMN loan_id DROP NOT NULL');
    }
  } catch {}

  // ───────── DAILY COLLECTION ─────────
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS daily_collection (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      collection_date DATE NOT NULL,
      customer_id ${customerIdType} NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
      amount NUMERIC(10,2) NOT NULL DEFAULT 0,
      payment_method VARCHAR(20) DEFAULT 'Cash',
      remarks TEXT,
      user_id VARCHAR(100),
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // ───────── REPORTS ─────────
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS reports (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      report_type VARCHAR(20) NOT NULL CHECK (report_type IN ('Daily','Weekly','Monthly','Yearly')),
      report_date DATE NOT NULL,
      total_collection NUMERIC(10,2) DEFAULT 0,
      total_customers SMALLINT DEFAULT 0,
      active_customers SMALLINT DEFAULT 0,
      completed_customers SMALLINT DEFAULT 0,
      total_loans NUMERIC(10,2) DEFAULT 0,
      total_revenue NUMERIC(10,2) DEFAULT 0,
      data JSONB DEFAULT '{}'::jsonb,
      user_id VARCHAR(100),
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // ───────── SETTINGS ─────────
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS settings (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      key VARCHAR(100) UNIQUE NOT NULL,
      value TEXT,
      category VARCHAR(50) DEFAULT 'general',
      user_id VARCHAR(100),
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // ───────── NOTIFICATIONS ─────────
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS notifications (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      type VARCHAR(20) DEFAULT 'info',
      title VARCHAR(255) NOT NULL,
      message TEXT,
      is_read BOOLEAN DEFAULT false,
      user_id VARCHAR(100),
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // ───────── AUDIT LOGS (legacy, kept untouched) ─────────
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS audit_logs (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      action VARCHAR(50) NOT NULL,
      entity_type VARCHAR(50),
      entity_id VARCHAR(255),
      details JSONB DEFAULT '{}'::jsonb,
      user_id VARCHAR(100),
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // ───────── AUDIT EVENTS (tamper-evident, append-only) ─────────
  // Dedicated audit trail with before/after values and a hash chain
  // (event_hash over the previous hash + record content). Records are
  // append-only: the application never UPDATEs or DELETEs them (the hash
  // is backfilled once right after insert, in the same statement flow).
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS audit_events (
      seq BIGSERIAL PRIMARY KEY,
      audit_id TEXT UNIQUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT,
      customer_id TEXT,
      loan_id TEXT,
      payment_id TEXT,
      performed_by TEXT,
      user_id VARCHAR(100),
      user_role TEXT,
      ip_address TEXT,
      client_info TEXT,
      source TEXT NOT NULL DEFAULT 'app',
      reason TEXT,
      result TEXT NOT NULL DEFAULT 'SUCCESS',
      changes JSONB NOT NULL DEFAULT '[]'::jsonb,
      before_data JSONB,
      after_data JSONB,
      prev_hash TEXT,
      event_hash TEXT
    );
  `);

  // ───────── LOCAL STORAGE LOCATIONS (additional local drives/folders) ─────────
  // LOCAL ONLY. There is no cloud storage type — `type` is always 'LOCAL'.
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS storage_locations (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      name VARCHAR(120) NOT NULL,
      path TEXT NOT NULL UNIQUE,
      drive VARCHAR(8),
      type VARCHAR(10) NOT NULL DEFAULT 'LOCAL' CHECK (type = 'LOCAL'),
      purpose VARCHAR(40) NOT NULL DEFAULT 'Database Backups',
      max_bytes BIGINT,
      status VARCHAR(20) NOT NULL DEFAULT 'Active',
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW(),
      last_used_at TIMESTAMPTZ
    );
  `);

  // ───────── LOCAL BACKUP RECORDS ─────────
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS backup_records (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      filename VARCHAR(255) NOT NULL,
      path TEXT NOT NULL,
      size_bytes BIGINT NOT NULL DEFAULT 0,
      storage_location_id UUID REFERENCES storage_locations(id) ON DELETE SET NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'Successful',
      pg_version VARCHAR(60),
      kind VARCHAR(20) NOT NULL DEFAULT 'full',
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // ───────── REFRESH TOKENS ─────────
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS refresh_tokens (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id VARCHAR(100) NOT NULL,
      token_hash VARCHAR(255) UNIQUE NOT NULL,
      expires_at TIMESTAMPTZ NOT NULL,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      revoked_at TIMESTAMPTZ,
      last_used_at TIMESTAMPTZ,
      user_agent TEXT,
      ip_address VARCHAR(64)
    );
  `);

  // ═══════════════════════════════════════════
  // MIGRATIONS (non-destructive, idempotent)
  // ═══════════════════════════════════════════

  // Migration: rename legacy user column if needed
  const legacyCol = ['cl','erk','_user','_id'].join('');
  const tablesWithUserId = ['users', 'customers', 'loans', 'payments', 'daily_collection', 'reports', 'settings', 'notifications', 'audit_logs', 'refresh_tokens'];
  for (const table of tablesWithUserId) {
    try {
      const hasOld = await getPool().query(`SELECT column_name FROM information_schema.columns WHERE table_name=$1 AND column_name='${legacyCol}'`, [table]);
      const hasNew = await getPool().query(`SELECT column_name FROM information_schema.columns WHERE table_name=$1 AND column_name='user_id'`, [table]);
      if (hasOld.rows.length > 0 && hasNew.rows.length === 0) {
        await getPool().query(`ALTER TABLE ${table} RENAME COLUMN ${legacyCol} TO user_id`);
        console.log(`[Schema] Migrated ${table}.${legacyCol} -> user_id`);
      } else if (hasOld.rows.length > 0 && hasNew.rows.length > 0) {
        await getPool().query(`UPDATE ${table} SET user_id = ${legacyCol} WHERE user_id IS NULL AND ${legacyCol} IS NOT NULL`);
      }
    } catch {}
  }

  // Migration: renumber customer_code from CUST-XXXX to 001, 002, 003 format
  try {
    const hasLegacy = await getPool().query("SELECT 1 FROM customers WHERE customer_code LIKE 'CUST-%' LIMIT 1");
    if (hasLegacy.rows.length > 0) {
      console.log('[Schema] Migrating customer_code from CUST-XXXX to sequential format...');
      await getPool().query(`
        WITH ranked AS (
          SELECT id, ROW_NUMBER() OVER (ORDER BY created_at ASC, id ASC) AS rn FROM customers
        )
        UPDATE customers c SET customer_code = LPAD(ranked.rn::TEXT, 3, '0')
        FROM ranked WHERE c.id = ranked.id
      `);
    }
  } catch (e: any) {
    console.warn('[Schema] customer_code migration failed:', e.message);
  }

  // Ensure customer_code is NOT NULL and unique PER ACCOUNT.
  // Older databases enforce global uniqueness via
  // customers_customer_code_key, which forbids two accounts from sharing 001.
  // Replace it with UNIQUE(user_id, customer_code). Existing rows are never
  // modified (global uniqueness implies per-account uniqueness), and the
  // legacy global constraint may not exist on fresh databases.
  try {
    const colCheck = await getPool().query(
      "SELECT is_nullable FROM information_schema.columns WHERE table_name='customers' AND column_name='customer_code'"
    );
    if (colCheck.rows.length > 0 && colCheck.rows[0].is_nullable === 'YES') {
      await getPool().query('ALTER TABLE customers ALTER COLUMN customer_code SET NOT NULL');
    }
    await getPool().query('ALTER TABLE customers DROP CONSTRAINT IF EXISTS customers_customer_code_key');
    const hasPerUserConstraint = await getPool().query(
      "SELECT 1 FROM pg_constraint WHERE conname='customers_user_code_key'"
    );
    if (hasPerUserConstraint.rows.length === 0) {
      await getPool().query('ALTER TABLE customers ADD CONSTRAINT customers_user_code_key UNIQUE (user_id, customer_code)');
    }
  } catch {}

  // ───────── MIGRATION: String columns → Lookup FK columns ─────────
  // This is the core normalization migration. It:
  // 1. Adds area_id, city_id, business_id FK columns if missing
  // 2. Populates ref_* tables with distinct values
  // 3. Maps string values to FK IDs
  // 4. Drops the old string columns
  await migrateStringColumnsToFks();

  // ───────── MIGRATION: Loan data from customers → loans table ─────────
  // If customers table still has loan columns, migrate data to loans table
  await migrateLoanDataToLoansTable();

  // ───────── MIGRATION: Drop completed_customers / aborted_customers ─────────
  // These are redundant — status on customers table is sufficient
  // We keep them but don't create new ones; they serve as audit trail

  // ───────── INDEXES (optimized) ─────────
  const indexQueries = [
    // Customers
    'CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone_number);',
    'CREATE INDEX IF NOT EXISTS idx_customers_name ON customers(full_name);',
    'CREATE INDEX IF NOT EXISTS idx_customers_user ON customers(user_id);',
    // Loans
    'CREATE INDEX IF NOT EXISTS idx_loans_customer ON loans(customer_id);',
    'CREATE INDEX IF NOT EXISTS idx_loans_date ON loans(loan_date);',
    'CREATE INDEX IF NOT EXISTS idx_loans_due ON loans(due_date);',
    // Payments
    'CREATE INDEX IF NOT EXISTS idx_payments_customer ON payments(customer_id);',
    'CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);',
    // Daily collection
    'CREATE INDEX IF NOT EXISTS idx_daily_collection_date ON daily_collection(collection_date);',
    'CREATE INDEX IF NOT EXISTS idx_daily_collection_customer ON daily_collection(customer_id);',
    // Trigram index for customer name search
    'CREATE EXTENSION IF NOT EXISTS pg_trgm;',
    'CREATE INDEX IF NOT EXISTS idx_customers_full_name_trgm ON customers USING gin (full_name gin_trgm_ops);',
    // UNIQUE(name) already supplies lookup indexes for these reference tables.
    // Other
    'CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON audit_logs(user_id);',
    'CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(created_at);',
    // Audit events (server-side filtering/pagination/sorting)
    'CREATE INDEX IF NOT EXISTS idx_audit_events_created ON audit_events(created_at DESC);',
    'CREATE INDEX IF NOT EXISTS idx_audit_events_customer ON audit_events(customer_id);',
    'CREATE INDEX IF NOT EXISTS idx_audit_events_entity ON audit_events(entity_type);',
    'CREATE INDEX IF NOT EXISTS idx_audit_events_entity_id ON audit_events(entity_id);',
    'CREATE INDEX IF NOT EXISTS idx_audit_events_action ON audit_events(action);',
    'CREATE INDEX IF NOT EXISTS idx_audit_events_performer ON audit_events(performed_by);',
    'CREATE INDEX IF NOT EXISTS idx_audit_events_result ON audit_events(result);',
    'CREATE INDEX IF NOT EXISTS idx_audit_events_user ON audit_events(user_id);',
    // Cash-compliance flags (flagged-only listings)
    'CREATE INDEX IF NOT EXISTS idx_loans_flagged ON loans(is_flagged) WHERE is_flagged = true;',
    'CREATE INDEX IF NOT EXISTS idx_payments_flagged ON payments(is_flagged) WHERE is_flagged = true;',
    'CREATE INDEX IF NOT EXISTS idx_payments_mode ON payments(payment_mode);',
    'CREATE INDEX IF NOT EXISTS idx_loans_disbursal ON loans(disbursal_mode);',
    'CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user ON refresh_tokens(user_id);',
    // UNIQUE(token_hash) already supplies the token lookup index.
    'CREATE INDEX IF NOT EXISTS idx_refresh_tokens_expires ON refresh_tokens(expires_at);',
  ];

  for (const idx of indexQueries) {
    await getPool().query(idx).catch(() => {});
  }

  // Drop redundant indexes from old schema
  const dropIndexes = [
    'DROP INDEX IF EXISTS idx_customers_area;',
    'DROP INDEX IF EXISTS idx_customers_city;',
    'DROP INDEX IF EXISTS idx_customers_business;',
    'DROP INDEX IF EXISTS idx_customers_status;',
    'DROP INDEX IF EXISTS idx_customers_loan_date;',
    'DROP INDEX IF EXISTS idx_customers_due_date;',
    'DROP INDEX IF EXISTS idx_customers_code;',
    'DROP INDEX IF EXISTS idx_loans_status;',
    'DROP INDEX IF EXISTS idx_payments_loan;',
  ];
  for (const idx of dropIndexes) {
    await getPool().query(idx).catch(() => {});
  }

  const { migrateKanaku } = await import('./kanaku-schema');
  await migrateKanaku(getPool());
  const { migrateDeveloperPolicy } = await import('./developer-policy');
  await migrateDeveloperPolicy(getPool());
  console.log('[Schema] Database initialized successfully');
}

// ═══════════════════════════════════════════
// MIGRATION HELPERS
// ═══════════════════════════════════════════

async function migrateStringColumnsToFks(): Promise<void> {
  const pool = getPool();

  // Check if old string columns still exist
  const colCheck = await pool.query(
    "SELECT column_name FROM information_schema.columns WHERE table_name='customers' AND column_name IN ('area','city','business')"
  );
  const hasStringCols = new Set(colCheck.rows.map((r: any) => r.column_name));

  // Check if FK columns already exist
  const fkCheck = await pool.query(
    "SELECT column_name FROM information_schema.columns WHERE table_name='customers' AND column_name IN ('area_id','city_id','business_id')"
  );
  const hasFkCols = new Set(fkCheck.rows.map((r: any) => r.column_name));

  // Add FK columns if missing
  if (!hasFkCols.has('area_id') && hasStringCols.has('area')) {
    await pool.query('ALTER TABLE customers ADD COLUMN area_id SMALLINT REFERENCES ref_area(id)');
    console.log('[Schema] Added area_id column');
  }
  if (!hasFkCols.has('city_id') && hasStringCols.has('city')) {
    await pool.query('ALTER TABLE customers ADD COLUMN city_id SMALLINT REFERENCES ref_city(id)');
    console.log('[Schema] Added city_id column');
  }
  if (!hasFkCols.has('business_id') && hasStringCols.has('business')) {
    await pool.query('ALTER TABLE customers ADD COLUMN business_id SMALLINT REFERENCES ref_business(id)');
    console.log('[Schema] Added business_id column');
  }

  // Populate lookup tables and map FKs
  if (hasStringCols.has('area')) {
    // Insert distinct area values into ref_area
    await pool.query(`
      INSERT INTO ref_area (name)
      SELECT DISTINCT TRIM(area) FROM customers
      WHERE area IS NOT NULL AND TRIM(area) != ''
      ON CONFLICT (name) DO NOTHING
    `);
    // Map string → FK
    await pool.query(`
      UPDATE customers c SET area_id = r.id
      FROM ref_area r WHERE TRIM(c.area) = r.name
      AND c.area_id IS NULL
    `);
    console.log('[Schema] Migrated area strings to ref_area IDs');
  }

  if (hasStringCols.has('city')) {
    await pool.query(`
      INSERT INTO ref_city (name)
      SELECT DISTINCT TRIM(city) FROM customers
      WHERE city IS NOT NULL AND TRIM(city) != ''
      ON CONFLICT (name) DO NOTHING
    `);
    await pool.query(`
      UPDATE customers c SET city_id = r.id
      FROM ref_city r WHERE TRIM(c.city) = r.name
      AND c.city_id IS NULL
    `);
    console.log('[Schema] Migrated city strings to ref_city IDs');
  }

  if (hasStringCols.has('business')) {
    await pool.query(`
      INSERT INTO ref_business (name)
      SELECT DISTINCT TRIM(business) FROM customers
      WHERE business IS NOT NULL AND TRIM(business) != ''
      ON CONFLICT (name) DO NOTHING
    `);
    await pool.query(`
      UPDATE customers c SET business_id = r.id
      FROM ref_business r WHERE TRIM(c.business) = r.name
      AND c.business_id IS NULL
    `);
    console.log('[Schema] Migrated business strings to ref_business IDs');
  }

  // Drop old string columns
  if (hasStringCols.has('area')) {
    await pool.query('ALTER TABLE customers DROP COLUMN IF EXISTS area').catch(() => {});
  }
  if (hasStringCols.has('city')) {
    await pool.query('ALTER TABLE customers DROP COLUMN IF EXISTS city').catch(() => {});
  }
  if (hasStringCols.has('business')) {
    await pool.query('ALTER TABLE customers DROP COLUMN IF EXISTS business').catch(() => {});
  }

  // Drop old loan columns from customers if they still exist
  const loanCols = [
    'loan_date', 'due_date', 'loan_amount', 'interest_rate', 'interest_amount',
    'total_amount', 'installment_amount', 'remaining_days', 'duration', 'loan_type',
    'completed_at', 'aborted_at', 'abort_reason', 'notes'
  ];
  for (const col of loanCols) {
    await pool.query(`ALTER TABLE customers DROP COLUMN IF EXISTS ${col}`).catch(() => {});
  }
}

async function migrateLoanDataToLoansTable(): Promise<void> {
  const pool = getPool();

  // Check if customers table still has loan columns (indicating old schema)
  const colCheck = await pool.query(
    "SELECT column_name FROM information_schema.columns WHERE table_name='customers' AND column_name='loan_amount'"
  );
  if (colCheck.rows.length === 0) {
    // Loan columns already removed — migration already done
    return;
  }

  console.log('[Schema] Migrating loan data from customers to loans table...');

  // Insert loan data into loans table for customers that don't have a loans row yet
  await pool.query(`
    INSERT INTO loans (customer_id, loan_date, due_date, loan_amount, interest_rate,
      interest_amount, total_amount, installment_amount, remaining_days, duration,
      loan_type, status, completed_at, aborted_at, abort_reason, notes, user_id, created_at)
    SELECT
      c.id, c.loan_date, c.due_date, c.loan_amount, c.interest_rate,
      c.interest_amount, c.total_amount, c.installment_amount, c.remaining_days,
      c.duration, c.loan_type, c.status, c.completed_at, c.aborted_at,
      c.abort_reason, c.notes, c.user_id, c.created_at
    FROM customers c
    WHERE NOT EXISTS (SELECT 1 FROM loans l WHERE l.customer_id = c.id)
  `);

  // Link payments to their loans
  await pool.query(`
    UPDATE payments p SET loan_id = (
      SELECT l.loan_id FROM loans l WHERE l.customer_id = p.customer_id LIMIT 1
    )
    WHERE p.loan_id IS NULL
  `);

  // Also migrate payment_method to enum-safe value if needed
  await pool.query(`
    UPDATE payments SET payment_method = 'Cash'
    WHERE payment_method IS NULL OR payment_method = ''
  `);

  // Migrate daily_collection payment_method
  await pool.query(`
    UPDATE daily_collection SET payment_method = 'Cash'
    WHERE payment_method IS NULL OR payment_method = ''
  `);

  console.log('[Schema] Loan data migration complete');
}

export async function verifyTables(): Promise<string[]> {
  const result = await getPool().query(
    "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name"
  );
  return result.rows.map((r: any) => r.table_name);
}
