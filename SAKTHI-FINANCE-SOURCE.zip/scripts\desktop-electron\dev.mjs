import { spawn } from 'node:child_process'

/**
 * Development launcher: starts the Next dev server, waits for it, then runs
 * Electron with SAKTHI_ELECTRON_DEV=1 (the ONLY mode that ever loads
 * localhost). Production is unaffected.
 */

const root = process.cwd()
const nextPort = process.env.SAKTHI_ELECTRON_DEV_PORT || '3000'

const next = spawn(process.execPath, ['node_modules/next/dist/bin/next', 'dev', '-p', nextPort], {
  cwd: root,
  stdio: 'inherit',
})

async function waitForServer() {
  for (let attempt = 0; attempt < 120; attempt++) {
    try {
      const response = await fetch(`http://localhost:${nextPort}/login`, { signal: AbortSignal.timeout(1500) })
      if (response.ok) return
    } catch { /* retry */ }
    await new Promise((resolve) => setTimeout(resolve, 1000))
  }
  throw new Error('Next dev server did not become ready')
}

try {
  await waitForServer()
  const electron = spawn('npx', ['electron', '.'], {
    cwd: root,
    stdio: ['inherit', 'pipe', 'pipe'],
    env: { ...process.env, SAKTHI_ELECTRON_DEV: '1' },
  })
  electron.stdout.on('data', (d) => process.stdout.write(d))
  electron.stderr.on('data', (d) => process.stderr.write(d))
  const fs = await import('node:fs')
  const logStream = fs.createWriteStream('desktop-main.log', { flags: 'a' })
  electron.stdout.pipe(logStream)
  electron.stderr.pipe(logStream)
  electron.on('exit', (code) => {
    next.kill('SIGTERM')
    process.exitCode = code ?? 0
  })
} catch (error) {
  console.error(error.message)
  next.kill('SIGTERM')
  process.exitCode = 1
}
