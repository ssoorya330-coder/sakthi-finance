﻿'use client'

import { create } from 'zustand'
import type { Customer, PaymentRecord } from '@/types/customer.types'
import { apiClient, mapDbCustomer, DbCustomer } from '@/services/api-client'
import { useAuthStore } from './auth-store'
import { useToastStore } from './toast-store'
import { writeAuditLog } from '@/services/audit-log'
import { mapPayment, paymentDateInIndia } from '@/lib/payment-history'
import { formatCustomerCode } from '@/utils/customer-id'

interface CustomerState {
  customers: Customer[]
  lastCustomerNumber: number
  receivedPayments: Record<string, string>
  receivedPaymentModes: Record<string, 'Cash' | 'PhonePe'>
  updateReceivedPaymentMode: (customerId: string, mode: 'Cash' | 'PhonePe') => void
  paymentHistory: PaymentRecord[]
  isSavingPayments: boolean
  loadCustomerPayments: (customerId: string) => Promise<void>
  initialized: boolean
  loading: boolean
  userId: string | null
  _initRetries: number
  savedTodayCollection: number
  todayCollection: number
  init: () => Promise<void>
  restoreFromSnapshot: (userId: string) => Promise<boolean>
  refresh: () => Promise<boolean>
  addCustomer: (customer: Omit<Customer, 'id' | 'createdAt' | 'updatedAt'>) => Promise<{ success: boolean; error?: string; id?: string; cashCompliance?: any }>
  deleteCustomer: (id: string) => Promise<void>
  getCustomerByMobile: (mobile: string) => Customer | undefined
  getDisplayId: (customer: Customer) => string
  updateReceivedPayment: (customerId: string, value: string) => void
  saveAllReceivedPayments: () => Promise<{ success: boolean; savedCount: number; failedIds: string[]; error?: string }>
  addPayment: (payment: Omit<PaymentRecord, 'id' | 'createdAt'>) => Promise<void>
  getPaymentsByCustomer: (customerId: string) => PaymentRecord[]
  updateCustomerStatus: (id: string, status: Customer['status'], extra?: Partial<Customer>) => Promise<void>
  updateCustomer: (id: string, updates: Partial<Customer>) => Promise<{ success: boolean; error?: string }>
  abortCustomer: (id: string, abortReason?: string) => Promise<void>
  getStats: () => { totalCustomers: number; activeCustomers: number; completedCustomers: number; overdueCustomers: number; abortedCustomers: number; totalLoanAmount: number; totalInterest: number; totalAmount: number; totalBalance: number }
}

let _initPromise: Promise<void> | null = null
let _initUserId: string | null = null

function todayStr(): string {
  return paymentDateInIndia()
}

function computeTodaySaved(customers: Customer[], paymentHistory: PaymentRecord[]): number {
  const today = todayStr()
  const ids = new Set(customers.map((c) => c.id))
  return paymentHistory
    .filter((p) => p.customerId && ids.has(p.customerId))
    .filter((p) => (p.paymentDate || p.createdAt || '').startsWith(today))
    .reduce((sum, p) => sum + (Number(p.paymentAmount) || 0), 0)
}

let syncRaf: number | null = null
function syncTodayCollection(): void {
  if (syncRaf !== null) cancelAnimationFrame(syncRaf)
  syncRaf = requestAnimationFrame(() => {
    syncRaf = null
    const { customers, paymentHistory, receivedPayments } = useCustomerStore.getState()
    const saved = computeTodaySaved(customers, paymentHistory)
    const draft = Object.values(receivedPayments).reduce((sum, v) => sum + (Number(v) || 0), 0)
    // Card shows pending (unsaved) entries only, so it resets to zero after Save All
    useCustomerStore.setState({ savedTodayCollection: saved, todayCollection: draft })
  })
}

function mapToDbCustomer(c: Customer): Record<string, any> {
  return {
    full_name: c.fullName,
    phone_number: c.mobileNumber || undefined,
    alternate_phone: c.alternateMobile || undefined,
    address: c.address || undefined,
    area: c.area || c.areaName || undefined,
    city: c.city || c.cityName || undefined,
    business: c.occupation || c.businessName || undefined,
    income: c.monthlyIncome ? Number(c.monthlyIncome) : undefined,
    status: c.status,
    // Loan fields (sent to API, which creates/updates loans table)
    loan_date: c.loanDate || undefined,
    due_date: c.dueDate || undefined,
    loan_amount: Number(c.loanAmount) || 0,
    interest_rate: Number(c.interestRate) || 0,
    interest_amount: Number(c.interestAmount) || 0,
    total_amount: Number(c.totalAmount) || 0,
    installment_amount: Number(c.installmentAmount) || 0,
    remaining_days: Number(c.remainingDays) || 0,
    duration: Number(c.duration) || 0,
    loan_type: c.loanType || 'Daily',
    notes: c.loanNotes || undefined,
    abort_reason: c.abortReason || undefined,
    disbursal_mode: (c as any).disbursalMode || undefined,
  }
}

function customerSeqNumber(c: Customer): number {
  const codeNum = Number(String(c.customerCode || '').match(/\d+/)?.[0] || 0)
  if (codeNum > 0) return codeNum
  const idNum = Number(String(c.id).split('-')[0])
  if (!isNaN(idNum) && idNum > 0) return idNum
  return Number(c.id) || 0
}

function sortCustomersAscending(list: Customer[]): Customer[] {
  return [...list].sort(
    (a, b) => a.createdAt.localeCompare(b.createdAt) || customerSeqNumber(a) - customerSeqNumber(b),
  )
}

const OFFLINE_KEY_PREFIX = 'sf-offline-customers-v1'
// The offline cache is namespaced per account (userId) so one Gmail account
// can never read another account's cached customers from this browser.
function offlineKey(userId: string | null): string {
  return `${OFFLINE_KEY_PREFIX}:${userId || 'public'}`
}
function loadOfflineCustomers(userId: string | null): Customer[] {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(offlineKey(userId)) : null
    if (!raw) return []
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed : []
  } catch { return [] }
}
function saveOfflineCustomers(userId: string | null, customers: Customer[]) {
  if(typeof localStorage!=='undefined'&&localStorage.getItem(`sf-device-mode:${userId}`)==='on')return
  try { if (typeof localStorage !== 'undefined') localStorage.setItem(offlineKey(userId), JSON.stringify(customers)) } catch {}
}
/** Remove every account's offline customer cache from this browser (logout). */
export function clearAllOfflineCustomerCaches(): void {
  try {
    if (typeof localStorage === 'undefined') return
    const doomed: string[] = []
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i)
      if (k === OFFLINE_KEY_PREFIX || k?.startsWith(`${OFFLINE_KEY_PREFIX}:`)) doomed.push(k)
    }
    doomed.forEach((k) => {
      try { localStorage.removeItem(k) } catch {}
    });
    // Legacy global (pre-isolation) key, if present from an older version.
    try { localStorage.removeItem('sf-offline-customers-v1') } catch {}
  } catch {}
}

// Automatically mark Active/Overdue customers as Completed when their
// balance reaches zero (total paid >= total amount). Completed customers
// then show up in the Completed Customers section automatically since it
// filters the shared store by status. No-ops when nothing needs flipping.
async function reconcileCompletedStatuses(): Promise<void> {
  // PostgreSQL derives completion per Kanaku in the payment transaction.
  // A client history snapshot must never complete unrelated loans.
}

export const useCustomerStore = create<CustomerState>()((set, get) => ({
  customers: [],
  lastCustomerNumber: 0,
  receivedPayments: {},
  receivedPaymentModes: {},
  updateReceivedPaymentMode: (customerId, mode) => set((state) => ({ receivedPaymentModes: { ...state.receivedPaymentModes, [customerId]: mode } })),
  paymentHistory: [],
  isSavingPayments: false,
  initialized: false,
  loading: false,
  userId: null,
  _initRetries: 0,
  savedTodayCollection: 0,
  todayCollection: 0,

  init: async () => {
    const auth=useAuthStore.getState()
    const userId=auth.userId
    if(!auth.isAuthenticated || !userId || auth.role==='customer')return
    const sameAccount=()=>useAuthStore.getState().isAuthenticated && useAuthStore.getState().userId===userId
    if (get().initialized && get().userId === userId) return
    if (_initPromise) {
      if(_initUserId===userId)return _initPromise
      await _initPromise
      if(sameAccount())return get().init()
      return
    }
    _initUserId=userId
    _initPromise = (async () => {
      set({ loading: true })
      try {
        const [result, payments] = await Promise.all([
          apiClient.fetchCustomers({ limit: 1000000 }),
          apiClient.fetchPayments({}).catch((error) => {
            if(error.response?.status===401 || error.response?.status===403)throw error
            return {data:[] as any[]}
          }),
        ])
        if(!sameAccount())return
        const customers = sortCustomersAscending(result.data.map(mapDbCustomer))
        let lastId = 0
        for (const c of customers) {
          const n = customerSeqNumber(c)
          if (n > lastId) lastId = n
        }
        const paymentHistory = (payments.data || []).map(mapPayment)
        set({ customers, lastCustomerNumber: lastId, userId: userId, initialized: true, loading: false, _initRetries: 0, paymentHistory })
        saveOfflineCustomers(userId, customers)
        syncTodayCollection()
        await reconcileCompletedStatuses()
} catch (err: any) {
        if(!sameAccount())return
        if(err.response?.status===401 || err.response?.status===403) {
          // Authentication failures are not offline mode. Never load cached
          // finance data or retry a rejected account request.
          set({customers:[],paymentHistory:[],lastCustomerNumber:0,userId:null,initialized:false,loading:false,_initRetries:0})
          return
        }
        // Offline fallback: per-account cache only — never another user's data.
          const offline = sortCustomersAscending(loadOfflineCustomers(userId))
        if (offline.length > 0) {
          console.warn('[CustomerStore] init offline fallback, loading cached', offline.length)
          let lastId = 0
          for (const c of offline) { const n = customerSeqNumber(c); if (n > lastId) lastId = n }
          set({ customers: offline, lastCustomerNumber: lastId, userId: userId, initialized: true, loading: false, _initRetries: 0, paymentHistory: [] })
          syncTodayCollection()
          return
        }
        const status = err.response?.status
        const isNetwork = !status && (err.message?.includes('Network Error') || err.code === 'ECONNREFUSED' || err.message?.includes('ECONNREFUSED'))
        if (isNetwork) {
          console.warn('[CustomerStore] init network error, no cache � initialized empty')
          set({ customers: [], lastCustomerNumber: 0, userId: userId, initialized: true, loading: false, _initRetries: 0, paymentHistory: [] })
          return
        }
        console.error('[CustomerStore] init failed:', err)
        const retries = get()._initRetries + 1
        if (retries < 3) {
          set({ _initRetries: retries, loading: true })
          _initPromise = null
          await new Promise((r) => setTimeout(r, 2000))
          await useCustomerStore.getState().init()
        } else {
          set({ loading: false, initialized: false, _initRetries: 0 })
        }
      } finally {
        _initPromise = null
      }
    })()
    return _initPromise
  },

  restoreFromSnapshot: async (userId) => {
    if (!userId) return false
    if (get().initialized && get().userId === userId) return true
    await get().init()
    return get().initialized
  },

  refresh: async () => {
    apiClient.clearCache()
    set({ loading: true })
    try {
      const result = await apiClient.fetchCustomers({ limit: 1000000 })
      const customers = sortCustomersAscending(result.data.map(mapDbCustomer))
      let lastId = 0
      for (const c of customers) {
        const n = customerSeqNumber(c)
        if (n > lastId) lastId = n
      }
      const payments = await apiClient.fetchPayments({})
      const paymentHistory = payments.data.map(mapPayment)
      set({ customers, paymentHistory, lastCustomerNumber: lastId, loading: false })
      syncTodayCollection()
      await reconcileCompletedStatuses()
      return true
    } catch (err) {
      console.error('[CustomerStore] refresh failed:', err)
      set({ loading: false })
      return false
    }
  },

  addCustomer: async (customerData) => {
    const userId = useAuthStore.getState().userId || 'public'
    try {
      const customers = get().customers
      let maxNumber = get().lastCustomerNumber
      for (const c of customers) {
        const n = customerSeqNumber(c)
        if (n > maxNumber) maxNumber = n
      }
      const nextNumber = maxNumber + 1
      const customerCode = String(nextNumber).padStart(3, '0')

      const newCustomer = await apiClient.createCustomer({
        ...mapToDbCustomer({ ...customerData, id: '', createdAt: '', updatedAt: '' } as Customer),
        customer_code: customerCode,
      })

      const mapped = mapDbCustomer(newCustomer)
      set((state) => ({
        customers: [...state.customers, mapped],
        lastCustomerNumber: nextNumber,
      }))
      syncTodayCollection()

      writeAuditLog({ userId: userId, action: 'create', entityType: 'customer', entityId: mapped.id, details: `Added customer ${mapped.fullName}` }).catch(() => {})
      return { success: true, id: mapped.id, cashCompliance: (newCustomer as any).cashCompliance }
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to create customer' }
    }
  },

  deleteCustomer: async (id: string) => {
    const userId = useAuthStore.getState().userId || 'public'
    try {
      const target = get().customers.find((c) => c.id === id)
      await apiClient.deleteCustomer(id)
      set((state) => ({
        customers: state.customers.filter((c) => c.id !== id),
        paymentHistory: state.paymentHistory.filter((p) => p.customerId !== id),
      }))
      const drafts = { ...get().receivedPayments }
      if (id in drafts) { delete drafts[id]; set({ receivedPayments: drafts }) }
      syncTodayCollection()
      writeAuditLog({ userId: userId, action: 'delete', entityType: 'customer', entityId: id, details: target ? `Deleted customer ${target.fullName}` : `Deleted customer ${id}` }).catch(() => {})
    } catch (error: any) {
      throw new Error(error?.response?.data?.error || error?.message || 'Customer could not be deleted.')
    }
  },

  updateCustomerStatus: async (id, status, extra = {}) => {
    const userId = useAuthStore.getState().userId || 'public'
    const now = new Date().toISOString()
    const updates: any = { status, updated_at: now }
    if (status === 'Completed') updates.completed_at = extra.completedAt || now
    if (status === 'Aborted') {
      updates.aborted_at = extra.abortedAt || now
      if (extra.abortReason) updates.abort_reason = extra.abortReason
    }
    try {
      await apiClient.updateCustomer(id, updates)
      set((state) => ({
        customers: state.customers.map((c) =>
          c.id === id ? { ...c, status, updatedAt: now, ...extra, completedAt: status === 'Completed' ? extra.completedAt || now : c.completedAt, abortedAt: status === 'Aborted' ? extra.abortedAt || now : c.abortedAt, abortReason: status === 'Aborted' ? extra.abortReason || c.abortReason : c.abortReason } : c
        ),
      }))
      saveOfflineCustomers(userId, get().customers)
      const target = get().customers.find((c) => c.id === id)
      writeAuditLog({ userId, action: 'update', entityType: 'customer', entityId: id, details: target ? `Marked ${target.fullName} as ${status}` : `Updated customer ${id} to ${status}` }).catch(() => {})
    } catch (err) {
      console.error('[CustomerStore] updateCustomerStatus failed:', err)
    }
  },

  abortCustomer: async (id, abortReason) => {
    await get().updateCustomerStatus(id, 'Aborted', { abortReason, abortedAt: new Date().toISOString() })
  },

  updateCustomer: async (id, updates) => {
    const userId = useAuthStore.getState().userId || 'public'
    try {
      const existing = get().customers.find((c) => c.id === id)
      if (!existing) return { success: false, error: 'Customer not found' }
      const merged: Customer = { ...existing, ...updates, updatedAt: new Date().toISOString() }
      const saved = await apiClient.updateCustomer(id, mapToDbCustomer(merged))
      const mapped = mapDbCustomer(saved)
      set((state) => ({ customers: state.customers.map((c) => c.id === id ? mapped : c) }))
      saveOfflineCustomers(userId, get().customers)
      syncTodayCollection()
      writeAuditLog({ userId, action: 'update', entityType: 'customer', entityId: id, details: `Updated customer ${mapped.fullName}` }).catch(() => {})
      await reconcileCompletedStatuses()
      return { success: true }
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to update customer' }
    }
  },

  getCustomerByMobile: (mobile) => get().customers.find((c) => c.mobileNumber === mobile),
  getDisplayId: (customer) => {
    return formatCustomerCode(customer.customerCode)
  },

  updateReceivedPayment: (customerId, value) => {
    const oldNum = Number(get().receivedPayments[customerId]) || 0
    const newNum = Number(value) || 0
    set((state) => ({ receivedPayments: { ...state.receivedPayments, [customerId]: value }, todayCollection: state.todayCollection - oldNum + newNum }))
  },

  loadCustomerPayments: async (customerId) => {
    const userId = useAuthStore.getState().userId
    const before = new Set(get().paymentHistory.map((p) => p.id))
    const response = await apiClient.fetchPayments({ customerId })
    if (useAuthStore.getState().userId !== userId) return
    const records = response.data.map(mapPayment)
    const fetchedIds = new Set(records.map((p) => p.id))
    set((state) => ({ paymentHistory: [
      ...state.paymentHistory.filter((p) => p.customerId !== customerId || (!before.has(p.id) && !fetchedIds.has(p.id))),
      ...records,
    ] }))
    syncTodayCollection()
  },

  saveAllReceivedPayments: async () => {
    if (get().isSavingPayments) return { success: false, savedCount: 0, failedIds: [], error: 'Payments are already being saved.' }
    set({ isSavingPayments: true })
    const userId = useAuthStore.getState().userId
    const drafts = { ...get().receivedPayments }
    const modes = { ...get().receivedPaymentModes }
    const failedIds: string[] = []
    let savedCount = 0
    const errors: string[] = []
    const moneyLabel = (value: number) => '₹' + value.toLocaleString('en-IN', { maximumFractionDigits: 2 })
    try {
      for (const [customerId, raw] of Object.entries(drafts)) {
        if (!raw.trim()) continue
        const customer = get().customers.find((c) => c.id === customerId)
        const amount = Number(raw)
        if (!customer || !/^\d+(\.\d{1,2})?$/.test(raw) || !Number.isFinite(amount) || amount <= 0) {
          failedIds.push(customerId)
          errors.push(`${customer?.fullName || 'Customer ' + customerId}: Invalid amount. Enter an amount greater than zero.`)
          continue
        }
        const paid = get().paymentHistory.filter((p) => p.customerId === customerId).reduce((sum, p) => sum + p.paymentAmount, Number(customer.offlinePaidAmount)||0)
        const balance = Math.max(0, Math.round(((Number(customer.totalAmount) || 0) - paid) * 100))
        if (Math.round(amount * 100) > balance) {
          failedIds.push(customerId)
          errors.push(`${customer.fullName || 'Customer ' + customerId}: Invalid amount. Entered ${moneyLabel(amount)}; balance ${moneyLabel(balance / 100)}. Enter ${moneyLabel(balance / 100)} or less.`)
          continue
        }
        // Stop a batch if the signed-in account changes while a request is pending.
        if (useAuthStore.getState().userId !== userId) break
        try {
          const now = new Date()
          const saved = await apiClient.createPayment({
            loan_id: customer.loanId, customer_id: customerId, amount,
            payment_date: paymentDateInIndia(now),
            payment_time: now.toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour12: false }),
            payment_method: modes[customerId] === 'PhonePe' ? 'UPI' : 'Cash', payment_mode: modes[customerId] || 'Cash', remarks: 'Received payment',
          })
          savedCount++
          if (useAuthStore.getState().userId !== userId) break
          const records = (saved.payments || [saved]).map(mapPayment)
          set((state) => {
            const remaining = { ...state.receivedPayments }
            // Preserve anything typed while this save was in flight.
            if (remaining[customerId] === raw) delete remaining[customerId]
            return { receivedPayments: remaining, paymentHistory: [...records, ...state.paymentHistory.filter((p) => !records.some((record: PaymentRecord) => record.id === p.id))] }
          })
          if (saved?.cashCompliance?.flagged) useToastStore.getState().addToast('Payment saved. Cash compliance review required; see Audit.', 'warning')
        } catch (err: any) {
          failedIds.push(customerId)
          errors.push(`${customer.fullName || 'Customer ' + customerId}: ${err?.message || 'Payment could not be saved.'}`)
        }
      }
      if (useAuthStore.getState().userId === userId) await reconcileCompletedStatuses()
      return { success: failedIds.length === 0, savedCount, failedIds,
        error: failedIds.length ? errors.join('\n') + (savedCount > 0 ? `\n${savedCount} other payment${savedCount === 1 ? '' : 's'} saved.` : '') : undefined }
    } finally {
      set({ isSavingPayments: false })
      syncTodayCollection()
    }
  },

  addPayment: async (paymentData) => {
    const userId = useAuthStore.getState().userId || 'public'
    const loanId = get().customers.find((c) => c.id === paymentData.customerId)?.loanId || null
    const saved = await apiClient.createPayment({ loan_id: loanId, customer_id: paymentData.customerId, amount: paymentData.paymentAmount, payment_date: paymentData.paymentDate, payment_time: paymentData.paymentTime, payment_method: paymentData.paymentMethod, payment_mode: paymentData.paymentMethod === 'Bank Transfer' ? 'Bank' : paymentData.paymentMethod, remarks: paymentData.remarks })
    const payment = mapPayment(saved)
    set((state) => ({ paymentHistory: [payment, ...state.paymentHistory.filter((p) => p.id !== payment.id)] }))
    syncTodayCollection()
    writeAuditLog({ userId: userId, action: 'create', entityType: 'payment', entityId: payment.customerId, details: `Payment of ?${payment.paymentAmount} recorded` }).catch(() => {})
    // Auto-complete when balance hits zero (same rule as Save All / refresh).
    if(useAuthStore.getState().userId===userId)await get().refresh()
  },

  getPaymentsByCustomer: (customerId) => get().paymentHistory.filter((p) => p.customerId === customerId),

  getStats: () => {
    const { customers, paymentHistory } = get()
    const paidByCustomer = new Map<string, number>(customers.map(c=>[c.id,Number(c.offlinePaidAmount)||0]))
    for (const p of paymentHistory) {
      if (!p.customerId) continue
      paidByCustomer.set(p.customerId, (paidByCustomer.get(p.customerId) ?? 0) + (Number(p.paymentAmount) || 0))
    }
    return {
      totalCustomers: customers.length,
      activeCustomers: customers.filter((c) => c.status === 'Active').length,
      completedCustomers: customers.filter((c) => c.status === 'Completed').length,
      overdueCustomers: customers.filter((c) => c.status === 'Overdue').length,
      abortedCustomers: customers.filter((c) => c.status === 'Aborted').length,
      totalLoanAmount: customers.reduce((sum, c) => sum + (Number(c.loanAmount) || 0), 0),
      totalInterest: customers.reduce((sum, c) => sum + (Number(c.interestAmount) || 0), 0),
      totalAmount: customers.reduce((sum, c) => sum + (c.totalAmount || 0), 0),
      totalBalance: customers.reduce((sum, c) => sum + Math.max(0, (Number(c.totalAmount) || 0) - (paidByCustomer.get(c.id) ?? 0)), 0),
    }
  },
}))
