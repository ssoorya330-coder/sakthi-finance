/**
 * Client-side auth helpers for the persistent login flow.
 *
 * - The access token is stored in an httpOnly cookie (set by the server) and
 *   read automatically by browsers when making same-origin requests.
 * - The refresh token is also in an httpOnly cookie — never readable from JS.
 * - The frontend only needs to know the access token for non-cookie contexts
 *   (e.g. WebSocket handshakes). It can read it from a non-httpOnly mirror
 *   cookie or by calling /api/auth/refresh.
 */

const ACCESS_COOKIE_NAME = 'sf_access';

export function readAccessTokenFromCookie(): string | null {
  if (typeof document === 'undefined') return null;
  const match = document.cookie.split('; ').find((c) => c.startsWith(`${ACCESS_COOKIE_NAME}=`));
  if (!match) return null;
  return decodeURIComponent(match.substring(ACCESS_COOKIE_NAME.length + 1));
}

export interface RefreshResponse {
  user: {
    id: string;
    email: string;
    name: string;
    picture?: string;
    role: string;
  };
  access_token: string;
  access_token_expires_in: number;
}

export async function tryRefresh(): Promise<RefreshResponse | null> {
  try {
    const res = await fetch('/api/auth/refresh', {
      method: 'POST',
      credentials: 'include',
    });
    if (!res.ok) return null;
    const data = (await res.json()) as RefreshResponse;
    return data;
  } catch {
    return null;
  }
}

export async function logout(): Promise<boolean> {
  try {
    const res = await fetch('/api/auth/logout', {
      method: 'POST',
      credentials: 'include',
    });
    return res.ok;
  } catch {
    return false;
  }
}

export function clearClientAuthStorage(): void {
  if (typeof window === 'undefined') return;
  try {
    const authKeys = [
      'sf-auth',
      'sf-sync',
      'sf-sidebar',
      'sf-toast',
      'sf_access_token',
      'sf_refresh_token',
      'sf_user',
      'sf_active_user_id',
    ];
    authKeys.forEach((k) => {
      try { localStorage.removeItem(k) } catch {}
      try { sessionStorage.removeItem(k) } catch {}
    });
    // Per-account offline customer caches — without this, a later login on
    // the same browser could read the previous account's cached customers.
    // (Inline sweep: importing the customer store here would create a
    // module cycle via services/api-client.)
    try {
      const doomed: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k === 'sf-offline-customers-v1' || k?.startsWith('sf-offline-customers-v1:')) doomed.push(k);
      }
      doomed.forEach((k) => {
        try { localStorage.removeItem(k) } catch {}
      });
    } catch {}
  } catch {}
}
