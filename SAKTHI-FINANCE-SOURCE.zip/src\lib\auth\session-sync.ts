import type { UserRole } from '@/store/auth-store'

interface SessionUser { id: string; email: string; name: string; role: UserRole }
interface LocalSession {
  userId: string | null; role: string; isAuthenticated: boolean; isLoggingOut: boolean
  user?: { email: string | null; name: string | null; role: string } | null
}

/** Serial, cancellable checks shared by startup, timer, focus and tab events. */
export function createSessionSync(options: {
  getState: () => LocalSession
  apply: (user: SessionUser) => void
  roleChanged: (role: UserRole) => void
  signedOut: () => void
  dataFormat?: (format: string) => void
  fetch: typeof fetch
}) {
  let disposed = false
  let busy = false
  let navigating = false
  let controller: AbortController | null = null
  const check = async () => {
    if (disposed || busy || navigating || options.getState().isLoggingOut) return
    busy = true
    const before = { ...options.getState() }
    controller = new AbortController()
    const timeout = setTimeout(() => controller?.abort(), 10000)
    const request = (url: string, method = 'GET') => options.fetch(url, {
      method, credentials: 'include', cache: 'no-store', signal: controller!.signal,
    })
    try {
      let response = await request('/api/auth/supabase/session')
      if (response.status === 401) {
        const refresh = await request('/api/auth/refresh', 'POST')
        // A server/network failure must not log the user out or restore an old role.
        if (!refresh.ok && refresh.status !== 401 && refresh.status !== 403) return
        response = refresh.ok ? await request('/api/auth/supabase/session') : refresh
      }
      const now = options.getState()
      // Ignore requests that crossed logout or another login.
      if (disposed || now.isLoggingOut || now.userId !== before.userId || now.isAuthenticated !== before.isAuthenticated) return
      if (response.status === 401 || response.status === 403) {
        if (now.isAuthenticated) { navigating = true; options.signedOut() }
        return
      }
      if (!response.ok) return
      const data = await response.json()
      if (disposed || options.getState().isLoggingOut || options.getState().userId !== before.userId || options.getState().isAuthenticated !== before.isAuthenticated) return
      if (!data.authenticated || !data.user?.id) return
      const user = data.user as SessionUser
      const changed = now.isAuthenticated && (now.role !== user.role || now.userId !== user.id)
      // Avoid rewriting persisted auth on every poll (and storage-event loops
      // between tabs). The first check still hydrates the in-memory user.
      if (changed || !now.user || now.user.email !== user.email || now.user.name !== user.name || now.user.role !== user.role) options.apply(user)
      if (changed) { navigating = true; options.roleChanged(user.role) }
      else if (typeof data.customerIdFormat === 'string') options.dataFormat?.(data.customerIdFormat)
    } catch {
      // Offline / unavailable: retain the last confirmed session and retry later.
    } finally {
      clearTimeout(timeout)
      busy = false
    }
  }
  return { check, dispose: () => { disposed = true; controller?.abort() } }
}
