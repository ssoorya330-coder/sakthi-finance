'use client'

import { motion } from 'framer-motion'
import { Logo } from './logo'
import { Shield, Cloud, Lock, Gauge } from 'lucide-react'

const features = [
  { icon: Shield, label: 'Secure' },
  { icon: Cloud, label: 'Cloud Sync' },
  { icon: Lock, label: 'Encrypted' },
  { icon: Gauge, label: '99.9% Uptime' },
]

export function LeftPanel() {
  return (
    <div className="relative flex-1 flex items-center justify-center overflow-hidden bg-[#080808]">
      <div className="absolute inset-0">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] rounded-full bg-gradient-radial from-gold-400/3 to-transparent blur-[120px]" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] rounded-full bg-gradient-radial from-gold-400/2 to-transparent blur-[120px]" />
        <div className="absolute top-[40%] left-[30%] w-[40%] h-[40%] rounded-full bg-gradient-radial from-white/[0.02] to-transparent blur-[80px]" />
      </div>

      <div className="relative z-10 max-w-lg mx-auto px-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <Logo variant="circular" size="xl" animated showText={false} />
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="mt-8 text-5xl font-bold tracking-tight"
        >
          <span className="bg-gradient-to-r from-gold-300 via-gold-200 to-gold-400 bg-clip-text text-transparent">
            SAKTHI
          </span>
          <br />
          <span className="text-white/80">Finance</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="mt-4 text-lg text-text-secondary leading-relaxed"
        >
          Enterprise financial intelligence platform. Secure, scalable, and built for the future of business.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="mt-10 flex items-center gap-6"
        >
          {features.map((feature) => {
            const Icon = feature.icon
            return (
              <div key={feature.label} className="flex items-center gap-2 text-text-muted">
                <Icon className="w-4 h-4 text-gold-400/60" />
                <span className="text-[13px] font-medium tracking-wide">{feature.label}</span>
              </div>
            )
          })}
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="mt-16 flex items-center gap-4"
        >
          <div className="flex -space-x-2">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="w-8 h-8 rounded-full border-2 border-bg-primary bg-bg-elevated flex items-center justify-center text-[11px] font-bold text-gold-300"
              >
                {['A', 'B', 'C', 'D'][i - 1]}
              </div>
            ))}
          </div>
          <p className="text-[13px] text-text-muted">
            Trusted by <span className="text-text-secondary font-medium">10,000+</span> enterprises
          </p>
        </motion.div>
      </div>
    </div>
  )
}
