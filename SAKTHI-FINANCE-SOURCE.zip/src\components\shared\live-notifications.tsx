'use client'

import { useEffect } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { useAuthStore } from '@/store/auth-store'
import { useToastStore } from '@/store/toast-store'
import { useNotifications } from '@/hooks/use-notifications'
import { isDesktopApp } from '@/lib/desktop/bridge'

export default function LiveNotifications() {
  const userId = useAuthStore(s => s.userId)
  const queryClient = useQueryClient()
  // Polling remains a fallback if a proxy or network blocks live delivery.
  useNotifications()
  useEffect(() => {
    if (!userId) return
    if (isDesktopApp()) {
      // Desktop (no HTTP server): the polling hook above is the delivery
      // mechanism; toasts fire from its query updates.
      return
    }
    const source = new EventSource('/api/notifications/stream')
    const refresh = () => { void queryClient.invalidateQueries({ queryKey: ['notifications', userId] }) }
    const seen = new Set<string>()
    source.addEventListener('ready', refresh)
    source.addEventListener('notification', event => {
      refresh()
      try {
        const data = JSON.parse((event as MessageEvent).data)
        if ( data.kind === 'new' && data.id && !seen.has(data.id)) {
          if (seen.size > 500) seen.clear()
          seen.add(data.id)
          useToastStore.getState().addToast(data.title || 'New notification received', 'info')
        }
      } catch { /* Refresh still retrieves the authoritative notification list. */ }
    })
    return () => source.close()
  }, [userId, queryClient])
  return null
}
