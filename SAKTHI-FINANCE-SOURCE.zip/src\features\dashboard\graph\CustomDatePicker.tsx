'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronLeft, ChevronRight, CalendarDays, X } from 'lucide-react'
import { formatDayFull, getDefaultCustomRange, startOfDay } from './graph-data'

const WEEKDAYS = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su']
const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
]

export interface CustomDatePickerProps {
  open: boolean
  initialStart: Date | null
  initialEnd: Date | null
  onApply: (start: Date, end: Date) => void
  onReset: () => void
  onClose: () => void
}

function sameDateKey(a: Date, b: Date): boolean {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  )
}

export default function CustomDatePicker({
  open,
  initialStart,
  initialEnd,
  onApply,
  onReset,
  onClose,
}: CustomDatePickerProps) {
  const now = new Date()
  const maxDate = startOfDay(now)

  const defaults = useMemo(() => {
    if (initialStart && initialEnd && initialStart.getTime() <= initialEnd.getTime()) {
      return { start: startOfDay(initialStart), end: startOfDay(initialEnd) }
    }
    return getDefaultCustomRange()
  }, [initialStart, initialEnd])

  const [draftStart, setDraftStart] = useState<Date | null>(null)
  const [draftEnd, setDraftEnd] = useState<Date | null>(null)
  const [view, setView] = useState({ year: maxDate.getFullYear(), month: maxDate.getMonth() })

  useEffect(() => {
    if (open) {
      setDraftStart(defaults.start)
      setDraftEnd(defaults.end)
      setView({ year: defaults.start.getFullYear(), month: defaults.start.getMonth() })
    }
  }, [open, defaults])

  useEffect(() => {
    if (!open) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [open, onClose])

  const handleDayClick = useCallback(
    (d: Date) => {
      const day = startOfDay(d)
      if (!draftStart) {
        setDraftStart(day)
        return
      }
      if (!draftEnd) {
        if (day.getTime() < draftStart.getTime()) {
          setDraftStart(day)
        } else {
          setDraftEnd(day)
        }
        return
      }
      setDraftStart(day)
      setDraftEnd(null)
    },
    [draftStart, draftEnd]
  )

  const firstDayIndex = (new Date(view.year, view.month, 1).getDay() + 6) % 7
  const daysInMonth = new Date(view.year, view.month + 1, 0).getDate()
  const isCurrentMonth =
    view.year === maxDate.getFullYear() && view.month === maxDate.getMonth()

  const goPrev = useCallback(
    () => setView((v) => (v.month === 0 ? { year: v.year - 1, month: 11 } : { year: v.year, month: v.month - 1 })),
    []
  )
  const goNext = useCallback(() => {
    if (isCurrentMonth) return
    setView((v) => (v.month === 11 ? { year: v.year + 1, month: 0 } : { year: v.year, month: v.month + 1 }))
  }, [isCurrentMonth])

  const selectionPreview = useMemo(() => {
    if (draftStart && draftEnd) return `${formatDayFull(draftStart)} – ${formatDayFull(draftEnd)}`
    if (draftStart) return `Start: ${formatDayFull(draftStart)} — select end date`
    return 'Select a start date'
  }, [draftStart, draftEnd])

  const canApply = Boolean(draftStart && draftEnd)

  const handleApply = useCallback(() => {
    if (draftStart && draftEnd) {
      const [s, e] =
        draftStart.getTime() <= draftEnd.getTime()
          ? [draftStart, draftEnd]
          : [draftEnd, draftStart]
      onApply(startOfDay(s), startOfDay(e))
    }
  }, [draftStart, draftEnd, onApply])

  const handleReset = useCallback(() => {
    setDraftStart(null)
    setDraftEnd(null)
    onReset()
  }, [onReset])

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          key="picker-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[var(--z-modal)] bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            key="picker-panel"
            initial={{ opacity: 0, y: 16, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.97 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-[420px] bg-white rounded-[24px] shadow-[0_24px_80px_rgba(0,0,0,0.25)] overflow-hidden"
          >
            <div className="px-6 pt-5 pb-4 bg-gradient-to-br from-slate-900 to-slate-800">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-[10px] bg-white/10 flex items-center justify-center">
                    <CalendarDays className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white">Custom Date Range</h3>
                    <p className="text-[11px] text-slate-300">Pick start and end dates</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onClose}
                  className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center text-slate-200 hover:bg-white/20 transition-colors"
                  aria-label="Close calendar"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="mt-3 text-[13px] font-medium text-emerald-300 tabular-nums">
                {selectionPreview}
              </p>
            </div>

            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <button
                  type="button"
                  onClick={goPrev}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-slate-500 hover:bg-slate-100 transition-colors"
                  aria-label="Previous month"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <p className="text-sm font-semibold text-slate-800">
                  {MONTHS[view.month]} {view.year}
                </p>
                <button
                  type="button"
                  onClick={goNext}
                  disabled={isCurrentMonth}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-slate-500 hover:bg-slate-100 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                  aria-label="Next month"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-7 gap-1 mb-1">
                {WEEKDAYS.map((d) => (
                  <div key={d} className="text-center text-[11px] font-semibold text-slate-400 py-1">
                    {d}
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-1">
                {Array.from({ length: firstDayIndex }).map((_, i) => (
                  <div key={`blank-${i}`} />
                ))}
                {Array.from({ length: daysInMonth }).map((_, i) => {
                  const day = new Date(view.year, view.month, i + 1)
                  const isFuture = day.getTime() > maxDate.getTime()
                  const isStart = draftStart ? sameDateKey(day, draftStart) : false
                  const isEnd = draftEnd ? sameDateKey(day, draftEnd) : false
                  const isInRange =
                    draftStart && draftEnd && day > draftStart && day < draftEnd
                  return (
                    <button
                      key={day.getTime()}
                      type="button"
                      disabled={isFuture}
                      onClick={() => handleDayClick(day)}
                      className={`h-9 rounded-[10px] text-xs font-medium transition-all duration-150 ${
                        isFuture
                          ? 'text-slate-300 cursor-not-allowed'
                          : 'text-slate-700 hover:bg-slate-100'
                      } ${isInRange ? 'bg-slate-100' : ''}`}
                      style={
                        isStart || isEnd
                          ? { backgroundColor: '#0F172A', color: '#fff', boxShadow: '0 4px 10px rgba(15,23,42,0.25)' }
                          : undefined
                      }
                    >
                      {i + 1}
                    </button>
                  )
                })}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 px-6 pb-6">
              <button
                type="button"
                onClick={handleReset}
                className="px-4 py-2 rounded-[12px] text-xs font-semibold text-slate-600 border border-slate-200 hover:bg-slate-50 transition-colors"
              >
                Reset
              </button>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-[12px] text-xs font-semibold text-slate-600 border border-slate-200 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleApply}
                disabled={!canApply}
                className="px-5 py-2 rounded-[12px] text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Apply
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
