'use client'

import { memo } from 'react'
import { motion } from 'framer-motion'
import { Check } from 'lucide-react'
import { GRAPH_METRICS } from './graph.types'
import type { GraphVisible, MetricKey } from './graph.types'

interface GraphLegendProps {
  visible: GraphVisible
  onToggle: (key: MetricKey) => void
}

function GraphLegendBase({ visible, onToggle }: GraphLegendProps) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {GRAPH_METRICS.map((metric) => {
        const isOn = visible[metric.key]
        return (
          <motion.button
            key={metric.key}
            type="button"
            onClick={() => onToggle(metric.key)}
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.95 }}
            transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
            aria-pressed={isOn}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all duration-300 ${
              isOn
                ? 'text-white border-transparent shadow-sm'
                : 'bg-white text-slate-500 border-slate-200 hover:border-slate-300 hover:text-slate-700'
            }`}
            style={
              isOn
                ? { backgroundColor: metric.color, boxShadow: `0 4px 14px ${metric.color}45` }
                : undefined
            }
          >
            <span
              className={`flex items-center justify-center w-3.5 h-3.5 rounded-full ${
                isOn ? 'bg-white/25' : 'bg-white'
              }`}
              style={isOn ? undefined : { border: `1.5px solid ${metric.color}` }}
            >
              {isOn && <Check className="w-2.5 h-2.5 text-white" strokeWidth={3.5} />}
            </span>
            {metric.label}
          </motion.button>
        )
      })}
    </div>
  )
}

export default memo(GraphLegendBase)
