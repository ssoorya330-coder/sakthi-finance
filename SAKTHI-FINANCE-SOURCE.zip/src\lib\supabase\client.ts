'use client';

import { createBrowserClient } from '@supabase/ssr';

export function isSupabaseConfigured(): boolean {
  return Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  );
}

let browserClient: ReturnType<typeof createBrowserClient> | null = null;

/**
 * Supabase Auth ONLY (browser). Used for Google OAuth login, session,
 * logout and refresh. Never used for application data — all customers,
 * loans, payments, etc. live in LOCAL PostgreSQL behind Next.js API routes.
 */
export function getSupabaseBrowserClient() {
  if (browserClient) return browserClient;
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !anonKey) {
    throw new Error(
      'Supabase Auth is not configured. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.'
    );
  }
  browserClient = createBrowserClient(url, anonKey);
  return browserClient;
}

/** Start Google OAuth via Supabase Auth. Returns the provider URL. */
export async function signInWithGoogleSupabase(next = '/dashboard'): Promise<string> {
  const supabase = getSupabaseBrowserClient();
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: {
      redirectTo: `${window.location.origin}/api/auth/supabase/callback?next=${encodeURIComponent(next)}`,
    },
  });
  if (error) throw error;
  if (!data.url) throw new Error('Supabase did not return an OAuth URL');
  window.location.href = data.url;
  return data.url;
}

export async function signOutSupabase(): Promise<void> {
  if (!isSupabaseConfigured()) return;
  try {
    const supabase = getSupabaseBrowserClient();
    await supabase.auth.signOut();
  } catch {
    // logout must never fail hard — cookies are cleared server-side too
  }
}
