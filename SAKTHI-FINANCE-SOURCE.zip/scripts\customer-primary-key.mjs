import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import dotenv from 'dotenv';
import pg from 'pg';

const inherited = new Set(Object.keys(process.env));
for (const file of ['.env', '.env.local']) {
  if (fs.existsSync(file)) for (const [key, value] of Object.entries(dotenv.parse(fs.readFileSync(file)))) {
    if (!inherited.has(key)) process.env[key] = value;
  }
}
const config = process.env.DATABASE_URL ? { connectionString: process.env.DATABASE_URL } : {
  host: process.env.DB_HOST || 'localhost', port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_NAME || 'sakthi_finance', user: process.env.DB_USER || 'postgres', password: process.env.DB_PASSWORD,
};
const client = new pg.Client({ ...config, connectionTimeoutMillis: 5000 });
const apply = process.argv.includes('--apply');
const quote = (name) => '"' + name.replaceAll('"', '""') + '"';
const table = (name) => 'public.' + quote(name);
const report = { mode: apply ? 'apply' : 'rehearsal' };
try {
  await client.connect();
  await client.query("SET lock_timeout = '5s'");
  await client.query("SET statement_timeout = '120s'");
  const source = (await client.query("SELECT data_type FROM information_schema.columns WHERE table_schema='public' AND table_name='customers' AND column_name='id'")).rows[0]?.data_type;
  if (source === 'bigint') {
    console.log(JSON.stringify({ alreadyMigrated: true, primaryKey: 'bigint' }));
  } else {
    if (source !== 'uuid') throw new Error('Unexpected customer primary key type');
    const refs = (await client.query(`SELECT table_name, column_name, data_type FROM information_schema.columns
      WHERE table_schema='public' AND column_name='customer_id' AND table_name <> 'customer_id_mappings' ORDER BY table_name`)).rows;
    const unexpected = refs.filter((r) => r.data_type !== 'uuid' && !['users', 'audit_events'].includes(r.table_name));
    if (unexpected.length) throw new Error('Unreviewed customer references: ' + unexpected.map((r) => r.table_name).join(', '));
    const constraints = (await client.query(`SELECT conrelid::regclass::text AS source, conname, pg_get_constraintdef(oid) AS definition
      FROM pg_constraint WHERE confrelid='public.customers'::regclass`)).rows;
    if (constraints.some((r) => !r.definition.startsWith('FOREIGN KEY (customer_id) REFERENCES customers(id)'))) {
      throw new Error('Unreviewed foreign key structure');
    }
    await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ');
    const locked = [...new Set(['customers', 'users', 'audit_events', 'audit_logs', ...refs.map((r) => r.table_name)])].sort();
    await client.query(`LOCK TABLE ${locked.map(table).join(', ')} IN SHARE ROW EXCLUSIVE MODE`);
    // Snapshot exact rows in temporary tables. Verification compares every
    // field; only customer IDs and operational foreign keys may change.
    for (let i = 0; i < locked.length; i++) await client.query(`CREATE TEMP TABLE pk_before_${i} ON COMMIT DROP AS SELECT to_jsonb(t) AS row FROM ${table(locked[i])} t`);
    if (apply) {
      const backupDir = path.resolve('.backups');
      fs.mkdirSync(backupDir, { recursive: true });
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backup = path.join(backupDir, `before-customer-numeric-id-${stamp}.dump`);
      const snapshot = (await client.query('SELECT pg_export_snapshot() AS snapshot')).rows[0].snapshot;
      const conn = client.connectionParameters;
      const binary = process.env.PG_DUMP_PATH || 'C:/Program Files/PostgreSQL/18/bin/pg_dump.exe';
      const restore = path.join(path.dirname(binary), 'pg_restore.exe');
      execFileSync(binary, ['--format=custom', '--file', backup, '--snapshot', snapshot, '--host', conn.host, '--port', String(conn.port), '--username', conn.user, '--dbname', conn.database], {
        env: { ...process.env, PGPASSWORD: conn.password }, windowsHide: true, timeout: 120000, stdio: ['ignore', 'pipe', 'pipe'],
      });
      const listing = execFileSync(restore, ['--list', backup], { windowsHide: true, timeout: 30000, encoding: 'utf8' });
      if (!listing.includes('TABLE DATA public customers')) throw new Error('Backup has no customers table data');
      report.backup = backup;
    }
    await client.query(fs.readFileSync(new URL('../migrations/005_customer_numeric_primary_key.sql', import.meta.url), 'utf8'));
    for (let i = 0; i < locked.length; i++) {
      const name = locked[i];
      let expected = 'b.row';
      if (name === 'customers') expected = "(b.row - 'id') || jsonb_build_object('id', (SELECT m.customer_id FROM customer_id_mappings m WHERE m.legacy_id::text=b.row->>'id'))";
      else if (refs.some((r) => r.table_name === name && r.data_type === 'uuid')) expected = "(b.row - 'customer_id') || jsonb_build_object('customer_id', (SELECT m.customer_id FROM customer_id_mappings m WHERE m.legacy_id::text=b.row->>'customer_id'))";
      else if (name === 'users') expected = "CASE WHEN EXISTS(SELECT 1 FROM customer_id_mappings m WHERE m.legacy_id::text=b.row->>'customer_id') THEN (b.row - 'customer_id') || jsonb_build_object('customer_id', (SELECT m.customer_id::text FROM customer_id_mappings m WHERE m.legacy_id::text=b.row->>'customer_id')) ELSE b.row END";
      const result = await client.query(`WITH expected AS (SELECT ${expected} AS row FROM pk_before_${i} b), actual AS (SELECT to_jsonb(t) AS row FROM ${table(name)} t)
        SELECT count(*)::int AS differences FROM ((SELECT row FROM expected EXCEPT ALL SELECT row FROM actual) UNION ALL (SELECT row FROM actual EXCEPT ALL SELECT row FROM expected)) d`);
      if (result.rows[0].differences !== 0) throw new Error('Unexpected data changes in ' + name);
    }
    const restored = (await client.query("SELECT count(*)::int AS count FROM pg_constraint WHERE confrelid='public.customers'::regclass AND convalidated")).rows[0].count;
    if (restored !== constraints.length) throw new Error('Foreign keys were not fully restored');
    report.customers = (await client.query('SELECT count(*)::int AS count, min(id)::text AS first, max(id)::text AS last FROM customers')).rows[0];
    report.foreignKeysVerified = restored;
    report.allRecordsVerified = locked;
    const sequence = (await client.query("SELECT pg_get_serial_sequence('public.customers','id') AS sequence")).rows[0].sequence;
    report.nextId = (await client.query(`SELECT CASE WHEN is_called THEN last_value+1 ELSE last_value END AS next FROM ${sequence}`)).rows[0].next;
    // Exercise default generation during rehearsal only; rolling back also
    // removes the newly-created identity sequence and this probe record.
    if (!apply) {
      const probe = (await client.query("INSERT INTO customers (customer_code, full_name) VALUES ('999999', 'Migration verification') RETURNING id")).rows[0];
      if (probe.id !== report.nextId) throw new Error('New customer identity was not generated correctly');
      report.insertDefaultVerified = true;
    }
    await client.query(apply ? 'COMMIT' : 'ROLLBACK');
    console.log(JSON.stringify(report, null, 2));
  }
} catch (error) {
  await client.query('ROLLBACK').catch(() => {});
  console.error('Customer ID migration failed; transaction rolled back:', error.message);
  process.exitCode = 1;
} finally {
  await client.end();
}
