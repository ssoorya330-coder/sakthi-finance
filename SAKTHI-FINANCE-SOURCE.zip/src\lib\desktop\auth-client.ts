'use client'

import { isDesktopApp, desktopApi } from './bridge'

/**
 * Electron auth client. Sign-in happens inside the app (modal OAuth window
 * with PKCE + state + nonce; the loopback redirect is intercepted before any
 * local server is contacted). The renderer never receives tokens — only the
 * resolved user after the main process created the session.
 */

export interface DesktopAuthUser {
  userId: string
  email: string
  name: string
  role: string
  customerId: string | null
}

const ERROR_TEXT: Record<string, string> = {
  'not-configured': 'Desktop sign-in is not configured. Complete the private setup first.',
  failed: 'Google sign-in failed. Please try again.',
  cancelled: 'Sign-in was cancelled.',
  timeout: 'Sign-in timed out. Please try again.',
  'exchange-failed': 'Could not verify the Google account. Check your connection and try again.',
  invalid: 'Google sign-in could not be verified. Please try again.',
  'not-allowed': 'This Google account is not authorized for Sakthi Finance.',
  unavailable: 'Account verification is unavailable right now. Please retry.',
}

export function desktopAuthErrorText(code: string): string {
  return ERROR_TEXT[code] || 'Sign-in failed. Please try again.'
}

export async function desktopSignIn(): Promise<{
  ok: boolean
  isNewUser?: boolean
  user?: DesktopAuthUser
  error?: string
}> {
  if (!isDesktopApp()) return { ok: false, error: 'failed' }
  const result = await desktopApi().startSignIn()
  return result as { ok: boolean; isNewUser?: boolean; user?: DesktopAuthUser; error?: string }
}

export async function desktopRestoreSession(): Promise<DesktopAuthUser | null> {
  if (!isDesktopApp()) return null
  const result = await desktopApi().restoreSession()
  return (result.user as DesktopAuthUser) || null
}

export async function desktopSetDisplayName(name: string): Promise<DesktopAuthUser | null> {
  if (!isDesktopApp()) return null
  const result = await desktopApi().setName(name)
  return (result.user as DesktopAuthUser) || null
}

export async function desktopCancelSignIn(): Promise<void> {
  if (!isDesktopApp()) return
  await desktopApi().cancelSignIn()
}

export async function desktopLogout(): Promise<void> {
  if (!isDesktopApp()) return
  await desktopApi().logout()
}
