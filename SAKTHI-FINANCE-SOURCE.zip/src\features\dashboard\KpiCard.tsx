'use client'

import { memo, useMemo } from 'react'
import { Users, Banknote, IndianRupee, Wallet, CreditCard, PiggyBank, UserMinus, Ban, Coins, Percent, Scale, BadgeCheck, UserCheck, HandCoins, Landmark, Clock, AlertTriangle } from 'lucide-react'
import { formatINR } from '@/lib/dashboard-utils'
import type { KpiCardData } from './dashboard.types'

const iconMap: Record<string, React.FC<React.SVGProps<SVGSVGElement>>> = {
  Users, Banknote, IndianRupee, Wallet, CreditCard, PiggyBank, UserMinus,
  Ban, Coins, Percent, Scale, BadgeCheck, UserCheck, HandCoins, Landmark,
  Clock, AlertTriangle,
}

interface KpiGradient {
  background: string
  from: string
  glow: string
}

const GRADIENT_CONFIG: Record<string, KpiGradient> = {
  'total-customers': { background: 'linear-gradient(135deg, #EAFBF4, #D8F8E7)', from: '#16A34A', glow: 'rgba(34,197,94,0.18)' },
  'active-customers': { background: 'linear-gradient(135deg, #E6F9FF, #D6F3FF)', from: '#0EA5E9', glow: 'rgba(14,165,233,0.18)' },
  'completed-customers': { background: 'linear-gradient(135deg, #FFF9E8, #FFF3C8)', from: 'var(--secondary)', glow: 'rgba(212,175,55,0.22)' },
  'aborted-customers': { background: 'linear-gradient(135deg, #FFF0F1, #FFE0E2)', from: '#E11D48', glow: 'rgba(225,29,72,0.18)' },
  'loan-amount-given': { background: 'linear-gradient(135deg, #F1F0FF, #E5DDFF)', from: '#7C3AED', glow: 'rgba(124,58,237,0.18)' },
  'interest-amount': { background: 'linear-gradient(135deg, #FFF0F8, #FFE2F2)', from: '#DB2777', glow: 'rgba(219,39,119,0.18)' },
  'total-amount': { background: 'linear-gradient(135deg, #FFF5E8, #FFE9CC)', from: '#F59E0B', glow: 'rgba(245,158,11,0.22)' },
  'balance-amount': { background: 'linear-gradient(135deg, #EEF6FF, #DCEEFF)', from: '#2563EB', glow: 'rgba(37,99,235,0.18)' },
}

function KpiCardSkeleton() {
  return (
    <div className="rounded-[24px] p-5 h-[156px] animate-pulse relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #F5F5F5, #EEEEEE)', border: '1px solid rgba(255,255,255,0.75)' }}>
      <div className="absolute top-0 left-0 right-0 h-[4px] bg-slate-200" />
      <div className="flex items-start justify-between mb-2">
        <div className="w-[52px] h-[52px] rounded-[18px] bg-slate-200/80" />
        <div className="w-14 h-5 rounded-full bg-slate-200/80" />
      </div>
      <div className="h-8 w-28 bg-slate-200/80 rounded mt-1 mb-1" />
      <div className="h-3.5 w-20 bg-slate-200/80 rounded" />
    </div>
  )
}

const KpiCard = memo(function KpiCard({ data, index }: { data: KpiCardData; index: number }) {
  const Icon = iconMap[data.icon] || IndianRupee
  const gradient = GRADIENT_CONFIG[data.id] || GRADIENT_CONFIG['balance-amount']
  const isPlain = data.id === 'total-customers' || data.id === 'active-customers' || data.id === 'completed-customers' || data.id === 'aborted-customers'
  const displayValue = useMemo(() => {
    const val = Number(data.value) || 0
    return isPlain ? new Intl.NumberFormat('en-IN').format(val) : formatINR(val)
  }, [data.value, isPlain])

  return (
    <div
      onClick={data.onClick}
      role={data.onClick ? 'button' : undefined}
      tabIndex={data.onClick ? 0 : undefined}
      onKeyDown={data.onClick ? event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); data.onClick?.() } } : undefined}
      className={`relative isolate flex h-[156px] min-w-0 flex-col justify-between overflow-hidden rounded-[24px] border bg-white px-5 pt-5 pb-3 shadow-[0_6px_24px_-12px_rgba(30,25,40,0.15)] transition-all duration-300 motion-reduce:transition-none hover:shadow-[0_16px_36px_-14px_rgba(30,25,40,0.22)] motion-safe:hover:-translate-y-1 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--primary)] group ${data.onClick ? 'cursor-pointer' : ''}`}
      style={{ borderColor: `color-mix(in srgb, ${gradient.from} 15%, transparent)` }}
    >
      <div aria-hidden="true" className="pointer-events-none absolute right-0 top-0 h-full w-[42%] rounded-bl-[100px] opacity-65" style={{ background: gradient.background }} />
      <svg aria-hidden="true" focusable="false" viewBox="0 0 120 180" className="pointer-events-none absolute right-0 top-0 h-full w-28 opacity-[0.18]" fill="none" stroke={gradient.from} strokeWidth="1">
        {index % 3 === 0 && [24, 40, 56, 72].map(r => <circle key={r} cx="120" cy="112" r={r} />)}
        {index % 3 === 1 && [0, 18, 36, 54].map(y => <path key={y} d={`M20 ${95 + y} Q65 ${45 + y} 120 ${85 + y}`} />)}
        {index % 3 === 2 && [0, 1, 2, 3].flatMap(row => [0, 1, 2].map(col => <path key={`${row}-${col}`} d={`M${60 + col * 20} ${80 + row * 20}h4m-2-2v4`} />))}
      </svg>
      <div className="relative flex items-center justify-between gap-3">
        <p className="max-w-[70%] text-[12px] font-semibold uppercase tracking-[0.07em] text-slate-500">{data.title}</p>
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[14px] bg-white shadow-sm ring-1 ring-white/80 motion-safe:transition-transform motion-safe:duration-300 motion-safe:group-hover:-rotate-6" style={{ color: gradient.from }}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
      <p className="relative whitespace-nowrap text-[clamp(1.3rem,2.1vw,2rem)] font-extrabold leading-tight tracking-tight text-[var(--text-primary)]" title={displayValue}>{displayValue}</p>
      <div aria-hidden="true" className="pointer-events-none relative flex h-3 items-center gap-1.5 opacity-40" style={{ color: gradient.from }}>
        <span className="h-1 rounded-full bg-current" style={{ width: 18 + (index * 7) % 25 }} />
        <span className="h-1 w-1 rounded-full bg-current" />
        <span className="h-1 rounded-full bg-current opacity-40" style={{ width: 12 + (index * 11) % 27 }} />
        <span className={`ml-1 h-2 w-2 border border-current ${index % 2 ? 'rounded-full' : 'rotate-45 rounded-[2px]'}`} />
      </div>
    </div>
  )
})

export { KpiCard as default, KpiCardSkeleton }
