import path from 'node:path'
import { pathToFileURL } from 'node:url'

/**
 * Plain-Node smoke test for the desktop API worker (no Electron, no HTTP):
 * signs a token for a real local users row and calls /api/customers through
 * callApi. Proves the dispatch chain AND the auth identity resolution work;
 * PostgreSQL must be reachable for this test.
 */

process.env.JWT_ACCESS_SECRET ??= 's'.repeat(48)
process.env.JWT_REFRESH_SECRET ??= 'r'.repeat(48)

const root = process.cwd()
const tokens = await import(pathToFileURL(path.join(root, 'src/lib/auth/tokens.ts')).href)
const { dbQuery } = await import(pathToFileURL(path.join(root, 'src/server/database.ts')).href)

// Sign for a real users row: getFullUserFromToken resolves token.sub against
// users.user_id (provider 'google') and rejects unknown ids with 401.
const users = await dbQuery(
  `SELECT user_id, email, role FROM users WHERE role IN ('owner','admin') AND is_active <> false LIMIT 1`
)
if (!users.rows[0]) {
  console.log('FAIL: no local owner/admin user found to sign a session for')
  process.exit(1)
}
const user = users.rows[0]

const worker = await import(pathToFileURL(path.join(root, 'dist-electron/api/routes.js')).href)
const token = tokens.signAccessToken({
  sub: String(user.user_id),
  email: user.email || 'smoke@test',
  name: user.email || 'Smoke',
  role: 'owner',
  provider: 'google',
})

const result = await worker.callApi(token, { path: '/customers', method: 'GET', query: { page: 1, limit: 5 } })
console.log(`user: ${user.user_id} | status:`, result.status, '| ok:', result.ok, '| error:', result.data?.error ?? 'none')
if (result.status === 200) {
  console.log('PASS: dispatch chain works with live database')
  process.exit(0)
}
if (result.status === 500 && /ECONNREFUSED|ETIMEDOUT|timeout/i.test(String(result.data?.details))) {
  console.log('PASS: dispatch chain works (DB unreachable in smoke environment, as expected)')
  process.exit(0)
}
console.log('UNEXPECTED result:', JSON.stringify(result).slice(0, 300))
process.exit(1)
