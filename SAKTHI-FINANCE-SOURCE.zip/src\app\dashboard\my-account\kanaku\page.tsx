'use client'

import { Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { ClientPageGate } from '@/components/auth/client-page-gate'
import KanakuDetailContent from '@/features/customer/KanakuDetailContent'

/**
 * Per-kanaku detail. Static-export compatible: the code travels as a query
 * parameter (?code=…) instead of a dynamic segment, and ownership is verified
 * client-side against the person group (server endpoints still enforce
 * authorization for every data request).
 */
function KanakuDetailFromQuery() {
  const code = useSearchParams().get('code') || ''
  return code ? <KanakuDetailContent code={code} /> : null
}

export default function KanakuDetailPageRoute() {
  return (
    <ClientPageGate requireRole="customer">
      <Suspense fallback={null}>
        <KanakuDetailFromQuery />
      </Suspense>
    </ClientPageGate>
  )
}
