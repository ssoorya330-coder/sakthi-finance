import { calculateKanaku } from '@/lib/kanaku'
import { resolveCustomerId } from '@/server/customer-identity'
import { NextRequest, NextResponse } from 'next/server'
import { dbTransaction, ensureSchema } from '@/server/database'
import { requireAuthWithPermission, isCustomerOwnedBy } from '@/lib/api-utils'
import {
  actorFromAuthUser,
  requestMeta,
  recordAuditEvent,
  LOAN_LABELS,
} from '@/server/audit'
import {
  DISBURSAL_MODES,
  checkDisbursalCompliance,
  getCashThreshold,
  recordCashFlagEvent,
} from '@/server/cash-compliance'

export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('loans:create');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const userId = user.userId
    const body = await request.json()
    let values: ReturnType<typeof calculateKanaku>
    try { values = calculateKanaku(body) } catch (error) {
      return NextResponse.json({ error: (error as Error).message }, { status: 400 })
    }
    const { customer_id: rawCustomerId, disbursal_mode } = body
    const { amount: loan_amount, rate: interest_rate, duration, type: loan_type, total: total_amount } = values
    const status = 'Active'
    const requestKey = typeof body.request_key === 'string' && /^[a-zA-Z0-9-]{16,100}$/.test(body.request_key) ? body.request_key : null
    const customer_id = await resolveCustomerId(rawCustomerId)

    if (!customer_id) {
      return NextResponse.json({ error: 'Customer is required' }, { status: 400 })
    }
    const disbursalMode = disbursal_mode === undefined || disbursal_mode === null || disbursal_mode === ''
      ? 'Cash'
      : String(disbursal_mode)
    if (!(DISBURSAL_MODES as readonly string[]).includes(disbursalMode)) {
      return NextResponse.json({ error: 'Disbursal mode must be Cash or Bank.' }, { status: 400 })
    }
    // Owner-scoped: a loan can only be attached to the caller's own customer.
    if (!(await isCustomerOwnedBy(customer_id, userId))) {
      return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
    }

    await ensureSchema()
    const meta = requestMeta(request)
    const actor = actorFromAuthUser(user)
    const threshold = await getCashThreshold()
    const disbursalCheck = checkDisbursalCompliance(
      { disbursal_mode: disbursalMode, loan_amount: loan_amount || 0 },
      threshold
    )
    // Loan insert + creation audit commit atomically.
    const loan = await dbTransaction(async (tx) => {
      await tx.query('SELECT id FROM customers WHERE id = $1 AND user_id = $2 FOR UPDATE', [customer_id, userId])
      if (requestKey) {
        const existing = await tx.query('SELECT * FROM loans WHERE customer_id = $1 AND user_id = $2 AND request_key = $3', [customer_id, userId, requestKey])
        if (existing.rows.length) return existing.rows[0]
      }
      const result = await tx.query(
        `INSERT INTO loans (customer_id, loan_amount, interest_rate, duration, loan_type, installment, installment_amount, total_amount, balance_amount, received_amount, status, user_id, disbursal_mode, is_flagged, flag_reason, loan_date, due_date, interest_amount, notes, request_key)
         VALUES ($1,$2,$3,$4,$5,$6,$6,$7,$7,0,'Active',$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING *`,
        [customer_id, loan_amount, interest_rate, duration, loan_type, values.installment, total_amount, userId,
          disbursalMode, disbursalCheck.flagged, disbursalCheck.reason, values.date, values.dueDate, values.interest,
          typeof body.notes === 'string' ? body.notes : null, requestKey]
      )
      const row = result.rows[0]
      const after = {
        loan_amount: loan_amount || 0, interest_rate: interest_rate || 0,
        duration: duration || 0, loan_type: loan_type || 'Daily',
        total_amount: total_amount || 0, status: status || 'Active',
        disbursal_mode: disbursalMode, cycle_number: row.cycle_number, kanaku_number: row.kanaku_number,
      }
      await recordAuditEvent(tx, {
        action: 'LOAN_CREATED',
        entityType: 'loan',
        entityId: row.loan_id,
        customerId: customer_id,
        loanId: row.loan_id,
        actor,
        ipAddress: meta.ip,
        clientInfo: meta.client,
        result: 'SUCCESS',
        changes: Object.entries(after).map(([field, v]) => ({
          field, label: LOAN_LABELS[field] || field, before: null, after: v,
        })),
        after,
      })
      if (disbursalCheck.flagged) {
        await recordCashFlagEvent(tx, {
          action: 'CASH_DISBURSAL_FLAGGED',
          entityType: 'loan',
          entityId: row.loan_id,
          customerId: customer_id,
          loanId: row.loan_id,
          paymentId: null,
          actor,
          ip: meta.ip,
          client: meta.client,
          threshold,
          amount: Number(loan_amount) || 0,
          reason: disbursalCheck.reason as string,
          after: { ...after, is_flagged: true },
        })
      }
      return row
    })

    return NextResponse.json({
      ...loan,
      cashCompliance: disbursalCheck.flagged
        ? { flagged: true, kind: 'disbursal', threshold, reason: disbursalCheck.reason }
        : { flagged: false, kind: 'disbursal', threshold },
    }, { status: 201 })
  } catch (err: any) {
    console.error('[POST /api/loan] Error:', err.message)
    return NextResponse.json(
      { error: 'Failed to create loan', details: err.message },
      { status: 500 }
    )
  }
}
