'use client'

import { AnimatedInput } from './animated-input'

export { AnimatedInput as Input }
export default AnimatedInput
