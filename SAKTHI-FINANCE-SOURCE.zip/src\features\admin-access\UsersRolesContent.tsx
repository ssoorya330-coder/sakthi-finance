'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'
import AdminSectionShell, { AdminEmpty, AdminError, AdminLoading } from './AdminSectionShell'

interface AdminUserRow {
  user_id?: string | null
  id?: string | number | null
  email?: string | null
  full_name?: string | null
  role?: string | null
  role_name?: string | null
  is_active?: boolean | null
  provider?: string | null
  last_login_at?: string | null
}

type LoadState = 'loading' | 'ready' | 'unauthorized' | 'failed'

const fmtDT = (iso: string | null | undefined) => {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: true,
    })
  } catch {
    return '—'
  }
}

export default function UsersRolesContent() {
  const [users, setUsers] = useState<AdminUserRow[]>([])
  const [state, setState] = useState<LoadState>('loading')
  const [retrying, setRetrying] = useState(false)
  const mountedRef = useRef(true)

  const load = useCallback(async (isRetry = false) => {
    if (isRetry) setRetrying(true)
    else setState('loading')
    try {
      const res = await fetch('/api/admin/users', { credentials: 'include' })
      if (res.status === 401 || res.status === 403) {
        if (mountedRef.current) setState('unauthorized')
        return
      }
      if (!res.ok) throw new Error(`Request failed (${res.status})`)
      const data = await res.json().catch(() => null)
      const rows = Array.isArray(data?.users) ? (data.users as AdminUserRow[]) : []
      if (mountedRef.current) {
        setUsers(rows)
        setState('ready')
      }
    } catch {
      if (mountedRef.current) setState('failed')
    } finally {
      if (mountedRef.current) setRetrying(false)
    }
  }, [])

  useEffect(() => {
    mountedRef.current = true
    load()
    return () => {
      mountedRef.current = false
    }
  }, [load])

  return (
    <AdminSectionShell title="Users & Roles" subtitle="Manage users and assign permitted roles" icon="users">
      {state === 'loading' && <AdminLoading />}
      {state === 'unauthorized' && (
        <AdminError message="You are not authorized to access this page." onRetry={() => load(true)} retrying={retrying} />
      )}
      {state === 'failed' && (
        <AdminError message="Unable to connect to the database. Please try again." onRetry={() => load(true)} retrying={retrying} />
      )}
      {state === 'ready' &&
        (users.length === 0 ? (
          <AdminEmpty message="No users found" />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-bold text-slate-900">
                Users <span className="text-slate-400 font-semibold">({users.length})</span>
              </p>
            </div>
            <div className="divide-y divide-slate-100">
              {users.map((u, i) => {
                const email = u.email || '—'
                const name = u.full_name || email.split('@')[0] || 'User'
                const role = u.role_name || u.role || 'employee'
                const active = u.is_active !== false
                return (
                  <div key={u.user_id || u.id || i} className="px-4 py-3 flex flex-wrap items-center gap-x-4 gap-y-1">
                    <span className="relative w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-xs flex-shrink-0"
                      style={{ background: 'linear-gradient(135deg, #D63E3E, #F36A6A)' }}>
                      {(name || 'U').charAt(0).toUpperCase()}
                    </span>
                    <span className="min-w-0">
                      <span className="block text-[13px] font-bold text-slate-900 truncate">{name}</span>
                      <span className="block text-[11px] text-slate-500 truncate">{email}</span>
                    </span>
                    <span className="ml-auto flex items-center gap-2">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-lg text-[11px] font-bold border bg-slate-100 text-slate-700 border-slate-200 capitalize">
                        {role}
                      </span>
                      <span className={cn(
                        'inline-flex items-center px-2 py-0.5 rounded-lg text-[11px] font-bold border',
                        active ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200'
                      )}>
                        {active ? 'Active' : 'Disabled'}
                      </span>
                    </span>
                    <span className="w-full text-[11px] text-slate-400">
                      Last login: {fmtDT(u.last_login_at)}
                      {u.provider ? ` · via ${u.provider}` : ''}
                    </span>
                  </div>
                )
              })}
            </div>
          </div>
        ))}
    </AdminSectionShell>
  )
}
