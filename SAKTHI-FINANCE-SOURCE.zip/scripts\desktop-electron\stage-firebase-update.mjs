import {readFile, stat, copyFile, rename} from 'node:fs/promises'
import {createReadStream} from 'node:fs'
import {createHash} from 'node:crypto'
import path from 'node:path'
import yaml from 'js-yaml'

const root = path.resolve('release/electron')
const destination = 'D:\\SAKTHI-FINANCE-UPDATES'
const {version} = JSON.parse(await readFile('package.json', 'utf8'))
if (!/^\d+\.\d+\.\d+$/.test(version)) throw Error('Invalid release version')
if (!(await stat(path.join(destination, 'public'))).isDirectory()) throw Error('Missing public update folder')
const manifest = yaml.load(await readFile(path.join(root, 'latest.yml'), 'utf8'))
const filename = `SAKTHI FINANCE Setup ${version}.exe`
if (manifest.version !== version || manifest.files?.length !== 1 || manifest.files[0].url !== filename || manifest.path !== filename) throw Error('Builder metadata does not match the current release')
const file = path.join(root, filename)
const digest = createHash('sha512')
for await (const chunk of createReadStream(file)) digest.update(chunk)
const hash = digest.digest('base64')
if (hash !== manifest.files[0].sha512 || hash !== manifest.sha512 || (await stat(file)).size !== manifest.files[0].size) throw Error('Installer integrity check failed')
if (!(await stat(file + '.blockmap')).isFile()) throw Error('Missing builder blockmap')
// Allowlisted binaries only. Copy metadata last; never touch application databases.
for (const name of [filename, filename + '.blockmap', 'latest.yml']) {
  const target = path.join(destination, 'public', name)
  await copyFile(path.join(root, name), target + '.staging')
  await rename(target + '.staging', target)
}
console.log(`Verified and staged ${version}: installer, blockmap and latest.yml only.`)
console.log('Public update URL: https://strixg16.tailb58398.ts.net/latest.yml')
