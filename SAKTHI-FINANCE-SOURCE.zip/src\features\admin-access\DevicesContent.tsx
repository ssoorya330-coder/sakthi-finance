'use client'

import { useState } from 'react'
import { cn } from '@/lib/utils'
import { classifyIpLocation, parseUserAgent } from '@/lib/device-info'
import AdminSectionShell, { AdminEmpty, AdminError, AdminLoading } from './AdminSectionShell'
import { adminMutate, useAdminApi } from './useAdminApi'

interface SessionRow {
  id?: string | null
  user_id?: string | null
  email?: string | null
  full_name?: string | null
  role?: string | null
  created_at?: string | null
  last_used_at?: string | null
  expires_at?: string | null
  user_agent?: string | null
  ip_address?: string | null
}

const fmtDT = (iso: string | null | undefined) => {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: true,
    })
  } catch {
    return '—'
  }
}

export default function DevicesContent() {
  const { data, state, retrying, retry } = useAdminApi<SessionRow[]>('/api/admin/devices', (j) =>
    Array.isArray(j?.sessions) ? (j.sessions as SessionRow[]) : []
  )
  const sessions = data || []
  const [busy, setBusy] = useState<string | null>(null)
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const [confirmOne, setConfirmOne] = useState<SessionRow | null>(null)
  const [confirmOthers, setConfirmOthers] = useState<{ userId: string; label: string } | null>(null)

  const logoutOne = async (s: SessionRow) => {
    setBusy(`one-${s.id}`)
    setMsg(null)
    const r = await adminMutate('/api/admin/devices', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tokenId: s.id, userId: s.user_id }),
    })
    setBusy(null)
    setMsg({ ok: r.ok, text: r.ok ? 'Device logged out. Its session was invalidated server-side.' : r.message })
    if (r.ok) retry()
  }

  const logoutOthers = async (userId: string) => {
    setBusy(`all-${userId}`)
    setMsg(null)
    const r = await adminMutate('/api/admin/devices', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, allOthers: true }),
    })
    setBusy(null)
    setMsg({ ok: r.ok, text: r.ok ? 'All other sessions for this user were invalidated.' : r.message })
    if (r.ok) retry()
  }

  return (
    <AdminSectionShell title="Device Management" subtitle="Active sessions and device logout" icon="login">
      {msg && (
        <div className={cn(
          'p-4 rounded-2xl border text-sm',
          msg.ok ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-amber-50 border-amber-200 text-amber-800'
        )}>
          {msg.text}
        </div>
      )}
      {state === 'loading' && <AdminLoading />}
      {state === 'unauthorized' && (
        <AdminError message="You are not authorized to access this page." onRetry={retry} retrying={retrying} />
      )}
      {state === 'failed' && (
        <AdminError message="Unable to connect to the database. Please try again." onRetry={retry} retrying={retrying} />
      )}
      {state === 'ready' &&
        (sessions.length === 0 ? (
          <AdminEmpty message="No active sessions" />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-bold text-slate-900">
                Active Sessions <span className="text-slate-400 font-semibold">({sessions.length})</span>
              </p>
            </div>
            <div className="divide-y divide-slate-100">
              {sessions.map((s) => {
                const d = parseUserAgent(s.user_agent)
                const label = `${s.full_name || s.email || s.user_id}`
                return (
                  <div key={s.id} className="px-4 py-3 flex flex-wrap items-center gap-x-4 gap-y-1.5">
                    <span className="min-w-0 flex-1 basis-56">
                      <span className="block text-[13px] font-bold text-slate-900 truncate">{label}</span>
                      <span className="block text-[11px] text-slate-500 truncate">
                        {d.device} · {d.browser} · {d.os}
                      </span>
                      <span className="block text-[11px] text-slate-400 tabular-nums">
                        IP {s.ip_address || '—'} · {classifyIpLocation(s.ip_address)}
                      </span>
                    </span>
                    <span className="text-[11px] text-slate-500 tabular-nums">
                      Login: {fmtDT(s.created_at)}<br />Active: {fmtDT(s.last_used_at || s.created_at)}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <button
                        disabled={busy !== null}
                        onClick={() => setConfirmOne(s)}
                        className="px-3 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                      >
                        Logout Device
                      </button>
                      <button
                        disabled={busy !== null}
                        onClick={() => setConfirmOthers({ userId: s.user_id || '', label })}
                        className="px-3 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                      >
                        {busy === `all-${s.user_id}` ? 'Working…' : 'Logout All Others'}
                      </button>
                    </span>
                  </div>
                )
              })}
            </div>
          </div>
        ))}

      {confirmOne && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setConfirmOne(null)}>
          <div onClick={(e) => e.stopPropagation()} className="w-full max-w-[440px] bg-white rounded-[22px] border border-slate-100 shadow-2xl p-6">
            <h3 className="text-base font-bold text-slate-900">Logout this device?</h3>
            <p className="text-sm text-slate-500 mt-2">
              The session for <b className="text-slate-800">{confirmOne.email || confirmOne.user_id}</b> will be
              invalidated server-side and removed from active sessions. The device must sign in again.
            </p>
            <div className="mt-5 flex gap-2 justify-end">
              <button onClick={() => setConfirmOne(null)} className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-medium hover:bg-slate-50">Cancel</button>
              <button
                onClick={() => {
                  const s = confirmOne
                  setConfirmOne(null)
                  logoutOne(s)
                }}
                disabled={busy !== null}
                className="px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222] disabled:opacity-50"
              >
                Logout Device
              </button>
            </div>
          </div>
        </div>
      )}

      {confirmOthers && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setConfirmOthers(null)}>
          <div onClick={(e) => e.stopPropagation()} className="w-full max-w-[440px] bg-white rounded-[22px] border border-slate-100 shadow-2xl p-6">
            <h3 className="text-base font-bold text-slate-900">Logout all other devices?</h3>
            <p className="text-sm text-slate-500 mt-2">
              Every other active session for <b className="text-slate-800">{confirmOthers.label}</b> will be
              invalidated server-side. The most recently active session is kept.
            </p>
            <div className="mt-5 flex gap-2 justify-end">
              <button onClick={() => setConfirmOthers(null)} className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-medium hover:bg-slate-50">Cancel</button>
              <button
                onClick={() => {
                  const c = confirmOthers
                  setConfirmOthers(null)
                  logoutOthers(c.userId)
                }}
                disabled={busy !== null}
                className="px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222] disabled:opacity-50"
              >
                Logout Others
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminSectionShell>
  )
}
