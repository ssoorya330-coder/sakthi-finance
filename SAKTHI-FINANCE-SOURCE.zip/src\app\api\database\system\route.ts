import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/api-utils'
import { getDataDirectory, getDiskUsageForPath, getServerTime, dirSizeBytes } from '@/server/storage'

/** Local PostgreSQL storage: data directory (+ its size) and hosting drive usage. */
export async function GET() {
  const auth = await requireAuth()
  if (auth.error) return auth.error

  try {
    const [dataDirectory, serverTime] = await Promise.all([getDataDirectory(), getServerTime()])
    const drive = dataDirectory ? getDiskUsageForPath(dataDirectory) : null
    let dataDirSizeBytes: number | null = null
    try {
      if (dataDirectory) dataDirSizeBytes = dirSizeBytes(dataDirectory)
    } catch {}
    return NextResponse.json({ dataDirectory, dataDirSizeBytes, drive, serverTime })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to load system storage information', details: err.message },
      { status: 500 }
    )
  }
}
