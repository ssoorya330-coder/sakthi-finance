'use client'

import { captureException, captureMessage, setTag, setUser } from '@sentry/nextjs'
import { createContext, useContext } from 'react'

interface SentryContextValue {
  captureException: typeof captureException
  captureMessage: typeof captureMessage
  setTag: typeof setTag
  setUser: typeof setUser
}

const SentryContext = createContext<SentryContextValue>({
  captureException,
  captureMessage,
  setTag,
  setUser,
})

export function SentryProvider({ children }: { children: React.ReactNode }) {
  return (
    <SentryContext.Provider value={{ captureException, captureMessage, setTag, setUser }}>
      {children}
    </SentryContext.Provider>
  )
}

export function useSentry() {
  return useContext(SentryContext)
}

export { captureException, captureMessage, setTag, setUser }
