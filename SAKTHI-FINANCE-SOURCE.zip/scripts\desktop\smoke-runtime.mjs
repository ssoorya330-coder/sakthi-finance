import { spawn } from 'node:child_process'
import path from 'node:path'
import assert from 'node:assert/strict'

const stage = process.argv[2]
if (!stage || !path.isAbsolute(stage)) throw Error('Explicit staging path required')
const child = spawn(path.join(stage, 'node.exe'), [path.join(stage, 'backend-launcher.mjs')], {
  windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'], env: { ...process.env,
    SAKTHI_DESKTOP_CONFIG: path.join(process.env.APPDATA, 'com.sakthifinance.desktop', 'runtime.json') },
})
const exited = new Promise(resolve => child.once('exit', resolve))
try {
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(Error('Runtime readiness timed out')), 75000)
    let output = ''
    child.stdout.on('data', chunk => {
      output = (output + chunk.toString()).slice(-4000)
      if (output.includes('SAKTHI_READY')) { clearTimeout(timer); resolve() }
      const failure = output.match(/SAKTHI_ERROR:([A-Z]+)/)
      if (failure) { clearTimeout(timer); reject(Error(`Runtime failed: ${failure[1]}`)) }
    })
    child.once('error', () => { clearTimeout(timer); reject(Error('Unable to start packaged Node')) })
    child.once('exit', () => { clearTimeout(timer); reject(Error('Packaged backend exited before readiness')) })
    child.stderr.resume() // never print potentially sensitive library errors
  })
  assert.equal((await fetch('http://127.0.0.1:38471/login')).status, 200)
  assert.equal((await fetch('http://127.0.0.1:38471/api/desktop/ready')).status, 404)
  assert.equal((await fetch('http://127.0.0.1:38471/api/customers')).status, 401)
  console.log('PASS: packaged Node/backend started, existing database preflight passed, login served, readiness protected, anonymous customers rejected.')
  child.stdin.end()
  await Promise.race([exited, new Promise((_, reject) => setTimeout(() => reject(Error('Backend did not stop with parent pipe')), 5000).unref())])
  console.log('PASS: backend exited when the parent closed its control pipe.')
} finally { if (child.exitCode === null) child.kill() }
