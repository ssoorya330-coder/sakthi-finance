'use client'

import { motion, AnimatePresence, useReducedMotion } from 'framer-motion'
import { CheckCircle2, XCircle, Info, X, AlertTriangle } from 'lucide-react'
import { useToastStore, type ToastType } from '@/store/toast-store'

const icons: Record<ToastType, React.ReactNode> = {
  success: <CheckCircle2 className="w-4 h-4 text-emerald-500" />,
  error: <XCircle className="w-4 h-4 text-red-500" />,
  info: <Info className="w-4 h-4 text-blue-500" />,
  warning: <AlertTriangle className="w-4 h-4 text-amber-500" />,
}

const bg: Record<ToastType, string> = {
  success: 'bg-emerald-50 border-emerald-200 text-emerald-700',
  error: 'bg-red-50 border-red-200 text-red-700',
  info: 'bg-blue-50 border-blue-200 text-blue-700',
  warning: 'bg-amber-50 border-amber-200 text-amber-700',
}

export default function ToastContainer() {
  const { toasts, removeToast } = useToastStore()
  const reducedMotion = useReducedMotion()
  const titles = { success: 'Action completed', error: 'Something needs attention', info: 'A quick update', warning: 'Please check' }

  return (
    <div aria-label="Notifications" className="fixed top-4 right-3 sm:right-5 w-[calc(100%-1.5rem)] sm:w-[390px] max-h-[calc(100dvh-2rem)] overflow-y-auto z-[var(--z-toast)] flex flex-col gap-3 pointer-events-none">
      <AnimatePresence>
        {toasts.map((toast) => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: reducedMotion ? 0 : -12, x: reducedMotion ? 0 : 20 }}
            animate={{ opacity: 1, y: 0, x: 0 }}
            exit={{ opacity: 0, x: reducedMotion ? 0 : 40 }}
            transition={{ duration: reducedMotion ? 0 : 0.25, ease: [0.22, 1, 0.36, 1] }}
            className={`relative overflow-hidden shrink-0 pointer-events-auto flex items-start gap-3 p-4 rounded-2xl border shadow-[0_12px_36px_-12px_rgba(80,25,25,0.3)] text-sm font-medium ${bg[toast.type]}`}
          >
            <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-gradient-to-r from-[#fffdf7] via-white/90 to-transparent" />
            <div aria-hidden="true" className="pointer-events-none absolute -right-6 -top-7 h-28 w-28 rounded-full border-[12px] border-current opacity-[0.06]" />
            <div aria-hidden="true" className="pointer-events-none absolute right-0 bottom-0 h-16 w-28 opacity-[0.12]" style={{ backgroundImage: 'radial-gradient(currentColor 1px, transparent 1px)', backgroundSize: '9px 9px' }} />
            <div aria-hidden="true" className="absolute left-0 inset-y-0 w-1 bg-current opacity-60" />
            <div aria-hidden="true" className="relative mt-1 flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white shadow-sm ring-4 ring-white/50">{icons[toast.type]}</div>
            <div role={toast.type === 'error' ? 'alert' : 'status'} aria-atomic="true" className="relative min-w-0 flex-1">
              <p className="text-[9px] uppercase tracking-[0.18em] font-bold text-[var(--primary)]/60">Sakthi Finance</p>
              <p className="mt-1 font-bold text-slate-900">{toast.type === 'success' && /customer/i.test(toast.message) ? (/abort/i.test(toast.message) ? 'Customer status updated' : /creat|added/i.test(toast.message) ? 'Customer added' : 'Customer details updated') : titles[toast.type]}</p>
              <p className="mt-1 whitespace-pre-line break-words leading-relaxed text-slate-600">{toast.message}</p>
            </div>
            <button
              type="button"
              aria-label="Dismiss notification"
              onClick={() => removeToast(toast.id)}
              className="relative -mr-1 -mt-1 shrink-0 p-2 rounded-full hover:bg-black/5 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--primary)]"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}
