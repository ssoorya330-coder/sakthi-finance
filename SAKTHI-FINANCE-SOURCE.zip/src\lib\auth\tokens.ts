import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { dbQuery } from '@/server/database';
import { signingKey } from './signing-keys';

const ACCESS_TOKEN_SECRET =
  signingKey('JWT_ACCESS_SECRET');
const REFRESH_TOKEN_SECRET =
  signingKey('JWT_REFRESH_SECRET');

export const ACCESS_TOKEN_TTL = '15m';
export const REFRESH_TOKEN_TTL_DAYS = 30;
export const REFRESH_TOKEN_TTL_SECONDS = REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60;

export const ACCESS_COOKIE_NAME = 'sf_access';
export const REFRESH_COOKIE_NAME = 'sf_refresh';

export interface TokenPayload {
  sub: string;
  email: string;
  name: string;
  role: string;
  provider?: string;
  picture?: string;
}

export interface RefreshTokenRecord {
  id: string;
  user_id: string;
  token_hash: string;
  expires_at: string;
  created_at: string;
  revoked_at: string | null;
  last_used_at: string | null;
  user_agent: string | null;
  ip_address: string | null;
}

export function isSecureCookie(): boolean {
  return process.env.NODE_ENV === 'production';
}

export function signAccessToken(payload: TokenPayload, expiresInMinutes = 15): string {
  return jwt.sign(payload, ACCESS_TOKEN_SECRET, { expiresIn: `${expiresInMinutes}m` });
}

export function signRefreshToken(payload: TokenPayload): string {
  return jwt.sign(
    { ...payload, typ: 'refresh' },
    REFRESH_TOKEN_SECRET,
    { expiresIn: `${REFRESH_TOKEN_TTL_DAYS}d` }
  );
}

export function verifyAccessToken(token: string): TokenPayload | null {
  try {
    const decoded = jwt.verify(token, ACCESS_TOKEN_SECRET) as TokenPayload & { iat: number; exp: number };
    return {
      sub: decoded.sub,
      email: decoded.email,
      name: decoded.name,
      role: decoded.role,
      provider: decoded.provider,
      picture: decoded.picture,
    };
  } catch {
    return null;
  }
}

export function verifyRefreshToken(token: string): (TokenPayload & { typ?: string }) | null {
  try {
    const decoded = jwt.verify(token, REFRESH_TOKEN_SECRET) as TokenPayload & { typ?: string; iat: number; exp: number };
    return decoded;
  } catch {
    return null;
  }
}

/**
 * Hash a refresh token using SHA-256. We never store the raw token in the DB.
 * This means even if the DB is leaked, attackers cannot reuse refresh tokens.
 */
export function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export async function storeRefreshToken(
  userId: string,
  token: string,
  metadata: { userAgent?: string; ipAddress?: string } = {}
): Promise<void> {
  const tokenHash = hashToken(token);
  const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_SECONDS * 1000);
  await dbQuery(
    `INSERT INTO refresh_tokens (user_id, token_hash, expires_at, user_agent, ip_address)
     VALUES ($1, $2, $3, $4, $5)`,
    [userId, tokenHash, expiresAt.toISOString(), metadata.userAgent || null, metadata.ipAddress || null]
  );
}

export async function findRefreshToken(token: string): Promise<RefreshTokenRecord | null> {
  const tokenHash = hashToken(token);
  const result = await dbQuery<RefreshTokenRecord>(
    `SELECT id, user_id, token_hash, expires_at, created_at, revoked_at, last_used_at, user_agent, ip_address
     FROM refresh_tokens WHERE token_hash = $1`,
    [tokenHash]
  );
  return result.rows[0] || null;
}

export async function markRefreshTokenUsed(id: string): Promise<void> {
  await dbQuery(
    `UPDATE refresh_tokens SET last_used_at = NOW() WHERE id = $1`,
    [id]
  );
}

export async function revokeRefreshToken(token: string): Promise<void> {
  const tokenHash = hashToken(token);
  await dbQuery(
    `UPDATE refresh_tokens SET revoked_at = NOW() WHERE token_hash = $1 AND revoked_at IS NULL`,
    [tokenHash]
  );
}

export async function revokeAllRefreshTokensForUser(userId: string): Promise<void> {
  await dbQuery(
    `UPDATE refresh_tokens SET revoked_at = NOW() WHERE user_id = $1 AND revoked_at IS NULL`,
    [userId]
  );
}

/** Revoke a single session by row id. Returns true when a row was revoked. */
export async function revokeRefreshTokenById(id: string, userId: string): Promise<boolean> {
  const result = await dbQuery(
    `UPDATE refresh_tokens SET revoked_at = NOW()
     WHERE id::text = $1 AND user_id = $2 AND revoked_at IS NULL AND expires_at > NOW()`,
    [id, userId]
  );
  return (result.rowCount || 0) > 0;
}

/**
 * Enforce a per-user active-session cap: revoke the oldest sessions beyond
 * `keep` most-recently-active ones. Returns the number revoked.
 */
export async function pruneSessionsBeyondLimit(userId: string, keep: number): Promise<number> {
  if (!Number.isFinite(keep) || keep < 1) return 0;
  const result = await dbQuery(
    `UPDATE refresh_tokens SET revoked_at = NOW()
     WHERE id IN (
       SELECT id FROM refresh_tokens
       WHERE user_id = $1 AND revoked_at IS NULL AND expires_at > NOW()
       ORDER BY COALESCE(last_used_at, created_at) DESC, created_at DESC
       OFFSET $2
     )`,
    [userId, Math.floor(keep)]
  );
  return result.rowCount || 0;
}

/**
 * Revoke every active session for a user except one kept session
 * (used by "logout all other devices"). Returns the number revoked.
 */
export async function revokeAllSessionsExcept(userId: string, exceptId: string): Promise<number> {
  const result = await dbQuery(
    `UPDATE refresh_tokens SET revoked_at = NOW()
     WHERE user_id = $1 AND id::text <> $2 AND revoked_at IS NULL AND expires_at > NOW()`,
    [userId, exceptId]
  );
  return result.rowCount || 0;
}

export interface CookieOptions {
  name: string;
  value: string;
  maxAge: number;
  httpOnly?: boolean;
  secure?: boolean;
  sameSite?: 'lax' | 'strict' | 'none';
  path?: string;
}

export function cookieOptions(maxAge: number, httpOnly = true): {
  httpOnly: boolean;
  secure: boolean;
  sameSite: 'lax';
  path: string;
  maxAge: number;
} {
  return {
    httpOnly,
    secure: isSecureCookie(),
    sameSite: 'lax',
    path: '/',
    maxAge,
  };
}

export function accessCookie(value: string): { name: string; value: string; options: ReturnType<typeof cookieOptions> } {
  return {
    name: ACCESS_COOKIE_NAME,
    value,
    options: cookieOptions(15 * 60),
  };
}

export function refreshCookie(value: string): { name: string; value: string; options: ReturnType<typeof cookieOptions> } {
  return {
    name: REFRESH_COOKIE_NAME,
    value,
    options: cookieOptions(REFRESH_TOKEN_TTL_SECONDS),
  };
}

export function clearCookieOptions(): {
  httpOnly: boolean;
  secure: boolean;
  sameSite: 'lax';
  path: string;
  maxAge: number;
} {
  return {
    httpOnly: true,
    secure: isSecureCookie(),
    sameSite: 'lax',
    path: '/',
    maxAge: 0,
  };
}
