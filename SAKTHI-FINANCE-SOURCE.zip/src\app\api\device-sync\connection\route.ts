import { NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'

export const dynamic = 'force-dynamic'

export async function GET() {
  const auth = await requireAuthWithPermission('customers:create')
  if (auth.error) return auth.error
  try {
    // Query the configured database only. Never create a fallback database.
    await dbQuery('SELECT 1 AS available')
    return NextResponse.json({ userId: auth.user.userId, available: true }, { headers: { 'Cache-Control': 'no-store' } })
  } catch {
    return NextResponse.json({ error: 'Storage offline. Check the laptop, PostgreSQL and its configured drive.' }, { status: 503 })
  }
}
