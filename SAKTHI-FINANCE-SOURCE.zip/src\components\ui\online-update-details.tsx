'use client'
import { useState } from 'react'
import type { OnlineUpdateStatus } from '../../../electron/online-updates'
import { useOnlineUpdates } from '@/hooks/use-online-updates'

const labels: Record<OnlineUpdateStatus['phase'], string> = {
  idle: 'Automatic updates', checking: 'Checking…', available: 'New Update Available', current: 'Up to date',
  downloading: 'Downloading Update', ready: 'Update Ready', offline: 'Offline', error: 'Update failed', installing: 'Restarting…', development: 'Development mode',
}
const mb = (bytes: number) => (bytes / 1048576).toFixed(1)
export function OnlineUpdateDetails({state}: {state: OnlineUpdateStatus}) {
  const [working, setWorking] = useState(false)
  const [error, setError] = useState('')
  const busy = working || ['checking', 'downloading', 'installing', 'development'].includes(state.phase)
  async function run(action: 'check' | 'download' | 'restart') {
    setWorking(true); setError('')
    try { await window.sakthi!.updates[action]() }
    catch { setError('Unable to complete the update. You can continue using Sakthi Finance.') }
    finally { setWorking(false) }
  }
  return <section className="rounded-xl border border-[var(--secondary)]/30 bg-white p-4 text-[var(--primary)]">
    <p className="text-xs font-bold tracking-widest">SAKTHI FINANCE</p>
    <h3 className="mt-1 text-lg font-bold">{labels[state.phase]}</h3>
    <p className="mt-2 text-sm">Current Version: {state.currentVersion}</p>
    {state.version && <p className="text-sm">New Version: {state.version}</p>}
    <p className="mt-1 text-xs text-slate-500">Last Update Check: {state.lastCheck ? new Date(state.lastCheck).toLocaleString() : 'Not checked yet'}</p>
    <p role="status" className="mt-3 text-sm text-slate-600">{error || state.message}</p>
    {state.phase === 'downloading' && <div className="mt-3">
      <progress aria-label="Update download progress" max={100} value={state.percent} className="h-3 w-full accent-[var(--primary)]" />
      <div className="flex justify-between text-xs"><span>{state.percent.toFixed(0)}%</span><span>{mb(state.transferred)} MB / {mb(state.total)} MB</span></div>
      {state.bytesPerSecond > 0 && <p className="mt-1 text-xs text-slate-500">{mb(state.bytesPerSecond)} MB/s</p>}
    </div>}
    {state.phase === 'ready' && <p className="mt-2 text-sm">Sakthi Finance v{state.version} has been downloaded. Restart to apply the update automatically.</p>}
    <div className="mt-4 flex flex-wrap gap-2">
      {state.phase !== 'ready' && <button type="button" disabled={busy} onClick={() => void run('check')} className="rounded-lg border border-[var(--secondary)]/40 px-3 py-2 text-sm disabled:opacity-50">Check for Updates</button>}
      {state.phase === 'available' && <button type="button" disabled={busy} onClick={() => void run('download')} className="rounded-lg bg-[var(--primary)] px-3 py-2 text-sm text-white disabled:opacity-50">Download Update</button>}
      {state.phase === 'ready' && <button type="button" disabled={busy} onClick={() => void run('restart')} className="rounded-lg bg-[var(--primary)] px-3 py-2 text-sm text-white disabled:opacity-50">Restart</button>}
    </div>
  </section>
}
export default function OnlineUpdateSettings() {
  const state = useOnlineUpdates()
  return state ? <div className="p-5"><OnlineUpdateDetails state={state} /></div> : null
}
