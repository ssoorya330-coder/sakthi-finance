'use client'

import { useEffect } from 'react'
import { useAuthStore, clearAuthPersistedState } from '@/store/auth-store'

const STORAGE_KEY = 'sf-auth'

export function AuthSync() {
  useEffect(() => {
    function handleStorageChange(e: StorageEvent) {
      if (e.key !== STORAGE_KEY) return

      const newValue = e.newValue ? JSON.parse(e.newValue) : null
      const isAuthenticated = newValue?.state?.isAuthenticated ?? false

      if (!isAuthenticated) {
        clearAuthPersistedState()
        useAuthStore.getState().logout()
        // No sign-in page — dashboard is accessible without auth
      }
    }

    window.addEventListener('storage', handleStorageChange)
    return () => window.removeEventListener('storage', handleStorageChange)
  }, [])

  return null
}
