import crypto from 'crypto'
import fs from 'fs'
import os from 'os'
import path from 'path'
import { execFile } from 'child_process'
import { promisify } from 'util'
import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'

const execFileAsync = promisify(execFile);

export const dynamic = 'force-dynamic'

const JOB_PREFIX = 'sakthi-pg-migrate-'
const HEARTBEAT_WAIT_MS = 25000
const POLL_MS = 1000

function jobDirFor(id: string): string | null {
  if (!/^[0-9a-f]{24}$/.test(id)) return null
  return path.join(os.tmpdir(), JOB_PREFIX + id)
}

function cleanupOldJobs() {
  try {
    const now = Date.now()
    for (const name of fs.readdirSync(os.tmpdir())) {
      if (!name.startsWith(JOB_PREFIX)) continue
      const dir = path.join(os.tmpdir(), name)
      try {
        const st = fs.statSync(dir)
        if (now - st.mtimeMs > 24 * 60 * 60 * 1000) {
          fs.rmSync(dir, { recursive: true, force: true })
        }
      } catch {}
    }
  } catch {}
}

/**
 * Launch the privileged migration worker through the Windows UAC mechanism.
 * The user only approves the UAC dialog — no terminal, no manual commands.
 *
 * Body: { mode?: 'migrate' | 'restore', source?: string, destination: string }
 * - migrate: full privileged sequence (stop -> copy -> verify -> configure -> start)
 * - restore: point the service back at `destination` (the original dir) + start
 *
 * No credentials are passed anywhere (the worker needs none).
 */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    if (os.platform() !== 'win32') {
      return NextResponse.json({ ok: false, error: 'Automatic migration is only supported on Windows.' }, { status: 200 })
    }
    const body = await request.json()
    const mode = body.mode === 'restore' ? 'restore' : 'migrate'
    const destination = (body.destination || '').trim()
    const source = (body.source || '').trim() || null
    if (!destination) return NextResponse.json({ error: 'Destination is required.' }, { status: 400 })
    // Normalize forward slashes before validating (detected paths use them).
    if (!/^[A-Za-z]:[\\/]/.test(destination)) {
      return NextResponse.json({ ok: false, error: 'Destination must be an absolute local path.' }, { status: 200 })
    }
    if (mode === 'migrate' && !source) {
      return NextResponse.json({ ok: false, error: 'Source data directory is required.' }, { status: 200 })
    }

    cleanupOldJobs()
    const jobId = crypto.randomBytes(12).toString('hex')
    const jobDir = jobDirFor(jobId) as string
    fs.mkdirSync(jobDir, { recursive: true })
    fs.writeFileSync(
      path.join(jobDir, 'params.json'),
      JSON.stringify(mode === 'restore' ? { mode, destination } : { mode, source, destination })
    )

    // Launch detached + elevated. Start-Process -Verb RunAs raises the UAC
    // consent dialog automatically. Fixed executable/paths only — the only
    // variable part is our own generated job dir (safe charset).
    const nodeExe = process.env.SAKTHI_NODE_EXE || process.execPath
    const worker = process.env.SAKTHI_HELPER_ROOT
      ? path.join(process.env.SAKTHI_HELPER_ROOT, 'pg-migrate-elevated.js')
      : path.join(process.cwd(), 'scripts', 'pg-migrate-elevated.js')
    if (!fs.existsSync(worker)) {
      return NextResponse.json({ ok: false, error: 'Migration helper is missing.' }, { status: 200 })
    }
    const psCommand =
      `Start-Process -FilePath "${nodeExe}" ` +
      `-ArgumentList "${worker}", "--jobDir", "${jobDir}" -Verb RunAs -WindowStyle Hidden`

    try {
      // NOTE: Start-Process -Verb RunAs blocks until the UAC dialog is
      // answered, so this wait covers a slow approval (denial returns fast).
      await execFileAsync('powershell.exe', [
        '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', psCommand,
      ], { timeout: 150000, windowsHide: true, encoding: 'utf8' })
    } catch (e: any) {
      const msg = String(e?.message || e)
      // User pressed "No" on the UAC dialog (or launch was blocked): report
      // precisely that — never blame PostgreSQL for an elevation refusal.
      if (/cancel|canceled|cancelled|denied|abort|0x800704C7/i.test(msg)) {
        try { fs.rmSync(jobDir, { recursive: true, force: true }) } catch {}
        return NextResponse.json(
          { ok: false, elevationDenied: true, error: 'Administrator permission is required to move the PostgreSQL data directory.' },
          { status: 200 }
        )
      }
      return NextResponse.json(
        { ok: false, error: `Could not request Administrator permission: ${msg.slice(0, 200)}` },
        { status: 200 }
      )
    }

    // Launched: wait for the worker heartbeat (proves UAC was approved).
    const start = Date.now()
    while (Date.now() - start < HEARTBEAT_WAIT_MS) {
      try {
        fs.accessSync(path.join(jobDir, 'started.json'), fs.constants.R_OK)
        return NextResponse.json({ ok: true, jobId })
      } catch {}
      await new Promise((r) => setTimeout(r, POLL_MS))
    }
    // Still no heartbeat: approval may still arrive — keep polling server-side
    // via the progress endpoint instead of failing here.
    return NextResponse.json({ ok: true, jobId, awaitingApproval: true })
  } catch (err: any) {
    return NextResponse.json(
      { ok: false, error: 'Elevation request failed', details: err.message },
      { status: 500 }
    )
  }
}
