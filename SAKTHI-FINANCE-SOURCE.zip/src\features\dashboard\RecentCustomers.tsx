'use client'

import { motion } from 'framer-motion'
import { ArrowUpRight } from 'lucide-react'
import { useCustomerStore } from '@/store/customer-store'
import { formatCurrency, getStatusColor, formatDateDMY } from './dashboard.styles'

export default function RecentCustomers() {
  const storeCustomers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const displayCustomers = storeCustomers.slice(0, 6)
  const paidByCustomer = new Map<string, number>()
  for (const p of paymentHistory) {
    if (!p.customerId) continue
    paidByCustomer.set(p.customerId, (paidByCustomer.get(p.customerId) ?? 0) + (Number(p.paymentAmount) || 0))
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.7, ease: [0.16, 1, 0.3, 1] }}
      className="bg-white rounded-[18px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] overflow-hidden"
    >
      <div className="flex items-center justify-between px-6 pt-6 pb-4">
        <div>
          <h3 className="text-lg font-bold text-slate-900">Recent Customers</h3>
          <p className="text-sm text-slate-500 mt-0.5">Latest customer entries</p>
        </div>
        <button className="flex items-center gap-1 text-sm font-medium text-[var(--primary)] hover:text-[var(--primary-hover)] transition-colors">
          View All
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-100">
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-3">Customer Name</th>
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-3">Phone</th>
              <th className="text-right text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-3">Amount Given</th>
              <th className="text-right text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-3">Interest</th>
              <th className="text-right text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-3">Balance</th>
              <th className="text-center text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-3">Status</th>
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-3">Date</th>
            </tr>
          </thead>
          <tbody>
            {displayCustomers.map((customer, i) => {
              const statusStyle = getStatusColor(customer.status)
              return (
                <motion.tr
                  key={customer.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.8 + i * 0.05 }}
                  className="border-b border-slate-50 last:border-0 hover:bg-slate-50/50 transition-colors"
                >
                  <td className="px-6 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                        {customer.fullName?.charAt(0) || 'C'}
                      </div>
                      <span className="text-sm font-medium text-slate-900">{customer.fullName}</span>
                    </div>
                  </td>
                  <td className="px-6 py-3.5 text-sm text-slate-500">{customer.mobileNumber}</td>
                  <td className="px-6 py-3.5 text-sm font-medium text-slate-900 text-right">
                    {formatCurrency(Number(customer.loanAmount) || 0)}
                  </td>
                  <td className="px-6 py-3.5 text-sm text-slate-600 text-right">
                    {formatCurrency(Number(customer.interestAmount) || 0)}
                  </td>
                  <td className="px-6 py-3.5 text-sm font-medium text-slate-900 text-right">
                    {formatCurrency(Math.max(0, (Number(customer.totalAmount) || 0) - (paidByCustomer.get(customer.id) ?? 0)))}
                  </td>
                  <td className="px-6 py-3.5 text-center">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold ${statusStyle.bg} ${statusStyle.text}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${statusStyle.dot}`} />
                      {customer.status}
                    </span>
                  </td>
                  <td className="px-6 py-3.5 text-sm text-slate-500">
                    {formatDateDMY(customer.loanDate || '')}
                  </td>
                </motion.tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </motion.div>
  )
}
