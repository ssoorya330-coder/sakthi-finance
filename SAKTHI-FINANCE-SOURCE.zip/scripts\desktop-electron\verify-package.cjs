// Read-only package inspection. Never print configuration values or secrets.
const asar = require('@electron/asar')
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const archive = path.resolve(process.argv[2] || 'release/electron/win-unpacked/resources/app.asar')
const entries = asar.listPackage(archive).map(file => file.replaceAll('\\', '/').replace(/^\//, ''))
const read = file => asar.extractFile(archive, file.split('/').join(path.sep))
const tests = []
const check = (test, pass) => tests.push({ test, status: pass ? 'PASS' : 'FAIL' })
for (const file of ['dist-electron/main.js', 'dist-electron/preload.js', 'dist-electron/api/routes.js']) {
  check(`${file} matches verified build`, read(file).equals(fs.readFileSync(file)))
}
check('private runtime, session and environment files excluded', !entries.some(file => /(^|\/)(\.env[^/]*|runtime\.json|sk-desktop-session[^/]*)$/.test(file)))
check('source backups and Tauri output excluded', !entries.some(file => /(^|\/)(\.backups|src-tauri|desktop-staging)(\/|$)/.test(file)))
for (const file of ['index.html','login.html','dashboard.html','dashboard/customers.html','database.html']) {
  check(`bundled page ${file}`, entries.includes('out-desktop-build/' + file))
}
check('native migration and voice helpers included outside read-only archive', ['node.exe','pg-migrate-elevated.js','node-LICENSE.txt','SakthiSpeech.exe'].every(file=>fs.existsSync(path.join(path.dirname(archive),'native',file))))
check('packaged brand artwork matches new logo', read('out-desktop-build/sakthi-brand.png').equals(fs.readFileSync('public/sakthi-brand.png')))
check('packaged Windows icon matches new logo icon', read('dist-electron/icon.ico').equals(fs.readFileSync('desktop/electron-assets/icon.ico')))
const privateConfig = JSON.parse(fs.readFileSync(path.join(process.env.APPDATA,'com.sakthifinance.desktop/runtime.json'),'utf8'))
const native = path.join(path.dirname(archive), 'native')
check('offline capture helper matches tested build', fs.readFileSync(path.join(native, 'SakthiAudio.exe')).equals(fs.readFileSync('dist-electron/native/SakthiAudio.exe')))
check('offline speech runtime and licenses included', ['whisper-cli.exe', 'whisper.dll', 'ggml.dll', 'ggml-base.dll', 'ggml-cpu-x64.dll', 'whisper-cpp-LICENSE.txt', 'whisper-model-LICENSE.txt'].every(file => fs.existsSync(path.join(native, 'voice', file))))
check('offline speech model matches pinned checksum', crypto.createHash('sha256').update(fs.readFileSync(path.join(native, 'voice/ggml-small-q5_1.bin'))).digest('hex') === 'ae85e4a935d7a567bd102fe55afc16bb595bdb618e11b2fc7591bc08120411bb')
check('installed native voice helper matches tested build', fs.readFileSync(path.join(native, 'SakthiSpeech.exe')).equals(fs.readFileSync('dist-electron/native/SakthiSpeech.exe')))
check('packaged version matches source', JSON.parse(read('package.json').toString()).version === JSON.parse(fs.readFileSync('package.json','utf8')).version)
const yaml = require('js-yaml')
const provider = yaml.load(fs.readFileSync('electron-builder.yml','utf8')).publish
const packagedProvider = yaml.load(fs.readFileSync(path.join(path.dirname(archive),'app-update.yml'),'utf8'))
const expectedURL = provider.url.replace(/\/$/, '')
check('packaged update provider matches release configuration', packagedProvider.provider === 'generic' && packagedProvider.url.replace(/\/$/, '') === expectedURL)
check('main process embeds the configured update URL', read('dist-electron/main.js').toString().includes(`UPDATE_URL = "${expectedURL}"`))
check('updater and safe logging libraries are bundled', ['node_modules/electron-updater/package.json','node_modules/electron-log/package.json'].every(file=>entries.includes(file)))
check('private update signing key excluded', !entries.some(file => /desktop-private|update-signing\.pem/.test(file)))
const oauth = JSON.parse(fs.readFileSync(path.join(native, 'desktop-oauth.json'), 'utf8'))
check('only approved Desktop OAuth identity distributed', Object.keys(oauth).sort().join(',') === 'clientId,clientSecret' && oauth.clientId === privateConfig.GOOGLE_DESKTOP_CLIENT_ID && oauth.clientSecret === privateConfig.GOOGLE_DESKTOP_CLIENT_SECRET)
check('PostgreSQL runtime and licenses included', ['bin/initdb.exe','bin/pg_ctl.exe','bin/postgres.exe','bin/pg_dump.exe','lib/pgcrypto.dll','share/postgres.bki','server_license.txt','commandlinetools_3rd_party_licenses.txt'].every(file => fs.existsSync(path.join(native, 'postgres', file))))
check('no PostgreSQL data cluster distributed', fs.readdirSync(path.join(native, 'postgres')).sort().join(',') === 'bin,commandlinetools_3rd_party_licenses.txt,lib,server_license.txt,share')
const secrets = Object.entries(privateConfig).filter(([key,value]) => /SECRET|PASSWORD|DATABASE_URL/.test(key) && typeof value === 'string' && value.length >= 8).map(([,value])=>value)
let clean = true
for (const file of entries.filter(file => /^(dist-electron|out-desktop-build)\//.test(file) && /\.(js|html|json|txt)$/.test(file))) {
  const source = read(file).toString('utf8')
  if (secrets.some(value=>source.includes(value))) clean = false
}
check('configured private secret values absent from first-party bundled code', clean)
const result = { date: new Date().toISOString(), archive, archiveSha256: crypto.createHash('sha256').update(fs.readFileSync(archive)).digest('hex'), tests }
fs.writeFileSync('test-reports/ELECTRON_PACKAGE_TEST.json', JSON.stringify(result,null,2))
console.log(JSON.stringify({ passed: tests.filter(t=>t.status==='PASS').length, failed: tests.filter(t=>t.status==='FAIL').length, tests }))
process.exitCode = tests.some(t=>t.status==='FAIL') ? 1 : 0
