import { NextRequest } from 'next/server'
import { POST as googleLogin } from '../src/app/api/auth/google/route'
import { dbQuery } from '../src/server/database'
import { signAccessToken, verifyRefreshToken, findRefreshToken, markRefreshTokenUsed, revokeRefreshToken, ACCESS_COOKIE_NAME, REFRESH_COOKIE_NAME } from '../src/lib/auth/tokens'

export interface DesktopSession {
  accessToken: string
  expiresAt: number
  user: { userId: string; email: string; name: string; role: string; customerId: string | null }
}
const sessions = new Map<number, DesktopSession & { refresh: string }>()
let nextId = 1

// Reuse the real Google route: account provisioning, roles, session settings,
// auditing and token persistence remain identical to the web application.
export async function createSessionFromGoogleIdToken(idToken: string, displayName?: string): Promise<
  { ok: true; session: DesktopSession; isNewUser: boolean } | { ok: false; code: string }
> {
  const response = await googleLogin(new NextRequest('http://sakthi.desktop/api/auth/google', {
    method: 'POST', headers: { 'content-type': 'application/json', 'user-agent': 'Sakthi Finance Desktop' },
    body: JSON.stringify({ id_token: idToken, client_type: 'desktop', mode: 'signin', ...(displayName ? { display_name: displayName } : {}) }),
  }))
  const data = await response.json()
  if (!response.ok || data.code === 'name_required') return { ok: false, code: data.code || 'unavailable' }
  const accessToken = response.cookies.get(ACCESS_COOKIE_NAME)?.value
  const refresh = response.cookies.get(REFRESH_COOKIE_NAME)?.value
  if (!accessToken || !refresh || !data.user?.id) return { ok: false, code: 'unavailable' }
  const session = { accessToken, expiresAt: Date.now() + Number(data.access_token_expires_in) * 1000,
    user: { userId: data.user.id, email: data.user.email, name: data.user.name, role: data.user.role, customerId: null } }
  sessions.set(nextId++, { ...session, refresh })
  return { ok: true, session, isNewUser: false }
}

export async function resolveSessionIdentity(id: number): Promise<DesktopSession['user'] | null> {
  const session = sessions.get(id)
  if (!session) return null
  const payload = verifyRefreshToken(session.refresh)
  if (!payload || payload.typ !== 'refresh') { sessions.delete(id); return null }
  const record = await findRefreshToken(session.refresh)
  if (!record || record.revoked_at || record.user_id !== payload.sub || new Date(record.expires_at).getTime() <= Date.now()) { sessions.delete(id); return null }
  const result = await dbQuery(`SELECT u.user_id, u.email, u.full_name, COALESCE(r.role_name,u.role) AS role, u.is_active, u.customer_id
    FROM users u LEFT JOIN roles r ON r.role_id=u.role_id WHERE u.user_id=$1`, [payload.sub])
  const row = result.rows[0]
  if (!row || row.is_active === false || !['owner', 'admin'].includes(row.role)) { sessions.delete(id); return null }
  const user = { userId: row.user_id, email: row.email, name: row.full_name || payload.name, role: row.role, customerId: row.customer_id || null }
  if (session.expiresAt < Date.now() + 60000 || session.user.role !== user.role || session.user.name !== user.name) {
    session.accessToken = signAccessToken({ sub: user.userId, email: user.email, name: user.name, role: user.role, provider: 'google' })
    session.expiresAt = Date.now() + 15 * 60000
    await markRefreshTokenUsed(record.id)
  }
  session.user = user
  return user
}
export async function restoreSession(refresh: string): Promise<number | null> {
  const payload = verifyRefreshToken(refresh)
  if (!payload || payload.typ !== 'refresh') return null
  const id = nextId++
  sessions.set(id, { refresh, accessToken: '', expiresAt: 0,
    user: { userId: payload.sub, email: payload.email, name: payload.name, role: payload.role, customerId: null } })
  try { if (await resolveSessionIdentity(id)) return id } catch (error) { sessions.delete(id); throw error }
  sessions.delete(id)
  return null
}
export async function destroySession(id: number): Promise<void> {
  const session = sessions.get(id)
  sessions.delete(id)
  if (session) await revokeRefreshToken(session.refresh)
}
export const sessionUser = (id: number) => sessions.get(id)?.user ?? null
export const currentAccessToken = (id: number) => sessions.get(id)?.accessToken ?? null
export const persistRefreshToken = (id: number) => sessions.get(id)?.refresh ?? null
export function findSessionIdByAccessToken(token: string): number | null {
  for (const [id, session] of sessions) if (session.accessToken === token) return id
  return null
}
export function updateSessionUserName(id: number, name: string) { const session = sessions.get(id); if (session) session.user.name = name }
