$ErrorActionPreference = 'Stop'
$sfDestination = Join-Path $PSScriptRoot '../../desktop/voice-runtime'
New-Item -ItemType Directory -Path $sfDestination -Force | Out-Null
function Get-VerifiedFile($Url, $Destination, $Sha256) {
    if (!(Test-Path -LiteralPath $Destination) -or (Get-FileHash -LiteralPath $Destination).Hash -ne $Sha256) {
        & curl.exe --fail --location --retry 2 --silent --show-error --output $Destination $Url
        if ($LASTEXITCODE -ne 0) { throw 'Voice download failed; retry before packaging' }
    }
    if ((Get-FileHash -LiteralPath $Destination).Hash -ne $Sha256) { throw 'Voice download checksum mismatch' }
}
Get-VerifiedFile 'https://github.com/ggml-org/whisper.cpp/releases/download/v1.9.1/whisper-bin-x64.zip' (Join-Path $sfDestination 'runtime.zip') '7d8be46ecd31828e1eb7a2ecdd0d6b314feafd82163038ab6092594b0a063539'
Expand-Archive -LiteralPath (Join-Path $sfDestination 'runtime.zip') -DestinationPath (Join-Path $sfDestination 'bin') -Force
Get-VerifiedFile 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small-q5_1.bin' (Join-Path $sfDestination 'ggml-small-q5_1.bin') 'ae85e4a935d7a567bd102fe55afc16bb595bdb618e11b2fc7591bc08120411bb'
Invoke-WebRequest 'https://raw.githubusercontent.com/ggml-org/whisper.cpp/v1.9.1/LICENSE' -OutFile (Join-Path $sfDestination 'whisper-cpp-LICENSE.txt')
Invoke-WebRequest 'https://raw.githubusercontent.com/openai/whisper/main/LICENSE' -OutFile (Join-Path $sfDestination 'whisper-model-LICENSE.txt')
Write-Output 'Offline speech runtime and model downloaded; SHA256 checks passed.'
