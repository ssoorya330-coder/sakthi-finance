import { readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { randomBytes } from 'node:crypto'
import dotenv from 'dotenv'
import { validateRuntimeConfig } from './runtime-config.mjs'

// Run only after the parent directory has been restricted to this Windows user.
const target = process.argv[2]
if (!target || !path.isAbsolute(target) || path.basename(target) !== 'runtime.json') throw Error('Explicit private runtime.json path required')
const env = { ...dotenv.parse(await readFile('.env')), ...dotenv.parse(await readFile('.env.local')) }
const config = validateRuntimeConfig({ ...env,
  JWT_ACCESS_SECRET: randomBytes(48).toString('base64url'),
  JWT_REFRESH_SECRET: randomBytes(48).toString('base64url'),
})
await writeFile(target, JSON.stringify(config), { flag: 'wx', mode: 0o600 })
console.log('Private desktop settings created. No database files moved or modified. Existing settings are never overwritten.')
