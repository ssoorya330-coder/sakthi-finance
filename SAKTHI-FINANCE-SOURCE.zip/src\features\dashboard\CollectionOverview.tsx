'use client'

export { default } from './graph/DashboardGraph'
