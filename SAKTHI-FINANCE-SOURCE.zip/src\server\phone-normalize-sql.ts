/**
 * SQL twin of `normalizePhone` from `@/lib/phone` (canonical 10-digit
 * Indian mobile). Used so lookups match stored numbers in ANY accepted
 * stored format even if the `phone_normalized` cache column is stale.
 *
 * `col` must be a trusted column reference (never user input).
 */
export function normalizeSql(col: string): string {
  const d = `REGEXP_REPLACE(COALESCE(${col}, ''), '\\D', '', 'g')`;
  return `(SELECT CASE
    WHEN LENGTH(${d}) = 12 AND ${d} LIKE '91%' THEN RIGHT(${d}, 10)
    WHEN LENGTH(${d}) = 11 AND ${d} LIKE '0%' THEN RIGHT(${d}, 10)
    WHEN ${d} ~ '^[6-9][0-9]{9}$' THEN ${d}
    ELSE NULL END)`;
}
