import { NextRequest, NextResponse } from 'next/server'
import { dbTransaction, ensureSchema } from '@/server/database'
import { requireAuthWithPermission } from '@/lib/api-utils'
import {
  actorFromAuthUser,
  requestMeta,
  recordAuditEvent,
  diffRecords,
  LOAN_LABELS,
} from '@/server/audit'
import {
  DISBURSAL_MODES,
  checkDisbursalCompliance,
  getCashThreshold,
  recordCashFlagEvent,
} from '@/server/cash-compliance'

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuthWithPermission('loans:update');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const { id } = await params
    const body = await request.json()
    const {
      loan_amount,
      interest_rate,
      duration,
      loan_type,
      installment,
      total_amount,
      balance_amount,
      received_amount,
      status,
      reason,
      disbursal_mode,
    } = body
    if (disbursal_mode !== undefined && disbursal_mode !== null && disbursal_mode !== '' && !(DISBURSAL_MODES as readonly string[]).includes(String(disbursal_mode))) {
      return NextResponse.json({ error: 'Disbursal mode must be Cash or Bank.' }, { status: 400 })
    }

    await ensureSchema()
    const meta = requestMeta(request)
    const actor = actorFromAuthUser(user)
    // Update + audit commit atomically; before-values are read first so the
    // audit shows exactly what changed.
    const updated = await dbTransaction(async (tx) => {
      const beforeRes = await tx.query(
        `SELECT * FROM loans WHERE loan_id = $1 AND user_id = $2 FOR UPDATE`, [id, user.userId]
      )
      if (beforeRes.rows.length === 0) return null
      const before = beforeRes.rows[0]
      // disbursal_mode is additive: preserved unless explicitly provided.
      const newMode = disbursal_mode === undefined || disbursal_mode === null || disbursal_mode === ''
        ? before.disbursal_mode || null
        : String(disbursal_mode)
      const result = await tx.query(
        `UPDATE loans SET loan_amount=$1, interest_rate=$2, duration=$3, loan_type=$4, installment=$5, total_amount=$6, balance_amount=$7, received_amount=$8, status=$9, disbursal_mode=$10, updated_at=NOW() WHERE loan_id=$11 AND user_id=$12 RETURNING *`,
        [
          loan_amount || 0,
          interest_rate || 0,
          duration || 0,
          loan_type || 'Daily',
          installment || 0,
          total_amount || 0,
          balance_amount || 0,
          received_amount || 0,
          status,
          newMode,
          id,
          user.userId,
        ]
      )
      const after = result.rows[0]
      // Re-evaluate the cash flag on the stored values (corrections included).
      const threshold = await getCashThreshold(tx).catch(() => 20000)
      const disbursalCheck = checkDisbursalCompliance(
        { disbursal_mode: after.disbursal_mode, loan_amount: after.loan_amount },
        threshold
      )
      await tx.query(`UPDATE loans SET is_flagged = $1, flag_reason = $2 WHERE loan_id = $3`, [
        disbursalCheck.flagged, disbursalCheck.reason, id,
      ])
      if (disbursalCheck.flagged && !before.is_flagged) {
        await recordCashFlagEvent(tx, {
          action: 'CASH_DISBURSAL_FLAGGED',
          entityType: 'loan',
          entityId: id,
          customerId: after.customer_id,
          loanId: id,
          paymentId: null,
          actor,
          ip: meta.ip,
          client: meta.client,
          threshold,
          amount: Number(after.loan_amount) || 0,
          reason: disbursalCheck.reason as string,
          after: { loan_amount: after.loan_amount, disbursal_mode: after.disbursal_mode, is_flagged: true },
        })
      }
      const changes = diffRecords(before, after, Object.keys(LOAN_LABELS), LOAN_LABELS)
      const st = changes.find((c) => c.field === 'status')
      const action = st
        ? (String(st.after) === 'Completed'
          ? 'LOAN_COMPLETED'
          : String(st.after) === 'Cancelled'
            ? 'LOAN_CANCELLED'
            : String(st.before) === 'Completed' && String(st.after) !== 'Completed'
              ? 'LOAN_REOPENED'
              : 'LOAN_STATUS_CHANGED')
        : 'LOAN_UPDATED'
      await recordAuditEvent(tx, {
        action,
        entityType: 'loan',
        entityId: id,
        customerId: after.customer_id,
        loanId: id,
        actor,
        ipAddress: meta.ip,
        clientInfo: meta.client,
        reason: typeof reason === 'string' ? reason : null,
        result: 'SUCCESS',
        changes,
        before,
        after,
      })
      return after
    })

    if (!updated) {
      return NextResponse.json({ error: 'Loan not found' }, { status: 404 })
    }
    return NextResponse.json(updated)
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to update loan', details: err.message },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuthWithPermission('loans:delete');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const { id } = await params
    await ensureSchema()
    const meta = requestMeta(request)
    const actor = actorFromAuthUser(user)
    // Delete + deletion audit commit atomically.
    const deleted = await dbTransaction(async (tx) => {
      await tx.query(`SELECT id FROM customers WHERE user_id=$2 AND id=(SELECT customer_id FROM loans WHERE loan_id=$1 AND user_id=$2) FOR UPDATE`, [id,user.userId])
      const beforeRes = await tx.query(
        `SELECT * FROM loans WHERE loan_id = $1 AND user_id = $2 FOR UPDATE`, [id, user.userId]
      )
      if (beforeRes.rows.length === 0) return null
      const before = beforeRes.rows[0]
      await tx.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',[before.kanaku_group_key])
      // Keep the customer and every other Kanaku intact. Retain the actual
      // loan/payment rows for restoration; never cascade through a customer.
      await tx.query(`INSERT INTO kanaku_trash(loan_id,customer_id,user_id,kanaku_group_key,cycle_number,kanaku_number)
        VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(loan_id) DO NOTHING`,
        [id,String(before.customer_id),String(user.userId),before.kanaku_group_key,before.cycle_number,before.kanaku_number])
      await tx.query('UPDATE customers SET updated_at=NOW() WHERE id=$1 AND user_id=$2', [before.customer_id,user.userId])
      await recordAuditEvent(tx, {
        action: 'LOAN_MOVED_TO_TRASH',
        entityType: 'loan',
        entityId: id,
        customerId: before.customer_id,
        loanId: id,
        actor,
        ipAddress: meta.ip,
        clientInfo: meta.client,
        result: 'SUCCESS',
        changes: [{ field: 'loan', label: 'Loan', before: `₹${before.loan_amount} (${before.status})`, after: null }],
        before,
        after: null,
      })
      return before
    })
    if (!deleted) {
      return NextResponse.json({ error: 'Loan not found' }, { status: 404 })
    }
    return NextResponse.json({ success: true, id })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to delete loan', details: err.message },
      { status: 500 }
    )
  }
}

