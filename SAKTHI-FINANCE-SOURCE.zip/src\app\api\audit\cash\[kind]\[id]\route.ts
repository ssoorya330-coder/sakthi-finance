import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { cashDetail } from '@/server/cash-audit'

export const dynamic = 'force-dynamic'

/**
 * Cash transaction detail: customer + loan + payment + compliance +
 * linked audit event. Read-only.
 * kind = 'disbursal' (loan_id) or 'payment' (payment_id).
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ kind: string; id: string }> }
) {
  const auth = await requireAuthWithPermission('audit:read')
  if (auth.error) return auth.error

  try {
    const { kind, id } = await params
    if (kind !== 'disbursal' && kind !== 'payment') {
      return NextResponse.json({ error: 'Kind must be disbursal or payment.' }, { status: 400 })
    }
    const detail = await cashDetail(auth.user.userId, kind, id)
    if (!detail) return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    return NextResponse.json({ detail })
  } catch (err: any) {
    return NextResponse.json({ error: 'Failed to load transaction detail' }, { status: 500 })
  }
}

