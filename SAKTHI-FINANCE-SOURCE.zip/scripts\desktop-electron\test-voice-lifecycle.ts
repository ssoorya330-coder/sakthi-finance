import assert from 'node:assert/strict'
import { readdirSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import { transcribeWave } from '../../electron/offline-transcription'

async function main() {
  // Synthetic tone: tests cancellation/error cleanup, not speech accuracy.
  const wav = Buffer.alloc(32044)
  wav.write('RIFF'); wav.writeUInt32LE(wav.length - 8, 4); wav.write('WAVEfmt ', 8); wav.writeUInt32LE(16, 16)
  wav.writeUInt16LE(1, 20); wav.writeUInt16LE(1, 22); wav.writeUInt32LE(16000, 24); wav.writeUInt32LE(32000, 28)
  wav.writeUInt16LE(2, 32); wav.writeUInt16LE(16, 34); wav.write('data', 36); wav.writeUInt32LE(32000, 40)
  for (let i = 44; i < wav.length; i += 2) wav.writeInt16LE(Math.round(Math.sin(i / 8) * 2000), i)
  const root = path.resolve('dist-electron/native')
  const before = readdirSync(path.join(root, 'voice')).sort()
  const controller = new AbortController()
  const started = Date.now()
  const inference = transcribeWave(root, wav, 'en-IN', controller.signal)
  const timer = setTimeout(() => controller.abort(), 100)
  try { await assert.rejects(inference, /aborted/) } finally { clearTimeout(timer) }
  assert.ok(Date.now() - started < 10000, 'Cancellation must not wait for complete inference')
  await assert.rejects(transcribeWave(path.join(root, 'not-installed'), wav, 'en-IN', new AbortController().signal), /helper-unavailable/)
  assert.deepEqual(readdirSync(path.join(root, 'voice')).sort(), before)
  wav.fill(0)
  const result = { date: new Date().toISOString(), tests: [
    { test: 'Cancel active native inference promptly', status: 'PASS' },
    { test: 'Missing executable returns safe error without unhandled rejection', status: 'PASS' },
    { test: 'No audio or transcript output files created', status: 'PASS' },
  ] }
  writeFileSync('test-reports/OFFLINE_VOICE_LIFECYCLE_TEST.json', JSON.stringify(result, null, 2))
  console.log('3 native voice lifecycle checks passed. No microphone used.')
}
void main()
