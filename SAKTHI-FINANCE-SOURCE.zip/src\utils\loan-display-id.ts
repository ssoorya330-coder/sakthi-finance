/** Cycle-local display number only; never use this as a database/payment key. */
export function formatLoanDisplayId(number: number | string | null | undefined): string {
  const value = Number(number)
  return Number.isSafeInteger(value) && value > 0 ? `L${String(value).padStart(3, '0')}` : '—'
}
