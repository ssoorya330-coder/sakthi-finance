import { NextRequest, NextResponse } from 'next/server'
import { dbQuery } from '@/server/database'
import { requireAuthWithPermission } from '@/lib/api-utils'

export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('customers:read');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const userId = user.userId
    let query = `
      SELECT c.*,
        ra.name AS area_name, rc.name AS city_name, rb.name AS business_name,
        l.loan_id, l.loan_date, l.due_date, l.loan_amount, l.interest_rate,
        l.interest_amount, l.total_amount, l.installment_amount, l.remaining_days,
        l.duration, l.loan_type, l.completed_at, l.aborted_at, l.abort_reason,
        l.notes AS loan_notes, l.status AS loan_status
      FROM customers c
      LEFT JOIN ref_area ra ON c.area_id = ra.id
      LEFT JOIN ref_city rc ON c.city_id = rc.id
      LEFT JOIN ref_business rb ON c.business_id = rb.id
      LEFT JOIN kanaku_loan_balances l ON l.customer_id = c.id AND l.user_id = c.user_id
      WHERE c.status = 'Aborted'
      AND (l.loan_id IS NOT NULL OR NOT EXISTS (SELECT 1 FROM kanaku_trash t WHERE t.customer_id=c.id::text AND t.user_id=c.user_id::text))
    `
    const params: any[] = []
    if (userId) { query += ' AND c.user_id = $1'; params.push(userId) }
    query += ' ORDER BY l.aborted_at DESC'

    const result = await dbQuery(query, params)
    return NextResponse.json({ data: result.rows })
  } catch (err: any) {
    console.error('[GET /api/aborted-customers] Error:', err.message)
    return NextResponse.json(
      { error: 'Failed to fetch aborted customers', details: err.message },
      { status: 500 }
    )
  }
}
