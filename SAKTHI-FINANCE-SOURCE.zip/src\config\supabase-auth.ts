import { cookies } from 'next/headers';
import { Role, normalizeRole } from './rbac';
import { ACCESS_COOKIE_NAME, verifyAccessToken, TokenPayload } from '@/lib/auth/tokens';
import { getSupabaseServerClient, isSupabaseConfigured } from '@/lib/supabase/server';
import { dbQuery } from '@/server/database';
import { isDeveloperEmail } from './developer-access';
import { AsyncLocalStorage } from 'node:async_hooks';

// Electron desktop session bridge: the main process owns the JWT session
// (no HTTP cookies exist there) and passes the verified access token into
// this module through setDesktopSession, scoped to the current IPC call.
// The HTTP server keeps reading the same httpOnly cookie unchanged.
const desktopSession = new AsyncLocalStorage<string | null>();
export function withDesktopSession<T>(token: string | null, operation: () => T): T {
  return desktopSession.run(token, operation);
}
export function getDesktopSessionToken(): string | null {
  return desktopSession.getStore() ?? null;
}

export async function getSupabaseRole(): Promise<Role | null> {
  try {
    const user = await getFullUserFromToken(true);
    if (!user?.isActive) return null;
    return normalizeRole(user.role);
  } catch {
    return null;
  }
}

export async function getSupabaseUserId(): Promise<string | null> {
  try {
    const user = await getFullUserFromToken(true);
    return user?.isActive ? user.userId : null;
  } catch {
    return null;
  }
}

function resolveRole(raw: string | null | undefined): Role {
  return normalizeRole(raw);
}

async function getTokenUser(): Promise<TokenPayload | null> {
  if (desktopSession.getStore() !== undefined) {
    const token = getDesktopSessionToken();
    return token ? verifyAccessToken(token) : null;
  }
  // 1) Supabase Auth session (when SUPABASE env is configured). The Supabase
  //    user id becomes the external identity; the local users row is found via
  //    users.supabase_user_id (see getFullUserFromToken).
  if (isSupabaseConfigured()) {
    try {
      const supabase = await getSupabaseServerClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user && user.email_confirmed_at) {
        return {
          sub: user.id,
          email: user.email || '',
          name:
            (user.user_metadata?.full_name as string) ||
            (user.user_metadata?.name as string) ||
            (user.email ? user.email.split('@')[0] : ''),
          role: ((user.user_metadata?.role as string) || 'customer') as string,
          provider: 'supabase',
          picture: (user.user_metadata?.avatar_url as string) || '',
        };
      }
    } catch {
      // fall through to app JWT
    }
  }

  // 2) Desktop (Electron main) session token for the current IPC invocation.

  // 3) App JWT (Google direct login, httpOnly sf_access cookie).
  try {
    const cookieStore = await cookies();
    const accessToken = cookieStore.get(ACCESS_COOKIE_NAME)?.value;
    if (!accessToken) return null;
    const decoded = verifyAccessToken(accessToken);
    return decoded ?? null;
  } catch {
    return null;
  }
}

export async function getFullUserFromToken(requireCurrentAccount = false): Promise<{
  userId: string;
  email: string;
  name: string;
  role: Role;
  isActive: boolean;
  customerId: string | null;
} | null> {
  const tokenUser = await getTokenUser();
  if (!tokenUser) return null;

  // Look up the user in LOCAL PostgreSQL to get is_active and actual role.
  // Identity key priority: users.supabase_user_id (Supabase Auth id) first,
  // then internal user_id, then email. Email is never the permanent key.
  try {
    const result = await dbQuery(
      `SELECT u.user_id, u.email, u.full_name, COALESCE(r.role_name, u.role) AS role_name, u.is_active, u.customer_id
       FROM users u
       LEFT JOIN roles r ON u.role_id = r.role_id
       WHERE ($2 = 'supabase' AND u.supabase_user_id = $1)
          OR ($2 <> 'supabase' AND u.user_id = $1)
       LIMIT 1`,
      [tokenUser.sub, tokenUser.provider || 'google']
    );
    if (result.rows.length === 0) {
      return null;
    }
    const row = result.rows[0];
    if (row.role_name !== 'owner' && row.role_name !== 'admin') return null;
    return {
      userId: row.user_id,
      email: row.email,
      name: row.full_name || tokenUser.name,
      role: resolveRole(row.role_name),
      isActive: row.is_active !== false,
      customerId: row.customer_id || null,
    };
  } catch (error) {
    if (requireCurrentAccount) throw error;
    return null;
  }
}
