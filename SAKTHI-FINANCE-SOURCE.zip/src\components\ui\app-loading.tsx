'use client'

import { LoaderCircle } from 'lucide-react'
import BrandLogo from './brand-logo'
import styles from './app-loading.module.css'

export default function AppLoading({ fullScreen = false, progress, onProgressComplete }: { fullScreen?: boolean; progress?: number; onProgressComplete?: () => void }) {
  return <div role="status" aria-live="polite" aria-busy="true" className={`${styles.stage} ${fullScreen ? 'min-h-screen' : 'min-h-[65vh]'} relative isolate flex w-full items-center justify-center overflow-hidden px-6 py-12`}>
    <svg aria-hidden="true" viewBox="0 0 1000 700" className="pointer-events-none absolute inset-0 h-full w-full" fill="none">
      <g className={styles.line} stroke="#B78B29" strokeWidth="1.2"><path d="M-60 550 Q200 150 440 540 T1080 120" /><path d="M-60 575 Q200 175 440 565 T1080 145" /><path d="M80 630 Q120 450 40 350 Q240 440 80 630 M80 630 Q250 600 290 420 Q100 440 80 630" /><path d="M880 40 Q730 150 820 270 Q950 160 880 40 M820 270 Q1040 250 970 110 Q830 130 820 270" /></g>
    </svg>
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-[0.12]" style={{ backgroundImage: 'radial-gradient(var(--secondary) 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
    <div aria-hidden="true" className={`${styles.halo} pointer-events-none absolute h-[580px] w-[580px] rounded-full`} />
    <div aria-hidden="true" className={`${styles.counterOrbit} pointer-events-none absolute h-[370px] w-[370px] rounded-full border border-[#80052C]/10 sm:h-[640px] sm:w-[640px]`}>
      <span className="absolute left-1/2 -top-1 h-2 w-2 rounded-full bg-[var(--secondary)] shadow-[0_0_14px_#D4AF3770]" />
      <span className="absolute -bottom-1 left-1/2 h-2 w-2 rounded-full bg-[#80052C]/50" />
    </div>
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
      {[{ left: '12%', top: '20%' }, { left: '83%', top: '22%' }, { left: '18%', top: '72%' }, { left: '78%', top: '76%' }, { left: '36%', top: '10%' }, { left: '64%', top: '88%' }].map((position, index) => <svg key={index} viewBox="0 0 60 60" className={`${styles.drift} absolute h-10 w-10 sm:h-16 sm:w-16`} style={{ ...position, animationDelay: `${index * -0.7}s` }} fill="none" stroke={index % 2 ? '#80052C' : '#B78B29'} strokeWidth="1">
        {index % 3 === 0 ? <><rect x="13" y="13" width="34" height="34" rx="9" transform="rotate(25 30 30)" /><rect x="20" y="20" width="20" height="20" rx="5" transform="rotate(25 30 30)" /></> : index % 3 === 1 ? <><circle cx="30" cy="30" r="18" /><circle cx="30" cy="30" r="10" /><path d="M30 5v8m0 34v8M5 30h8m34 0h8" /></> : <><path d="M30 8 50 42H10Z" /><path d="M30 20 40 37H20Z" /><circle cx="48" cy="13" r="2" /></>}
      </svg>)}
    </div>
    <div aria-hidden="true" className={`${styles.orbit} absolute h-80 w-80 rounded-full border border-dashed border-[var(--secondary)]/30 sm:h-[520px] sm:w-[520px]`} />
    <div aria-hidden="true" className="absolute h-64 w-64 rounded-full border border-[var(--primary)]/10 sm:h-80 sm:w-80" />
    <div className="relative w-full max-w-sm overflow-hidden rounded-3xl border border-[var(--secondary)]/25 bg-white/95 p-8 text-center shadow-[0_20px_70px_-30px_rgba(127,29,29,0.25)]">
      <div aria-hidden="true" className={`${styles.sweep} pointer-events-none absolute inset-y-0 -left-1/2 w-1/3 bg-gradient-to-r from-transparent via-[#F6E7AF]/20 to-transparent`} />
      <BrandLogo className={`${styles.float} mx-auto mb-3 h-56 w-56 drop-shadow-lg`} />
      <p className="text-xs font-semibold uppercase tracking-[0.25em] text-[#96772B]">Welcome to</p>
      <h1 className="mt-2 text-2xl font-bold tracking-wide text-[var(--primary)]">SAKTHI FINANCE</h1>
      <p className="mt-2 text-sm text-slate-500">Your finance workspace is loading</p>
      <div className="mt-7 flex items-center justify-center gap-2 text-sm font-medium text-[var(--primary)]"><LoaderCircle aria-hidden="true" size={20} className="motion-safe:animate-spin" />Please wait…</div>
      <div role="progressbar" aria-label="Application startup" aria-valuemin={0} aria-valuemax={100} aria-valuenow={progress === undefined ? undefined : Math.round(progress)} className="mx-auto mt-5 h-1 w-40 overflow-hidden rounded-full bg-[var(--secondary)]/15"><div className={`${progress === undefined ? styles.shine + ' w-12' : 'w-full transition-transform duration-300 ease-out motion-reduce:transition-none'} h-full origin-left rounded-full bg-gradient-to-r from-[#80052C] to-[var(--secondary)]`} onTransitionEnd={event => { if (event.target === event.currentTarget && event.propertyName === 'transform' && progress === 100) onProgressComplete?.() }} style={progress === undefined ? undefined : { transform: `scaleX(${progress / 100})` }} /></div>
    </div>
  </div>
}
