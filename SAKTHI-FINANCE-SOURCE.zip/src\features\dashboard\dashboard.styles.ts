export const colors = {
  primary: '#7C3AED',
  primaryLight: '#8B5CF6',
  primaryDark: '#6D28D9',
  secondary: '#4F46E5',
  secondaryLight: '#6366F1',
  accent: '#F59E0B',
  accentLight: '#FBBF24',
  success: '#22C55E',
  successLight: '#4ADE80',
  warning: '#F97316',
  warningLight: '#FB923C',
  danger: '#EF4444',
  dangerLight: '#F87171',
  white: '#FFFFFF',
  background: '#F8FAFC',
  surface: '#FFFFFF',
  border: '#E2E8F0',
  textPrimary: '#0F172A',
  textSecondary: '#64748B',
  textMuted: '#94A3B8',
} as const;

export const cardBase = `
  bg-white rounded-[20px] border border-slate-100
  shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)]
  transition-all duration-300 ease-out
  hover:shadow-[0_4px_16px_rgba(0,0,0,0.06),0_8px_24px_rgba(0,0,0,0.04)]
  hover:-translate-y-0.5
`;

export const cardStatic = `
  bg-white rounded-[20px] border border-slate-100
  shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)]
`;

export const glassCard = `
  bg-white/70 backdrop-blur-xl rounded-[22px] border border-white/20
  shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)]
  transition-all duration-300 ease-out
  hover:bg-white/80 hover:shadow-[0_4px_16px_rgba(0,0,0,0.06),0_12px_32px_rgba(0,0,0,0.05)]
  hover:-translate-y-0.5
`;

export const glassCardStatic = `
  bg-white/70 backdrop-blur-xl rounded-[22px] border border-white/20
  shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)]
`;

export const formatCurrency = (value: number): string => {
  const safeValue = Number(value) || 0
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
  }).format(safeValue);
};

export const formatNumber = (value: number): string => {
  const safeValue = Number(value) || 0
  return new Intl.NumberFormat('en-IN').format(safeValue);
};

export const formatDate = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
};

export const formatDateDMY = (value: string): string => {
  if (!value) return ''
  const datePart = value.split('T')[0]
  const parts = datePart.split('-')
  if (parts.length === 3 && parts[0] && parts[1] && parts[2]) {
    return `${parts[2]}-${parts[1]}-${parts[0]}`
  }
  const date = new Date(value)
  if (isNaN(date.getTime())) return value
  const dd = String(date.getDate()).padStart(2, '0')
  const mm = String(date.getMonth() + 1).padStart(2, '0')
  return `${dd}-${mm}-${date.getFullYear()}`
};

export const getStatusColor = (status: string): { bg: string; text: string; dot: string } => {
  switch (status) {
    case 'Active':
      return { bg: 'bg-[#FDF2F2]', text: 'text-[#7F1D1D]', dot: 'bg-[#7F1D1D]' };
    case 'Completed':
      return { bg: 'bg-[#FFFBEB]', text: 'text-[#D4AF37]', dot: 'bg-[#D4AF37]' };
    case 'Pending':
      return { bg: 'bg-amber-50', text: 'text-amber-700', dot: 'bg-amber-500' };
    default:
      return { bg: 'bg-slate-50', text: 'text-slate-700', dot: 'bg-slate-500' };
  }
};
