'use client'

export default function EmptyStateGraph() {
  return (
    <div className="h-[320px] flex flex-col items-center justify-center gap-3 text-center px-4">
      <svg width="180" height="130" viewBox="0 0 180 130" fill="none" aria-hidden="true">
        <path d="M24 108 L160 108" stroke="#CBD5E1" strokeWidth="2" strokeLinecap="round" />
        <path d="M32 108 L32 22" stroke="#CBD5E1" strokeWidth="2" strokeLinecap="round" />
        <rect x="48" y="72" width="16" height="36" rx="4" fill="#3B82F6" opacity="0.25" />
        <rect x="72" y="58" width="16" height="50" rx="4" fill="#22C55E" opacity="0.25" />
        <rect x="96" y="82" width="16" height="26" rx="4" fill="#F97316" opacity="0.25" />
        <rect x="120" y="50" width="16" height="58" rx="4" fill="#EF4444" opacity="0.25" />
        <rect x="144" y="64" width="16" height="44" rx="4" fill="#A855F7" opacity="0.25" />
        <path
          d="M56 84 C 74 76 84 62 104 60 C 120 58 128 46 148 40"
          stroke="#94A3B8"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeDasharray="5 5"
        />
        <circle cx="148" cy="40" r="5" fill="#0F172A" stroke="#fff" strokeWidth="2" />
      </svg>
      <p className="text-sm font-semibold text-slate-700">No historical records found.</p>
      <p className="text-xs text-slate-400 max-w-[280px] leading-relaxed">
        Records appear here once you add customers and collect payments.
      </p>
    </div>
  )
}
