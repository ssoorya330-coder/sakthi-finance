'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import SystemHealthContent from '@/features/admin-access/SystemHealthContent'

export default function SystemHealthContentPage() {
  return (
    <ClientPageGate requireRole="owner">
      <SystemHealthContent />
    </ClientPageGate>
  )
}
