'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import {
  ShieldCheck, Download, Printer, Search, ChevronLeft, ChevronRight,
  X, CheckCircle2, XCircle, AlertTriangle, Loader2, RefreshCw,
  Users, WalletCards, IndianRupee, Settings as SettingsIcon, Activity,
  LayoutDashboard, FileText, Banknote, ScrollText,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useSidebarStore } from '@/store/sidebar-store'
import FinancialAudit from './FinancialAudit'
import CashAudit from './CashAudit'
import { formatCustomerCode } from '@/utils/customer-id'

interface AuditEvent {
  seq: number
  audit_id: string
  created_at: string
  action: string
  entity_type: string
  entity_id: string | null
  customer_id: string | null
  customer_code?: string | null
  loan_id: string | null
  payment_id: string | null
  performed_by: string | null
  user_role: string | null
  source: string | null
  result: string
  changes: Array<{ field: string; label: string; before: any; after: any }>
  reason?: string | null
  before_data?: any
  after_data?: any
  user_id?: string | null
  ip_address?: string | null
  client_info?: string | null
  prev_hash?: string | null
  event_hash?: string | null
}

interface Summary {
  total: number
  today: number
  customer: number
  loan: number
  payment: number
  system: number
  failed: number
  recent: AuditEvent[]
}

const ACTIONS = [
  'CUSTOMER_CREATED', 'CUSTOMER_UPDATED', 'CUSTOMER_STATUS_CHANGED', 'CUSTOMER_DELETED',
  'LOAN_CREATED', 'LOAN_UPDATED', 'LOAN_STATUS_CHANGED', 'LOAN_COMPLETED', 'LOAN_REOPENED', 'LOAN_CANCELLED', 'LOAN_DELETED',
  'PAYMENT_RECORDED', 'PAYMENT_UPDATED', 'PAYMENT_CORRECTED', 'PAYMENT_REVERSED', 'PAYMENT_DELETED',
  'BACKUP_CREATED', 'BACKUP_RESTORED', 'DATA_EXPORTED', 'DATA_IMPORTED',
  'DATA_DIRECTORY_MIGRATED', 'DATA_DIRECTORY_CONFIG_CHANGED',
  'STORAGE_LOCATION_CREATED', 'STORAGE_LOCATION_UPDATED', 'STORAGE_LOCATION_DELETED',
  'LOGIN', 'LOGOUT', 'LOGIN_FAILED', 'USER_CREATED', 'USER_STATUS_CHANGED',
]

const ENTITIES = ['customer', 'loan', 'payment', 'database', 'backup', 'storage', 'auth', 'user', 'settings', 'system']

const fmtDT = (iso: string) => {
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true,
    })
  } catch {
    return iso
  }
}

const fmtVal = (v: any): string => {
  if (v === null || v === undefined || v === '') return '—'
  if (typeof v === 'number') return v.toLocaleString('en-IN')
  if (typeof v === 'object') return JSON.stringify(v)
  return String(v)
}

function actionBadge(action: string) {
  const color = action.includes('DELETE')
    ? 'bg-red-50 text-red-700 border-red-200'
    : action.includes('FAILED') || action.includes('REVERSED') || action.includes('CANCELLED')
      ? 'bg-amber-50 text-amber-700 border-amber-200'
      : action.includes('CREATED') || action.includes('RECORDED') || action.includes('COMPLETED') || action === 'LOGIN'
        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
        : 'bg-slate-100 text-slate-700 border-slate-200'
  return (
    <span className={cn('inline-flex items-center px-2 py-0.5 rounded-lg text-[11px] font-bold border whitespace-nowrap', color)}>
      {action.replace(/_/g, ' ')}
    </span>
  )
}

function resultBadge(result: string) {
  const ok = result === 'SUCCESS'
  return (
    <span className={cn(
      'inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-bold border whitespace-nowrap',
      ok ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200'
    )}>
      {ok ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
      {result}
    </span>
  )
}

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, { credentials: 'include', ...init })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error((data as any).error || `Request failed (${res.status})`)
  return data as T
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 2000)
}

export default function AuditPage() {
  type AuditMenuKey = 'overview' | 'financial' | 'cash' | 'logs'
  const toggleSidebar = useSidebarStore((s) => s.toggleSidebar)
  const [activeMenu, setActiveMenu] = useState<AuditMenuKey>('overview')
  const [summary, setSummary] = useState<Summary | null>(null)
  const [events, setEvents] = useState<AuditEvent[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(true)
  const [forbidden, setForbidden] = useState(false)

  const [search, setSearch] = useState('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [action, setAction] = useState('')
  const [entityType, setEntityType] = useState('')
  const [result, setResult] = useState('')
  const [performedBy, setPerformedBy] = useState('')
  const [customerId, setCustomerId] = useState('')
  const [sort, setSort] = useState('created_at')
  const [dir, setDir] = useState<'asc' | 'desc'>('desc')

  const [selected, setSelected] = useState<AuditEvent | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [verifyState, setVerifyState] = useState<{ ok: boolean; message: string } | null>(null)
  const [verifying, setVerifying] = useState(false)
  const [exporting, setExporting] = useState<string | null>(null)
  // Shared Financial Year for the Financial Audit + Cash sections.
  const [auditFy, setAuditFy] = useState<number | null>(null)
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const queryString = useCallback((extra?: Record<string, string>) => {
    const p = new URLSearchParams()
    if (search) p.set('search', search)
    if (dateFrom) p.set('dateFrom', dateFrom)
    if (dateTo) p.set('dateTo', dateTo)
    if (action) p.set('action', action)
    if (entityType) p.set('entityType', entityType)
    if (result) p.set('result', result)
    if (performedBy) p.set('performedBy', performedBy)
    if (customerId) p.set('customerId', customerId)
    p.set('sort', sort)
    p.set('dir', dir)
    if (extra) for (const [k, v] of Object.entries(extra)) p.set(k, v)
    return p.toString()
  }, [search, dateFrom, dateTo, action, entityType, result, performedBy, customerId, sort, dir])

  const loadSummary = useCallback(async () => {
    try {
      const s = await api<Summary>('/api/audit/summary')
      setSummary(s)
    } catch (e: any) {
      if (/403|Forbidden/.test(e.message)) setForbidden(true)
    }
  }, [])

  const loadEvents = useCallback(async (pageNum: number) => {
    setLoading(true)
    try {
      const d = await api<{ events: AuditEvent[]; total: number; totalPages: number }>(
        `/api/audit?${queryString({ page: String(pageNum), limit: '25' })}`
      )
      setEvents(d.events)
      setTotal(d.total)
      setTotalPages(d.totalPages)
      setPage(pageNum)
    } catch (e: any) {
      if (/403|Forbidden/.test(e.message)) setForbidden(true)
    } finally {
      setLoading(false)
    }
  }, [queryString])

  useEffect(() => {
    loadSummary()
    loadEvents(1)
    // Auto-refresh while the page is open so new events appear without a
    // manual click (same pattern as Database Management).
    const t = setInterval(() => {
      loadSummary()
      setPage((p) => {
        loadEvents(p)
        return p
      })
    }, 30000)
    return () => clearInterval(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Debounced search; other filters apply on change via Apply-on-select.
  const onSearchChange = (v: string) => {
    setSearch(v)
    if (searchTimer.current) clearTimeout(searchTimer.current)
    searchTimer.current = setTimeout(() => loadEvents(1), 500)
  }

  const applyFilters = () => loadEvents(1)

  const clearFilters = () => {
    setSearch(''); setDateFrom(''); setDateTo(''); setAction('')
    setEntityType(''); setResult(''); setPerformedBy(''); setCustomerId('')
    setSort('created_at'); setDir('desc')
    setTimeout(() => loadEvents(1), 0)
  }

  const openDetail = async (row: AuditEvent) => {
    setSelected(row)
    setDetailLoading(true)
    try {
      const d = await api<{ event: AuditEvent }>(`/api/audit/${encodeURIComponent(row.audit_id || String(row.seq))}`)
      setSelected(d.event)
    } catch {}
    finally {
      setDetailLoading(false)
    }
  }

  const runVerify = async () => {
    setVerifying(true)
    setVerifyState(null)
    try {
      const r = await api<{ ok: boolean; message: string }>('/api/audit/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })
      setVerifyState({ ok: r.ok, message: r.message })
      loadSummary()
    } catch (e: any) {
      setVerifyState({ ok: false, message: e.message })
    } finally {
      setVerifying(false)
    }
  }

  const runExport = async (format: 'csv' | 'json' | 'xlsx') => {
    setExporting(format)
    try {
      const res = await fetch(`/api/audit/export?${queryString({ format })}`, { credentials: 'include' })
      if (!res.ok) throw new Error('Export failed')
      const blob = await res.blob()
      const stamp = new Date().toISOString().slice(0, 10)
      downloadBlob(blob, `sakthi-finance-audit-${stamp}.${format}`)
    } catch (e: any) {
      setVerifyState({ ok: false, message: e.message })
    } finally {
      setExporting(null)
    }
  }

  const runExportPdf = async () => {
    setExporting('pdf')
    try {
      // Reuse the filtered JSON export so the PDF matches current filters.
      const res = await fetch(`/api/audit/export?${queryString({ format: 'json' })}`, { credentials: 'include' })
      if (!res.ok) throw new Error('PDF export failed')
      const payload = await res.json().catch(() => null)
      const rows: AuditEvent[] = Array.isArray(payload?.records) ? payload.records : events
      const { downloadAuditLogPdf } = await import('@/lib/audit-pdf')
      downloadAuditLogPdf(rows, {
        filters: queryString() || 'none',
        generatedBy: payload?.generatedBy || undefined,
        total: payload?.totalRecords ?? total,
      })
    } catch (e: any) {
      setVerifyState({ ok: false, message: e.message })
    } finally {
      setExporting(null)
    }
  }

  const runReportArchive = async () => {
    setExporting('archive')
    try {
      const res = await fetch('/api/audit/reports-archive', { credentials: 'include' })
      if (!res.ok) {
        const error = await res.json().catch(() => ({}))
        throw new Error(error.error || 'Report archive could not be generated')
      }
      const filename = res.headers.get('Content-Disposition')?.match(/filename="([^"]+)"/)?.[1] || 'SakthiFinance_Reports.zip'
      downloadBlob(await res.blob(), filename)
    } catch (error) {
      setVerifyState({ ok: false, message: error instanceof Error ? error.message : 'Report archive could not be generated' })
    } finally {
      setExporting(null)
    }
  }

  const toggleSort = (col: string) => {
    if (sort === col) {
      setDir(dir === 'asc' ? 'desc' : 'asc')
    } else {
      setSort(col)
      setDir('desc')
    }
    setTimeout(() => loadEvents(1), 0)
  }

  if (forbidden) {
    return (
      <div className="min-h-screen bg-[var(--background)] flex items-center justify-center p-6">
        <div className="max-w-md text-center bg-white rounded-2xl border border-slate-200 p-8 shadow-sm">
          <ShieldCheck className="w-10 h-10 text-[var(--primary)] mx-auto" />
          <h1 className="text-lg font-bold text-slate-900 mt-3">Restricted Area</h1>
          <p className="text-sm text-slate-500 mt-1">Audit history is available to authorized administrators only.</p>
        </div>
      </div>
    )
  }

  const cards = summary ? [
    { label: 'Total Audit Events', value: summary.total.toLocaleString('en-IN'), icon: Activity },
    { label: "Today's Events", value: summary.today.toLocaleString('en-IN'), icon: ShieldCheck },
    { label: 'Customer Changes', value: summary.customer.toLocaleString('en-IN'), icon: Users },
    { label: 'Loan Changes', value: summary.loan.toLocaleString('en-IN'), icon: IndianRupee },
    { label: 'Payment Changes', value: summary.payment.toLocaleString('en-IN'), icon: WalletCards },
    { label: 'User / System Actions', value: summary.system.toLocaleString('en-IN'), icon: SettingsIcon },
    { label: 'Failed / Rejected', value: summary.failed.toLocaleString('en-IN'), icon: XCircle },
  ] : []

  const inputCls = 'px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-[var(--primary)]/30 focus:outline-none bg-white min-w-0'

  const MENU_ITEMS: Array<{ key: AuditMenuKey; label: string; icon: any; desc: string }> = [
    { key: 'overview', label: 'Overview', icon: LayoutDashboard, desc: 'Summary & recent activity' },
    { key: 'financial', label: 'Financial Audit', icon: FileText, desc: 'Overall, ledger & reconciliation' },
    { key: 'cash', label: 'Cash Transactions', icon: Banknote, desc: 'Cash compliance' },
    { key: 'logs', label: 'Audit Log', icon: ScrollText, desc: 'Searchable event history' },
  ]

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-[1400px] mx-auto space-y-5">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              onClick={toggleSidebar}
              aria-label="Open menu"
              className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors active:scale-95 shadow-sm flex-shrink-0"
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round">
                <path d="M3 5h14" />
                <path d="M3 10h14" />
                <path d="M3 15h14" />
              </svg>
            </button>
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">Audit</h1>
              <p className="text-xs sm:text-sm text-slate-500">Tamper-evident history of financial and system activity</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button onClick={runVerify} disabled={verifying} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-[var(--primary)] text-white hover:bg-[#912222] disabled:opacity-50">
              <ShieldCheck className={cn('w-3.5 h-3.5', verifying && 'animate-spin')} /> {verifying ? 'Verifying…' : 'Verify Integrity'}
            </button>
            <button onClick={() => runExport('xlsx')} disabled={exporting !== null} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50" title="Excel workbook — preserves customer IDs and leading zeros">
              <Download className="w-3.5 h-3.5" /> {exporting === 'xlsx' ? 'Exporting…' : 'Export Excel'}
            </button>
            <button onClick={() => runExport('csv')} disabled={exporting !== null} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50" title="Raw CSV for importing into other systems. Excel may offer data conversions; use Export Excel to preserve leading zeros.">
              <Download className="w-3.5 h-3.5" /> {exporting === 'csv' ? 'Exporting…' : 'Raw CSV'}
            </button>
            <button onClick={runReportArchive} disabled={exporting !== null} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50" title="ZIP of your account's reports for all financial years, grouped into folders. Audit Log table filters do not apply.">
              <Download className="w-3.5 h-3.5" /> {exporting === 'archive' ? 'Preparing reports…' : 'Compressed Reports (All Years)'}
            </button>
            <button onClick={() => runExport('json')} disabled={exporting !== null} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50">
              <Download className="w-3.5 h-3.5" /> {exporting === 'json' ? 'Exporting…' : 'Export JSON'}
            </button>
            <button onClick={runExportPdf} disabled={exporting !== null} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-[var(--primary)] text-white hover:bg-[#912222] disabled:opacity-50">
              <Download className={cn('w-3.5 h-3.5', exporting === 'pdf' && 'animate-bounce')} /> {exporting === 'pdf' ? 'Preparing PDF…' : 'Download PDF'}
            </button>
            <button onClick={() => window.print()} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50">
              <Printer className="w-3.5 h-3.5" /> Print
            </button>
          </div>
        </div>

        {verifyState && (
          <div className={cn('flex items-start gap-2 p-4 rounded-2xl border text-sm', verifyState.ok ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-amber-50 border-amber-200 text-amber-800')}>
            {verifyState.ok
              ? <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
              : <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />}
            <span className="flex-1"><b>{verifyState.ok ? '✓ Audit integrity verified. ' : '⚠ Audit integrity check failed. '}</b>{verifyState.message}</span>
            <button onClick={() => setVerifyState(null)}><X className="w-4 h-4 opacity-60" /></button>
          </div>
        )}

        {/* Audit views menu — switch between audit views */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-2">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2" role="tablist" aria-label="Audit sections">
            {MENU_ITEMS.map((m) => {
              const isActive = activeMenu === m.key
              const Icon = m.icon
              return (
                <button
                  key={m.key}
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setActiveMenu(m.key)}
                  className={cn(
                    'flex items-center gap-3 rounded-xl px-4 py-3 text-left transition-colors border',
                    isActive
                      ? 'bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)] text-white border-[var(--primary)] shadow-md shadow-[var(--primary)]/20'
                      : 'bg-white text-slate-700 border-transparent hover:bg-slate-50 hover:border-slate-200'
                  )}
                >
                  <span className={cn(
                    'w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0',
                    isActive ? 'bg-white/15' : 'bg-slate-100'
                  )}>
                    <Icon className={cn('w-5 h-5', isActive ? 'text-white' : 'text-[var(--primary)]')} />
                  </span>
                  <span className="min-w-0">
                    <span className={cn('block text-[13px] font-bold leading-tight truncate', isActive ? 'text-white' : 'text-slate-900')}>{m.label}</span>
                    <span className={cn('block text-[11px] leading-tight truncate mt-0.5', isActive ? 'text-white/70' : 'text-slate-400')}>{m.desc}</span>
                  </span>
                </button>
              )
            })}
          </div>
        </div>

        {activeMenu === 'overview' && (
        <>
        {/* Summary cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-7 gap-3">
          {cards.map((c) => (
            <div key={c.label} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
              <c.icon className="w-5 h-5 text-[var(--primary)]" />
              <p className="text-xl font-extrabold text-slate-900 tabular-nums mt-2">{c.value}</p>
              <p className="text-[11px] font-semibold text-slate-500 mt-0.5">{c.label}</p>
            </div>
          ))}
        </div>

        {/* Recent activity */}
        {summary && summary.recent.length > 0 && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-bold text-slate-900">Recent Audit Activity</p>
            </div>
            <div className="divide-y divide-slate-100">
              {summary.recent.map((e) => (
                <button key={e.seq} onClick={() => openDetail(e)} className="w-full text-left px-4 py-3 hover:bg-slate-50 flex flex-wrap items-center gap-x-4 gap-y-1">
                  <span className="text-[13px] font-bold text-slate-900">{e.action.replace(/_/g, ' ')}</span>
                  {e.customer_id && <span className="text-xs text-slate-500">Customer: <span className="font-mono font-semibold">{formatCustomerCode(e.customer_code)}</span></span>}
                  <span className="text-xs text-slate-500">{fmtDT(e.created_at)}</span>
                  <span className="text-xs text-slate-500">By <b>{e.performed_by || '—'}</b></span>
                  <span className="ml-auto">{resultBadge(e.result)}</span>
                </button>
              ))}
            </div>
          </div>
        )}
        </>
        )}

        {activeMenu === 'financial' && (
        <>
        {/* Financial Audit (overall / customer / ledger + FY exports) */}
        <FinancialAudit fyYear={auditFy} onFyYearChange={setAuditFy} />
        </>
        )}

        {activeMenu === 'cash' && (
        <>
        {/* Cash Transactions compliance (shares the same Financial Year) */}
        <CashAudit fyYear={auditFy} onFyYearChange={setAuditFy} />
        </>
        )}

        {activeMenu === 'logs' && (
        <>
        {/* Filters */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
          <div className="flex flex-wrap gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input value={search} onChange={(e) => onSearchChange(e.target.value)} placeholder="Search action, entity, performer, audit ID…" className={cn(inputCls, 'w-full pl-9')} />
            </div>
            <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className={inputCls} title="From date" />
            <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className={inputCls} title="To date" />
            <select value={action} onChange={(e) => { setAction(e.target.value); setTimeout(() => loadEvents(1), 0) }} className={inputCls}>
              <option value="">All actions</option>
              {ACTIONS.map((a) => <option key={a} value={a}>{a}</option>)}
            </select>
            <select value={entityType} onChange={(e) => { setEntityType(e.target.value); setTimeout(() => loadEvents(1), 0) }} className={inputCls}>
              <option value="">All entities</option>
              {ENTITIES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
            <select value={result} onChange={(e) => { setResult(e.target.value); setTimeout(() => loadEvents(1), 0) }} className={inputCls}>
              <option value="">All results</option>
              <option value="SUCCESS">SUCCESS</option>
              <option value="FAILED">FAILED</option>
            </select>
            <input value={customerId} onChange={(e) => setCustomerId(e.target.value)} placeholder="Customer ID e.g. 001" className={cn(inputCls, 'w-36')} />
            <input value={performedBy} onChange={(e) => setPerformedBy(e.target.value)} placeholder="Performed by" className={cn(inputCls, 'w-36')} />
            <button onClick={applyFilters} className="px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222]">Apply</button>
            <button onClick={clearFilters} className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-medium hover:bg-slate-50">Clear</button>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
            <p className="text-sm font-bold text-slate-900">Audit Log <span className="text-slate-400 font-semibold">({total.toLocaleString('en-IN')})</span></p>
            <button onClick={() => { loadEvents(page); loadSummary() }} className="inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--primary)] hover:underline">
              <RefreshCw className={cn('w-3 h-3', loading && 'animate-spin')} /> Refresh
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[900px]">
              <thead>
                <tr className="bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)] text-left">
                  {([
                    ['created_at', 'Date & Time'], ['audit_id', 'Audit ID'], ['action', 'Action'],
                    ['entity_type', 'Entity'], ['customer_id', 'Customer'], ['performed_by', 'Performed By'],
                  ] as Array<[string, string]>).map(([col, label]) => (
                    <th key={col} onClick={() => toggleSort(col)} className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-[#F3DFA7] cursor-pointer select-none whitespace-nowrap">
                      {label} {sort === col ? (dir === 'asc' ? '▲' : '▼') : ''}
                    </th>
                  ))}
                  <th className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-[#F3DFA7]">Changes</th>
                  <th className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-[#F3DFA7]">Result</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading && events.length === 0 ? (
                  <tr><td colSpan={8} className="px-4 py-10 text-center text-slate-500 text-sm">Loading audit events…</td></tr>
                ) : events.length === 0 ? (
                  <tr><td colSpan={8} className="px-4 py-10 text-center text-slate-500 text-sm">No audit events found.</td></tr>
                ) : events.map((e) => (
                  <tr key={e.seq} onClick={() => openDetail(e)} className="hover:bg-slate-50 cursor-pointer">
                    <td className="px-4 py-2.5 text-xs text-slate-600 whitespace-nowrap tabular-nums">{fmtDT(e.created_at)}</td>
                    <td className="px-4 py-2.5 text-xs font-mono font-semibold text-slate-800 whitespace-nowrap">{e.audit_id || `seq-${e.seq}`}</td>
                    <td className="px-4 py-2.5">{actionBadge(e.action)}</td>
                    <td className="px-4 py-2.5 text-xs text-slate-600 capitalize">{e.entity_type}</td>
                    <td className="px-4 py-2.5 text-xs font-mono text-slate-600">{formatCustomerCode(e.customer_code)}</td>
                    <td className="px-4 py-2.5 text-xs text-slate-700">{e.performed_by || '—'}</td>
                    <td className="px-4 py-2.5 text-xs text-slate-500">{Array.isArray(e.changes) && e.changes.length > 0 ? `${e.changes.length} field${e.changes.length > 1 ? 's' : ''}` : '—'}</td>
                    <td className="px-4 py-2.5">{resultBadge(e.result)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 border-t border-slate-100 flex items-center justify-between">
            <p className="text-xs text-slate-500">Page {page} of {totalPages}</p>
            <div className="flex gap-2">
              <button disabled={page <= 1 || loading} onClick={() => loadEvents(page - 1)} className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50 disabled:opacity-40">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button disabled={page >= totalPages || loading} onClick={() => loadEvents(page + 1)} className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50 disabled:opacity-40">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
        </>
        )}

        {/* Detail modal */}
        {selected && (
          <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setSelected(null)}>
            <div onClick={(e) => e.stopPropagation()} className="w-full max-w-[640px] max-h-[90vh] overflow-y-auto bg-white rounded-[22px] border border-slate-100 shadow-2xl">
              <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 sticky top-0 bg-white rounded-t-[22px]">
                <div>
                  <h3 className="text-base font-bold text-slate-900">Audit Event</h3>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">{selected.audit_id || `seq-${selected.seq}`}</p>
                </div>
                <button onClick={() => setSelected(null)} className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                {detailLoading && <p className="text-sm text-slate-500">Loading full details…</p>}
                <div className="rounded-2xl border border-slate-200 p-4 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2">
                  {([
                    ['Timestamp', fmtDT(selected.created_at)], ['Action', selected.action.replace(/_/g, ' ')],
                    ['Entity', `${selected.entity_type}${selected.entity_id ? ` (${selected.entity_type === 'customer' ? formatCustomerCode(selected.customer_code) : selected.entity_id})` : ''}`],
                    ['Customer', formatCustomerCode(selected.customer_code)],
                    ['Loan', selected.loan_id || '—'], ['Payment', selected.payment_id || '—'],
                    ['Performed By', selected.performed_by || '—'], ['Role', selected.user_role || '—'],
                    ['Source', selected.source || '—'], ['Result', selected.result],
                    ['Reason', selected.reason || '—'],
                  ] as Array<[string, string]>).map(([k, v]) => (
                    <div key={k} className="flex justify-between gap-4 py-1 border-b border-slate-50 last:border-0">
                      <span className="text-xs text-slate-500">{k}</span>
                      <span className="text-xs font-semibold text-slate-900 text-right break-all">{v}</span>
                    </div>
                  ))}
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900 mb-2">Changes</p>
                  {Array.isArray(selected.changes) && selected.changes.length > 0 ? (
                    <div className="rounded-2xl border border-slate-200 overflow-hidden">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="bg-slate-50 text-left">
                            <th className="px-3 py-2 font-bold text-slate-600">Field</th>
                            <th className="px-3 py-2 font-bold text-slate-600">Before</th>
                            <th className="px-3 py-2 font-bold text-slate-600">After</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {selected.changes.map((c, i) => (
                            <tr key={i}>
                              <td className="px-3 py-2 font-semibold text-slate-800">{c.label || c.field}</td>
                              <td className="px-3 py-2 text-slate-600 break-all">{fmtVal(c.before)}</td>
                              <td className="px-3 py-2 font-semibold text-slate-900 break-all">{fmtVal(c.after)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-500">No field-level changes recorded for this event.</p>
                  )}
                </div>
                <div className="rounded-2xl bg-slate-50 border border-slate-200 p-4">
                  <p className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Technical Information</p>
                  <div className="space-y-1">
                    <p className="text-[11px] text-slate-500 break-all">IP Address: <span className="font-mono">{selected.ip_address || '—'}</span></p>
                    <p className="text-[11px] text-slate-500 break-all">Client: <span className="font-mono">{selected.client_info || '—'}</span></p>
                    <p className="text-[11px] text-slate-500 break-all">Event Hash: <span className="font-mono">{selected.event_hash ? `${selected.event_hash.slice(0, 20)}…` : '—'}</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
