import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { pgServiceAction, getPgServiceInfo } from '@/server/storage'

export const dynamic = 'force-dynamic'

/**
 * STEP 4 / STEP 7 — Stop or start the PostgreSQL Windows service.
 * Clean service control only (never kills postgres.exe). Requires the server
 * to run elevated; otherwise returns the exact manual command.
 */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const action = body.action as 'stop' | 'start' | undefined
    if (action !== 'stop' && action !== 'start') {
      return NextResponse.json({ error: "Action must be 'stop' or 'start'." }, { status: 400 })
    }
    const info = await getPgServiceInfo()
    if (!info.name) {
      return NextResponse.json(
        { ok: false, error: 'No PostgreSQL Windows service was detected. Stop/start it manually.' },
        { status: 200 }
      )
    }
    if ((action === 'stop' && info.state === 'stopped') || (action === 'start' && info.state === 'running')) {
      return NextResponse.json({ ok: true, state: info.state, message: `Service already ${info.state}.`, needsManual: false, manualCommand: null })
    }
    const result = await pgServiceAction(info.name, action)
    return NextResponse.json(result, { status: 200 })
  } catch (err: any) {
    return NextResponse.json(
      { ok: false, error: 'Service control failed', details: err.message },
      { status: 500 }
    )
  }
}

/** Current service state (for polling after a manual stop/start). */
export async function GET() {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error
  try {
    const info = await getPgServiceInfo()
    return NextResponse.json(info)
  } catch (err: any) {
    return NextResponse.json({ error: 'Failed to query service state' }, { status: 500 })
  }
}
