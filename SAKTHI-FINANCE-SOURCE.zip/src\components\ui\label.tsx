'use client'

import { forwardRef } from 'react'
import { cn } from '@/lib/utils'

interface LabelProps extends React.LabelHTMLAttributes<HTMLLabelElement> {
  children: React.ReactNode
}

const Label = forwardRef<HTMLLabelElement, LabelProps>(
  ({ className, children, ...props }, ref) => (
    <label
      ref={ref}
      className={cn(
        'text-[14px] font-medium text-text-secondary mb-1.5 block',
        className
      )}
      {...props}
    >
      {children}
    </label>
  )
)

Label.displayName = 'Label'

export { Label }
