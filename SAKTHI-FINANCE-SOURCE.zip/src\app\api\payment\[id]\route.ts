import { NextRequest, NextResponse } from 'next/server'
import { dbTransaction, ensureSchema } from '@/server/database'
import { requireAuthWithPermission } from '@/lib/api-utils'
import {
  actorFromAuthUser,
  requestMeta,
  recordAuditEvent,
  diffRecords,
  PAYMENT_LABELS,
} from '@/server/audit'
import {
  PAYMENT_MODES,
  checkRepaymentCompliance,
  getCashThreshold,
  recordCashFlagEvent,
} from '@/server/cash-compliance'
import { fyOf } from '@/server/financial-audit'

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuthWithPermission('payments:update');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const { id } = await params
    const body = await request.json()
    const { amount, payment_date, payment_time, payment_method, payment_mode, remarks, reason } = body
    if (payment_mode !== undefined && payment_mode !== null && payment_mode !== '' && !(PAYMENT_MODES as readonly string[]).includes(String(payment_mode))) {
      return NextResponse.json({ error: 'Payment mode must be Cash, Bank, UPI, PhonePe or Cheque.' }, { status: 400 })
    }

    await ensureSchema()
    const meta = requestMeta(request)
    const actor = actorFromAuthUser(user)
    // Update + audit commit atomically; before-values are read first so the
    // audit shows exactly what changed (amount/date/method corrections).
    const updated = await dbTransaction(async (tx) => {
      const beforeRes = await tx.query(
        `SELECT * FROM payments WHERE payment_id = $1 AND user_id = $2 FOR UPDATE`, [id, user.userId]
      )
      if (beforeRes.rows.length === 0) return null
      const before = beforeRes.rows[0]
      // Same full-replace semantics as before (missing fields reset to defaults).
      // payment_mode is additive: preserved unless explicitly provided.
      const newMode = payment_mode === undefined || payment_mode === null || payment_mode === ''
        ? before.payment_mode || before.payment_method || 'Cash'
        : String(payment_mode)
      const result = await tx.query(
        `UPDATE payments SET amount=$1, payment_date=$2, payment_time=$3, payment_method=$4, payment_mode=$5, remarks=$6 WHERE payment_id=$7 AND user_id=$8 RETURNING *`,
        [amount || 0, payment_date, payment_time || null, payment_method || 'Cash', newMode, remarks || null, id, user.userId]
      )
      const after = result.rows[0]
      // Re-evaluate the cash flag against history (corrections included).
      const threshold = await getCashThreshold(tx).catch(() => 20000)
      const currentFy = fyOf()
      const recheck = await checkRepaymentCompliance(
        tx,
        {
          userId: user.userId,
          customerId: after.customer_id,
          amount: Number(after.amount) || 0,
          mode: newMode,
          fyFrom: currentFy.from,
          fyTo: currentFy.to,
          excludePaymentId: id,
        },
        threshold
      )
      // Exclude this very row from its own FY cumulative (it is already
      // counted in history since the update precedes this check).
      await tx.query(`UPDATE payments SET is_flagged = $1, flag_reason = $2 WHERE payment_id = $3`, [
        recheck.flagged, recheck.reason, id,
      ])
      if (recheck.flagged && !before.is_flagged) {
        await recordCashFlagEvent(tx, {
          action: 'CASH_PAYMENT_FLAGGED',
          entityType: 'payment',
          entityId: id,
          customerId: after.customer_id,
          loanId: after.loan_id,
          paymentId: id,
          actor,
          ip: meta.ip,
          client: meta.client,
          threshold,
          amount: Number(after.amount) || 0,
          reason: recheck.reason as string,
          after: { amount: after.amount, payment_mode: newMode, is_flagged: true },
        })
      }
      const changes = diffRecords(before, after, Object.keys(PAYMENT_LABELS), PAYMENT_LABELS)
      const amountChanged = changes.some((c) => c.field === 'amount' && Number(c.before) !== Number(c.after))
      await recordAuditEvent(tx, {
        action: amountChanged ? 'PAYMENT_CORRECTED' : 'PAYMENT_UPDATED',
        entityType: 'payment',
        entityId: id,
        customerId: after.customer_id,
        loanId: after.loan_id,
        paymentId: id,
        actor,
        ipAddress: meta.ip,
        clientInfo: meta.client,
        reason: typeof reason === 'string' ? reason : null,
        result: 'SUCCESS',
        changes,
        before,
        after,
      })
      return after
    })

    if (!updated) {
      return NextResponse.json({ error: 'Payment not found' }, { status: 404 })
    }
    return NextResponse.json(updated)
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to update payment', details: err.message },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuthWithPermission('payments:delete');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const { id } = await params
    await ensureSchema()
    const meta = requestMeta(request)
    const actor = actorFromAuthUser(user)
    // Delete + deletion audit commit atomically.
    const deleted = await dbTransaction(async (tx) => {
      const beforeRes = await tx.query(
        `SELECT * FROM payments WHERE payment_id = $1 AND user_id = $2 FOR UPDATE`, [id, user.userId]
      )
      if (beforeRes.rows.length === 0) return null
      const before = beforeRes.rows[0]
      await tx.query('DELETE FROM payments WHERE payment_id = $1 AND user_id = $2', [id, user.userId])
      await recordAuditEvent(tx, {
        action: 'PAYMENT_DELETED',
        entityType: 'payment',
        entityId: id,
        customerId: before.customer_id,
        loanId: before.loan_id,
        paymentId: id,
        actor,
        ipAddress: meta.ip,
        clientInfo: meta.client,
        result: 'SUCCESS',
        changes: [{ field: 'payment', label: 'Payment', before: `₹${before.amount} on ${before.payment_date}`, after: null }],
        before,
        after: null,
      })
      return before
    })
    if (!deleted) {
      return NextResponse.json({ error: 'Payment not found' }, { status: 404 })
    }
    return NextResponse.json({ success: true, id })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to delete payment', details: err.message },
      { status: 500 }
    )
  }
}

