/** Partial digits for display only; unknown words are never silently discarded. */
export function spokenPhoneDigits(text: string): string | null {
  const words: Record<string, string> = {
    zero: '0', oh: '0', o: '0', one: '1', won: '1', two: '2', to: '2', too: '2', three: '3', four: '4', for: '4',
    five: '5', six: '6', seven: '7', eight: '8', ate: '8', nine: '9',
    'பூஜ்ஜியம்': '0', 'பூஜ்யம்': '0', 'சுழியம்': '0', 'ஒன்று': '1', 'ஒன்னு': '1',
    'இரண்டு': '2', 'ரெண்டு': '2', 'மூன்று': '3', 'மூணு': '3', 'நான்கு': '4', 'நாலு': '4',
    'ஐந்து': '5', 'அஞ்சு': '5', 'ஆறு': '6', 'ஏழு': '7', 'எட்டு': '8', 'ஒன்பது': '9',
  }
  const normalized = text.replace(/[௦-௯]/g, (digit) => String(digit.charCodeAt(0) - 0x0be6))
  const tokens = normalized.toLowerCase().replace(/it['’]s/g, 'it is').replace(/[+(),.\-]/g, ' ').trim().split(/\s+/)
    .filter(token => !['my', 'number', 'is', 'mobile', 'phone', 'contact', 'it', 'please', 'plus', ''].includes(token))
  let digits = ''
  for (let i = 0; i < tokens.length; i++) {
    let repeat = 1
    if (tokens[i] === 'double' || tokens[i] === 'triple') {
      repeat = tokens[i] === 'double' ? 2 : 3
      i++
    }
    const token = tokens[i]
    const value = words[token] ?? (/^\d+$/.test(token ?? '') ? token : null)
    if (!value || (repeat > 1 && value.length !== 1)) return null
    digits += value.repeat(repeat)
  }
  if (digits.startsWith('0091') && digits.length === 14) return digits.slice(4)
  if (digits.startsWith('91') && digits.length === 12) return digits.slice(2)
  return digits
}

export function parseSpokenPhone(text: string): string | null {
  const digits = spokenPhoneDigits(text)
  return digits?.length === 10 ? digits : null
}

export function phoneVoiceError(text: string): string {
  const digits = spokenPhoneDigits(text)
  return digits === null ? 'The number was unclear. Please try again or type it.'
    : digits.length < 10 ? `Only ${digits.length} digits were recognized. Please try the number again.`
      : `${digits.length} digits were recognized. Please enter a 10-digit mobile number.`
}
