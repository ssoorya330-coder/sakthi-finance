/** Server-only policy. User IDs must come from a verified session, not a request body. */
export type AccountStorageBinding = {
  userId: string
  mode: 'legacy' | 'dedicated'
  state: 'pending' | 'provisioning' | 'ready' | 'failed'
  databaseName: string | null
  tablespaceName: string | null
  storagePath: string | null
}

export class AccountStorageNotReady extends Error {
  readonly status = 503
  constructor() { super('Account storage is not ready. Complete storage setup; no alternate database was used.') }
}

export function resolveAccountDatabase(userId: string, binding: AccountStorageBinding | null):
  { mode: 'legacy' } | { mode: 'dedicated'; databaseName: string; storagePath: string; tablespaceName: string } {
  if (!userId || !binding || binding.userId !== userId || binding.state !== 'ready') throw new AccountStorageNotReady()
  if (binding.mode === 'legacy') return { mode: 'legacy' }
  if (!binding.databaseName || !/^sf_account_[a-f0-9]{32}$/.test(binding.databaseName)
      || !binding.tablespaceName || !/^sf_storage_[a-f0-9]{32}$/.test(binding.tablespaceName)
      || !binding.storagePath) throw new AccountStorageNotReady()
  return { mode: 'dedicated', databaseName: binding.databaseName, tablespaceName: binding.tablespaceName, storagePath: binding.storagePath }
}
