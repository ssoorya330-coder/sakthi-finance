import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { AUDIT_COLUMNS, buildAuditWhere, auditOrderBy, readFilters } from '@/server/audit-query'

export const dynamic = 'force-dynamic'

/**
 * Server-side paginated + filtered audit event list.
 * Append-only store: no update/delete endpoints exist by design.
 */
export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('audit:read')
  if (auth.error) return auth.error

  try {
    const searchParams = new URL(request.url).searchParams
    const f = readFilters(searchParams)
    const page = Math.max(parseInt(searchParams.get('page') || '1', 10) || 1, 1)
    const limit = Math.min(Math.max(parseInt(searchParams.get('limit') || '25', 10) || 25, 1), 200)
    const offset = (page - 1) * limit

    const params: any[] = []
    const { clause, nextIdx } = buildAuditWhere(f, params, 1)
    const rows = await dbQuery(
      `SELECT ${AUDIT_COLUMNS} FROM audit_events WHERE 1=1${clause} ${auditOrderBy(f.sort, f.dir)} LIMIT $${nextIdx} OFFSET $${nextIdx + 1}`,
      [...params, limit, offset]
    )
    const countParams: any[] = []
    const countWhere = buildAuditWhere(f, countParams, 1)
    const counted = await dbQuery(`SELECT COUNT(*) AS c FROM audit_events WHERE 1=1${countWhere.clause}`, countParams)
    const total = Number(counted.rows[0]?.c) || 0

    return NextResponse.json({
      events: rows.rows,
      total,
      page,
      limit,
      totalPages: Math.max(Math.ceil(total / limit), 1),
    })
  } catch (err: any) {
    console.error('[GET /api/audit] Error:', err.message)
    return NextResponse.json({ error: 'Failed to load audit events' }, { status: 500 })
  }
}
