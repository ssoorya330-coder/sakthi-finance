import path from 'node:path'
import { randomBytes } from 'node:crypto'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { createServer } from 'node:net'
import { access, mkdir, readFile, writeFile, unlink, realpath } from 'node:fs/promises'
import { Client } from 'pg'

const execute = promisify(execFile)
export type ManagedDatabase = { dataRoot: string; dataDirectory: string; systemIdentifier: string; port: number; database: string }
const exists = (file: string) => access(file).then(() => true, () => false)
export const managedFile = (settings: string) => path.join(settings, 'managed-postgres.json')

async function privateDirectory(directory: string) {
  await mkdir(directory, { recursive: true })
  const identity = await execute('whoami.exe', ['/user', '/fo', 'csv', '/nh'], { windowsHide: true })
  const sid = identity.stdout.match(/S-1-5-[\d-]+/)?.[0]
  if (!sid) throw Error('Windows user could not be identified. Setup stopped.')
  await execute('icacls.exe', [directory, '/inheritance:r', '/grant:r', `*${sid}:(OI)(CI)F`, '*S-1-5-18:(OI)(CI)F'], { windowsHide: true })
}
async function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const server = createServer(); server.once('error', reject)
    server.listen(0, '127.0.0.1', () => { const address = server.address(); if (!address || typeof address === 'string') return server.close(() => reject(Error('No local port'))); server.close(() => resolve(address.port)) })
  })
}
const binary = (runtime: string, name: string) => path.join(runtime, 'postgres', 'bin', name + '.exe')
async function pgControl(runtime: string, data: string, command: 'start' | 'stop' | 'status') {
  const args = [command, '-D', data]
  if (command === 'start') args.push('-w', '-t', '45', '-l', path.join(path.dirname(data), 'postgres.log'))
  if (command === 'stop') args.push('-w', '-t', '30', '-m', 'fast')
  return execute(binary(runtime, 'pg_ctl'), args, { windowsHide: true, timeout: 60000, maxBuffer: 1024 * 1024 })
}
export async function provisionNewDatabase(options: {
  selectedFolder: string; settingsDirectory: string; nativeDirectory: string;
  oauth: { clientId: string; clientSecret: string };
  initialize: (config: Record<string, string>) => Promise<void>;
}): Promise<ManagedDatabase> {
  const { settingsDirectory: settings, nativeDirectory: runtime, oauth } = options
  if (await exists(path.join(settings, 'runtime.json')) || await exists(managedFile(settings))) throw Error('This installation already has settings. Nothing was overwritten.')
  if (!oauth.clientId.endsWith('.apps.googleusercontent.com') || !oauth.clientSecret) throw Error('Desktop Google sign-in configuration is missing.')
  if (!await exists(binary(runtime, 'initdb'))) throw Error('PostgreSQL runtime is missing. Install the complete current Sakthi Finance installer.')
  const selected = await realpath(options.selectedFolder)
  if (!/^[A-Za-z]:[\\/]/.test(selected)) throw Error('Choose a local drive or connected external drive, not a network share.')
  const dataRoot = path.join(selected, 'SakthiFinanceData')
  // mkdir is deliberately exclusive: never initialize inside existing data.
  try { await mkdir(dataRoot) } catch { throw Error('SakthiFinanceData already exists or the folder is not writable. Choose a different empty location; existing files are unchanged.') }
  await privateDirectory(dataRoot)
  await privateDirectory(settings)
  const dataDirectory = path.join(dataRoot, 'postgres-data')
  const password = randomBytes(36).toString('base64url')
  const port = await freePort()
  const config = {
    DB_HOST: '127.0.0.1', DB_PORT: String(port), DB_NAME: 'sakthi_finance', DB_USER: 'sakthi_local', DB_PASSWORD: password,
    JWT_ACCESS_SECRET: randomBytes(48).toString('base64url'), JWT_REFRESH_SECRET: randomBytes(48).toString('base64url'),
    GOOGLE_DESKTOP_CLIENT_ID: oauth.clientId, GOOGLE_DESKTOP_CLIENT_SECRET: oauth.clientSecret,
  }
  const passwordFile = path.join(settings, 'initdb-' + randomBytes(12).toString('hex') + '.password')
  let started = false
  try {
    await writeFile(passwordFile, password + '\n', { flag: 'wx' })
    try {
      await execute(binary(runtime, 'initdb'), ['-D', dataDirectory, '-U', config.DB_USER, '--pwfile=' + passwordFile, '--auth=scram-sha-256', '--encoding=UTF8', '--locale=C'], { windowsHide: true, timeout: 120000, maxBuffer: 1024 * 1024 })
    } catch { throw Error('PostgreSQL initialization failed. The new folder is retained for inspection; existing databases were not changed.') }
    finally { await unlink(passwordFile).catch(() => {}) }
    await writeFile(path.join(dataDirectory, 'postgresql.auto.conf'), `listen_addresses = '127.0.0.1'\nport = ${port}\npassword_encryption = 'scram-sha-256'\n`, { flag: 'w' })
    try { started = true; await pgControl(runtime, dataDirectory, 'start') }
    catch { throw Error('The new local PostgreSQL server could not start. Check drive availability and the Microsoft Visual C++ x64 runtime.') }
    const admin = new Client({ host: config.DB_HOST, port, database: 'postgres', user: config.DB_USER, password, connectionTimeoutMillis: 5000 })
    let identifier = ''
    try { await admin.connect(); await admin.query('CREATE DATABASE sakthi_finance'); identifier = String((await admin.query('SELECT system_identifier FROM pg_control_system()')).rows[0].system_identifier) }
    finally { await admin.end() }
    await options.initialize(config)
    const verify = new Client({ host: config.DB_HOST, port, database: config.DB_NAME, user: config.DB_USER, password, connectionTimeoutMillis: 5000 })
    try {
      await verify.connect()
      const counts = await verify.query('SELECT (SELECT COUNT(*) FROM customers) + (SELECT COUNT(*) FROM loans) + (SELECT COUNT(*) FROM payments) AS total')
      if (Number(counts.rows[0].total) !== 0) throw Error('Fresh database verification failed.')
    } finally { await verify.end() }
    const metadata = { dataRoot, dataDirectory, systemIdentifier: identifier, port, database: config.DB_NAME }
    await writeFile(managedFile(settings), JSON.stringify(metadata), { flag: 'wx' })
    await writeFile(path.join(settings, 'runtime.json'), JSON.stringify(config), { flag: 'wx' })
    return metadata
  } catch (error) {
    if (started) await pgControl(runtime, dataDirectory, 'stop').catch(() => {})
    throw error
  }
}

export async function startManagedDatabase(settings: string, runtime: string, config: Record<string, string | undefined>): Promise<ManagedDatabase | null> {
  if (!await exists(managedFile(settings))) return null // Existing service-based installations unchanged.
  const meta = JSON.parse(await readFile(managedFile(settings), 'utf8')) as ManagedDatabase
  if (!path.isAbsolute(meta.dataDirectory) || path.dirname(meta.dataDirectory) !== meta.dataRoot || path.basename(meta.dataDirectory) !== 'postgres-data' || config.DB_HOST !== '127.0.0.1' || String(meta.port) !== config.DB_PORT || meta.database !== config.DB_NAME) throw Error('Managed storage settings do not match. Nothing was changed.')
  if (!await exists(path.join(meta.dataDirectory, 'PG_VERSION'))) throw Error('Storage offline. Connect the configured Sakthi Finance drive. A replacement database will not be created.')
  try { await pgControl(runtime, meta.dataDirectory, 'status') }
  catch { try { await pgControl(runtime, meta.dataDirectory, 'start') } catch { throw Error('Configured PostgreSQL could not start. Check the selected drive and local port availability.') } }
  const client = new Client({ host: config.DB_HOST, port: Number(config.DB_PORT), database: config.DB_NAME, user: config.DB_USER, password: config.DB_PASSWORD, connectionTimeoutMillis: 5000 })
  try {
    await client.connect()
    const result = await client.query('SELECT system_identifier FROM pg_control_system()')
    if (String(result.rows[0].system_identifier) !== meta.systemIdentifier) throw Error('Database identity mismatch. Access refused.')
  } finally { await client.end() }
  return meta
}
export async function stopManagedDatabase(runtime: string, meta: ManagedDatabase | null) {
  if (meta) await pgControl(runtime, meta.dataDirectory, 'stop')
}
