import * as Sentry from '@sentry/nextjs';

const SENTRY_DSN = process.env.NEXT_PUBLIC_SENTRY_DSN || '';

class ErrorMonitoringServiceClass {
  private initialized = false;

  init(): void {
    if (this.initialized || !SENTRY_DSN) return;
    try {
      Sentry.init({
        dsn: SENTRY_DSN,
        enabled: process.env.NODE_ENV === 'production',
        tracesSampleRate: 0.2,
        replaysSessionSampleRate: 0.1,
        replaysOnErrorSampleRate: 0.5,
      });
      this.initialized = true;
      if (process.env.NODE_ENV === 'development') {
        console.log('[ErrorMonitoring] Sentry initialized');
      }
    } catch (err) {
      if (process.env.NODE_ENV === 'development') {
        console.warn('[ErrorMonitoring] Failed to initialize Sentry:', err);
      }
    }
  }

  captureException(error: Error, context?: Record<string, unknown>): string | undefined {
    if (!this.initialized) {
      if (process.env.NODE_ENV === 'development') {
        console.error('[ErrorMonitoring]', error, context);
      }
      return undefined;
    }
    return Sentry.captureException(error, (scope) => {
      if (context) {
        scope.setExtras(context);
      }
      return scope;
    });
  }

  captureMessage(message: string, level: Sentry.SeverityLevel = 'info'): string | undefined {
    if (!this.initialized) {
      if (process.env.NODE_ENV === 'development') {
        console.log(`[ErrorMonitoring] [${level}] ${message}`);
      }
      return undefined;
    }
    return Sentry.captureMessage(message, level);
  }

  setUser(user: { id: string; email?: string; name?: string } | null): void {
    if (!this.initialized) return;
    Sentry.setUser(user);
  }

  setTag(key: string, value: string): void {
    if (!this.initialized) return;
    Sentry.setTag(key, value);
  }

  setContext(key: string, context: Record<string, unknown>): void {
    if (!this.initialized) return;
    Sentry.setContext(key, context);
  }

  addBreadcrumb(breadcrumb: {
    message?: string;
    category?: string;
    level?: Sentry.SeverityLevel;
    data?: Record<string, unknown>;
  }): void {
    if (!this.initialized) return;
    Sentry.addBreadcrumb({
      message: breadcrumb.message,
      category: breadcrumb.category || 'custom',
      level: breadcrumb.level || 'info',
      data: breadcrumb.data,
    });
  }

  flush(timeout?: number): Promise<boolean> {
    if (!this.initialized) return Promise.resolve(true);
    return Sentry.flush(timeout);
  }
}

export const errorMonitoring = new ErrorMonitoringServiceClass();
