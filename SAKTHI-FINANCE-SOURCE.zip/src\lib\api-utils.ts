import { NextResponse } from 'next/server';
import { getFullUserFromToken } from '@/config/supabase-auth';
import { Role, hasPermission, Permission } from '@/config/rbac';
import { dbQuery } from '@/server/database';
import { isDeveloperEmail } from '@/config/developer-access';

export interface AuthUser {
  userId: string;
  email: string;
  name: string;
  role: Role;
  isActive: boolean;
  /** Linked customers.id for customer-role logins (null otherwise). */
  customerId?: string | null;
}

export function apiError(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export function apiSuccess<T>(data: T, status = 200) {
  return NextResponse.json(data, { status });
}

export function parseBody<T>(request: Request): Promise<T> {
  return request.json();
}

/**
 * Verify the user is authenticated by checking the JWT cookie.
 * Returns the authenticated user or an error response.
 */
export async function requireAuth(): Promise<
  { user: AuthUser; error: null } | { user: null; error: NextResponse }
> {
  const fullUser = await getFullUserFromToken();
  if (!fullUser) {
    return { user: null, error: apiError('Unauthorized', 401) };
  }
  if (!fullUser.isActive) {
    return { user: null, error: apiError('Account is disabled', 403) };
  }
  return {
    user: {
      userId: fullUser.userId,
      email: fullUser.email,
      name: fullUser.name,
      role: fullUser.role,
      isActive: fullUser.isActive,
      customerId: fullUser.customerId || null,
    },
    error: null,
  };
}

/**
 * Check if the user has the required permission.
 * Returns null if authorized, or a NextResponse error if not.
 */
export function requirePermission(user: AuthUser, permission: Permission): NextResponse | null {
  if (['users:manage','security:manage'].includes(permission) && user.role !== 'owner') return apiError('Owner access required',403);
  if (!hasPermission(user.role, permission)) {
    return apiError('Forbidden: insufficient permissions', 403);
  }
  return null;
}

/**
 * Developer-only Admin Access gate (legacy function name).
 * Requires an active, current database account and exact developer email.
 * Owner/Admin roles or browser-supplied roles cannot grant access.
 */
export async function requireOwner(): Promise<
  { user: AuthUser; error: null } | { user: null; error: NextResponse }
> {
  // Legacy name retained for callers. Always resolve current DB identity;
  // never authorize administration from an offline token fallback.
  try {
    const user=await getFullUserFromToken(true);
    if(!user)return {user:null,error:apiError('Unauthorized',401)};
    if(!user.isActive || user.role !== 'owner')return {user:null,error:apiError('Owner access required',403)};
    return {user:{...user,role:'owner'},error:null};
  } catch {return {user:null,error:apiError('Account verification unavailable',503)}}
}
/**
 * Customer self-service gate: explicit rule role === 'customer' with a
 * server-resolved linked customers.id. The customer id always comes from
 * the users.customer_id database relationship — never from URL params,
 * query strings, request bodies, or any client-controlled value.
 */
export async function requireCustomer(): Promise<
  { user: AuthUser; customerId: string; error: null } | { user: null; customerId: null; error: NextResponse }
> {
  const auth = await requireAuth();
  if (auth.error) return { user: null, customerId: null, error: auth.error };
  if (auth.user.role !== 'customer' || !auth.user.customerId) {
    return { user: null, customerId: null, error: apiError('Forbidden', 403) };
  }
  return { user: auth.user, customerId: auth.user.customerId, error: null };
}
/**
 * Combined auth + permission check. Use in API routes:
 * const auth = await requireAuthWithPermission('customers:create');
 * if (auth.error) return auth.error;
 * const { user } = auth;
 */
export async function requireAuthWithPermission(permission: Permission): Promise<
  { user: AuthUser; error: null } | { user: null; error: NextResponse }
> {
  const auth = await requireAuth();
  if (auth.error) return auth;
  const permError = requirePermission(auth.user, permission);
  if (permError) return { user: null, error: permError };
  return auth;
}

// Legacy exports for backward compatibility
export function checkPermission(role: Role | null, permission: Permission): NextResponse | null {
  if (!hasPermission(role, permission)) {
    return apiError('Forbidden', 403);
  }
  return null;
}

// ── Per-account ownership ("RLS" equivalent) ─────────────────────────────
// There is no Supabase RLS in this project; isolation is enforced here, in
// every API route, by comparing row ownership against the session user ID
// (JWT `sub`, stable per Google account — never the email, never a
// client-supplied value). Callers must return 404 (not 403) on failure so
// one account cannot probe another account's record IDs.

/** True when the customer row belongs to the session user. */
export async function isCustomerOwnedBy(
  customerId: string | null | undefined,
  userId: string
): Promise<boolean> {
  if (!customerId) return false;
  const result = await dbQuery('SELECT id FROM customers WHERE id = $1 AND user_id = $2 LIMIT 1', [
    customerId,
    userId,
  ]);
  return result.rows.length > 0;
}

/** True when the loan row belongs to the session user. */
export async function isLoanOwnedBy(
  loanId: string | null | undefined,
  userId: string
): Promise<boolean> {
  if (!loanId) return false;
  const result = await dbQuery('SELECT loan_id FROM loans WHERE loan_id = $1 AND user_id = $2 LIMIT 1', [
    loanId,
    userId,
  ]);
  return result.rows.length > 0;
}

/** True when the payment row belongs to the session user. */
export async function isPaymentOwnedBy(
  paymentId: string | null | undefined,
  userId: string
): Promise<boolean> {
  if (!paymentId) return false;
  const result = await dbQuery(
    'SELECT payment_id FROM payments WHERE payment_id = $1 AND user_id = $2 LIMIT 1',
    [paymentId, userId]
  );
  return result.rows.length > 0;
}
