import { build } from 'esbuild'
import { readdir, mkdir, writeFile, copyFile, cp, readFile } from 'node:fs/promises'
import path from 'node:path'
import { execFileSync } from 'node:child_process'

/**
 * Bundles the Electron main-process code:
 *   - electron/main.ts        → dist-electron/main.js
 *   - electron/preload.ts     → dist-electron/preload.js (sandbox-safe)
 *   - electron/api-worker.ts  → dist-electron/api/routes.js — bundled TOGETHER
 *     with all 88 route handlers so the per-call session token and handlers
 *     share one module instance (importing the generated route map).
 *
 * Node built-ins, pg, Google libraries etc. stay external and load from the
 * shipped node_modules.
 */

const root = process.cwd()
const outDir = path.join(root, 'dist-electron')
await mkdir(path.join(outDir, 'api'), { recursive: true })

const nodeExternal = [
  'electron', // runtime-provided; never bundle the npm stub
  'electron-updater', 'electron-log/main',
  'pg', 'google-auth-library', 'jsonwebtoken', 'zod', 'dotenv',
  '@supabase/ssr', '@supabase/supabase-js', 'cors', 'express',
  'gaxios', 'googleapis-common', 'gtoken',
]

async function listRouteFiles(dir) {
  const routes = []
  async function walk(current) {
    for (const entry of await readdir(current, { withFileTypes: true })) {
      const full = path.join(current, entry.name)
      if (entry.isDirectory()) { await walk(full); continue }
      if (entry.name === 'route.ts' || entry.name === 'route.tsx') routes.push(full)
    }
  }
  await walk(dir)
  return routes
}

// ── Generated route map: every handler importable from the worker ─────────
const apiDir = path.join(root, 'src', 'app', 'api')
const routeFiles = await listRouteFiles(apiDir)
const mapLines = []
const entryLines = []
for (const [index, file] of routeFiles.entries()) {
  const rel = path.relative(apiDir, file).replaceAll('\\', '/')
  const key = '/' + rel.replace(/\/route\.tsx?$/, '')
  mapLines.push(`  '${key}': mod_${index},`)
  const source = path.relative(path.join(root, 'electron'), file).replaceAll('\\', '/')
  entryLines.push(`import * as mod_${index} from '${source}';`)
}
const entrySource = `${entryLines.join('\n')}\n\nexport default {\n${mapLines.join('\n')}\n}\n`
// .js extensions keep tsc happy; esbuild resolves them to the .ts sources.
await writeFile(
  path.join(root, 'electron', 'api-routes.generated.ts'),
  entrySource.replaceAll(".ts';", ".js';")
)

// ── esbuild ────────────────────────────────────────────────────────────────
const common = {
  bundle: true,
  platform: 'node',
  target: 'node20',
  format: 'cjs',
  sourcemap: false,
  logLevel: 'info',
  external: nodeExternal,
  define: { 'process.env.NEXT_RUNTIME': '"nodejs"' },
}

await build({
  ...common,
  entryPoints: [path.join(root, 'electron/main.ts')],
  // The worker bundle is loaded at runtime from disk — never merged into main.
  external: [...nodeExternal, './api/routes.js'],
  outfile: path.join(outDir, 'main.js'),
})

await build({
  ...common,
  entryPoints: [path.join(root, 'electron/preload.ts')],
  outfile: path.join(outDir, 'preload.js'),
})

await build({
  ...common,
  entryPoints: [path.join(root, 'electron/api-worker.ts')],
  outfile: path.join(outDir, 'api/routes.js'),
})

console.log(`Bundled ${routeFiles.length} API routes into dist-electron/api/routes.js`)
await copyFile(path.join(root, 'desktop/electron-assets/icon.ico'), path.join(outDir, 'icon.ico'))
await copyFile(path.join(root, 'electron/setup-progress.html'), path.join(outDir, 'setup-progress.html'))
// The existing storage migration helper needs real Node, not Electron.exe.
const nativeDir = path.join(outDir, 'native')
await mkdir(nativeDir, { recursive: true })
await import('./build-voice.mjs')
await copyFile(process.execPath, path.join(nativeDir, 'node.exe'))
await copyFile(path.join(root, 'scripts/pg-migrate-elevated.js'), path.join(nativeDir, 'pg-migrate-elevated.js'))
await copyFile(path.join(root, 'desktop/node-LICENSE.txt'), path.join(nativeDir, 'node-LICENSE.txt'))
const framework = path.join(process.env.WINDIR || 'C:/Windows', 'Microsoft.NET/Framework64/v4.0.30319')
const speechAssembly = path.join(process.env.WINDIR || 'C:/Windows', 'Microsoft.NET/assembly/GAC_MSIL/System.Speech/v4.0_4.0.0.0__31bf3856ad364e35/System.Speech.dll')
execFileSync(path.join(framework, 'csc.exe'), ['/nologo', '/target:exe', '/platform:x64', `/reference:${speechAssembly}`, '/reference:System.Web.Extensions.dll', `/out:${path.join(nativeDir, 'SakthiSpeech.exe')}`, path.join(root, 'electron/native/SpeechHost.cs')], { stdio: 'inherit', windowsHide: true })
// Redistribute program files and license notices ONLY, never the source cluster.
const pgSource = process.env.SAKTHI_POSTGRES_RUNTIME_SOURCE || 'C:/Program Files/PostgreSQL/18'
for (const directory of ['bin', 'lib', 'share']) await cp(path.join(pgSource, directory), path.join(nativeDir, 'postgres', directory), { recursive: true })
for (const file of ['server_license.txt', 'commandlinetools_3rd_party_licenses.txt']) await copyFile(path.join(pgSource, file), path.join(nativeDir, 'postgres', file))
await copyFile(path.join(pgSource, 'installer/vcredist_x64.exe'), path.join(nativeDir, 'vcredist_x64.exe'))
// User-approved distribution of the non-confidential Desktop OAuth identity.
// No Web OAuth credentials, database credentials, signing keys or records.
const privateConfig = JSON.parse(await readFile(path.join(process.env.APPDATA, 'com.sakthifinance.desktop/runtime.json'), 'utf8'))
const desktopOAuth = { clientId: privateConfig.GOOGLE_DESKTOP_CLIENT_ID, clientSecret: privateConfig.GOOGLE_DESKTOP_CLIENT_SECRET }
if (!desktopOAuth.clientId?.endsWith('.apps.googleusercontent.com') || !desktopOAuth.clientSecret) throw Error('Desktop OAuth distribution configuration is missing')
await writeFile(path.join(nativeDir, 'desktop-oauth.json'), JSON.stringify(desktopOAuth))
