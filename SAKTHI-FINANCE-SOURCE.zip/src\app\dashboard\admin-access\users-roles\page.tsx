'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import UsersRolesContent from '@/features/admin-access/UsersRolesContent'

export default function UsersRolesContentPage() {
  return (
    <ClientPageGate requireRole="owner">
      <UsersRolesContent />
    </ClientPageGate>
  )
}
