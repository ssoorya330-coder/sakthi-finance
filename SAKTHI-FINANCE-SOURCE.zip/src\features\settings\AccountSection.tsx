'use client'

import { motion } from 'framer-motion'
import { UserRound, Mail, CircleCheck } from 'lucide-react'
import { useAuthStore } from '@/store/auth-store'

/**
 * Account section. Reads ONLY the current session from the auth store, so one
 * Gmail account can never see another account's information. No tokens,
 * passwords, secrets — and no role information — are displayed.
 */
export default function AccountSection() {
  const userEmail = useAuthStore((s) => s.userEmail)
  const userName = useAuthStore((s) => s.userName)
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)

  const displayName = userName || userEmail?.split('@')[0] || 'User'

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-white rounded-[20px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] overflow-hidden"
    >
      <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-[var(--primary-soft)] flex items-center justify-center">
          <UserRound className="w-4 h-4 text-[var(--primary)]" />
        </div>
        <div>
          <h2 className="text-base font-semibold text-slate-900">Account</h2>
          <p className="text-xs text-slate-500 mt-0.5">Currently signed-in Google account</p>
        </div>
      </div>

      <div className="p-5">
        <div className="flex items-center gap-4">
          <div
            className="relative w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-lg flex-shrink-0 shadow-md"
            style={{ background: 'linear-gradient(135deg, #D63E3E, #F36A6A)' }}
          >
            {displayName.charAt(0).toUpperCase()}
            <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full" />
          </div>
          <div className="min-w-0">
            <p className="text-base font-semibold text-slate-900 truncate">{displayName}</p>
            <p className="text-sm text-slate-500 truncate flex items-center gap-1.5 mt-0.5">
              <Mail className="w-3.5 h-3.5 flex-shrink-0" />
              {userEmail || '—'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 mt-5">
          <div className="rounded-xl bg-slate-50 border border-slate-100 px-4 py-3">
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Status</p>
            <p className="text-sm font-semibold text-emerald-700 mt-1 flex items-center gap-1.5">
              <CircleCheck className="w-4 h-4" />
              {isAuthenticated ? 'Signed in' : 'Signed out'}
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
