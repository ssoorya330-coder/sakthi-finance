/**
 * Server-side ONLY local storage helpers (never imported by client code).
 *
 * Everything here is LOCAL: PostgreSQL size queries, Windows disk/drive
 * inspection, pg_dump/pg_restore execution, and filesystem path validation.
 * No cloud, no network calls, no credentials in logs.
 */
import { execFile, ExecFileOptions } from 'child_process';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { promisify } from 'util';
import { dbQuery } from './database';

const execFileAsync = promisify(execFile);

export interface DiskUsage {
  root: string;
  totalBytes: number;
  freeBytes: number;
  usedBytes: number;
}

export interface LocalDrive extends DiskUsage {
  label: string;
}

interface DbConn {
  host: string;
  port: string;
  database: string;
  user: string;
  password: string;
}

/** Server-side DB connection values for pg tools. Never send to the client. */
export function getDbConn(): DbConn {
  const url = process.env.DATABASE_URL;
  if (url && url.trim()) {
    const u = new URL(url.trim());
    return {
      host: u.hostname || 'localhost',
      port: u.port || '5432',
      database: decodeURIComponent(u.pathname.replace(/^\//, '') || 'sakthi_finance'),
      user: decodeURIComponent(u.username || 'postgres'),
      password: decodeURIComponent(u.password || ''),
    };
  }
  return {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || '5432',
    database: process.env.DB_NAME || 'sakthi_finance',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || '',
  };
}

function pgToolEnv(conn: DbConn): NodeJS.ProcessEnv {
  return {
    ...process.env,
    PGHOST: conn.host,
    PGPORT: conn.port,
    PGDATABASE: conn.database,
    PGUSER: conn.user,
    PGPASSWORD: conn.password,
  };
}

let pgBinCache: string | null | undefined;
/** Locate the PostgreSQL bin directory (pg_dump/pg_restore/psql). */
export function findPgBin(): string | null {
  if (pgBinCache !== undefined) return pgBinCache;
  const probe = (dir: string, tool: string) => {
    try {
      const full = path.join(dir, tool);
      fs.accessSync(full, fs.constants.X_OK);
      return true;
    } catch {
      return false;
    }
  };
  // 1) Directories on PATH
  const pathDirs = (process.env.PATH || '').split(path.delimiter).filter(Boolean);
  for (const dir of pathDirs) {
    if (probe(dir, 'pg_dump.exe') || probe(dir, 'pg_dump')) {
      pgBinCache = dir;
      return dir;
    }
  }
  // 2) Standard Windows install locations
  const bases = ['C:\\Program Files\\PostgreSQL', 'C:\\Program Files (x86)\\PostgreSQL'];
  for (const base of bases) {
    let versions: string[] = [];
    try {
      versions = fs
        .readdirSync(/* turbopackIgnore: true */ base)
        .filter((v) => /^\d+$/.test(v))
        .sort((a, b) => Number(b) - Number(a));
    } catch {
      continue;
    }
    for (const v of versions) {
      const bin = path.join(base, v, 'bin');
      if (probe(bin, 'pg_dump.exe')) {
        pgBinCache = bin;
        return bin;
      }
    }
  }
  pgBinCache = null;
  return null;
}

export function pgToolPath(tool: 'pg_dump' | 'pg_restore' | 'psql'): string | null {
  const bin = findPgBin();
  if (!bin) return null;
  const ext = os.platform() === 'win32' ? '.exe' : '';
  const full = path.join(bin, tool + ext);
  try {
    fs.accessSync(full, fs.constants.X_OK);
    return full;
  } catch {
    return null;
  }
}

/** PostgreSQL data directory (SHOW data_directory). Display-safe, not secret. */
export async function getDataDirectory(): Promise<string | null> {
  try {
    const r = await dbQuery<{ data_directory: string }>('SHOW data_directory');
    return r.rows[0]?.data_directory || null;
  } catch {
    return null;
  }
}

export async function getServerVersion(): Promise<string | null> {
  try {
    const r = await dbQuery<{ version: string }>('SELECT version() AS version');
    return r.rows[0]?.version || null;
  } catch {
    return null;
  }
}

export async function getServerTime(): Promise<string | null> {
  try {
    const r = await dbQuery<{ now: string }>('SELECT NOW() AS now');
    return r.rows[0]?.now || null;
  } catch {
    return null;
  }
}

export async function getDatabaseSizeBytes(): Promise<number | null> {
  try {
    const r = await dbQuery<{ size: string }>('SELECT pg_database_size(current_database()) AS size');
    return Number(r.rows[0]?.size);
  } catch {
    return null;
  }
}

/** Disk usage of the volume hosting `targetPath`. Null when unavailable. */
export function getDiskUsageForPath(targetPath: string): DiskUsage | null {
  try {
    const root = path.parse(path.resolve(targetPath)).root;
    const s = fs.statfsSync(root);
    const totalBytes = s.bsize * s.blocks;
    const freeBytes = s.bsize * s.bfree;
    return { root, totalBytes, freeBytes, usedBytes: Math.max(0, totalBytes - freeBytes) };
  } catch {
    return null;
  }
}

function splitCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      inQuotes = !inQuotes;
    } else if (ch === ',' && !inQuotes) {
      out.push(cur);
      cur = '';
    } else {
      cur += ch;
    }
  }
  out.push(cur);
  return out.map((s) => s.trim());
}

/**
 * List fixed local drives (LOCAL ONLY). Labels/sizes detected from the OS —
 * never invented. Returns [] when detection fails.
 */
export async function listLocalDrives(): Promise<LocalDrive[]> {
  const roots: Array<{ root: string; label: string }> = [];
  // Primary: wmic (fast, includes volume labels). Read-only, no user input.
  try {
    const opts: ExecFileOptions = { timeout: 15000, windowsHide: true, encoding: 'utf8' };
    const { stdout } = await execFileAsync(
      'wmic',
      ['logicaldisk', 'where', 'drivetype=3', 'get', 'DeviceID,VolumeName', '/format:csv'],
      opts
    );
    const lines = String(stdout).split(/\r?\n/).map((l: string) => l.trim()).filter(Boolean);
    for (const line of lines.slice(1)) {
      const cols = splitCsvLine(line);
      // Header: Node,DeviceID,VolumeName
      const device = cols[1] || '';
      const label = cols[2] || '';
      if (/^[A-Za-z]:$/.test(device)) {
        roots.push({ root: `${device.toUpperCase()}\\`, label });
      }
    }
  } catch {
    // Fallback: PowerShell (wmic is deprecated on newer Windows builds).
    try {
      const { stdout } = await execFileAsync(
        'powershell.exe',
        [
          '-NoProfile',
          '-NonInteractive',
          '-Command',
          "Get-PSDrive -PSProvider FileSystem | Select-Object Name | ConvertTo-Json -Compress",
        ],
        { timeout: 20000, windowsHide: true, encoding: 'utf8' }
      );
      const parsed = JSON.parse(String(stdout).trim() || '[]');
      const arr = Array.isArray(parsed) ? parsed : [parsed];
      for (const d of arr) {
        if (d && typeof d.Name === 'string' && /^[A-Za-z]$/.test(d.Name)) {
          roots.push({ root: `${d.Name.toUpperCase()}:\\`, label: '' });
        }
      }
    } catch {
      return [];
    }
  }
  const drives: LocalDrive[] = [];
  for (const { root, label } of roots) {
    try {
      const s = fs.statfsSync(root);
      const totalBytes = s.bsize * s.blocks;
      const freeBytes = s.bsize * s.bfree;
      if (totalBytes > 0) {
        drives.push({
          root,
          label: label || 'Local Disk',
          totalBytes,
          freeBytes,
          usedBytes: Math.max(0, totalBytes - freeBytes),
        });
      }
    } catch {
      // Drive disconnected/unreadable — skip, never invent numbers.
    }
  }
  return drives.sort((a, b) => a.root.localeCompare(b.root));
}

/** Recursive folder size with guards (file count + total budget). Null on error. */
export function dirSizeBytes(dir: string, maxFiles = 200000): number | null {
  try {
    let total = 0;
    let files = 0;
    const stack: string[] = [dir];
    while (stack.length > 0) {
      const cur = stack.pop() as string;
      let entries: fs.Dirent[];
      try {
        entries = fs.readdirSync(cur, { withFileTypes: true });
      } catch {
        continue;
      }
      for (const e of entries) {
        const full = path.join(cur, e.name);
        try {
          if (e.isDirectory()) {
            if (!e.isSymbolicLink()) stack.push(full);
          } else if (e.isFile()) {
            const st = fs.statSync(full);
            total += st.size;
            if (++files > maxFiles) return total;
          }
        } catch {
          continue;
        }
      }
    }
    return total;
  } catch {
    return null;
  }
}

export interface PgLogInfo {
  bytes: number;
  fileCount: number;
  latestFile: string | null;
  available: boolean;
}

/** Size of the PostgreSQL log directory, or {available:false} when unreadable. */
export async function getPgLogInfo(): Promise<PgLogInfo> {
  try {
    const dataDir = await getDataDirectory();
    let logDir: string | null = null;
    try {
      const r = await dbQuery<{ log_directory: string }>('SHOW log_directory');
      const raw = r.rows[0]?.log_directory || 'log';
      logDir = path.isAbsolute(raw) ? raw : dataDir ? path.join(/* turbopackIgnore: true */ dataDir, raw) : null;
    } catch {
      logDir = dataDir ? path.join(/* turbopackIgnore: true */ dataDir, 'log') : null;
    }
    if (!logDir) return { bytes: 0, fileCount: 0, latestFile: null, available: false };
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(/* turbopackIgnore: true */ logDir, { withFileTypes: true });
    } catch {
      return { bytes: 0, fileCount: 0, latestFile: null, available: false };
    }
    let bytes = 0;
    let fileCount = 0;
    let latestFile: string | null = null;
    let latestMtime = 0;
    for (const e of entries) {
      if (!e.isFile()) continue;
      try {
        const full = path.join(/* turbopackIgnore: true */ logDir, e.name);
        const st = fs.statSync(/* turbopackIgnore: true */ full);
        bytes += st.size;
        fileCount++;
        if (st.mtimeMs > latestMtime) {
          latestMtime = st.mtimeMs;
          latestFile = e.name;
        }
      } catch {
        continue;
      }
    }
    return { bytes, fileCount, latestFile, available: true };
  } catch {
    return { bytes: 0, fileCount: 0, latestFile: null, available: false };
  }
}

export interface PathValidation {
  ok: boolean;
  error?: string;
  normalizedPath?: string;
  drive?: string;
  freeBytes?: number | null;
}

const PURPOSE_OPTIONS = ['Database Backups', 'Application Backups', 'Documents', 'General Storage'] as const;
export function validPurposes(): string[] {
  return [...PURPOSE_OPTIONS];
}

/**
 * Validate a user-supplied storage path. Returns normalized path or a
 * user-friendly error. Never throws for bad input.
 */
export async function validateStoragePath(input: string): Promise<PathValidation> {
  const raw = (input || '').trim();
  if (!raw) return { ok: false, error: 'Storage path is required.' };
  if (/[\0<>:"|?*]/.test(raw.replace(/^[A-Za-z]:/, ''))) {
    return { ok: false, error: 'Path contains characters that are not allowed.' };
  }
  const normalized = path.win32.normalize(raw);
  if (!path.win32.isAbsolute(normalized) || !/^[A-Za-z]:\\/.test(normalized)) {
    return { ok: false, error: 'Path must be an absolute local path, e.g. D:\\Sakthi Finance\\Storage.' };
  }
  if (/^\\\\/.test(normalized)) {
    return { ok: false, error: 'Network (UNC) paths are not allowed. Use a local drive.' };
  }
  // Must not be the PostgreSQL system/data directory (or inside it).
  try {
    const dataDir = await getDataDirectory();
    if (dataDir) {
      const dd = path.win32.normalize(dataDir).toLowerCase();
      const np = normalized.toLowerCase();
      if (np === dd || np.startsWith(dd.endsWith('\\') ? dd : dd + '\\')) {
        return { ok: false, error: 'This path is inside the PostgreSQL system directory. Choose another folder.' };
      }
    }
  } catch {
    // If the DB is unreachable we still validate the filesystem below.
  }
  const drive = path.win32.parse(normalized).root.toUpperCase();
  let usage: DiskUsage | null = null;
  try {
    const s = fs.statfsSync(drive);
    const totalBytes = s.bsize * s.blocks;
    usage = { root: drive, totalBytes, freeBytes: s.bsize * s.bfree, usedBytes: 0 };
    usage.usedBytes = Math.max(0, totalBytes - usage.freeBytes);
  } catch {
    return { ok: false, error: `Drive ${drive} is not available. Check that it is connected.` };
  }
  // Exists, or can be created (nearest existing parent must be writable).
  try {
    const st = fs.statSync(normalized);
    if (!st.isDirectory()) {
      return { ok: false, error: 'This path exists but is not a folder.' };
    }
    fs.accessSync(normalized, fs.constants.W_OK);
  } catch (err: any) {
    if (err?.code !== 'ENOENT') {
      return { ok: false, error: 'This folder is not writable. Check permissions.' };
    }
    // Walk up to nearest existing ancestor and check writability.
    let parent = path.win32.dirname(normalized);
    let guard = 0;
    while (guard++ < 32) {
      try {
        const pst = fs.statSync(parent);
        if (!pst.isDirectory()) return { ok: false, error: 'This path cannot be created.' };
        fs.accessSync(parent, fs.constants.W_OK);
        break;
      } catch (e: any) {
        if (e?.code === 'ENOENT') {
          const next = path.win32.dirname(parent);
          if (next === parent) return { ok: false, error: 'This path cannot be created.' };
          parent = next;
          continue;
        }
        return { ok: false, error: 'This location is not writable. Check permissions.' };
      }
    }
  }
  return { ok: true, normalizedPath: normalized, drive, freeBytes: usage.freeBytes };
}

export interface BackupResult {
  filePath: string;
  filename: string;
  sizeBytes: number;
  pgVersion: string | null;
}

/**
 * Run pg_dump into `storageDir` using PostgreSQL's custom archive format at
 * the highest compression level.  This is deliberately applied to backups,
 * not PostgreSQL's live data directory: database files must remain under
 * PostgreSQL's control to preserve durability and recovery guarantees.
 */
export async function runPgBackup(storageDir: string): Promise<BackupResult> {
  const pgDump = pgToolPath('pg_dump');
  if (!pgDump) {
    throw new Error('PostgreSQL backup tool (pg_dump) was not found on this computer.');
  }
  const conn = getDbConn();
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const filename = `${conn.database}-backup-${stamp}-${crypto.randomUUID()}.dump`;
  const filePath = path.join(storageDir, filename);
  await new Promise<void>((resolve, reject) => {
    const child = require('child_process').spawn(
      pgDump,
      ['-Fc', '-Z', '9', '-f', filePath],
      { env: pgToolEnv(conn), windowsHide: true, timeout: 30 * 60 * 1000 }
    );
    let stderr = '';
    child.stderr?.on('data', (d: Buffer) => {
      stderr += d.toString();
    });
    child.on('error', (e: Error) => reject(new Error(`Backup failed to start: ${e.message}`)));
    child.on('close', (code: number) => {
      if (code === 0) resolve();
      else {
        try {
          fs.unlinkSync(filePath);
        } catch {}
        const tail = stderr.trim().split(/\r?\n/).slice(-3).join(' ');
        reject(new Error(tail ? `Backup failed: ${tail}` : `Backup failed (exit code ${code}).`));
      }
    });
  });
  let sizeBytes = 0;
  try {
    sizeBytes = fs.statSync(filePath).size;
  } catch {}
  const version = await getServerVersion();
  return { filePath, filename, sizeBytes, pgVersion: version ? version.slice(0, 60) : null };
}

/** Restore a custom-format dump (pg_restore) or plain SQL file (psql). */
export async function runPgRestore(filePath: string): Promise<void> {
  if (!fs.existsSync(filePath)) {
    throw new Error('Backup file no longer exists on disk.');
  }
  const conn = getDbConn();
  const isPlainSql = /\.sql$/i.test(filePath);
  const tool = pgToolPath(isPlainSql ? 'psql' : 'pg_restore');
  if (!tool) {
    throw new Error('PostgreSQL restore tool was not found on this computer.');
  }
  const args = isPlainSql
    ? ['-v', 'ON_ERROR_STOP=1', '-f', filePath]
    : ['--clean', '--if-exists', '-d', conn.database, filePath];
  await new Promise<void>((resolve, reject) => {
    const child = require('child_process').spawn(tool, args, {
      env: pgToolEnv(conn),
      windowsHide: true,
      timeout: 30 * 60 * 1000,
    });
    let stderr = '';
    child.stderr?.on('data', (d: Buffer) => {
      stderr += d.toString();
    });
    child.on('error', (e: Error) => reject(new Error(`Restore failed to start: ${e.message}`)));
    child.on('close', (code: number) => {
      if (code === 0) resolve();
      else {
        const tail = stderr.trim().split(/\r?\n/).slice(-3).join(' ');
        reject(new Error(tail ? `Restore failed: ${tail}` : `Restore failed (exit code ${code}).`));
      }
    });
  });
}

/* ═══════════ DATA-DIRECTORY MIGRATION (manual, safety-first) ═══════════
 * These helpers only DETECT and VERIFY. They never delete, overwrite, or
 * modify database contents. Copying is done by the user with robocopy
 * (preserves permissions); deletion of the old directory is manual-only.
 */

export interface PgServiceInfo {
  name: string | null;
  displayName: string | null;
  state: 'running' | 'stopped' | 'transitional' | 'unknown';
  binaryPath: string | null;
  dataDirFromService: string | null;
  available: boolean;
}

function parseScState(output: string): PgServiceInfo['state'] {
  const m = output.match(/STATE\s*:\s*(\d+)\s+(\S+)/i);
  if (!m) return 'unknown';
  const code = Number(m[1]);
  if (code === 4) return 'running';
  if (code === 1) return 'stopped';
  return 'transitional';
}

function parseScBinaryPath(output: string): string | null {
  const m = output.match(/BINARY_PATH_NAME\s*:\s*(.+)/i);
  return m ? m[1].trim() : null;
}

function parseDataDirFromBinaryPath(binaryPath: string | null): string | null {
  if (!binaryPath) return null;
  const m = binaryPath.match(/-D\s+"([^"]+)"/) || binaryPath.match(/-D\s+(\S+)/);
  return m ? m[1] : null;
}

/** Detect the PostgreSQL Windows service (read-only). Null name when absent. */
export async function getPgServiceInfo(): Promise<PgServiceInfo> {
  const empty: PgServiceInfo = {
    name: null,
    displayName: null,
    state: 'unknown',
    binaryPath: null,
    dataDirFromService: null,
    available: false,
  };
  if (os.platform() !== 'win32') return empty;
  try {
    const { stdout } = await execFileAsync('sc.exe', ['query', 'state=', 'all'], {
      timeout: 20000,
      windowsHide: true,
      encoding: 'utf8',
    });
    const text = String(stdout);
    const names: string[] = [];
    for (const line of text.split(/\r?\n/)) {
      const m = line.match(/SERVICE_NAME\s*:\s*(.+)/i);
      if (m && /^postgresql/i.test(m[1].trim())) names.push(m[1].trim());
    }
    if (names.length === 0) return empty;
    // Prefer the service whose binary path matches the running server version,
    // otherwise the first PostgreSQL service.
    let chosen = names[0];
    try {
      const version = await getServerVersion();
      const major = version ? (version.match(/PostgreSQL\s+(\d+)/i) || [])[1] : null;
      if (major) {
        const hit = names.find((n) => n.includes(major));
        if (hit) chosen = hit;
      }
    } catch {}
    const info: PgServiceInfo = { ...empty, name: chosen, available: true };
    try {
      const q = await execFileAsync('sc.exe', ['query', chosen], {
        timeout: 15000,
        windowsHide: true,
        encoding: 'utf8',
      });
      info.state = parseScState(String(q.stdout));
    } catch {}
    try {
      const qc = await execFileAsync('sc.exe', ['qc', chosen], {
        timeout: 15000,
        windowsHide: true,
        encoding: 'utf8',
      });
      const out = String(qc.stdout);
      info.binaryPath = parseScBinaryPath(out);
      info.dataDirFromService = parseDataDirFromBinaryPath(info.binaryPath);
      const dm = out.match(/DISPLAY_NAME\s*:\s*(.+)/i);
      info.displayName = dm ? dm[1].trim() : null;
    } catch {}
    return info;
  } catch {
    return empty;
  }
}

export interface ServiceActionResult {
  ok: boolean;
  state: PgServiceInfo['state'];
  message: string;
  needsManual: boolean;
  manualCommand: string | null;
}

/**
 * Attempt to stop/start the PostgreSQL service. Requires elevation — when
 * access is denied, returns needsManual with the exact command for the user
 * to run in an elevated terminal. Never kills postgres.exe processes.
 */
export async function pgServiceAction(
  serviceName: string,
  action: 'stop' | 'start'
): Promise<ServiceActionResult> {
  const manualCommand =
    action === 'stop' ? `net stop "${serviceName}"` : `net start "${serviceName}"`;
  const fail = (message: string, needsManual = true): ServiceActionResult => ({
    ok: false,
    state: 'unknown',
    message,
    needsManual,
    manualCommand,
  });
  if (!/^[A-Za-z0-9_.$-]+$/.test(serviceName)) {
    return fail('Invalid service name.');
  }
  try {
    const verb = action === 'stop' ? 'stop' : 'start';
    const r = await execFileAsync('sc.exe', [verb, serviceName], {
      timeout: 120000,
      windowsHide: true,
      encoding: 'utf8',
    });
    const out = String(r.stdout) + String(r.stderr || '');
    if (/Access\s+is\s+denied|FAILED\s+5/i.test(out)) {
      return fail(
        `Access denied. Run this in an elevated (Administrator) terminal: ${manualCommand}`,
        true
      );
    }
    // Poll until the target state is reached.
    const want = action === 'stop' ? 'stopped' : 'running';
    for (let i = 0; i < 24; i++) {
      await new Promise((r2) => setTimeout(r2, 5000));
      const info = await getPgServiceInfo();
      if (info.name !== serviceName) continue;
      if (info.state === want) {
        return { ok: true, state: info.state, message: `Service ${want}.`, needsManual: false, manualCommand: null };
      }
      if (info.state === 'unknown') break;
    }
    const info = await getPgServiceInfo();
    return {
      ok: info.state === want,
      state: info.state,
      message:
        info.state === want
          ? `Service ${want}.`
          : `Service did not reach "${want}" yet (state: ${info.state}). Verify with: sc.exe query "${serviceName}"`,
      needsManual: info.state !== want,
      manualCommand: info.state !== want ? manualCommand : null,
    };
  } catch (e: any) {
    const msg = String(e?.message || e);
    if (/Access\s+is\s+denied|EPERM|EACCES/i.test(msg)) {
      return fail(
        `Access denied. Run this in an elevated (Administrator) terminal: ${manualCommand}`,
        true
      );
    }
    return fail(`Service ${action} failed: ${msg}`);
  }
}

/** Total size of the PostgreSQL data directory (for space planning). */
export async function getDataDirSizeBytes(): Promise<number | null> {
  try {
    const dataDir = await getDataDirectory();
    if (!dataDir) return null;
    return dirSizeBytes(dataDir);
  } catch {
    return null;
  }
}

export interface CopyCheck {
  key: string;
  label: string;
  ok: boolean;
  detail: string;
}

/**
 * Verify a copied data directory WITHOUT touching the original.
 * Read-only checks: version marker, config files, base dir, size compare.
 */
export async function verifyCopiedDataDir(
  destination: string,
  opts?: { sourceBytes?: number | null; source?: string | null; skipSizeCheck?: boolean }
): Promise<{ ok: boolean; checks: CopyCheck[] }> {
  const checks: CopyCheck[] = [];
  const norm = path.win32.normalize(destination);
  const push = (key: string, label: string, ok: boolean, detail: string) => {
    checks.push({ key, label, ok, detail });
  };

  // Source version marker. Prefer an explicit source path (read from disk —
  // works even while PostgreSQL is stopped); fall back to the live lookup.
  let srcVersion: string | null = null;
  const explicitSrc = opts?.source?.trim() ? path.win32.normalize(opts.source.trim()) : null;
  if (explicitSrc) {
    try {
      srcVersion = fs.readFileSync(path.join(explicitSrc, 'PG_VERSION'), 'utf8').trim();
    } catch {}
  }
  if (!srcVersion) {
    try {
      const dataDir = await getDataDirectory();
      if (dataDir) {
        try {
          srcVersion = fs.readFileSync(path.join(dataDir, 'PG_VERSION'), 'utf8').trim();
        } catch {}
      }
    } catch {}
  }

  // 1) Destination exists and is a directory.
  try {
    const st = fs.statSync(norm);
    if (!st.isDirectory()) {
      push('exists', 'Destination folder', false, 'Destination exists but is not a folder.');
      return { ok: false, checks };
    }
    push('exists', 'Destination folder', true, norm);
  } catch {
    push('exists', 'Destination folder', false, 'Destination folder does not exist yet.');
    return { ok: false, checks };
  }

  // 2) PG_VERSION present and matches source major version.
  try {
    const dstVersion = fs.readFileSync(path.join(norm, 'PG_VERSION'), 'utf8').trim();
    if (srcVersion && dstVersion !== srcVersion) {
      push('version', 'Version marker (PG_VERSION)', false, `Source is ${srcVersion}, copy is ${dstVersion}. Major versions must not be mixed.`);
    } else {
      push('version', 'Version marker (PG_VERSION)', true, `PostgreSQL ${dstVersion}`);
    }
  } catch {
    push('version', 'Version marker (PG_VERSION)', false, 'PG_VERSION not found — the copy looks incomplete.');
  }

  // 3) Config files present.
  for (const f of ['postgresql.conf', 'pg_hba.conf', 'pg_ident.conf']) {
    try {
      fs.accessSync(path.join(/* turbopackIgnore: true */ norm, f), fs.constants.R_OK);
      push(`cfg-${f}`, `Config file ${f}`, true, 'Present.');
    } catch {
      push(`cfg-${f}`, `Config file ${f}`, false, 'Missing — the copy looks incomplete.');
    }
  }

  // 4) base/ directory (actual database files) present and non-empty.
  try {
    const base = path.join(norm, 'base');
    const entries = fs.readdirSync(base);
    if (entries.length > 0) push('base', 'Database files (base/)', true, `${entries.length} database directories.`);
    else push('base', 'Database files (base/)', false, 'base/ is empty — the copy looks incomplete.');
  } catch {
    push('base', 'Database files (base/)', false, 'base/ is missing — the copy looks incomplete.');
  }

  // 5) Size comparison (copy should be within 5% of source).
  // Fast path: caller may pass the already-measured source size (Step 2
  // status) so we skip re-walking the entire source tree here.
  // Rollback path (re-pointing at the original directory while stopped) may
  // skip the size comparison: presence checks above still apply.
  if (opts?.skipSizeCheck) {
    push('size', 'Size comparison', true, 'Skipped for restore-to-original; file checks passed.');
    return { ok: checks.every((c) => c.ok), checks };
  }
  try {
    const knownSrc = opts?.sourceBytes;
    const srcPromise =
      typeof knownSrc === 'number' && knownSrc > 0
        ? Promise.resolve(knownSrc)
        : getDataDirSizeBytes();
    const dstPromise = Promise.resolve().then(() => dirSizeBytes(norm));
    const [srcSize, dstSize] = await Promise.all([srcPromise, dstPromise]);
    if (srcSize === null || srcSize <= 0 || dstSize === null) {
      push('size', 'Size comparison', false, 'Could not measure one side; re-check manually.');
    } else {
      const ratio = dstSize / srcSize;
      if (ratio >= 0.95 && ratio <= 1.05) {
        push('size', 'Size comparison', true, `Source ${srcSize.toLocaleString()} B, copy ${dstSize.toLocaleString()} B.`);
      } else {
        push('size', 'Size comparison', false, `Source ${srcSize.toLocaleString()} B vs copy ${dstSize.toLocaleString()} B — sizes differ too much. Re-copy.`);
      }
    }
  } catch {
    push('size', 'Size comparison', false, 'Could not compare sizes.');
  }

  return { ok: checks.every((c) => c.ok), checks };
}

/** Verify a pg_dump custom-format archive is readable (pg_restore --list). */
export async function verifyBackupArchive(filePath: string): Promise<{ ok: boolean; entries: number; message: string }> {
  const pgRestore = pgToolPath('pg_restore');
  if (!pgRestore) return { ok: false, entries: 0, message: 'pg_restore was not found on this computer.' };
  try {
    fs.accessSync(filePath, fs.constants.R_OK);
  } catch {
    return { ok: false, entries: 0, message: 'Backup file is not readable.' };
  }
  if (/\.sql$/i.test(filePath)) {
    try {
      const st = fs.statSync(filePath);
      if (st.size > 0) return { ok: true, entries: 0, message: `Plain SQL backup, ${(st.size / 1048576).toFixed(1)} MB, readable.` };
      return { ok: false, entries: 0, message: 'Backup file is empty.' };
    } catch {
      return { ok: false, entries: 0, message: 'Backup file is not readable.' };
    }
  }
  try {
    const { stdout } = await execFileAsync(pgRestore, ['--list', filePath], {
      timeout: 120000,
      windowsHide: true,
      encoding: 'utf8',
      maxBuffer: 32 * 1024 * 1024,
    });
    const entries = String(stdout).split(/\r?\n/).filter((l) => l.trim() && !l.trim().startsWith(';')).length;
    if (entries > 0) return { ok: true, entries, message: `Archive verified: ${entries} entries readable.` };
    return { ok: false, entries: 0, message: 'Archive appears empty.' };
  } catch (e: any) {
    return { ok: false, entries: 0, message: `Archive verification failed: ${String(e?.message || e).slice(0, 200)}` };
  }
}

export interface DbSnapshot {
  version: string | null;
  dataDirectory: string | null;
  databases: string[];
  dbSizeBytes: number | null;
  serverTime: string | null;
  tables: Array<{ name: string; rows: number }>;
  counts: Record<string, number>;
}

/**
 * Application-level snapshot: metadata + exact row counts of key tables.
 * Contains no customer/payment contents — only counts for before/after diff.
 */
export async function captureDbSnapshot(): Promise<DbSnapshot> {
  const [version, dataDirectory, dbSize, serverTime] = await Promise.all([
    getServerVersion(),
    getDataDirectory(),
    getDatabaseSizeBytes(),
    getServerTime(),
  ]);
  let databases: string[] = [];
  try {
    const r = await dbQuery<{ datname: string }>('SELECT datname FROM pg_database WHERE datistemplate = false ORDER BY 1');
    databases = r.rows.map((x) => x.datname);
  } catch {}
  let tables: Array<{ name: string; rows: number }> = [];
  try {
    const r = await dbQuery<{ name: string; rows: string }>(
      `SELECT c.relname AS name, COALESCE(c.reltuples::bigint, 0)::text AS rows
       FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
       WHERE n.nspname = 'public' AND c.relkind IN ('r', 'p') ORDER BY 1`
    );
    tables = r.rows.map((x) => ({ name: x.name, rows: Number(x.rows) || 0 }));
  } catch {}
  // Exact counts for the tables the finance app depends on.
  const counts: Record<string, number> = {};
  for (const t of ['customers', 'loans', 'payments', 'users', 'daily_collection', 'settings', 'storage_locations']) {
    try {
      const r = await dbQuery(`SELECT COUNT(*) AS c FROM "${t}"`);
      counts[t] = Number(r.rows[0]?.c) || 0;
    } catch {
      counts[t] = -1; // table missing/unreadable — surfaced in the diff
    }
  }
  return { version, dataDirectory, databases, dbSizeBytes: dbSize, serverTime, tables, counts };
}
