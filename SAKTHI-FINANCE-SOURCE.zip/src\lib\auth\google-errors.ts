/** Never log library error objects: they can contain credentials and JWT claims. */
export function googleVerificationError(error: unknown, credential: string) {
  const e = error as { message?: string; code?: string; response?: { status?: number }; cause?: { code?: string } };
  const message = String(e?.message || 'Unknown verification error');
  const code = e?.code || e?.cause?.code || '';
  const network = /^(ENOTFOUND|EAI_AGAIN|ECONNRESET|ECONNREFUSED|ETIMEDOUT|EACCES|ENETUNREACH|CERT_HAS_EXPIRED|UNABLE_TO_VERIFY_LEAF_SIGNATURE|DEPTH_ZERO_SELF_SIGNED_CERT)$/.test(code)
    || message.startsWith('Failed to retrieve verification certificates:');
  // Google embeds JWTs, decoded payloads and envelopes in several errors.
  const safeMessage = message.split(credential || '\u0000').join('[redacted token]')
    .replace(/[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g, '[redacted token]')
    .replace(/\{[\s\S]*/g, '[redacted claims]').slice(0, 350);
  return {
    status: network ? 503 : 401,
    code: network ? 'google_unavailable' : 'invalid_token',
    error: network ? 'Google verification could not be reached. Please retry shortly.' : 'Google sign-in could not be verified. Please sign in again.',
    diagnostic: { message: safeMessage, code, httpStatus: e?.response?.status },
  };
}
