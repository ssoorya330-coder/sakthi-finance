import { NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'

export async function GET() {
  const auth=await requireAuthWithPermission('dashboard:read')
  if(auth.error)return auth.error
  try {
    const result=await dbQuery('SELECT COUNT(DISTINCT customer_id)::int AS count FROM kanaku_trash WHERE user_id=$1 AND purged_at IS NULL',[auth.user.userId])
    return NextResponse.json({count:result.rows[0].count},{headers:{'Cache-Control':'no-store'}})
  } catch {
    return NextResponse.json({error:'Deleted customer count unavailable.'},{status:503})
  }
}
