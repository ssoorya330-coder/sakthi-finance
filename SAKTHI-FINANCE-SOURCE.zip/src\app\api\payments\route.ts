import { resolveCustomerId } from '@/server/customer-identity'
import { NextRequest, NextResponse } from 'next/server'
import { dbQuery } from '@/server/database'
import { requireAuthWithPermission } from '@/lib/api-utils'

export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('payments:read');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const userId = user.userId
    const { searchParams } = new URL(request.url)
    const customerId = await resolveCustomerId(searchParams.get('customer_id'))
    const loanId = searchParams.get('loan_id')
    const startDate = searchParams.get('start_date')
    const endDate = searchParams.get('end_date')

    let query = "SELECT p.*, to_char(p.payment_date, 'YYYY-MM-DD') AS payment_date, c.full_name as customer_name, collector.full_name AS collected_by FROM payments p JOIN customers c ON p.customer_id = c.id LEFT JOIN users collector ON collector.user_id = p.user_id WHERE 1=1"
    const params: any[] = []
    let paramIdx = 1
    query += ' AND NOT EXISTS (SELECT 1 FROM kanaku_trash t WHERE t.loan_id=p.loan_id)'

    if (userId) { query += ` AND p.user_id = $${paramIdx++}`; params.push(userId) }
    if (customerId) { query += ` AND p.customer_id = $${paramIdx++}`; params.push(customerId) }
    if (loanId) { query += ` AND p.loan_id = $${paramIdx++}`; params.push(loanId) }
    if (startDate) { query += ` AND p.payment_date >= $${paramIdx++}`; params.push(startDate) }
    if (endDate) { query += ` AND p.payment_date <= $${paramIdx++}`; params.push(endDate) }
    query += ' ORDER BY p.payment_date DESC, p.created_at DESC'

    const result = await dbQuery(query, params)
    return NextResponse.json({ data: result.rows })
  } catch (err: any) {
    console.error('[GET /api/payments] Error:', err.message)
    return NextResponse.json(
      { error: 'Failed to fetch payments', details: err.message },
      { status: 500 }
    )
  }
}
