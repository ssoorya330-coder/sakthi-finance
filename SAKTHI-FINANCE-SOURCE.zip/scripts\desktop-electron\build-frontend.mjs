import { spawnSync } from 'node:child_process'
import { randomBytes } from 'node:crypto'
// Select the already-inspected desktop configuration without renaming or
// overwriting the web configuration, even if the build is interrupted.
const result = spawnSync(process.execPath, ['node_modules/next/dist/bin/next', 'build'], {
  stdio: 'inherit', cwd: process.cwd(), env: { ...process.env,
    SAKTHI_ELECTRON_BUILD: '1', NEXT_PUBLIC_API_URL: '', NEXT_PUBLIC_SAKTHI_SERVER_URL: '',
    JWT_ACCESS_SECRET: randomBytes(48).toString('base64url'),
    JWT_REFRESH_SECRET: randomBytes(48).toString('base64url'),
  },
})
process.exitCode = result.status ?? 1
