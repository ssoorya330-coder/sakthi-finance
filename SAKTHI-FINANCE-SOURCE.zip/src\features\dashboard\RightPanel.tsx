'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'
import {
  HandCoins,
  Percent,
  UserCheck,
  BadgeCheck,
  UserX,
} from 'lucide-react'
import { AreaChart, Area, ResponsiveContainer } from 'recharts'
import { useCustomerStore } from '@/store/customer-store'
import { formatINR } from '@/lib/dashboard-utils'
import { computeKypMiniCards } from './dashboard-data'
import type { KypMiniCardData } from './dashboard.types'

const iconMap: Record<string, React.FC<React.SVGProps<SVGSVGElement>>> = {
  HandCoins,
  Percent,
  UserCheck,
  BadgeCheck,
  UserX,
}

const GRADIENT_CONFIG: Record<string, { from: string; to: string; shadow: string; sparkColor: string }> = {
  'amount-given': { from: 'var(--primary)', to: 'var(--primary-hover)', shadow: 'rgba(127,29,29,0.2)', sparkColor: 'var(--primary)' },
  'interest-amount': { from: 'var(--secondary)', to: '#B8943A', shadow: 'rgba(212,169,74,0.2)', sparkColor: 'var(--secondary)' },
  'active-customers': { from: 'var(--primary)', to: 'var(--primary-hover)', shadow: 'rgba(127,29,29,0.2)', sparkColor: 'var(--primary)' },
  'completed-customers': { from: 'var(--secondary)', to: '#B8943A', shadow: 'rgba(212,169,74,0.2)', sparkColor: 'var(--secondary)' },
  'aborted-customers': { from: 'var(--primary-hover)', to: 'var(--primary)', shadow: 'rgba(155,29,29,0.2)', sparkColor: 'var(--primary-hover)' },
}

function KypMiniCard({ data, index }: { data: KypMiniCardData; index: number }) {
  const Icon = iconMap[data.icon] || HandCoins
  const grad = GRADIENT_CONFIG[data.id] || { from: '#6366F1', to: '#4F46E5', shadow: 'rgba(99,102,241,0.2)', sparkColor: '#6366F1' }
  const isPositive = data.change >= 0

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.1 + index * 0.06 }}
      whileHover={{ y: -3, boxShadow: `0 12px 32px ${grad.shadow}` }}
      className="relative bg-white/70 backdrop-blur-xl rounded-[16px] border border-white/20 p-4 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] overflow-hidden group"
    >
      <div className="absolute inset-0 sf-pattern-dots opacity-30 pointer-events-none" />
      <div className="relative">
        <div className="flex items-center justify-between mb-3">
          <div
            className="w-9 h-9 rounded-[11px] flex items-center justify-center shadow-md"
            style={{ background: `linear-gradient(135deg, ${grad.from}, ${grad.to})`, boxShadow: `0 4px 10px ${grad.shadow}` }}
          >
            <Icon className="w-[15px] h-[15px] text-white" />
          </div>
          <span className={`text-xs font-semibold ${isPositive ? 'text-emerald-600' : 'text-red-500'}`}>
            {isPositive ? '+' : ''}{data.change}%
          </span>
        </div>
        <p className="text-lg font-bold text-slate-900 tracking-tight mb-0.5">{formatINR(data.value)}</p>
        <p className="text-xs text-slate-500 font-medium mb-2">{data.label}</p>
        <div className="h-8">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data.sparkData.map((v, i) => ({ x: i, y: v }))}>
              <defs>
                <linearGradient id={`kyp-spark-${data.id}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={grad.sparkColor} stopOpacity={0.25} />
                  <stop offset="100%" stopColor={grad.sparkColor} stopOpacity={0} />
                </linearGradient>
              </defs>
              <Area
                type="monotone"
                dataKey="y"
                stroke={grad.sparkColor}
                strokeWidth={2}
                fill={`url(#kyp-spark-${data.id})`}
                dot={false}
                isAnimationActive
                animationDuration={1000}
                animationEasing="ease-out"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </motion.div>
  )
}

export default function RightPanel() {
  const customers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const miniCards = useMemo(() => computeKypMiniCards(customers, paymentHistory), [customers, paymentHistory])

  return (
    <div className="space-y-4">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex items-center gap-2.5 mb-3"
      >
        <div className="w-8 h-8 rounded-[9px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
          <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
          </svg>
        </div>
        <div>
          <h3 className="text-sm font-semibold text-slate-900">KYP Overview</h3>
          <p className="text-[10px] text-slate-500">Key performance metrics</p>
        </div>
      </motion.div>
      <div className="grid grid-cols-1 gap-4">
        {miniCards.map((card, i) => (
          <KypMiniCard key={card.id} data={card} index={i} />
        ))}
      </div>
    </div>
  )
}
