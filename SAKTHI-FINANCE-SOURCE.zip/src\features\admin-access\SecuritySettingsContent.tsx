'use client'

import { useState } from 'react'
import { cn } from '@/lib/utils'
import AdminSectionShell, { AdminError, AdminLoading } from './AdminSectionShell'
import { adminMutate, useAdminApi } from './useAdminApi'

interface SettingsData {
  sessionTimeoutMinutes: number
  maxSessionsPerUser: number
  canManage: boolean
}

export default function SecuritySettingsContent() {
  const { data, state, retrying, retry } = useAdminApi<SettingsData>('/api/admin/security-settings', (j) => ({
    sessionTimeoutMinutes: Number(j?.sessionTimeoutMinutes) || 15,
    maxSessionsPerUser: Number(j?.maxSessionsPerUser) || 10,
    canManage: j?.canManage === true,
  }))
  const [timeout, setTimeout] = useState('')
  const [maxSessions, setMaxSessions] = useState('')
  const [touched, setTouched] = useState(false)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null)

  const currentTimeout = touched && timeout !== '' ? timeout : String(data?.sessionTimeoutMinutes ?? '')
  const currentMax = touched && maxSessions !== '' ? maxSessions : String(data?.maxSessionsPerUser ?? '')

  const save = async () => {
    setSaving(true)
    setMsg(null)
    const r = await adminMutate('/api/admin/security-settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sessionTimeoutMinutes: Number(currentTimeout),
        maxSessionsPerUser: Number(currentMax),
      }),
    })
    setSaving(false)
    setMsg({ ok: r.ok, text: r.ok ? 'Security settings saved. New sessions use the updated values.' : r.message })
    if (r.ok) {
      setTouched(false)
      retry()
    }
  }

  const inputCls =
    'w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-[var(--primary)]/30 focus:outline-none bg-white disabled:opacity-50 disabled:bg-slate-50'

  return (
    <AdminSectionShell title="Security Settings" subtitle="Owner-controlled session and security policies" icon="permissions">
      {state === 'loading' && <AdminLoading />}
      {state === 'unauthorized' && (
        <AdminError message="You are not authorized to access this page." onRetry={retry} retrying={retrying} />
      )}
      {state === 'failed' && (
        <AdminError message="Unable to connect to the database. Please try again." onRetry={retry} retrying={retrying} />
      )}
      {state === 'ready' && data && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-5 max-w-[640px]">
          {msg && (
            <div className={cn(
              'p-3 rounded-xl border text-sm',
              msg.ok ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-amber-50 border-amber-200 text-amber-800'
            )}>
              {msg.text}
            </div>
          )}
          {!data.canManage && (
            <div className="p-3 rounded-xl border text-sm bg-slate-50 border-slate-200 text-slate-600">
              Only the Owner can change security settings. Changes you submit will be rejected.
            </div>
          )}
          <div>
            <label className="block text-sm font-bold text-slate-900">Session timeout (minutes)</label>
            <p className="text-xs text-slate-500 mt-0.5 mb-2">
              Access tokens and cookies expire after this long. Applies to new sign-ins and refreshes (5–480).
            </p>
            <input
              type="number"
              min={5}
              max={480}
              value={currentTimeout}
              disabled={!data.canManage}
              onChange={(e) => {
                setTimeout(e.target.value)
                setTouched(true)
              }}
              className={inputCls}
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-900">Maximum sessions per user</label>
            <p className="text-xs text-slate-500 mt-0.5 mb-2">
              When a user exceeds this many active sessions, the oldest are revoked at sign-in (1–50).
            </p>
            <input
              type="number"
              min={1}
              max={50}
              value={currentMax}
              disabled={!data.canManage}
              onChange={(e) => {
                setMaxSessions(e.target.value)
                setTouched(true)
              }}
              className={inputCls}
            />
          </div>
          <div className="rounded-xl bg-slate-50 border border-slate-200 p-3.5 text-xs text-slate-600">
            Always enforced: server-side role checks on every admin API, per-account data isolation
            (user_id ownership on all business records), refresh-token revocation on logout and
            force-logout, and tamper-evident audit logging that cannot be disabled.
          </div>
          {data.canManage && (
            <button
              onClick={save}
              disabled={saving}
              className="px-5 py-2.5 rounded-xl bg-[var(--primary)] text-white text-sm font-semibold hover:bg-[#912222] disabled:opacity-50"
            >
              {saving ? 'Saving…' : 'Save Changes'}
            </button>
          )}
        </div>
      )}
    </AdminSectionShell>
  )
}
