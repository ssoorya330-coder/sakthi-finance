import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { validPurposes } from '@/server/storage'
import { actorFromAuthUser, requestMeta, recordAuditStandalone, diffRecords } from '@/server/audit'

const MAX_BYTES_CAP = 16 * 1024 ** 4 // 16 TB sanity cap

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const { id } = await params
    const body = await request.json()
    const updates: string[] = []
    const values: any[] = []
    let i = 1

    // Renaming / purpose / allocation / status only — the path itself is
    // immutable (remove + re-add to change location). Roles are never touched.
    if (body.name !== undefined) {
      const name = (body.name || '').trim()
      if (!name) return NextResponse.json({ error: 'Storage name is required.' }, { status: 400 })
      if (name.length > 120) return NextResponse.json({ error: 'Storage name is too long.' }, { status: 400 })
      updates.push(`name = $${i++}`)
      values.push(name)
    }
    if (body.purpose !== undefined) {
      if (!validPurposes().includes(body.purpose)) {
        return NextResponse.json({ error: 'Invalid storage purpose.' }, { status: 400 })
      }
      updates.push(`purpose = $${i++}`)
      values.push(body.purpose)
    }
    if (body.maxBytes !== undefined) {
      if (body.maxBytes !== null && (!Number.isFinite(body.maxBytes) || body.maxBytes <= 0 || body.maxBytes > MAX_BYTES_CAP)) {
        return NextResponse.json({ error: 'Invalid storage allocation.' }, { status: 400 })
      }
      updates.push(`max_bytes = $${i++}`)
      values.push(body.maxBytes)
    }
    if (body.status !== undefined) {
      if (!['Active', 'Disabled'].includes(body.status)) {
        return NextResponse.json({ error: 'Invalid status.' }, { status: 400 })
      }
      updates.push(`status = $${i++}`)
      values.push(body.status)
    }
    if (updates.length === 0) {
      return NextResponse.json({ error: 'No fields to update.' }, { status: 400 })
    }
    updates.push('updated_at = NOW()')
    values.push(id)
    const beforeRow = await dbQuery('SELECT * FROM storage_locations WHERE id = $1', [id])
    const before = beforeRow.rows[0] || null
    const result = await dbQuery(
      `UPDATE storage_locations SET ${updates.join(', ')} WHERE id = $${i} RETURNING *`,
      values
    )
    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Storage location not found.' }, { status: 404 })
    }
    {
      const meta = requestMeta(request)
      const changes = diffRecords(
        before ? { name: before.name, purpose: before.purpose, max_bytes: before.max_bytes, status: before.status } : null,
        { name: result.rows[0].name, purpose: result.rows[0].purpose, max_bytes: result.rows[0].max_bytes, status: result.rows[0].status },
        ['name', 'purpose', 'max_bytes', 'status'],
        { name: 'Name', purpose: 'Purpose', max_bytes: 'Allocation (bytes)', status: 'Status' }
      )
      await recordAuditStandalone({
        action: 'STORAGE_LOCATION_UPDATED',
        entityType: 'storage',
        entityId: id,
        actor: actorFromAuthUser(auth.user),
        ipAddress: meta.ip,
        clientInfo: meta.client,
        result: 'SUCCESS',
        changes,
      })
    }
    return NextResponse.json({ location: result.rows[0] })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to update storage', details: err.message },
      { status: 500 }
    )
  }
}

export async function DELETE(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const { id } = await params
    // Config row only — existing files on the drive are NEVER deleted.
    const result = await dbQuery('DELETE FROM storage_locations WHERE id = $1 RETURNING id, name', [id])
    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Storage location not found.' }, { status: 404 })
    }
    await dbQuery(
      "INSERT INTO audit_logs (action, entity_type, entity_id, details, user_id) VALUES ('delete', 'storage', $1, $2, $3)",
      [id, JSON.stringify({ name: result.rows[0].name }), auth.user.userId]
    ).catch(() => {})
    {
      const meta = requestMeta(_request)
      await recordAuditStandalone({
        action: 'STORAGE_LOCATION_DELETED',
        entityType: 'storage',
        entityId: id,
        actor: actorFromAuthUser(auth.user),
        ipAddress: meta.ip,
        clientInfo: meta.client,
        result: 'SUCCESS',
        changes: [{ field: 'name', label: 'Name', before: result.rows[0].name, after: null }],
      })
    }
    return NextResponse.json({ success: true, id })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to remove storage', details: err.message },
      { status: 500 }
    )
  }
}

