'use client'

import { useEffect, useState } from 'react'
import { formatCurrency, formatDateDMY } from '@/features/dashboard/dashboard.styles'

type Account = {
  loan_id: string; loan_amount: string; total_amount: string; paid_amount: string
  interest_rate: string; duration: string; loan_type: string; status: string
  loan_date: string; due_date: string; notes?: string
}

export default function CustomerKanaku({ customerId }: { customerId: string }) {
  const [accounts, setAccounts] = useState<Account[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [retry, setRetry] = useState(0)
  useEffect(() => {
    const controller = new AbortController()
    setLoading(true)
    setError('')
    setAccounts([])
    fetch(`/api/loans?customer_id=${encodeURIComponent(customerId)}`, { signal: controller.signal, cache: 'no-store' })
      .then(async response => {
        if (!response.ok) throw new Error('Unable to load this customer’s Kanaku. Please retry.')
        const result = await response.json()
        if (!controller.signal.aborted) setAccounts(result.data)
      })
      .catch(error => { if (!controller.signal.aborted) setError(error.message) })
      .finally(() => { if (!controller.signal.aborted) setLoading(false) })
    return () => controller.abort()
  }, [customerId, retry])
  if (loading) return <p role="status" className="p-6 text-sm text-slate-500">Loading Kanaku…</p>
  if (error) return <div role="alert" className="p-6 text-red-700">{error} <button onClick={() => setRetry(value => value + 1)} className="underline">Retry</button></div>
  const paid = accounts.reduce((sum, account) => sum + Number(account.paid_amount), 0)
  const outstanding = accounts.reduce((sum, account) => sum + Math.max(0, Number(account.total_amount) - Number(account.paid_amount)), 0)
  const summary = [
    ['Total Kanaku', accounts.length],
    ['Completed', accounts.filter(account => account.status === 'Completed').length],
    ['Active', accounts.filter(account => ['Active', 'Overdue'].includes(account.status)).length],
    ['Total Borrowed', formatCurrency(accounts.reduce((sum, account) => sum + Number(account.loan_amount), 0))],
    ['Total Paid', formatCurrency(paid)],
    ['Outstanding', formatCurrency(outstanding)],
  ]
  return <section aria-label="Customer Kanaku" className="p-5 space-y-5">
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">{summary.map(([label, value]) => <div key={label} className="rounded-xl border border-rose-100 bg-gradient-to-br from-white to-rose-50 p-3"><p className="text-xs text-slate-500">{label}</p><p className="mt-1 font-bold text-[var(--primary)]">{value}</p></div>)}</div>
    <h3 className="font-semibold text-slate-900">Kanaku List</h3>
    <p className="text-xs text-slate-500">Paid totals include payments linked to each loan. Unassigned legacy payments remain in Payment History.</p>
    {!accounts.length ? <p className="text-sm text-slate-500">No loan accounts recorded for this customer.</p> : <div className="overflow-x-auto rounded-xl border border-slate-200"><table className="w-full min-w-[580px] text-left text-sm">
      <thead className="bg-[var(--primary)] text-white"><tr>{['Loan ID', 'Amount', 'Interest', 'Tenure', 'Status', 'Outstanding', 'Details'].map(title => <th key={title} className="p-3">{title}</th>)}</tr></thead>
      <tbody>{accounts.map(account => <tr key={account.loan_id} className="border-t border-slate-100">
        <td className="p-3 font-medium">{account.loan_id}</td><td className="p-3">{formatCurrency(Number(account.loan_amount))}</td><td className="p-3">{Number(account.interest_rate)}%</td><td className="p-3">{account.duration} · {account.loan_type}</td><td className="p-3"><span className="rounded-full bg-slate-100 px-2 py-1 text-xs">{account.status}</span></td><td className="p-3 font-semibold">{formatCurrency(Math.max(0, Number(account.total_amount) - Number(account.paid_amount)))}</td>
        <td className="p-3"><details><summary className="cursor-pointer text-[var(--primary)]">View</summary><div className="mt-2 min-w-40 space-y-1 text-xs"><p>Loan date: {formatDateDMY(account.loan_date)}</p><p>Due date: {formatDateDMY(account.due_date)}</p><p>Total: {formatCurrency(Number(account.total_amount))}</p><p>Paid: {formatCurrency(Number(account.paid_amount))}</p>{account.notes && <p>{account.notes}</p>}</div></details></td>
      </tr>)}</tbody>
    </table></div>}
  </section>
}
