import { access, readFile } from 'node:fs/promises'
import path from 'node:path'

const stage = process.argv[2] || process.env.SAKTHI_DESKTOP_STAGE
if (!stage || !path.isAbsolute(stage)) throw Error('Run scripts/desktop/prepare-release.mjs and supply its generated Tauri configuration first.')
for (const file of ['release-checked.json', 'node.exe', 'node-LICENSE.txt', 'backend-launcher.mjs', 'runtime-config.mjs', 'server/server.js', 'server/.next/BUILD_ID']) await access(path.join(stage, file))
const manifest = JSON.parse(await readFile(path.join(stage, 'release-checked.json'), 'utf8'))
if (manifest.buildId !== (await readFile(path.join(stage, 'server/.next/BUILD_ID'), 'utf8')).trim()) throw Error('Staged build does not match release check.')
console.log('Desktop resources checked. Runtime configuration remains outside the installer.')
