import AuditPage from '@/features/audit/AuditPage'

export default function AuditPageRoute() {
  return <AuditPage />
}
