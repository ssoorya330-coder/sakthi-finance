import { readFile } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { randomBytes } from 'node:crypto'
import { fileURLToPath, pathToFileURL } from 'node:url'
import path from 'node:path'
import { validateRuntimeConfig, databaseProbeConfig } from './runtime-config.mjs'

const directory = path.dirname(fileURLToPath(import.meta.url))
const requireServer = createRequire(path.join(directory, 'server/server.js'))
const fail = code => { process.stdout.write(`SAKTHI_ERROR:${code}\n`); process.exit(1) }
let config
try {
  if (!process.env.SAKTHI_DESKTOP_CONFIG) throw Error('missing')
  config = validateRuntimeConfig(JSON.parse(await readFile(process.env.SAKTHI_DESKTOP_CONFIG, 'utf8')))
} catch { fail('CONFIGURATION') }

// Refuse missing/offline storage before importing the application or running its
// normal startup routines. This probe cannot create databases or migrate records.
try {
  const { Client } = requireServer('pg')
  const probe = new Client(databaseProbeConfig(config))
  try {
    await probe.connect()
    const result = await probe.query("SELECT to_regclass('public.customers') IS NOT NULL AND to_regclass('public.loans') IS NOT NULL AND to_regclass('public.payments') IS NOT NULL AS existing")
    if (!result.rows[0]?.existing) throw Error('Existing finance schema missing')
  } finally { await probe.end() }
} catch { fail('DATABASE') }

// Fixed, loopback-only desktop port. Never silently attach to another process.
const marker = randomBytes(32).toString('hex')
Object.assign(process.env, config, {
  NODE_ENV: 'production', HOSTNAME: '127.0.0.1', PORT: '38471',
  NEXT_TELEMETRY_DISABLED: '1', SAKTHI_DESKTOP_RUN_ID: marker,
})
process.stdin.resume()
process.stdin.on('end', () => process.exit(0)) // Parent closed/crashed: no orphan backend.
const backendFailure = error => {
  // Only emit a fixed diagnostic code, never an error message/token/connection URL.
  const code = ['EINVAL', 'EBADF', 'EPIPE', 'EADDRINUSE', 'ENOENT', 'EACCES'].includes(error?.code) ? error.code : 'UNKNOWN'
  fail(`BACKEND_${code}`)
}
process.on('uncaughtException', backendFailure)
process.on('unhandledRejection', backendFailure)
await import(pathToFileURL(path.join(directory, 'server/server.js')).href)
const deadline = Date.now() + 60_000
let busy = false
const timer = setInterval(async () => {
  if (busy) return
  if (Date.now() >= deadline) fail('TIMEOUT')
  busy = true
  try {
    const response = await fetch('http://127.0.0.1:38471/api/desktop/ready', {
      headers: { 'x-sakthi-desktop-run': marker }, signal: AbortSignal.timeout(2000),
    })
    if (response.ok && (await response.json()).run === marker) {
      clearInterval(timer)
      process.stdout.write('SAKTHI_READY\n')
    }
  } catch { /* readiness retries are bounded by deadline */ }
  finally { busy = false }
}, 250)
