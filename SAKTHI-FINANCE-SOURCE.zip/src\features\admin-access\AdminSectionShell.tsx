'use client'

import { useRouter } from 'next/navigation'
import { Activity, ArrowLeft, History, LockKeyhole, RefreshCw, Users } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useSidebarStore } from '@/store/sidebar-store'

export type AdminSectionIcon = 'users' | 'login' | 'permissions' | 'system'

const ICONS: Record<AdminSectionIcon, React.FC<{ className?: string }>> = {
  users: Users,
  login: History,
  permissions: LockKeyhole,
  system: Activity,
}

interface AdminSectionShellProps {
  title: string
  subtitle: string
  icon: AdminSectionIcon
  children: React.ReactNode
}

/**
 * Shared shell for Admin Access sub-sections (client-side only, so icon
 * component references never cross the RSC serialization boundary).
 */
export default function AdminSectionShell({ title, subtitle, icon, children }: AdminSectionShellProps) {
  const router = useRouter()
  const toggleSidebar = useSidebarStore((s) => s.toggleSidebar)
  const Icon = ICONS[icon] ?? Activity

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-[1400px] mx-auto space-y-5">
        <div className="flex items-center gap-3">
          <button
            onClick={toggleSidebar}
            aria-label="Open menu"
            className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors active:scale-95 shadow-sm flex-shrink-0"
          >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round">
              <path d="M3 5h14" />
              <path d="M3 10h14" />
              <path d="M3 15h14" />
            </svg>
          </button>
          <button
            onClick={() => router.push('/dashboard/admin-access')}
            aria-label="Back to Admin Access"
            className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors active:scale-95 shadow-sm flex-shrink-0"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
            <Icon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">{title}</h1>
            <p className="text-xs sm:text-sm text-slate-500">{subtitle}</p>
          </div>
        </div>

        {children}
      </div>
    </div>
  )
}

export function AdminLoading() {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 space-y-2.5" aria-label="Loading">
      {[0, 1, 2].map((i) => (
        <div key={i} className="h-12 rounded-xl bg-slate-100 animate-pulse" />
      ))}
    </div>
  )
}

export function AdminEmpty({ message }: { message: string }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 text-center">
      <p className="text-sm font-bold text-slate-900">{message}</p>
      <p className="text-xs text-slate-500 mt-1">New records will appear here automatically.</p>
    </div>
  )
}

export function AdminError({ message, onRetry, retrying }: { message: string; onRetry: () => void; retrying: boolean }) {
  return (
    <div className="bg-white rounded-2xl border border-red-200 shadow-sm p-8 text-center">
      <p className="text-sm font-bold text-slate-900">{message}</p>
      <button
        onClick={onRetry}
        disabled={retrying}
        className={cn(
          'mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-[var(--primary)] text-white hover:bg-[#912222] disabled:opacity-50'
        )}
      >
        <RefreshCw className={cn('w-3.5 h-3.5', retrying && 'animate-spin')} />
        {retrying ? 'Retrying…' : 'Try Again'}
      </button>
    </div>
  )
}
