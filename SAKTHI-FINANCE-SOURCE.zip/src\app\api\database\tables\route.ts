import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'

/** Full per-table sizes for the Manage Tables view. */
export async function GET() {
  const auth = await requireAuth()
  if (auth.error) return auth.error

  try {
    const counts = await dbQuery(`SELECT
      (SELECT COUNT(*)::text FROM customers WHERE user_id=$1) AS customers,
      (SELECT COUNT(*)::text FROM loans WHERE user_id=$1) AS loans,
      (SELECT COUNT(*)::text FROM payments WHERE user_id=$1) AS payments,
      (SELECT COUNT(*)::text FROM customers WHERE user_id=$1 AND status='Completed') AS completed,
      (SELECT COUNT(*)::text FROM customers WHERE user_id=$1 AND status='Aborted') AS aborted`, [auth.user.userId])
    const result = await dbQuery<{ name: string; total: string; heap: string; indexes: string; toast: string; rows: string }>(
      `SELECT c.relname AS name,
        pg_total_relation_size(c.oid)::text AS total,
        pg_relation_size(c.oid)::text AS heap,
        pg_indexes_size(c.oid)::text AS indexes,
        COALESCE(pg_total_relation_size(c.reltoastrelid), 0)::text AS toast,
        COALESCE(c.reltuples::bigint, 0)::text AS rows
       FROM pg_class c
       JOIN pg_namespace n ON n.oid = c.relnamespace
       WHERE n.nspname = 'public' AND c.relkind IN ('r', 'p')
       ORDER BY pg_total_relation_size(c.oid) DESC`
    )
    return NextResponse.json({
      recordCounts: counts.rows[0],
      tables: result.rows.map((r) => ({
        name: r.name,
        rows: Number(r.rows) || 0,
        totalBytes: Number(r.total) || 0,
        heapBytes: Number(r.heap) || 0,
        indexBytes: Number(r.indexes) || 0,
        toastBytes: Number(r.toast) || 0,
      })),
    })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to load table information', details: err.message },
      { status: 500 }
    )
  }
}
