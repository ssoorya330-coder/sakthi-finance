'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'
import { Landmark } from 'lucide-react'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts'
import { formatINR } from '@/lib/dashboard-utils'
import { useCustomerStore } from '@/store/customer-store'
import { computeLoanAnalytics } from './dashboard-data'
import { axisProps, gridLineProps } from './dashboard-animations'

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
      className="bg-white/95 backdrop-blur-sm rounded-xl border border-slate-100 shadow-xl px-4 py-3"
    >
      <p className="text-xs font-medium text-slate-500 mb-2">{label}</p>
      {payload.map((entry: any, i: number) => (
        <div key={i} className="flex items-center gap-2 text-sm">
          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
          <span className="text-slate-600 capitalize">{entry.name}:</span>
          <span className="font-semibold text-slate-900">{formatINR(entry.value)}</span>
        </div>
      ))}
    </motion.div>
  )
}

function EmptyState() {
  return (
    <div className="h-[270px] flex items-center justify-center">
      <div className="text-center">
        <Landmark className="w-10 h-10 text-slate-300 mx-auto mb-3" />
        <p className="text-sm text-slate-400 font-medium">No loan data available</p>
        <p className="text-xs text-slate-300 mt-1">Add customers to see loan analytics</p>
      </div>
    </div>
  )
}

export default function LoanAnalyticsChart() {
  const customers = useCustomerStore((s) => s.customers)
  const data = useMemo(() => computeLoanAnalytics(customers), [customers])
  const totalDisbursed = data.reduce((s, d) => s + d.disbursed, 0)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="relative bg-white/70 backdrop-blur-xl rounded-[20px] border border-white/20 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] p-6 overflow-hidden"
    >
      <div className="absolute inset-0 sf-pattern-dots opacity-40 pointer-events-none" />
      <div className="flex items-center justify-between mb-6 relative">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
            <Landmark className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-slate-900">Loan Analytics</h3>
            <p className="text-xs text-slate-500">Total disbursed: {formatINR(totalDisbursed)}</p>
          </div>
        </div>
      </div>
      {data.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="h-[270px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
              <CartesianGrid {...gridLineProps} />
              <XAxis dataKey="month" {...axisProps} />
              <YAxis {...axisProps} tickFormatter={(v) => `${(v / 100000).toFixed(1)}L`} />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                iconType="circle"
                iconSize={8}
                wrapperStyle={{ fontSize: '12px', paddingTop: '16px' }}
              />
              <Bar
                dataKey="disbursed"
                fill="var(--primary)"
                radius={[4, 4, 0, 0]}
                name="Disbursed"
                isAnimationActive
                animationDuration={1200}
                animationEasing="ease-out"
                animationBegin={200}
              />
              <Bar
                dataKey="collected"
                fill="var(--secondary)"
                radius={[4, 4, 0, 0]}
                name="Collected"
                isAnimationActive
                animationDuration={1200}
                animationEasing="ease-out"
                animationBegin={400}
              />
              <Bar
                dataKey="pending"
                fill="var(--primary-hover)"
                radius={[4, 4, 0, 0]}
                name="Pending"
                isAnimationActive
                animationDuration={1200}
                animationEasing="ease-out"
                animationBegin={600}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </motion.div>
  )
}
