'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Loader2, Mail } from 'lucide-react'
import { useAuthStore } from '@/store/auth-store'

export function CustomerEmailLogin() {
  const router = useRouter()
  const setUser = useAuthStore((state) => state.setUser)
  const [phone, setPhone] = useState('')
  const [email, setEmail] = useState('')
  const [code, setCode] = useState('')
  const [sent, setSent] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const [cooldown, setCooldown] = useState(0)

  useEffect(() => {
    if (!cooldown) return
    const timer = setTimeout(() => setCooldown((value) => Math.max(0, value - 1)), 1000)
    return () => clearTimeout(timer)
  }, [cooldown])

  async function submit(action: 'send' | 'verify') {
    if (busy) return
    setBusy(true)
    setError('')
    setMessage('')
    try {
      const response = await fetch('/api/auth/customer-email', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, phone, email, ...(action === 'verify' ? { code } : {}) }),
      })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'Unable to sign in. Please try again.')
      if (action === 'send') {
        setSent(true)
        setCode('')
        setCooldown(60)
        setMessage(data.message)
      } else {
        setUser({ userId: data.user.id, email: data.user.email, name: data.user.name, role: 'customer' })
        router.replace('/dashboard/my-account')
        router.refresh()
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Unable to connect. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  const inputClass = 'mt-1.5 w-full rounded-xl border border-[#E8E5E0] px-3 py-3 text-sm text-[var(--text-primary)] outline-none focus:ring-2 focus:ring-[var(--primary)]/30 disabled:bg-slate-50 disabled:text-slate-500'
  return (
    <section aria-labelledby="customer-signin-title" className="mb-6">
      <h3 id="customer-signin-title" className="font-semibold text-[var(--text-primary)] flex items-center gap-2"><Mail className="h-4 w-4" />Customer sign in</h3>
      <p className="text-sm text-[#6A6A72] mt-2 mb-5">Enter your registered phone number and email. We’ll send a verification code to your email.</p>
      <form onSubmit={(event) => { event.preventDefault(); void submit(sent ? 'verify' : 'send') }} className="space-y-4">
        <label className="block text-sm font-medium text-[var(--text-primary)]" htmlFor="customer-phone">Phone number
          <input id="customer-phone" type="tel" autoComplete="tel" required maxLength={30} disabled={sent || busy} value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="Registered mobile number" className={inputClass} />
        </label>
        <label className="block text-sm font-medium text-[var(--text-primary)]" htmlFor="customer-email">Email address
          <input id="customer-email" type="email" autoComplete="email" required maxLength={254} disabled={sent || busy} value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" className={inputClass} />
        </label>
        {sent && <label className="block text-sm font-medium text-[var(--text-primary)]" htmlFor="customer-code">Email verification code
          <input id="customer-code" inputMode="numeric" autoComplete="one-time-code" required pattern="[0-9]{6,10}" minLength={6} maxLength={10} autoFocus disabled={busy} value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, ''))} className={inputClass} />
        </label>}
        {error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}
        {message && <p role="status" className="rounded-xl bg-emerald-50 p-3 text-sm text-emerald-800">{message}</p>}
        <button type="submit" disabled={busy || (!sent && cooldown > 0)} className="w-full flex justify-center items-center gap-2 rounded-xl bg-[var(--primary)] py-3 text-sm font-semibold text-white hover:bg-[#641717] disabled:opacity-50">
          {busy && <Loader2 className="h-4 w-4 animate-spin" />}{busy ? 'Please wait…' : sent ? 'Verify and sign in' : cooldown ? `Send code in ${cooldown}s` : 'Send email code'}
        </button>
        {sent && <div className="flex justify-between gap-3 text-sm">
          <button type="button" disabled={busy || cooldown > 0} onClick={() => void submit('send')} className="text-[var(--primary)] disabled:text-slate-400">{cooldown ? `Resend in ${cooldown}s` : 'Resend code'}</button>
          <button type="button" disabled={busy} onClick={() => { setSent(false); setCode(''); setError(''); setMessage('') }} className="text-[#6A6A72]">Change details</button>
        </div>}
      </form>
      <p className="mt-4 text-xs leading-relaxed text-[#6A6A72]">No password or SMS needed. If your email is not linked to your customer account, contact the office.</p>
    </section>
  )
}
