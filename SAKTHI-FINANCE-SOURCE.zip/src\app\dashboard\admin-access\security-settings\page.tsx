'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import SecuritySettingsContent from '@/features/admin-access/SecuritySettingsContent'

export default function SecuritySettingsContentPage() {
  return (
    <ClientPageGate requireRole="owner">
      <SecuritySettingsContent />
    </ClientPageGate>
  )
}
