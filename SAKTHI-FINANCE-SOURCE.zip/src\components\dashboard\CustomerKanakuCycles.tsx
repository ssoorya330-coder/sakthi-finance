'use client'

import { useEffect, useRef, useState } from 'react'
import { Plus, X } from 'lucide-react'
import { formatCurrency as money, formatDateDMY as date } from '@/features/dashboard/dashboard.styles'
import { apiClient } from '@/services/api-client'
import { useCustomerStore } from '@/store/customer-store'
import { paymentDateInIndia } from '@/lib/payment-history'
import { calculateKanaku } from '@/lib/kanaku'
import { formatLoanDisplayId } from '@/utils/loan-display-id'
import { formatCustomerCode } from '@/utils/customer-id'
import { useAuthStore } from '@/store/auth-store'
import { hasPermission } from '@/config/rbac'

type Account = { customer_id: string; customer_code?: string; loan_id: string; cycle_number: number; kanaku_number: number; loan_amount: string; total_amount: string; paid_amount: string; outstanding: string; interest_rate: string; duration: string; loan_type: string; status: string; loan_date: string; due_date: string; legacy_paid_amount: string }
type Receipt = { payment_id: string; amount: string; payment_date: string; payment_method: string }
const field = 'w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm focus:ring-2 focus:ring-[var(--primary)]/20'
const button = 'rounded-xl bg-[var(--primary)] px-4 py-2 text-sm font-semibold text-white disabled:opacity-50'

export default function CustomerKanakuCycles({ customerId, readOnly = false, onViewPayments, onChanged, paymentHistory, view = 'all' }: { customerId: string; readOnly?: boolean; onViewPayments?: (loanId: string) => void; onChanged?: () => void; paymentHistory?: React.ReactNode; view?: 'all' | 'summary' | 'overview' }) {
  const [accounts, setAccounts] = useState<Account[]>([])
  const role = useAuthStore(s => s.role)
  async function deleteKanaku(account: Account) {
    if (!window.confirm(`Move Customer ${account.customer_code || account.customer_id} · Cycle ${account.cycle_number} · Kanaku ${account.kanaku_number} to Recently Deleted for 30 days? Only this Kanaku and its payments will be removed. Other Kanaku stay unchanged.`)) return
    if (busy.current) return
    busy.current=true
    try {
      await apiClient.deleteLoan(account.loan_id)
      setStatement(null);setRetry(v=>v+1);onChanged?.()
      await useCustomerStore.getState().refresh()
      setNotice(`Kanaku ${account.kanaku_number} moved to Recently Deleted for 30 days.`)
    } catch(error) {setError(error instanceof Error?error.message:'Unable to delete this Kanaku.')}
    finally {busy.current=false}
  }
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [retry, setRetry] = useState(0)
  const [adding, setAdding] = useState(false)
  const [saving, setSaving] = useState(false)
  const busy = useRef(false)
  const requestKey = useRef('')
  const [statement, setStatement] = useState<Account | null>(null)
  const [receipts, setReceipts] = useState<Receipt[]>([])
  const [statementLoading, setStatementLoading] = useState(false)
  const [statementError, setStatementError] = useState('')
  const [payment, setPayment] = useState('')
  useEffect(() => {
    const controller = new AbortController()
    setLoading(true); setError('')
    apiClient.fetchLoans({ customerId }).then(result => {
      if (!controller.signal.aborted) setAccounts(result.data as unknown as Account[])
    }).catch(error => { if (!controller.signal.aborted) setError(error.message) }).finally(() => { if (!controller.signal.aborted) setLoading(false) })
    return () => controller.abort()
  }, [customerId, retry])
  useEffect(() => {
    if (!statement) return
    let cancelled = false
    setStatementLoading(true); setStatementError(''); setReceipts([]); setPayment('')
    apiClient.fetchPayments({ customerId: String(statement.customer_id), loanId: statement.loan_id }).then(result => { if (!cancelled) setReceipts(result.data) }).catch(error => { if (!cancelled) setStatementError(error.message) }).finally(() => { if (!cancelled) setStatementLoading(false) })
    return () => { cancelled = true }
  }, [customerId, statement, retry])
  const current = Math.max(1, ...accounts.map(account => account.cycle_number))
  const currentLoans = accounts.filter(account => account.cycle_number === current)
  const done = currentLoans.length > 0 && currentLoans.every(account => account.status === 'Completed' && Number(account.outstanding) === 0)
  const previous = [...new Set(accounts.map(account => account.cycle_number))].filter(cycle => cycle !== current).sort((a, b) => b - a)
  const refresh = async () => { setRetry(value => value + 1); await useCustomerStore.getState().refresh(); onChanged?.() }
  const create = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (busy.current) return
    const data = Object.fromEntries(new FormData(event.currentTarget))
    try { calculateKanaku(data) } catch (error) { setError((error as Error).message); return }
    busy.current = true; setSaving(true); setError(''); setNotice('')
    try {
      const loan = await apiClient.createLoan({ customer_id: customerId, loan_amount: Number(data.loan_amount), interest_rate: Number(data.interest_rate), duration: Number(data.duration), loan_type: String(data.loan_type), loan_date: String(data.loan_date), disbursal_mode: String(data.disbursal_mode), notes: String(data.notes), request_key: requestKey.current })
      setAdding(false); setNotice(`Created Cycle ${loan.cycle_number} · Kanaku ${loan.kanaku_number}.`); await refresh()
    } catch (error) { setError((error as Error).message) } finally { busy.current = false; setSaving(false) }
  }
  const receive = async () => {
    if (!statement || busy.current) return
    const amount = Number(payment)
    if (!/^\d+(\.\d{1,2})?$/.test(payment) || amount <= 0 || amount > Number(statement.outstanding)) { setStatementError('Enter a positive amount not exceeding this Kanaku balance.'); return }
    busy.current = true; setSaving(true); setStatementError('')
    try {
      await apiClient.createPayment({ customer_id: statement.customer_id, loan_id: statement.loan_id, amount, payment_date: paymentDateInIndia(), payment_method: 'Cash', payment_mode: 'Cash', remarks: `Cycle ${statement.cycle_number} · Kanaku ${statement.kanaku_number}` })
      setStatement(null); setNotice('Payment saved. Kanaku and cycle balances updated.'); await refresh()
    } catch (error) { setStatementError((error as Error).message) } finally { busy.current = false; setSaving(false) }
  }
  const summary = [
    ['Current Cycle', current], ['Active Kanaku', accounts.filter(a => ['Active', 'Overdue'].includes(a.status) || Number(a.outstanding) > 0).length],
    ['Lifetime Kanaku', accounts.length], ['Completed Kanaku', accounts.filter(a => a.status === 'Completed' && Number(a.outstanding) === 0).length],
    ['Total Borrowed', money(accounts.reduce((sum, a) => sum + Number(a.loan_amount), 0))], ['Total Repaid', money(accounts.reduce((sum, a) => sum + Number(a.paid_amount), 0))], ['Outstanding', money(accounts.reduce((sum, a) => sum + Number(a.outstanding), 0))],
  ]
  const table = (loans: Account[]) => <div className="overflow-x-auto rounded-xl border border-slate-200"><table className="w-full min-w-[740px] text-left text-sm"><thead className="bg-[var(--primary)] text-white"><tr>{['Kanaku', 'Status', 'Amount', 'Paid', 'Balance', 'Dates', 'Statement', ...(hasPermission(role,'loans:delete') ? ['Actions'] : [])].map(title => <th key={title} className="p-3">{title}</th>)}</tr></thead><tbody>{loans.map(a => <tr key={a.loan_id} className="border-t border-slate-100 align-top">
    <td className="p-3"><p className="whitespace-nowrap font-semibold">Kanaku {a.kanaku_number}</p><p className="mt-1 max-w-32 break-all text-[10px] text-slate-500">Customer ID: {formatCustomerCode(a.customer_code)}</p></td><td className="p-3"><span className={`rounded-full px-2 py-1 text-xs ${a.status === 'Completed' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-800'}`}>{a.status}</span></td>
<td className="p-3">{money(Number(a.loan_amount))}<p className="text-xs text-slate-500">{Number(a.interest_rate)}% · {a.duration} {a.loan_type}</p></td><td className="p-3 text-emerald-700">{money(Number(a.paid_amount))}</td><td className="p-3 font-semibold">{money(Number(a.outstanding))}</td><td className="p-3 text-xs"><p>Loan: {a.loan_date ? date(a.loan_date) : '—'}</p><p>Due: {a.due_date ? date(a.due_date) : '—'}</p></td><td className="p-3"><button onClick={() => onViewPayments ? onViewPayments(a.loan_id) : setStatement(a)} className="rounded-lg border border-rose-200 px-2 py-1 text-xs font-semibold text-[var(--primary)]" >{onViewPayments ? 'View Payments' : 'View Statement'}</button></td>
    {hasPermission(role,'loans:delete') && <td className="p-3"><button className="text-xs text-red-700 underline" onClick={()=>void deleteKanaku(a)}>Delete this Kanaku</button></td>}
  </tr>)}</tbody></table></div>
  return <section aria-label="Customer Kanaku cycles" className="space-y-5 p-5">
    {error && <div role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error} <button onClick={() => setRetry(value => value + 1)} className="underline">Retry</button></div>}{notice && <p role="status" className="rounded-xl bg-emerald-50 p-3 text-sm text-emerald-800">{notice}</p>}{loading && <p role="status">Loading Kanaku…</p>}
    {view !== 'overview' && <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">{summary.map(([label, value]) => <div key={label} className="rounded-xl border border-rose-100 bg-gradient-to-br from-white to-rose-50 p-3"><p className="text-xs text-slate-500">{label}</p><p className="mt-1 font-bold text-[var(--primary)]">{value}</p></div>)}</div>}
    {paymentHistory}
    {view !== 'summary' && <section aria-label="Kanaku Overview" className="space-y-4 rounded-2xl border border-[var(--secondary)]/20 bg-white p-4">
    <h3 className="text-lg font-bold text-[var(--primary)]">Kanaku Overview</h3>
    <div className="flex flex-wrap items-center justify-between gap-3"><h3 className="font-semibold">Current Cycle · {current} · {done ? 'Completed' : 'Active'}</h3>{!readOnly && <button disabled={loading || saving || adding} className={`${button} inline-flex items-center gap-2`} onClick={() => { requestKey.current = crypto.randomUUID(); setAdding(true); setError('') }}><Plus size={16} />Add New Kanaku</button>}</div>
    {done && <p className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">New Cycle — numbering starts from Kanaku 1.</p>}
    {!readOnly && adding && <form onSubmit={create} className="space-y-3 rounded-2xl border border-rose-200 bg-rose-50/50 p-4"><div className="flex justify-between"><h4 className="font-semibold">New Kanaku · Cycle {done ? current + 1 : current}</h4><button type="button" aria-label="Close new Kanaku" disabled={saving} onClick={() => setAdding(false)}><X size={18} /></button></div><p className="text-xs text-slate-500">Numbering, total and due date are calculated safely when saved.</p><div className="grid gap-3 sm:grid-cols-2">
      <label className="text-xs">Loan amount<input required name="loan_amount" type="number" min="0.01" step="0.01" className={field} /></label><label className="text-xs">Interest (%)<input required name="interest_rate" type="number" defaultValue="0" min="0" max="99.99" step="0.01" className={field} /></label><label className="text-xs">Loan type<select name="loan_type" className={field}>{['Daily','Weekly','Monthly','Yearly'].map(type => <option key={type}>{type}</option>)}</select></label><label className="text-xs">Number of installments<input required name="duration" type="number" min="1" max="32767" step="1" className={field} /></label><label className="text-xs">Loan date<input required name="loan_date" type="date" defaultValue={paymentDateInIndia()} className={field} /></label><label className="text-xs">Disbursal mode<select name="disbursal_mode" className={field}><option>Cash</option><option>Bank</option></select></label>
    </div><label className="block text-xs">Notes<textarea name="notes" className={field} /></label><button disabled={saving} className={button}>{saving ? 'Saving…' : 'Create Kanaku'}</button></form>}
    {currentLoans.length ? table(currentLoans) : !loading && <p>No Kanaku yet. First loan starts Cycle 1 · Kanaku 1.</p>}
    <h3 className="font-semibold">Previous Cycles</h3>{previous.length ? previous.map(cycle => <details key={cycle} className="rounded-xl border border-slate-200 p-3"><summary className="cursor-pointer font-semibold text-[var(--primary)]">Cycle {cycle} · Completed</summary><div className="mt-3">{table(accounts.filter(a => a.cycle_number === cycle))}</div></details>) : <p className="text-sm text-slate-500">Previous cycles remain here with their full statements.</p>}
    </section>}
    {statement && <section aria-label="Kanaku statement" className="space-y-3 rounded-2xl border-2 border-[var(--primary)]/20 p-4"><div className="flex justify-between"><h3 className="font-semibold">Statement · Cycle {statement.cycle_number} · Kanaku {statement.kanaku_number}</h3><button aria-label="Close statement" onClick={() => setStatement(null)}><X size={18} /></button></div><p className="break-all text-xs text-slate-500">Loan ID: {formatLoanDisplayId(statement.kanaku_number)}</p><p className="text-sm">Total {money(Number(statement.total_amount))} · Paid {money(Number(statement.paid_amount))} · Balance {money(Number(statement.outstanding))}</p>
      {Number(statement.legacy_paid_amount) > 0 && <p className="text-xs">Preserved opening paid amount: {money(Number(statement.legacy_paid_amount))}</p>}{statementError && <p role="alert" className="text-sm text-red-700">{statementError}</p>}{statementLoading ? <p role="status">Loading statement…</p> : receipts.length ? receipts.map(receipt => <div key={receipt.payment_id} className="rounded-lg bg-slate-50 p-3 text-sm"><p>{date(receipt.payment_date)} · {money(Number(receipt.amount))} · {receipt.payment_method}</p><p className="break-all text-xs text-slate-500">Receipt: {receipt.payment_id}</p></div>) : <p className="text-sm text-slate-500">No linked receipts.</p>}
      {!readOnly && statement.cycle_number === current && Number(statement.outstanding) > 0 && <div className="flex flex-wrap items-end gap-2"><label className="text-xs">Received amount (Cash)<input aria-label="Kanaku received amount" value={payment} onChange={event => setPayment(event.target.value)} inputMode="decimal" className={field} /></label><button disabled={saving || statementLoading} className={button} onClick={receive}>{saving ? 'Saving…' : 'Save Payment'}</button></div>}
    </section>}
  </section>
}
