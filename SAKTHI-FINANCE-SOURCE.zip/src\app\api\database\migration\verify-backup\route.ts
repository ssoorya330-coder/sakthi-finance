import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { verifyBackupArchive } from '@/server/storage'

/**
 * STEP 2 (verify) — Confirm a backup archive is actually readable
 * (pg_restore --list) before migration proceeds.
 */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const backupId = (body.backup_id || '').trim()
    if (!backupId) return NextResponse.json({ error: 'Backup is required.' }, { status: 400 })
    const rec = await dbQuery('SELECT * FROM backup_records WHERE id = $1 LIMIT 1', [backupId])
    if (rec.rows.length === 0) {
      return NextResponse.json({ ok: false, error: 'Backup record not found.' }, { status: 200 })
    }
    const row = rec.rows[0]
    if (row.status !== 'Successful') {
      return NextResponse.json({ ok: false, error: 'Backup did not complete successfully.' }, { status: 200 })
    }
    const result = await verifyBackupArchive(row.path)
    return NextResponse.json({
      ok: result.ok,
      entries: result.entries,
      message: result.message,
      filename: row.filename,
      sizeBytes: Number(row.size_bytes) || 0,
      createdAt: row.created_at,
    })
  } catch (err: any) {
    return NextResponse.json(
      { ok: false, error: 'Backup verification failed', details: err.message },
      { status: 500 }
    )
  }
}
