import 'dotenv/config'
import { dbQuery } from '../src/server/database'

const linked = await dbQuery('SELECT COUNT(*)::int AS n FROM users WHERE supabase_user_id IS NOT NULL')
console.log('users with supabase_user_id:', linked.rows[0].n)
const total = await dbQuery('SELECT COUNT(*)::int AS n FROM users')
console.log('total users:', total.rows[0].n)
process.exit(0)
