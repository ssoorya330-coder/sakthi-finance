import { NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { AUDIT_CUSTOMER_CODE } from '@/server/audit-query'

export const dynamic = 'force-dynamic'

const CUSTOMER_ACTIONS = ['CUSTOMER_CREATED', 'CUSTOMER_UPDATED', 'CUSTOMER_STATUS_CHANGED', 'CUSTOMER_DELETED', 'CUSTOMER_ARCHIVED', 'CUSTOMER_RESTORED']
const LOAN_ACTIONS = ['LOAN_CREATED', 'LOAN_UPDATED', 'LOAN_STATUS_CHANGED', 'LOAN_COMPLETED', 'LOAN_REOPENED', 'LOAN_CANCELLED', 'LOAN_DELETED']
const PAYMENT_ACTIONS = ['PAYMENT_RECORDED', 'PAYMENT_UPDATED', 'PAYMENT_CORRECTED', 'PAYMENT_REVERSED', 'PAYMENT_DELETED']

/** Dashboard aggregates — all computed in PostgreSQL, never in the browser. */
export async function GET() {
  const auth = await requireAuthWithPermission('audit:read')
  if (auth.error) return auth.error

  try {
    const [total, today, byCat, failed] = await Promise.all([
      dbQuery(`SELECT COUNT(*) AS c FROM audit_events`),
      dbQuery(`SELECT COUNT(*) AS c FROM audit_events WHERE created_at >= CURRENT_DATE`),
      dbQuery(
        `SELECT
           COUNT(*) FILTER (WHERE action = ANY($1)) AS customer,
           COUNT(*) FILTER (WHERE action = ANY($2)) AS loan,
           COUNT(*) FILTER (WHERE action = ANY($3)) AS payment,
           COUNT(*) FILTER (WHERE entity_type IN ('user','auth','system','settings','storage','database','backup')) AS system
         FROM audit_events`,
        [CUSTOMER_ACTIONS, LOAN_ACTIONS, PAYMENT_ACTIONS]
      ),
      dbQuery(`SELECT COUNT(*) AS c FROM audit_events WHERE result <> 'SUCCESS'`),
    ])
    const recent = await dbQuery(
      `SELECT seq, audit_id, created_at, action, entity_type, entity_id, customer_id,
              loan_id, payment_id, performed_by, result, changes, ${AUDIT_CUSTOMER_CODE} AS customer_code
       FROM audit_events ORDER BY seq DESC LIMIT 8`
    )
    return NextResponse.json({
      total: Number(total.rows[0]?.c) || 0,
      today: Number(today.rows[0]?.c) || 0,
      customer: Number(byCat.rows[0]?.customer) || 0,
      loan: Number(byCat.rows[0]?.loan) || 0,
      payment: Number(byCat.rows[0]?.payment) || 0,
      system: Number(byCat.rows[0]?.system) || 0,
      failed: Number(failed.rows[0]?.c) || 0,
      recent: recent.rows,
    })
  } catch (err: any) {
    console.error('[GET /api/audit/summary] Error:', err.message)
    return NextResponse.json({ error: 'Failed to load audit summary' }, { status: 500 })
  }
}
