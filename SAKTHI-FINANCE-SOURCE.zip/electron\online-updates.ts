import type { AppUpdater, UpdateInfo, ProgressInfo } from 'electron-updater'
import { newerVersion } from './updates'

export const UPDATE_URL = 'https://strixg16.tailb58398.ts.net'
export type OnlineUpdatePhase = 'idle' | 'checking' | 'available' | 'current' | 'downloading' | 'ready' | 'offline' | 'error' | 'installing' | 'development'
export interface OnlineUpdateStatus {
  currentVersion: string
  phase: OnlineUpdatePhase
  version?: string
  lastCheck?: string
  percent: number
  transferred: number
  total: number
  bytesPerSecond: number
  message: string
}
type Updater = Pick<AppUpdater, 'on' | 'autoDownload' | 'autoInstallOnAppQuit' | 'allowDowngrade' | 'allowPrerelease' | 'disableWebInstaller' | 'setFeedURL' | 'checkForUpdates' | 'downloadUpdate'> & { quitAndInstall(silent?: boolean, forceRunAfter?: boolean): void }

/** Main-process controller. The renderer cannot supply URLs, versions or installer paths. */
export class OnlineUpdates {
  private state: OnlineUpdateStatus
  private busy = false
  private pendingInstall = false
  private lastProgressLog = -1
  private startupTimer?: ReturnType<typeof setTimeout>
  constructor(private updater: Updater, private packaged: boolean, version: string,
    private publish: (state: OnlineUpdateStatus) => void,
    private log: (event: string, detail?: string | number) => void) {
    this.state = { currentVersion: version, phase: packaged ? 'idle' : 'development', percent: 0, transferred: 0, total: 0, bytesPerSecond: 0,
      message: packaged ? 'Updates are checked automatically when the app starts.' : 'Automatic updates are available in the installed app.' }
    updater.autoDownload = false
    updater.autoInstallOnAppQuit = false
    updater.allowDowngrade = false
    updater.allowPrerelease = false
    updater.disableWebInstaller = true
    if (!packaged) return
    updater.setFeedURL({provider: 'generic', url: UPDATE_URL, useMultipleRangeRequest: false})
    updater.on('checking-for-update', () => this.set({phase: 'checking', message: 'Checking for updates…'}))
    updater.on('update-available', (info: UpdateInfo) => {
      if (!this.validRelease(info)) { this.fail(Error('INVALID_UPDATE_METADATA')); return }
      this.log('update_available', info.version)
      this.set({phase: 'available', version: info.version, percent: 0, message: 'New Update Available'})
    })
    updater.on('update-not-available', () => this.set({phase: 'current', version: undefined, message: 'Sakthi Finance is up to date.'}))
    updater.on('download-progress', (progress: ProgressInfo) => {
      if (this.state.phase !== 'downloading') return
      const percent = Math.max(0, Math.min(100, Number.isFinite(progress.percent) ? progress.percent : 0))
      this.set({percent, transferred: Math.max(0, progress.transferred), total: Math.max(0, progress.total), bytesPerSecond: Math.max(0, progress.bytesPerSecond)})
      const bucket = Math.floor(percent / 10)
      if (bucket !== this.lastProgressLog) { this.lastProgressLog = bucket; this.log('download_progress', Math.floor(percent)) }
    })
    updater.on('update-downloaded', (info: UpdateInfo) => {
      if (!this.validRelease(info) || info.version !== this.state.version) { this.fail(Error('INVALID_UPDATE_METADATA')); return }
      this.log('download_completed', info.version)
      this.set({phase: 'ready', percent: 100, transferred: this.state.total, message: 'Update Ready. Save your work before restarting.'})
    })
    updater.on('error', (error: Error) => this.fail(error))
  }
  status() { return {...this.state} }
  private set(next: Partial<OnlineUpdateStatus>) { this.state = {...this.state, ...next}; this.publish(this.status()) }
  private validRelease(info: UpdateInfo) {
    return newerVersion(info.version, this.state.currentVersion) && Array.isArray(info.files) && info.files.length > 0 && info.files.every(file =>
      /^[A-Za-z0-9 _.-]+\.exe$/.test(file.url) && !file.url.includes('..') && /^[A-Za-z0-9+/]{86}==$/.test(file.sha512) &&
      typeof file.size === 'number' && file.size > 0 && file.size <= 1024 * 1024 * 1024)
  }
  private fail(error: unknown) {
    // Never forward or log raw library errors: URLs, local paths and headers may be included.
    const message = error instanceof Error ? error.message : ''
    const offline = /ENOTFOUND|EAI_AGAIN|ENETUNREACH|ECONNREFUSED|ETIMEDOUT|ERR_INTERNET_DISCONNECTED|ERR_NAME_NOT_RESOLVED|ERR_CONNECTION|network/i.test(message)
    this.log(offline ? 'update_network_unavailable' : 'update_failed')
    this.set({phase: offline ? 'offline' : 'error', message: offline ? 'Unable to reach the update server. You can continue using Sakthi Finance.' : 'Unable to complete the update. You can continue using Sakthi Finance and try again.'})
  }
  start() {
    if (!this.packaged || this.startupTimer) return
    this.startupTimer = setTimeout(() => { this.startupTimer = undefined; void this.check() }, 4000)
    this.startupTimer.unref?.()
  }
  stop() { clearTimeout(this.startupTimer); this.startupTimer = undefined }
  async check() {
    if (!this.packaged || this.busy || ['ready', 'installing', 'downloading'].includes(this.state.phase)) return this.status()
    this.busy = true
    this.log('update_check_started', this.state.currentVersion); this.log('update_server', UPDATE_URL)
    this.set({phase: 'checking', version: undefined, lastCheck: new Date().toISOString(), message: 'Checking for updates…'})
    try { await this.updater.checkForUpdates() } catch (error) { this.fail(error) }
    finally { this.busy = false }
    return this.status()
  }
  async download() {
    if (!this.packaged || this.busy || this.state.phase !== 'available') return this.status()
    this.busy = true; this.lastProgressLog = -1
    this.set({phase: 'downloading', percent: 0, transferred: 0, total: 0, message: 'Downloading Update'})
    try { await this.updater.downloadUpdate() } catch (error) { this.fail(error) }
    finally { this.busy = false }
    return this.status()
  }
  prepareInstall() {
    if (!this.packaged || this.busy || this.state.phase !== 'ready' || !this.state.version || !newerVersion(this.state.version, this.state.currentVersion)) throw Error('Downloaded update required')
    this.pendingInstall = true
    this.log('installation_requested', this.state.version)
    this.set({phase: 'installing', message: 'Restarting safely to apply the update…'})
  }
  /** Called only after the application's database/voice shutdown has finished. */
  installAfterShutdown() {
    if (!this.pendingInstall) return false
    this.pendingInstall = false
    this.updater.quitAndInstall(true, true)
    if (this.state.phase === 'error' || this.state.phase === 'offline') throw Error('Installer could not start')
    return true
  }
}
