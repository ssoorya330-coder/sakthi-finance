'use client'

import { cn } from '@/lib/utils'
import { motion } from 'framer-motion'


type LogoVariant = 'circular' | 'shield' | 'growth' | 'monogram'
type LogoSize = 'sm' | 'md' | 'lg' | 'xl'

interface LogoProps {
  variant?: LogoVariant
  size?: LogoSize
  showText?: boolean
  animated?: boolean
  className?: string
}

const sizeMap: Record<LogoSize, { icon: number; text: string }> = {
  sm: { icon: 24, text: 'text-lg' },
  md: { icon: 32, text: 'text-xl' },
  lg: { icon: 48, text: 'text-2xl' },
  xl: { icon: 64, text: 'text-4xl' },
}

function CircularGoldS({ size }: { size: LogoSize }) {
  const s = sizeMap[size].icon
  return (
    <svg width={s} height={s} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="32" r="30" stroke="url(#circular-gold)" strokeWidth="2.5" fill="none" />
      <circle cx="32" cy="32" r="30" stroke="url(#circular-glow)" strokeWidth="2.5" fill="none" opacity="0.3" />
      <text x="32" y="40" textAnchor="middle" fill="url(#circular-gold)" fontSize="28" fontWeight="700" fontFamily="Georgia, serif">S</text>
      <defs>
        <linearGradient id="circular-gold" x1="0" y1="0" x2="64" y2="64">
          <stop offset="0%" stopColor="#E8C15A" />
          <stop offset="50%" stopColor="#F5D77A" />
          <stop offset="100%" stopColor="#D4A94A" />
        </linearGradient>
        <radialGradient id="circular-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#E8C15A" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#E8C15A" stopOpacity="0" />
        </radialGradient>
      </defs>
    </svg>
  )
}

function ShieldS({ size }: { size: LogoSize }) {
  const s = sizeMap[size].icon
  return (
    <svg width={s} height={s} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M32 4L8 16V32C8 46.4 18.4 59.2 32 64C45.6 59.2 56 46.4 56 32V16L32 4Z" fill="url(#shield-gold)" opacity="0.15" />
      <path d="M32 4L8 16V32C8 46.4 18.4 59.2 32 64C45.6 59.2 56 46.4 56 32V16L32 4Z" stroke="url(#shield-gold)" strokeWidth="2" fill="none" />
      <text x="32" y="38" textAnchor="middle" fill="url(#shield-gold)" fontSize="20" fontWeight="700" fontFamily="Georgia, serif">S</text>
      <defs>
        <linearGradient id="shield-gold" x1="0" y1="0" x2="64" y2="64">
          <stop offset="0%" stopColor="#E8C15A" />
          <stop offset="50%" stopColor="#F5D77A" />
          <stop offset="100%" stopColor="#D4A94A" />
        </linearGradient>
      </defs>
    </svg>
  )
}

function GrowthS({ size }: { size: LogoSize }) {
  const s = sizeMap[size].icon
  return (
    <svg width={s} height={s} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="32" r="30" stroke="url(#growth-gold)" strokeWidth="1.5" fill="none" opacity="0.3" />
      <path d="M32 52V20M32 20L22 30M32 20L42 30" stroke="url(#growth-gold)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="32" cy="32" r="4" fill="url(#growth-gold)" />
      <defs>
        <linearGradient id="growth-gold" x1="0" y1="0" x2="64" y2="64">
          <stop offset="0%" stopColor="#E8C15A" />
          <stop offset="100%" stopColor="#F5D77A" />
        </linearGradient>
      </defs>
    </svg>
  )
}

function MonogramS({ size }: { size: LogoSize }) {
  const s = sizeMap[size].icon
  return (
    <svg width={s} height={s} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="4" y="4" width="56" height="56" rx="14" stroke="url(#monogram-gold)" strokeWidth="2" fill="url(#monogram-bg)" />
      <text x="32" y="40" textAnchor="middle" fill="url(#monogram-gold)" fontSize="24" fontWeight="700" fontFamily="Georgia, serif">S</text>
      <defs>
        <linearGradient id="monogram-gold" x1="0" y1="0" x2="64" y2="64">
          <stop offset="0%" stopColor="#E8C15A" />
          <stop offset="50%" stopColor="#F5D77A" />
          <stop offset="100%" stopColor="#D4A94A" />
        </linearGradient>
        <linearGradient id="monogram-bg" x1="0" y1="0" x2="64" y2="64">
          <stop offset="0%" stopColor="rgba(232,193,90,0.08)" />
          <stop offset="100%" stopColor="rgba(232,193,90,0.02)" />
        </linearGradient>
      </defs>
    </svg>
  )
}

export function Logo({
  variant = 'circular',
  size = 'md',
  showText = true,
  animated,
  className,
}: LogoProps) {
  const logoComponents = {
    circular: CircularGoldS,
    shield: ShieldS,
    growth: GrowthS,
    monogram: MonogramS,
  }

  const LogoIcon = logoComponents[variant]

  const content = (
    <div className={cn('flex items-center gap-3', className)}>
      <div className="relative">
        {animated && (
          <motion.div
            className="absolute inset-0 rounded-full"
            animate={{
              boxShadow: [
                '0 0 20px rgba(232,193,90,0.2)',
                '0 0 40px rgba(232,193,90,0.4)',
                '0 0 20px rgba(232,193,90,0.2)',
              ],
            }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          />
        )}
        <LogoIcon size={size} />
      </div>
      {showText && (
        <div className="flex flex-col leading-tight">
          <span
            className={cn(
              'font-bold tracking-wide',
              sizeMap[size].text,
              variant === 'circular' || variant === 'monogram'
                ? 'bg-gradient-to-r from-gold-300 to-gold-200 bg-clip-text text-transparent'
                : 'text-white'
            )}
          >
            SAKTHI
          </span>
          <span className="text-[11px] tracking-[0.2em] uppercase text-text-muted font-medium">
            Finance
          </span>
        </div>
      )}
    </div>
  )

  if (animated) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      >
        {content}
      </motion.div>
    )
  }

  return content
}
