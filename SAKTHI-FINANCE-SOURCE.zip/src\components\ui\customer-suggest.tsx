'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { Search, User, Phone, MapPin, Briefcase } from 'lucide-react'

interface SuggestCustomer {
  customer_code: string
  full_name: string
  phone_number: string | null
  alternate_phone: string | null
  address: string | null
  area: string | null
  city: string | null
  business: string | null
}

interface CustomerSuggestProps {
  onSelect: (customer: SuggestCustomer) => void
  placeholder?: string
  disabled?: boolean
}

export default function CustomerSuggest({ onSelect, placeholder = 'Type to search existing customers...', disabled }: CustomerSuggestProps) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SuggestCustomer[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [highlightIndex, setHighlightIndex] = useState(-1)
  const containerRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const abortRef = useRef<AbortController | null>(null)

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const searchCustomers = useCallback(async (q: string) => {
    if (q.length < 2) {
      setResults([])
      setIsOpen(false)
      return
    }

    // Cancel previous request
    if (abortRef.current) {
      abortRef.current.abort()
    }
    abortRef.current = new AbortController()

    setLoading(true)
    try {
      const res = await fetch(`/api/customers/suggest?q=${encodeURIComponent(q)}`, {
        credentials: 'include',
        signal: abortRef.current.signal,
      })
      if (res.ok) {
        const data = await res.json()
        setResults(data.customers || [])
        setIsOpen(true)
        setHighlightIndex(-1)
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error('Search failed:', err)
      }
    } finally {
      setLoading(false)
    }
  }, [])

  const handleInputChange = useCallback((value: string) => {
    setQuery(value)

    // Debounce
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      searchCustomers(value)
    }, 250)
  }, [searchCustomers])

  const handleSelect = useCallback((customer: SuggestCustomer) => {
    onSelect(customer)
    setQuery('')
    setResults([])
    setIsOpen(false)
  }, [onSelect])

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (!isOpen || results.length === 0) return

    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setHighlightIndex((prev) => (prev < results.length - 1 ? prev + 1 : 0))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setHighlightIndex((prev) => (prev > 0 ? prev - 1 : results.length - 1))
    } else if (e.key === 'Enter' && highlightIndex >= 0) {
      e.preventDefault()
      handleSelect(results[highlightIndex])
    } else if (e.key === 'Escape') {
      setIsOpen(false)
      setHighlightIndex(-1)
    }
  }, [isOpen, results, highlightIndex, handleSelect])

  // Scroll highlighted item into view
  useEffect(() => {
    if (highlightIndex >= 0 && dropdownRef.current) {
      const items = dropdownRef.current.querySelectorAll('[data-suggest-item]')
      items[highlightIndex]?.scrollIntoView({ block: 'nearest' })
    }
  }, [highlightIndex])

  return (
    <div ref={containerRef} className="relative">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9A9AA2]" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => handleInputChange(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => results.length > 0 && setIsOpen(true)}
          placeholder={placeholder}
          disabled={disabled}
          className="w-full pl-10 pr-4 py-2.5 rounded-[14px] border border-[#E8E5E0] bg-white text-sm text-[var(--text-primary)] placeholder-[#9A9AA2] focus:outline-none focus:ring-2 focus:ring-[var(--secondary)]/50 focus:border-[var(--secondary)] disabled:opacity-50"
        />
        {loading && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2">
            <div className="w-4 h-4 border-2 border-[var(--secondary)]/30 border-t-[var(--secondary)] rounded-full animate-spin" />
          </div>
        )}
      </div>

      {/* Results dropdown */}
      {isOpen && results.length > 0 && (
        <div
          ref={dropdownRef}
          className="absolute z-50 left-0 right-0 mt-2 bg-white rounded-[16px] shadow-[0_12px_40px_rgba(0,0,0,0.12)] border border-[#E8E5E0] overflow-hidden"
          style={{ maxHeight: '400px', overflowY: 'auto' }}
        >
          <div className="px-3 py-2 border-b border-[#E8E5E0] bg-[var(--background)]">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-[#9A9AA2]">
              Existing Customers ({results.length})
            </p>
          </div>
          {results.map((customer, idx) => (
            <button
              key={customer.customer_code}
              data-suggest-item
              onClick={() => handleSelect(customer)}
              className={`w-full text-left px-4 py-3 border-b border-[#E8E5E0]/50 last:border-0 transition-colors ${
                idx === highlightIndex ? 'bg-[var(--background)]' : 'hover:bg-[var(--background)]/50'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[var(--primary)] to-[var(--secondary)] flex items-center justify-center text-white font-semibold text-xs flex-shrink-0 mt-0.5">
                  {customer.full_name?.charAt(0)?.toUpperCase() || '?'}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-sm text-[var(--text-primary)] truncate">{customer.full_name}</p>
                    <span className="text-[10px] font-mono text-[#9A9AA2] bg-[var(--background)] px-1.5 py-0.5 rounded">{customer.customer_code}</span>
                  </div>
                  <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1">
                    {customer.phone_number && (
                      <span className="flex items-center gap-1 text-xs text-[#6A6A72]">
                        <Phone className="w-3 h-3" /> {customer.phone_number}
                      </span>
                    )}
                    {customer.alternate_phone && (
                      <span className="flex items-center gap-1 text-xs text-[#6A6A72]">
                        Alt: {customer.alternate_phone}
                      </span>
                    )}
                  </div>
                  {(customer.address || customer.area || customer.city) && (
                    <div className="flex items-center gap-1 text-xs text-[#9A9AA2] mt-0.5">
                      <MapPin className="w-3 h-3 flex-shrink-0" />
                      <span className="truncate">
                        {[customer.address, customer.area, customer.city].filter(Boolean).join(', ')}
                      </span>
                    </div>
                  )}
                  {customer.business && (
                    <div className="flex items-center gap-1 text-xs text-[#9A9AA2] mt-0.5">
                      <Briefcase className="w-3 h-3 flex-shrink-0" />
                      <span className="truncate">{customer.business}</span>
                    </div>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      {isOpen && query.length >= 2 && results.length === 0 && !loading && (
        <div className="absolute z-50 left-0 right-0 mt-2 bg-white rounded-[16px] shadow-[0_12px_40px_rgba(0,0,0,0.12)] border border-[#E8E5E0] p-6 text-center">
          <User className="w-8 h-8 text-[var(--secondary)]/40 mx-auto mb-2" />
          <p className="text-sm text-[#6A6A72]">No existing customer found.</p>
          <p className="text-xs text-[#9A9AA2] mt-1">You can continue creating a new customer.</p>
        </div>
      )}
    </div>
  )
}
