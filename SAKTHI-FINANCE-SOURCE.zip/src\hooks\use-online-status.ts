'use client';

import { useState, useEffect, useCallback, useRef } from 'react';

interface OnlineStatus {
  isOnline: boolean;
  wasOffline: boolean;
}

export function useOnlineStatus(): OnlineStatus {
  const [isOnline, setIsOnline] = useState(true);
  const [wasOffline, setWasOffline] = useState(false);
  const wasPreviouslyOffline = useRef(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleOnline = () => {
      setIsOnline(true);
      if (wasPreviouslyOffline.current) {
        setWasOffline(true);
      }
      if (process.env.NODE_ENV === 'development') {
        console.log('[useOnlineStatus] Connection restored');
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      wasPreviouslyOffline.current = true;
      if (process.env.NODE_ENV === 'development') {
        console.log('[useOnlineStatus] Connection lost');
      }
    };

    setIsOnline(navigator.onLine);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const resetWasOffline = useCallback(() => {
    setWasOffline(false);
  }, []);

  return { isOnline, wasOffline };
}
