import fs from 'fs'
import path from 'path'
import { NextRequest, NextResponse } from 'next/server'
import { requireAuth, requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { validateStoragePath, validPurposes, getDiskUsageForPath, dirSizeBytes } from '@/server/storage'
import { actorFromAuthUser, requestMeta, recordAuditStandalone } from '@/server/audit'

const MAX_ALLOCATIONS: Record<string, number | null> = {
  '10 GB': 10 * 1024 ** 3,
  '25 GB': 25 * 1024 ** 3,
  '50 GB': 50 * 1024 ** 3,
  '100 GB': 100 * 1024 ** 3,
}

function withLiveUsage(row: any) {
  const usage = getDiskUsageForPath(row.path)
  let folderBytes: number | null = null
  try {
    if (fs.existsSync(row.path)) folderBytes = dirSizeBytes(row.path)
  } catch {}
  return {
    id: row.id,
    name: row.name,
    path: row.path,
    drive: row.drive,
    type: row.type,
    purpose: row.purpose,
    maxBytes: row.max_bytes !== null ? Number(row.max_bytes) : null,
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    lastUsedAt: row.last_used_at,
    driveTotalBytes: usage?.totalBytes ?? null,
    driveFreeBytes: usage?.freeBytes ?? null,
    driveUsedBytes: usage?.usedBytes ?? null,
    folderBytes,
    reachable: usage !== null,
  }
}

export async function GET() {
  const auth = await requireAuth()
  if (auth.error) return auth.error
  try {
    const result = await dbQuery(
      'SELECT * FROM storage_locations ORDER BY created_at ASC'
    )
    return NextResponse.json({ locations: result.rows.map(withLiveUsage) })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to load storage locations', details: err.message },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const name = (body.name || '').trim()
    const purpose = (body.purpose || 'Database Backups').trim()
    const allocation = body.allocation || 'Use Available Space'

    if (!name) return NextResponse.json({ error: 'Storage name is required.' }, { status: 400 })
    if (name.length > 120) return NextResponse.json({ error: 'Storage name is too long.' }, { status: 400 })
    if (!validPurposes().includes(purpose)) {
      return NextResponse.json({ error: 'Invalid storage purpose.' }, { status: 400 })
    }

    const check = await validateStoragePath(body.path || '')
    if (!check.ok) return NextResponse.json({ error: check.error }, { status: 400 })
    const normalizedPath = check.normalizedPath as string

    // Duplicate (case-insensitive — Windows paths).
    const dup = await dbQuery('SELECT id FROM storage_locations WHERE LOWER(path) = LOWER($1) LIMIT 1', [
      normalizedPath,
    ])
    if (dup.rows.length > 0) {
      return NextResponse.json({ error: 'This location is already configured.' }, { status: 409 })
    }

    let maxBytes: number | null = null
    if (allocation !== 'Use Available Space') {
      maxBytes = MAX_ALLOCATIONS[allocation] ?? null
      if (maxBytes === null && allocation !== 'Use Available Space') {
        return NextResponse.json({ error: 'Invalid storage allocation.' }, { status: 400 })
      }
      if (maxBytes !== null && (check.freeBytes ?? null) !== null && maxBytes > (check.freeBytes as number)) {
        return NextResponse.json(
          { error: 'Insufficient free space on this drive for the selected allocation.' },
          { status: 400 }
        )
      }
    }

    // Create folder structure: root + Backups subfolder.
    try {
      fs.mkdirSync(normalizedPath, { recursive: true })
      fs.mkdirSync(path.join(normalizedPath, 'Backups'), { recursive: true })
      fs.accessSync(normalizedPath, fs.constants.W_OK)
    } catch {
      return NextResponse.json(
        { error: 'Could not create or write to this folder. Check permissions.' },
        { status: 400 }
      )
    }

    try {
      const inserted = await dbQuery(
        `INSERT INTO storage_locations (name, path, drive, type, purpose, max_bytes, status)
         VALUES ($1, $2, $3, 'LOCAL', $4, $5, 'Active') RETURNING *`,
        [name, normalizedPath, check.drive, purpose, maxBytes]
      )
      await dbQuery(
        "INSERT INTO audit_logs (action, entity_type, entity_id, details, user_id) VALUES ('create', 'storage', $1, $2, $3)",
        [inserted.rows[0].id, JSON.stringify({ name, path: normalizedPath }), auth.user.userId]
      ).catch(() => {})
      {
        const meta = requestMeta(request)
        await recordAuditStandalone({
          action: 'STORAGE_LOCATION_CREATED',
          entityType: 'storage',
          entityId: inserted.rows[0].id,
          actor: actorFromAuthUser(auth.user),
          ipAddress: meta.ip,
          clientInfo: meta.client,
          result: 'SUCCESS',
          changes: [
            { field: 'name', label: 'Name', before: null, after: name },
            { field: 'path', label: 'Path', before: null, after: normalizedPath },
            { field: 'purpose', label: 'Purpose', before: null, after: purpose },
          ],
        })
      }
      return NextResponse.json({ location: withLiveUsage(inserted.rows[0]) }, { status: 201 })
    } catch (err: any) {
      if (err?.code === '23505') {
        return NextResponse.json({ error: 'This location is already configured.' }, { status: 409 })
      }
      throw err
    }
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to configure storage', details: err.message },
      { status: 500 }
    )
  }
}
