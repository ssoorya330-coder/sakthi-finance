'use client'

import NextLink from 'next/link'
import { forwardRef } from 'react'
import { cn } from '@/lib/utils'

interface LinkProps extends React.ComponentPropsWithoutRef<typeof NextLink> {
  children: React.ReactNode
}

const Link = forwardRef<HTMLAnchorElement, LinkProps>(
  ({ className, children, ...props }, ref) => (
    <NextLink
      ref={ref}
      className={cn(
        'text-gold-400 hover:text-gold-300 transition-colors duration-200',
        'text-[14px] font-medium',
        className
      )}
      {...props}
    >
      {children}
    </NextLink>
  )
)

Link.displayName = 'Link'

export { Link }
