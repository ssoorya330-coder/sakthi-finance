const {app,BrowserWindow}=require('electron')
const path=require('node:path'),fs=require('node:fs')
app.setPath('userData',path.resolve('test-reports/appearance-ui-profile'))
app.whenReady().then(async()=>{
  const window=new BrowserWindow({show:false,webPreferences:{contextIsolation:true,nodeIntegration:false,sandbox:true}})
  let report
  try{
    await window.loadURL('file://'+path.resolve('test-reports/voice-ui.html').replaceAll('\\','/'))
    const cssRoot=path.resolve('out-desktop-build/_next/static/chunks')
    for(const name of fs.readdirSync(cssRoot).filter(n=>n.endsWith('.css'))) await window.webContents.insertCSS(fs.readFileSync(path.join(cssRoot,name),'utf8'))
    await window.webContents.executeJavaScript(fs.readFileSync('test-reports/appearance-ui-bundle.js','utf8'))
    report={date:new Date().toISOString(),status:'PASS',passed:await window.webContents.executeJavaScript('window.runAppearanceChecks()'),scope:'Real React provider and Appearance UI in isolated Electron; no finance data'}
  }catch(error){report={date:new Date().toISOString(),status:'FAIL',error:String(error)}}
  fs.writeFileSync('test-reports/APPEARANCE_1.0.9_TEST.json',JSON.stringify(report,null,2))
  window.destroy();app.exit(report.status==='PASS'?0:1)
})
