using System;
using System.Linq;
using System.Text;
using System.Threading;
using System.Speech.Recognition;
using System.Web.Script.Serialization;

// Local Windows dictation. Audio is never saved or sent to a network service.
class SpeechHost {
    static readonly object OutputLock = new object();
    static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
    static void Emit(object value) { lock (OutputLock) { Console.WriteLine(Json.Serialize(value)); Console.Out.Flush(); } }
    static int Main(string[] args) {
        Console.OutputEncoding = new UTF8Encoding(false);
        try {
            var engines = SpeechRecognitionEngine.InstalledRecognizers();
            if (args.Length == 1 && args[0] == "--list") { Emit(new { languages = engines.Select(e => e.Culture.Name).ToArray() }); return 0; }
            string language = args.Length > 0 ? args[0] : "en-IN";
            var selected = engines.FirstOrDefault(e => e.Culture.Name.Equals(language, StringComparison.OrdinalIgnoreCase));
            // Only use a dialect of the SAME language, never another language.
            if (selected == null) selected = engines.FirstOrDefault(e => e.Culture.TwoLetterISOLanguageName.Equals(language.Split('-')[0], StringComparison.OrdinalIgnoreCase));
            if (selected == null) { Emit(new { type = "error", error = "language-not-supported" }); return 2; }
            using (var engine = new SpeechRecognitionEngine(selected))
            using (var completed = new ManualResetEvent(false)) {
                var dictation = new DictationGrammar();
                engine.LoadGrammar(dictation);
                if (args.Contains("--context")) {
                    var phrases = Json.Deserialize<string[]>(Console.ReadLine() ?? "[]");
                    if (phrases != null && phrases.Length > 0) {
                        var alternatives = phrases.Select(p => new GrammarBuilder(new SemanticResultValue(p, p))).ToList();
                        if (phrases.Any(p => p.Equals("Soorya", StringComparison.OrdinalIgnoreCase))) {
                            alternatives.Add(new GrammarBuilder(new SemanticResultValue("Surya", "Soorya")));
                            alternatives.Add(new GrammarBuilder(new SemanticResultValue("soar ya", "Soorya")));
                        }
                        var builder = new GrammarBuilder(new Choices(alternatives.ToArray()));
                        builder.Culture = selected.Culture;
                        var names = new Grammar(builder); names.Name = "Customer names"; names.Priority = 1;
                        engine.LoadGrammar(names);
                        dictation.Weight = 0.2f;
                    }
                }
                engine.InitialSilenceTimeout = TimeSpan.FromSeconds(12);
                engine.BabbleTimeout = TimeSpan.FromSeconds(15);
                engine.EndSilenceTimeout = TimeSpan.FromMilliseconds(900);
                engine.EndSilenceTimeoutAmbiguous = TimeSpan.FromMilliseconds(1500);
                // File input is for deterministic QA only; IPC never accepts a file path.
                int waveIndex = Array.IndexOf(args, "--wave");
                bool fixture = waveIndex >= 0 && args.Length > waveIndex + 1;
                if (fixture) engine.SetInputToWaveFile(args[waveIndex + 1]); else engine.SetInputToDefaultAudioDevice();
                // Do not commit uncertain hypotheses as final names on timeout.
                engine.SpeechRecognized += (s,e) => {
                    if (fixture) Emit(new { type = "qa-confidence", confidence = e.Result.Confidence, grammar = e.Result.Grammar.Name, text = e.Result.Text });
                    if (e.Result.Confidence < 0.35f) { Emit(new { type = "error", error = "low-confidence" }); engine.RecognizeAsyncStop(); }
                    else Emit(new { type = "result", text = e.Result.Grammar.Name == "Customer names" && e.Result.Semantics.Value is string ? (string)e.Result.Semantics.Value : e.Result.Text });
                };
                engine.RecognizeCompleted += (s,e) => { if (e.Error != null) Emit(new { type = "error", error = "audio-capture" }); completed.Set(); };
                engine.RecognizeAsync(RecognizeMode.Multiple);
                Emit(new { type = "ready", language = selected.Culture.Name });
                var input = new Thread(() => {
                    try {
                        var command = Console.ReadLine();
                        if (command == "stop") engine.RecognizeAsyncStop();
                        else engine.RecognizeAsyncCancel();
                    } catch { }
                });
                if (!fixture) { input.IsBackground = true; input.Start(); }
                if (!completed.WaitOne(TimeSpan.FromSeconds(60))) { engine.RecognizeAsyncStop(); completed.WaitOne(1500); }
                Emit(new { type = "end" });
            }
            return 0;
        } catch (UnauthorizedAccessException) { Emit(new { type = "error", error = "not-allowed" }); return 3; }
        catch { Emit(new { type = "error", error = "audio-capture" }); return 4; }
    }
}
