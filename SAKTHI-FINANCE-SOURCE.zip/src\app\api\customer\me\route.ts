import { NextResponse } from 'next/server';
import { requireAuth } from '@/lib/api-utils';
import { dbQuery } from '@/server/database';
import { getPersonGroup } from '@/lib/customer-group';

export const dynamic = 'force-dynamic';

/**
 * Customer self-service snapshot. The person is resolved EXCLUSIVELY from
 * the authenticated session's linked customers.id (users.customer_id) —
 * this endpoint accepts no customer identifier of any kind, so IDOR by
 * URL/body tampering is structurally impossible.
 *
 * Person grouping: all kanaku rows sharing the linked row's normalized
 * phone AND normalized name belong to the same person and are served
 * together (loans, payments, per-kanaku breakdown).
 */
export async function GET() {
  const auth = await requireAuth();
  if (auth.error) return auth.error;
  if (auth.user.role !== 'customer') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }
  const customerId = auth.user.customerId || null;
  if (!customerId) {
    return NextResponse.json(
      { error: 'No customer account is linked yet.', code: 'not_linked' },
      { status: 404 }
    );
  }

  try {
    const group = await getPersonGroup(customerId);
    if (!group) {
      return NextResponse.json({ error: 'Customer account not found.' }, { status: 404 });
    }
    const { groupIds, accounts } = group;
    const p = (
      await dbQuery(
        `SELECT c.id, c.customer_code, c.full_name, c.phone_number, c.address,
                rc.name AS city_name, ra.name AS area_name, rb.name AS business_name,
                c.status, c.created_at
         FROM customers c
         LEFT JOIN ref_city rc ON rc.id = c.city_id
         LEFT JOIN ref_area ra ON ra.id = c.area_id
         LEFT JOIN ref_business rb ON rb.id = c.business_id
         WHERE c.id = $1 LIMIT 1`,
        [group.primaryId]
      )
    ).rows[0] as any;
    const [loans, payments] = await Promise.all([
      dbQuery(
        `SELECT l.loan_id, l.customer_id, c.customer_code, l.loan_date, l.due_date,
                l.loan_amount, l.interest_rate,
                l.interest_amount, l.total_amount, l.installment, l.installment_amount,
                l.balance_amount, l.received_amount, l.duration, l.loan_type, l.status,
                l.disbursal_mode, l.completed_at
         FROM loans l JOIN customers c ON c.id = l.customer_id
         WHERE l.customer_id = ANY($1)
         ORDER BY c.created_at ASC, l.loan_date DESC NULLS LAST, l.created_at DESC`,
        [groupIds]
      ),
      dbQuery(
        `SELECT payment_id, loan_id, customer_id, amount, payment_date, payment_time,
                COALESCE(payment_mode, payment_method, 'Cash') AS mode, remarks
         FROM payments WHERE customer_id = ANY($1)
         ORDER BY payment_date DESC, created_at DESC LIMIT 200`,
        [groupIds]
      ),
    ]);

    const loanRows = Array.isArray(loans.rows) ? loans.rows : [];
    const payRows = Array.isArray(payments.rows) ? payments.rows : [];
    const num = (v: any) => Number(v) || 0;
    const summary = {
      totalLoans: loanRows.length,
      activeLoans: loanRows.filter((l: any) => (l.status || 'Active') === 'Active').length,
      completedLoans: loanRows.filter((l: any) => l.status === 'Completed').length,
      totalGiven: loanRows.reduce((s: number, l: any) => s + num(l.loan_amount), 0),
      totalInterest: loanRows.reduce((s: number, l: any) => s + num(l.interest_amount), 0),
      totalReceivable: loanRows.reduce((s: number, l: any) => s + num(l.total_amount), 0),
      totalReceived: loanRows.reduce((s: number, l: any) => s + num(l.received_amount), 0),
      totalOutstanding: loanRows.reduce((s: number, l: any) => s + num(l.balance_amount), 0),
      totalPayments: payRows.length,
    };
    return NextResponse.json({
      customer: {
        id: p.id,
        customer_code: p.customer_code,
        full_name: p.full_name,
        phone_number: p.phone_number,
        address: p.address,
        city_name: p.city_name,
        area_name: p.area_name,
        business_name: p.business_name,
        status: p.status,
        created_at: p.created_at,
      },
      accounts,
      loans: loanRows,
      payments: payRows,
      summary,
    });
  } catch (err: any) {
    console.error('[GET /api/customer/me] Error:', err?.message || err);
    return NextResponse.json(
      { error: 'Unable to load your account. Please try again.' },
      { status: 500 }
    );
  }
}
