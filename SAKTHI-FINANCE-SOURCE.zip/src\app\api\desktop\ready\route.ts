import { timingSafeEqual } from 'node:crypto'
import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'nodejs'
export function GET(request: NextRequest) {
  const expected = process.env.SAKTHI_DESKTOP_RUN_ID || ''
  const received = request.headers.get('x-sakthi-desktop-run') || ''
  if (!expected || Buffer.byteLength(expected) !== Buffer.byteLength(received) || !timingSafeEqual(Buffer.from(expected), Buffer.from(received))) {
    return new NextResponse(null, { status: 404 })
  }
  return NextResponse.json({ run: expected }, { headers: { 'Cache-Control': 'no-store' } })
}
