import { AsyncLocalStorage } from 'node:async_hooks'
import type { PoolClient } from 'pg'

/** Only set by the authenticated sync endpoint, never by a request header. */
export const syncTransaction = new AsyncLocalStorage<{ client: PoolClient }>()
