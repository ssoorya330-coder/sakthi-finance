'use client'

import { AnimatedButton } from './animated-button'

export { AnimatedButton as Button }
export default AnimatedButton
