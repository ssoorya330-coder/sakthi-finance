import { NextRequest, NextResponse } from 'next/server'
import { requireAuth } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'

export async function GET(request: NextRequest) {
  const auth = await requireAuth()
  if (auth.error) return auth.error
  const { user } = auth;

  try {
    const { searchParams } = new URL(request.url)
    const q = searchParams.get('q')?.trim() || ''

    if (q.length < 2) {
      return NextResponse.json({ customers: [] })
    }

    // Strict per-account isolation: autocomplete must only ever return the
    // logged-in user's own customers. Ownership comes from the session —
    // never from client input. No status filter: Active, Completed and
    // Aborted customers are all searchable; prefix matches rank first.
    const result = await dbQuery(
      `SELECT
        c.customer_code,
        c.full_name,
        c.phone_number,
        c.alternate_phone,
        c.address,
        c.status,
        ra.name as area,
        rc.name as city,
        rb.name as business
       FROM customers c
       LEFT JOIN ref_area ra ON c.area_id = ra.id
       LEFT JOIN ref_city rc ON c.city_id = rc.id
       LEFT JOIN ref_business rb ON c.business_id = rb.id
       WHERE c.full_name ILIKE $1 AND c.user_id = $3
       ORDER BY
         CASE WHEN c.full_name ILIKE $2 THEN 0 ELSE 1 END,
         c.full_name
       LIMIT 20`,
      [`%${q}%`, `${q}%`, user.userId]
    )

    return NextResponse.json({ customers: result.rows })
  } catch (err: any) {
    console.error('[GET /api/customers/suggest] Error:', err.message)
    return NextResponse.json({ error: 'Failed to search customers' }, { status: 500 })
  }
}
