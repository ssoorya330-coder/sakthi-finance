'use client'

import { motion } from 'framer-motion'

const BARS = [0.4, 0.7, 0.5, 0.85, 0.6, 0.95, 0.7, 1, 0.8, 0.55]

export default function GraphLoader() {
  return (
    <div className="h-[320px] flex flex-col items-center justify-center gap-4">
      <div className="flex items-end gap-1.5 h-16">
        {BARS.map((h, i) => (
          <motion.div
            key={i}
            className="w-3 rounded-t-md bg-gradient-to-t from-slate-200 to-slate-100"
            animate={{ height: [`${h * 40}px`, `${h * 64}px`, `${h * 40}px`] }}
            transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut', delay: i * 0.08 }}
          />
        ))}
      </div>
      <p className="text-xs font-medium text-slate-400">Loading analytics…</p>
    </div>
  )
}
