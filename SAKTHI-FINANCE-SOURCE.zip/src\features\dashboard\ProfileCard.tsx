'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'
import {
  Landmark,
  Users,
  IndianRupee,
  CalendarCheck,
  Award,
  TrendingUp,
} from 'lucide-react'
import { useAuthStore } from '@/store/auth-store'
import { useCustomerStore } from '@/store/customer-store'
import { formatINR } from '@/lib/dashboard-utils'

const gradientBar = 'bg-gradient-to-r from-[var(--primary)] via-[var(--primary-hover)] to-[var(--secondary)]'

export default function ProfileCard() {
  const userName = useAuthStore((s) => s.userName)
  const customers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)

  const stats = useMemo(() => {
    const active = customers.filter((c) => c.status === 'Active').length
    const completed = customers.filter((c) => c.status === 'Completed').length
    const totalGiven = customers.reduce((s, c) => s + (Number(c.loanAmount) || 0), 0)
    const totalCollected = paymentHistory.reduce((s, p) => s + (p.paymentAmount || 0), 0)
    return { active, completed, totalGiven, totalCollected }
  }, [customers, paymentHistory])

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="relative bg-white/70 backdrop-blur-xl rounded-[22px] border border-white/20 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] p-6 overflow-hidden"
    >
      <div className="absolute inset-0 sf-pattern-dots opacity-30 pointer-events-none" />
      <div className="absolute -top-20 -right-20 w-60 h-60 bg-gradient-to-br from-[var(--primary)]/5 to-[var(--secondary)]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-gradient-to-br from-[var(--secondary)]/5 to-[var(--primary)]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <motion.div
            whileHover={{ scale: 1.05, rotate: -3 }}
            className="relative w-14 h-14 rounded-[16px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20 flex-shrink-0"
          >
            <Landmark className="w-7 h-7 text-white" />
          </motion.div>
          <div>
            <div className="flex items-center gap-2.5 mb-1">
              <h2 className="text-lg font-bold text-slate-900">Sakthi Finance</h2>
              <span className="px-2 py-0.5 rounded-lg bg-gradient-to-r from-[var(--primary-soft)] to-[var(--primary-soft)] text-[10px] font-semibold text-[var(--primary)] border border-[var(--primary)]/10 flex items-center gap-1">
                <Award className="w-3 h-3" />
                Enterprise
              </span>
            </div>
            <p className="text-sm text-slate-500">
              Welcome back, <span className="font-semibold text-slate-700">{userName || 'User'}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-6 flex-wrap">
          {[
            { label: 'Active Loans', value: stats.active, icon: Users, color: 'from-[var(--primary)] to-[var(--primary-hover)]' },
            { label: 'Completed', value: stats.completed, icon: CalendarCheck, color: 'from-[var(--primary)] to-[var(--primary-hover)]' },
            { label: 'Total Given', value: formatINR(stats.totalGiven), icon: IndianRupee, color: 'from-[var(--primary)] to-[var(--primary-hover)]' },
            { label: 'Collected', value: formatINR(stats.totalCollected), icon: TrendingUp, color: 'from-[var(--secondary)] to-[#B8943A]' },
          ].map((stat, i) => {
            const Icon = stat.icon
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.7 + i * 0.05 }}
                className="flex items-center gap-2.5 px-3 py-2 rounded-[12px] bg-white/50 backdrop-blur-sm border border-white/30"
              >
                <div className={`w-8 h-8 rounded-[9px] bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-md`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900 leading-tight">{stat.value}</p>
                  <p className="text-[9px] text-slate-500">{stat.label}</p>
                </div>
              </motion.div>
            )
          })}
        </div>
      </div>

        <div className="relative mt-4 pt-4 border-t border-slate-100/50">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span>© {new Date().getFullYear()} Sakthi Finance. All rights reserved.</span>
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            System operational
          </span>
        </div>
        <div className="mt-2 h-[2px] rounded-full bg-slate-100/50 overflow-hidden">
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 1.2, delay: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className={`h-full rounded-full ${gradientBar}`}
            style={{ transformOrigin: 'left' }}
          />
        </div>
      </div>
    </motion.div>
  )
}
