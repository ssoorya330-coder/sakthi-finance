import { NextRequest, NextResponse } from 'next/server';
import {
  REFRESH_COOKIE_NAME,
  ACCESS_COOKIE_NAME,
  verifyRefreshToken,
  signAccessToken,
  findRefreshToken,
  markRefreshTokenUsed,
  cookieOptions,
  type TokenPayload,
} from '@/lib/auth/tokens';
import { getSessionTimeoutMinutes, DEFAULT_SESSION_TIMEOUT_MINUTES } from '@/server/app-settings';
import { dbQuery } from '@/server/database';
import { normalizeRole } from '@/config/rbac';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const refreshToken = request.cookies.get(REFRESH_COOKIE_NAME)?.value;
    if (!refreshToken) {
      return NextResponse.json(
        { error: 'No refresh token', code: 'no_refresh_token' },
        { status: 401 }
      );
    }

    // Step 1: verify the JWT signature & expiry
    const payload = verifyRefreshToken(refreshToken);
    if (!payload || payload.typ !== 'refresh') {
      // Clear the bad cookie
      const response = NextResponse.json(
        { error: 'Invalid or expired refresh token', code: 'invalid_refresh_token' },
        { status: 401 }
      );
      response.cookies.set(REFRESH_COOKIE_NAME, '', cookieOptions(0, true));
      response.cookies.set(ACCESS_COOKIE_NAME, '', cookieOptions(0, true));
      return response;
    }

    // Step 2: confirm the token is still active in the DB (not revoked)
    let record;
    try {
      record = await findRefreshToken(refreshToken);
    } catch (dbErr) {
      const message = dbErr instanceof Error ? dbErr.message : 'Unknown error';
      console.error('[Auth/Refresh] DB error:', message);
      return NextResponse.json(
        { error: 'Database unavailable', code: 'db_error' },
        { status: 503 }
      );
    }

    if (!record) {
      const response = NextResponse.json(
        { error: 'Refresh token not recognised', code: 'unknown_refresh_token' },
        { status: 401 }
      );
      response.cookies.set(REFRESH_COOKIE_NAME, '', cookieOptions(0, true));
      response.cookies.set(ACCESS_COOKIE_NAME, '', cookieOptions(0, true));
      return response;
    }

    if (record.revoked_at) {
      const response = NextResponse.json(
        { error: 'Refresh token revoked', code: 'revoked_refresh_token' },
        { status: 401 }
      );
      response.cookies.set(REFRESH_COOKIE_NAME, '', cookieOptions(0, true));
      response.cookies.set(ACCESS_COOKIE_NAME, '', cookieOptions(0, true));
      return response;
    }

    if (new Date(record.expires_at).getTime() <= Date.now()) {
      const response = NextResponse.json(
        { error: 'Refresh token expired', code: 'expired_refresh_token' },
        { status: 401 }
      );
      response.cookies.set(REFRESH_COOKIE_NAME, '', cookieOptions(0, true));
      response.cookies.set(ACCESS_COOKIE_NAME, '', cookieOptions(0, true));
      return response;
    }

    // Step 3: issue a new access token (we do NOT rotate the refresh token here —
    // rotation would require the user to log in again if the request fails halfway).
    // Expiry honors the Owner-configured session timeout.
    const timeoutMinutes = await getSessionTimeoutMinutes().catch(
      () => DEFAULT_SESSION_TIMEOUT_MINUTES
    );
    // Refresh tokens establish identity, never the current authorization role.
    const accountResult = await dbQuery(
      `SELECT u.user_id, u.email, u.full_name, u.is_active,
              COALESCE(r.role_name, u.role) AS role
       FROM users u LEFT JOIN roles r ON u.role_id = r.role_id
       WHERE u.user_id = $1 OR u.id::text = $1 LIMIT 1`,
      [record.user_id]
    );
    const account = accountResult.rows[0];
    if (!account || account.is_active === false || !['owner', 'admin'].includes(account.role)) {
      const response = NextResponse.json(
        { error: 'Account unavailable', code: 'account_inactive' }, { status: 403 }
      );
      response.cookies.set(REFRESH_COOKIE_NAME, '', cookieOptions(0, true));
      response.cookies.set(ACCESS_COOKIE_NAME, '', cookieOptions(0, true));
      return response;
    }
    const accessPayload: TokenPayload = {
      sub: account.user_id,
      email: account.email,
      name: account.full_name || payload.name,
      role: normalizeRole(account.role),
      provider: payload.provider,
      picture: payload.picture,
    };
    const accessToken = signAccessToken(accessPayload, timeoutMinutes);

    // Update last_used_at (best-effort)
    markRefreshTokenUsed(record.id).catch((err) => {
      console.warn('[Auth/Refresh] Failed to update last_used_at:', err);
    });

    const response = NextResponse.json({
      user: {
        id: accessPayload.sub,
        email: accessPayload.email,
        name: accessPayload.name,
        picture: payload.picture,
        role: accessPayload.role,
      },
      access_token: accessToken,
      access_token_expires_in: timeoutMinutes * 60,
    });

    response.cookies.set(ACCESS_COOKIE_NAME, accessToken, cookieOptions(timeoutMinutes * 60, true));
    return response;
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    console.error('[Auth/Refresh] Error:', message);
    return NextResponse.json(
      { error: 'Refresh failed', details: message, code: 'refresh_error' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  return POST(request);
}
