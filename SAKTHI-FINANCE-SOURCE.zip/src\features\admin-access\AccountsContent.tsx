'use client'

import { useMemo, useState } from 'react'
import { cn } from '@/lib/utils'
import AdminSectionShell, { AdminEmpty, AdminError, AdminLoading } from './AdminSectionShell'
import { adminMutate, useAdminApi } from './useAdminApi'
import { formatCurrency } from '@/features/dashboard/dashboard.styles'
import { isDeveloperEmail } from '@/config/developer-access'

interface AccountRow {
  customer_count?:number
  active_customer_count?:number
  completed_customer_count?:number
  aborted_customer_count?:number
  loan_count?:number
  loan_amount?:string
  total_amount?:string
  paid_amount?:string
  balance_amount?:string
  user_id?: string | null
  id?: string | number | null
  email?: string | null
  full_name?: string | null
  role?: string | null
  role_name?: string | null
  is_active?: boolean | null
  provider?: string | null
  last_login_at?: string | null
  created_at?: string | null
}

const fmtDT = (iso: string | null | undefined) => {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: true,
    })
  } catch {
    return '—'
  }
}

export default function AccountsContent() {
  const { data, state, retrying, retry } = useAdminApi<AccountRow[]>('/api/admin/users', (j) =>
    Array.isArray(j?.users) ? (j.users as AccountRow[]) : []
  )
  const users = useMemo(() => data || [], [data])
  const [busy, setBusy] = useState<string | null>(null)
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const [confirm, setConfirm] = useState<{ user: AccountRow; action: 'suspend' | 'reactivate' } | null>(null)

  const apply = async (u: AccountRow, suspend: boolean) => {
    const uid = u.user_id || String(u.id || '')
    const key = `${suspend ? 'sus' : 'rea'}-${uid}`
    setBusy(key)
    setMsg(null)
    const r = await adminMutate(`/api/admin/users/${encodeURIComponent(uid)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_active: !suspend, reason: suspend ? 'suspended' : 'reactivated' }),
    })
    setBusy(null)
    setMsg({ ok: r.ok, text: r.ok ? (suspend ? 'Account suspended.' : 'Account reactivated.') : r.message })
    if (r.ok) retry()
  }

  const forceLogout = async (u: AccountRow) => {
    const uid = u.user_id || String(u.id || '')
    setBusy(`out-${uid}`)
    setMsg(null)
    const r = await adminMutate(`/api/admin/devices?userId=${encodeURIComponent(uid)}`, { method: 'DELETE' })
    setBusy(null)
    setMsg({ ok: r.ok, text: r.ok ? 'All sessions revoked for this account.' : r.message })
  }

  return (
    <AdminSectionShell title="Account Management" subtitle="Account status, access control, and sessions" icon="users">
      {msg && (
        <div className={cn(
          'p-4 rounded-2xl border text-sm',
          msg.ok ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-amber-50 border-amber-200 text-amber-800'
        )}>
          {msg.text}
        </div>
      )}
      {state === 'loading' && <AdminLoading />}
      {state === 'unauthorized' && (
        <AdminError message="You are not authorized to access this page." onRetry={retry} retrying={retrying} />
      )}
      {state === 'failed' && (
        <AdminError message="Unable to connect to the database. Please try again." onRetry={retry} retrying={retrying} />
      )}
      {state === 'ready' &&
        (users.length === 0 ? (
          <AdminEmpty message="No accounts found" />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm min-w-[900px]">
                <thead>
                  <tr className="bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)] text-left">
                    {['Account', 'Created', 'Actions'].map((h) => (
                      <th key={h} className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-[#F3DFA7] whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map((u, i) => {
                    const uid = u.user_id || String(u.id || `row-${i}`)
                    const email = u.email || '—'
                    const name = u.full_name || email.split('@')[0] || 'User'
                    const active = u.is_active !== false
                    return (
                      <tr key={uid} className="hover:bg-slate-50 align-top">
                        <td className="px-4 py-2.5">
                          <span className="block text-xs font-bold text-slate-900">{name}</span>
                          <span className="block text-[11px] text-slate-500">{email}</span>
                          <span className="inline-flex mt-1 items-center px-2 py-0.5 rounded-lg text-[10px] font-bold border bg-slate-100 text-slate-600 border-slate-200 capitalize">
                            {isDeveloperEmail(u.email)?'Developer':(u.role_name || u.role || 'owner')}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-xs text-slate-500 tabular-nums whitespace-nowrap">{fmtDT(u.created_at)}</td>
                        <td className="px-4 py-2.5">
                          <div className="flex flex-wrap gap-1.5">
                            {active ? (
                              <button
                                disabled={busy !== null}
                                onClick={() => setConfirm({ user: u, action: 'suspend' })}
                                className="px-2 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                              >
                                Suspend
                              </button>
                            ) : (
                              <button
                                disabled={busy !== null}
                                onClick={() => apply(u, false)}
                                className="px-2 py-1.5 rounded-lg text-[11px] font-semibold bg-[var(--primary)] text-white hover:bg-[#912222] disabled:opacity-50"
                              >
                                {busy === `rea-${uid}` ? 'Saving…' : 'Reactivate'}
                              </button>
                            )}
                            <button
                              disabled={busy !== null}
                              onClick={() => forceLogout(u)}
                              className="px-2 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                            >
                              {busy === `out-${uid}` ? 'Working…' : 'Force logout'}
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ))}

      {confirm && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setConfirm(null)}>
          <div onClick={(e) => e.stopPropagation()} className="w-full max-w-[440px] bg-white rounded-[22px] border border-slate-100 shadow-2xl p-6">
            <h3 className="text-base font-bold text-slate-900">Suspend this account?</h3>
            <p className="text-sm text-slate-500 mt-2">
              <b className="text-slate-800">{confirm.user.email || confirm.user.user_id}</b> will no longer be able to
              access Sakthi Finance until reactivated. The account and its data are kept.
            </p>
            <div className="mt-5 flex gap-2 justify-end">
              <button onClick={() => setConfirm(null)} className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-medium hover:bg-slate-50">Cancel</button>
              <button
                onClick={() => {
                  const u = confirm.user
                  setConfirm(null)
                  apply(u, true)
                }}
                disabled={busy !== null}
                className="px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222] disabled:opacity-50"
              >
                Suspend Account
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminSectionShell>
  )
}
