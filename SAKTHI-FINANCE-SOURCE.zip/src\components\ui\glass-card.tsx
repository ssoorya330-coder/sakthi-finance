'use client'

import { cn } from '@/lib/utils'
import { motion, type HTMLMotionProps } from 'framer-motion'

interface GlassCardProps extends HTMLMotionProps<'div'> {
  children: React.ReactNode
  className?: string
  elevated?: boolean
  goldBorder?: boolean
  variant?: string
  size?: string
}

function GlassCard({ children, className, elevated, goldBorder, variant, size, ...props }: GlassCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        'sf-premium-glass',
        'rounded-[28px] p-10',
        goldBorder && 'sf-gold-border',
        'will-change-transform',
        className
      )}
      {...props}
    >
      {children}
    </motion.div>
  )
}

export { GlassCard }
export default GlassCard
