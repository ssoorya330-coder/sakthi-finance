'use client'
import { Check, Palette } from 'lucide-react'
import { THEMES } from '@/lib/appearance'
import { useAppearance } from '@/providers/appearance-provider'
export default function AppearanceSection() {
  const { theme, select, storageWarning } = useAppearance()
  return <section className="rounded-2xl border border-slate-200 bg-white p-5 space-y-5">
    <div className="flex items-center gap-3"><Palette aria-hidden="true" /><div>
      <h2 className="font-semibold">Appearance</h2>
      <p className="text-sm text-slate-600">Light palettes. Changes apply instantly without interrupting your work.</p>
    </div></div>
    <div className="grid gap-3 sm:grid-cols-2" aria-label="Application theme">
      {THEMES.map(t => <button key={t.id} type="button" aria-pressed={theme === t.id} onClick={() => select(t.id)}
        className="rounded-xl border p-4 text-left focus-visible:outline-2 focus-visible:outline-offset-2"
        style={{ background: t.colors[4], borderColor: theme === t.id ? t.action : t.colors[3], color: t.text }}>
        <span className="flex items-center justify-between font-semibold">{t.name}{theme === t.id && <Check aria-label="Selected" size={18} />}</span>
        <span className="mt-3 flex gap-2">{t.colors.map(c => <span key={c} className="h-6 w-6 rounded-full border border-black/10" style={{ background: c }} />)}</span>
      </button>)}
    </div>
    {storageWarning && <p role="status" className="text-sm text-amber-800">Theme applied. This device could not save it for the next launch.</p>}
  </section>
}
