/** Trigram posting index keeps substring searches fast without changing matching semantics. */
export function customerSearchIndex<T>(rows:T[],fields:(row:T)=>unknown[]) {
  const text=rows.map(row=>fields(row).map(v=>String(v??'').toLocaleLowerCase()).join('\u0000'))
  const postings=new Map<string,Set<number>>()
  text.forEach((value,index)=>{
    for(let i=0;i<=value.length-3;i++){
      const token=value.slice(i,i+3)
      let bucket=postings.get(token);if(!bucket){bucket=new Set();postings.set(token,bucket)}bucket.add(index)
    }
  })
  return (input:string):Set<T>=>{
    const q=input.toLocaleLowerCase().trim()
    if(!q)return new Set(rows)
    let candidates:Iterable<number>=text.keys()
    if(q.length>=3){
      let smallest:Set<number>|undefined
      for(let i=0;i<=q.length-3;i++){const bucket=postings.get(q.slice(i,i+3));if(!bucket)return new Set();if(!smallest||bucket.size<smallest.size)smallest=bucket}
      candidates=smallest!
    }
    return new Set([...candidates].filter(i=>text[i].includes(q)).map(i=>rows[i]))
  }
}
