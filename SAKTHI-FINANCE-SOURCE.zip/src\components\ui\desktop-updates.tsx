'use client'
import { useEffect, useState } from 'react'
import { useOnlineUpdates } from '@/hooks/use-online-updates'
import { OnlineUpdateDetails } from './online-update-details'

export default function DesktopUpdatesPanel() {
  const online = useOnlineUpdates()
  const [open, setOpen] = useState(false)
  useEffect(() => {
    const show = () => { setOpen(true); void window.sakthi?.updates?.check().catch(() => {}) }
    window.addEventListener('sakthi:open-updates', show)
    return () => window.removeEventListener('sakthi:open-updates', show)
  }, [])
  useEffect(() => { if (online?.phase === 'available' || online?.phase === 'ready') setOpen(true) }, [online?.phase, online?.version])
  if (!online) return null
  return <>
    {open && <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/30 p-4" onKeyDown={e => { if(e.key === 'Escape') setOpen(false) }}>
      <section role="dialog" aria-modal="true" aria-labelledby="desktop-update-title" className="max-h-[90vh] w-full max-w-lg overflow-auto rounded-2xl border border-[var(--secondary)]/30 bg-[#FFFEF9] p-6 shadow-xl text-[var(--primary)]">
        <div className="flex items-center justify-between"><h2 id="desktop-update-title" className="text-xl font-bold">App updates</h2><button autoFocus type="button" onClick={() => setOpen(false)} aria-label="Close update panel">Later</button></div>
        {online && <div className="mt-4"><OnlineUpdateDetails state={online} /></div>}
      </section>
    </div>}
  </>
}
