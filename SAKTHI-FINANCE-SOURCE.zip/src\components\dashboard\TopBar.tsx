'use client'

import { useSidebarStore } from '@/store/sidebar-store'
import NotificationBell from '@/components/shared/notification-bell'

interface TopBarProps {
  title: string
  subtitle?: string
  /** Legacy callers may provide this; the header no longer shows a back button. */
  backHref?: string
}

export default function TopBar({ title, subtitle }: TopBarProps) {
  const { toggleSidebar } = useSidebarStore()

  return (
    <div className="flex items-center justify-between gap-3 mb-6">
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={toggleSidebar}
          aria-label="Open menu"
          className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors active:scale-95 shadow-sm flex-shrink-0"
        >
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round">
            <path d="M3 5h14" />
            <path d="M3 10h14" />
            <path d="M3 15h14" />
          </svg>
        </button>
        <div className="min-w-0">
          <h1 className="text-lg font-bold text-slate-900 leading-tight truncate">{title}</h1>
          {subtitle && <p className="text-xs text-slate-500 truncate">{subtitle}</p>}
        </div>
      </div>
      <NotificationBell />
    </div>
  )
}
