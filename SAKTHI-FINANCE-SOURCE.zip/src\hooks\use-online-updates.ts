'use client'
import { useEffect, useState } from 'react'
import type { OnlineUpdateStatus } from '../../electron/online-updates'

export function useOnlineUpdates() {
  const [state, setState] = useState<OnlineUpdateStatus>()
  useEffect(() => {
    const updates = window.sakthi?.updates
    if (!updates?.onlineStatus || !updates.onEvent) return
    let alive = true
    let receivedEvent = false
    const unsubscribe = updates.onEvent(next => { receivedEvent = true; if (alive) setState(next) })
    void updates.onlineStatus().then(next => { if (alive && !receivedEvent) setState(next) }).catch(() => {})
    return () => { alive = false; unsubscribe() }
  }, [])
  return state
}
