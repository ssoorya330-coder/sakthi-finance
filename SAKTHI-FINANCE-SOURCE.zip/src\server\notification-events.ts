import type { AuditQueryable, RecordAuditInput } from './audit'

/** Saved alongside the audit event: rolled-back actions never produce alerts. */
export async function notifyAuditEvent(q: AuditQueryable, input: RecordAuditInput) {
  if (!input.actor.userId) return
  const title = input.action.toLowerCase().replace(/_/g, ' ').replace(/^./, c => c.toUpperCase())
  const warning = input.result && input.result !== 'SUCCESS' || /FAILED|FLAGGED|UNAUTHORIZED/.test(input.action)
  const reference = input.customerId || input.entityId
  const message = `${title}${reference ? ` · ${input.entityType} ${reference}` : ''}.`
  const result = await q.query(
    'INSERT INTO notifications (user_id, title, message, type) VALUES ($1, $2, $3, $4) RETURNING id',
    [input.actor.userId, title, message, warning ? 'warning' : 'info'],
  )
  await q.query("SELECT pg_notify('app_notifications', $1)", [JSON.stringify({ userId: input.actor.userId, id: result.rows[0].id, title, kind: 'new' })])
}
