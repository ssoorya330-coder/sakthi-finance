'use client'

import { LeftPanel } from '@/components/shared/left-panel'
import { GlassCard } from '@/components/ui/glass-card'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'

interface AuthLayoutProps {
  children: React.ReactNode
  className?: string
}

export default function AuthLayout({ children, className }: AuthLayoutProps) {
  return (
    <div
      className={cn(
        'relative w-full h-screen flex overflow-hidden bg-[#080808]',
        className
      )}
    >
      <LeftPanel />

      <div className="w-[440px] min-w-[440px] flex items-center justify-center px-8 bg-[#080808]">
        <motion.div
          initial={{ opacity: 0, x: 40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
          className="w-full"
        >
          <GlassCard className="w-full">
            {children}
          </GlassCard>
        </motion.div>
      </div>
    </div>
  )
}
