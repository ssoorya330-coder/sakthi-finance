'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'
import AdminSectionShell, { AdminEmpty, AdminError, AdminLoading } from './AdminSectionShell'

type LoadState = 'loading' | 'ready' | 'unauthorized' | 'failed'

const ROLES = ['owner', 'admin', 'manager', 'employee', 'viewer', 'customer'] as const

// Key administrative permissions shown as matrix columns.
const KEY_PERMISSIONS = [
  { id: 'users:manage', label: 'Manage Users' },
  { id: 'audit:read', label: 'Audit' },
  { id: 'settings:manage', label: 'Settings' },
  { id: 'security:manage', label: 'Security Settings' },
  { id: 'customers:create', label: 'Create Records' },
  { id: 'reports:export', label: 'Export Reports' },
] as const

export default function PermissionsContent() {
  const [matrix, setMatrix] = useState<Record<string, string[]> | null>(null)
  const [state, setState] = useState<LoadState>('loading')
  const [retrying, setRetrying] = useState(false)
  const mountedRef = useRef(true)

  const load = useCallback(async (isRetry = false) => {
    if (isRetry) setRetrying(true)
    else setState('loading')
    try {
      const res = await fetch('/api/admin/access', { credentials: 'include' })
      if (res.status === 401 || res.status === 403) {
        if (mountedRef.current) setState('unauthorized')
        return
      }
      if (!res.ok) throw new Error(`Request failed (${res.status})`)
      const data = await res.json().catch(() => null)
      const perms = data?.permissions
      if (!perms || typeof perms !== 'object') throw new Error('Invalid response')
      if (mountedRef.current) {
        setMatrix(perms as Record<string, string[]>)
        setState('ready')
      }
    } catch {
      if (mountedRef.current) setState('failed')
    } finally {
      if (mountedRef.current) setRetrying(false)
    }
  }, [])

  useEffect(() => {
    mountedRef.current = true
    load()
    return () => {
      mountedRef.current = false
    }
  }, [load])

  const has = (role: string, perm: string) => Array.isArray(matrix?.[role]) && (matrix as Record<string, string[]>)[role].includes(perm)

  return (
    <AdminSectionShell title="Permissions" subtitle="Manage administrative permissions and access controls" icon="permissions">
      {state === 'loading' && <AdminLoading />}
      {state === 'unauthorized' && (
        <AdminError message="You are not authorized to access this page." onRetry={() => load(true)} retrying={retrying} />
      )}
      {state === 'failed' && (
        <AdminError message="Unable to load permissions. Please try again." onRetry={() => load(true)} retrying={retrying} />
      )}
      {state === 'ready' &&
        (!matrix ? (
          <AdminEmpty message="Permissions have not been configured yet" />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-bold text-slate-900">Role Permissions</p>
              <p className="text-[11px] text-slate-400 font-medium mt-0.5">
                Read-only overview. Role changes are managed server-side only.
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm min-w-[760px]">
                <thead>
                  <tr className="bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)] text-left">
                    <th className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-[#F3DFA7]">Role</th>
                    {KEY_PERMISSIONS.map((p) => (
                      <th key={p.id} className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-[#F3DFA7] text-center whitespace-nowrap">
                        {p.label}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {ROLES.map((r) => (
                    <tr key={r} className="hover:bg-slate-50">
                      <td className="px-4 py-2.5 text-xs font-bold text-slate-900 capitalize">{r}</td>
                      {KEY_PERMISSIONS.map((p) => (
                        <td key={p.id} className="px-4 py-2.5 text-center">
                          <span className={cn(
                            'inline-flex items-center px-2 py-0.5 rounded-lg text-[11px] font-bold border',
                            has(r, p.id)
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-slate-100 text-slate-400 border-slate-200'
                          )}>
                            {has(r, p.id) ? '✓' : '—'}
                          </span>
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
    </AdminSectionShell>
  )
}
