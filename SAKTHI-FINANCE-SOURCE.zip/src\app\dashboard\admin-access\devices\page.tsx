'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import DevicesContent from '@/features/admin-access/DevicesContent'

export default function DevicesContentPage() {
  return (
    <ClientPageGate requireRole="owner">
      <DevicesContent />
    </ClientPageGate>
  )
}
