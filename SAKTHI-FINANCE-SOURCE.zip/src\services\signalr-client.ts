import React from 'react';
import {
  HubConnectionBuilder,
  HubConnection,
  HubConnectionState,
  LogLevel,
  HttpTransportType,
} from '@microsoft/signalr';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || '';
const NOTIFICATION_HUB = `${API_BASE}/hubs/notification`;
const DASHBOARD_HUB = `${API_BASE}/hubs/dashboard`;

type ConnectionStatus = 'connected' | 'disconnected' | 'connecting' | 'reconnecting';

type SignalREventHandler = (...args: unknown[]) => void;

class SignalRServiceClass {
  private notificationConnection: HubConnection | null = null;
  private dashboardConnection: HubConnection | null = null;
  private status: ConnectionStatus = 'disconnected';
  private listeners: Array<(status: ConnectionStatus) => void> = [];

  private async getToken(): Promise<string> {
    try {
      const { getToken } = await import('@/api/client')
      return (await getToken()) ?? ''
    } catch {
      return '';
    }
  }

  private buildConnection(url: string): HubConnection {
    return new HubConnectionBuilder()
      .withUrl(url, {
        accessTokenFactory: () => this.getToken(),
        transport: HttpTransportType.WebSockets | HttpTransportType.LongPolling,
      })
      .withAutomaticReconnect({
        nextRetryDelayInMilliseconds: (retryContext) => {
          const base = Math.min(1000 * Math.pow(2, retryContext.previousRetryCount), 30_000);
          const jitter = Math.random() * 1000;
          return base + jitter;
        },
      })
      .configureLogging(LogLevel.Warning)
      .build();
  }

  async connect(): Promise<void> {
    if (typeof window === 'undefined') return;
    if (this.status === 'connected' || this.status === 'connecting') return;

    this.status = 'connecting';
    this.emitStatus();

    try {
      this.notificationConnection = this.buildConnection(NOTIFICATION_HUB);
      this.dashboardConnection = this.buildConnection(DASHBOARD_HUB);

      this.setupConnectionEvents(this.notificationConnection, 'notification');
      this.setupConnectionEvents(this.dashboardConnection, 'dashboard');

      await Promise.allSettled([
        this.notificationConnection.start(),
        this.dashboardConnection.start(),
      ]);

      this.status = 'connected';
      this.emitStatus();

      if (process.env.NODE_ENV === 'development') {
        console.log('[SignalR] Connected to hubs');
      }
    } catch (err) {
      this.status = 'disconnected';
      this.emitStatus();
      if (process.env.NODE_ENV === 'development') {
        console.error('[SignalR] Connection failed:', err);
      }
    }
  }

  private setupConnectionEvents(connection: HubConnection, hubName: string): void {
    connection.onreconnecting(() => {
      this.status = 'reconnecting';
      this.emitStatus();
      if (process.env.NODE_ENV === 'development') {
        console.log(`[SignalR] Reconnecting to ${hubName}...`);
      }
    });

    connection.onreconnected(() => {
      this.status = 'connected';
      this.emitStatus();
      if (process.env.NODE_ENV === 'development') {
        console.log(`[SignalR] Reconnected to ${hubName}`);
      }
    });

    connection.onclose((err) => {
      this.status = 'disconnected';
      this.emitStatus();
      if (process.env.NODE_ENV === 'development') {
        console.warn(`[SignalR] ${hubName} connection closed:`, err);
      }
    });
  }

  async disconnect(): Promise<void> {
    try {
      if (this.notificationConnection) {
        await this.notificationConnection.stop();
        this.notificationConnection = null;
      }
      if (this.dashboardConnection) {
        await this.dashboardConnection.stop();
        this.dashboardConnection = null;
      }
      this.status = 'disconnected';
      this.emitStatus();
      if (process.env.NODE_ENV === 'development') {
        console.log('[SignalR] Disconnected');
      }
    } catch (err) {
      if (process.env.NODE_ENV === 'development') {
        console.warn('[SignalR] Error disconnecting:', err);
      }
    }
  }

  on(event: string, handler: SignalREventHandler, hub: 'notification' | 'dashboard' = 'notification'): void {
    const connection = hub === 'notification' ? this.notificationConnection : this.dashboardConnection;
    if (!connection) {
      if (process.env.NODE_ENV === 'development') {
        console.warn(`[SignalR] Cannot register handler for ${event}: no ${hub} connection`);
      }
      return;
    }

    connection.on(event, (...args: unknown[]) => {
      try {
        handler(...args);
      } catch (err) {
        if (process.env.NODE_ENV === 'development') {
          console.error(`[SignalR] Error in handler for ${event}:`, err);
        }
      }
    });
  }

  off(event: string, hub: 'notification' | 'dashboard' = 'notification'): void {
    const connection = hub === 'notification' ? this.notificationConnection : this.dashboardConnection;
    if (connection) {
      connection.off(event);
    }
  }

  async invoke(method: string, ...args: unknown[]): Promise<unknown> {
    if (!this.notificationConnection || this.notificationConnection.state !== HubConnectionState.Connected) {
      throw new Error('[SignalR] Notification hub not connected');
    }
    return this.notificationConnection.invoke(method, ...args);
  }

  async invokeDashboard(method: string, ...args: unknown[]): Promise<unknown> {
    if (!this.dashboardConnection || this.dashboardConnection.state !== HubConnectionState.Connected) {
      throw new Error('[SignalR] Dashboard hub not connected');
    }
    return this.dashboardConnection.invoke(method, ...args);
  }

  getStatus(): ConnectionStatus {
    return this.status;
  }

  isConnected(): boolean {
    return this.status === 'connected';
  }

  onStatusChange(listener: (status: ConnectionStatus) => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private emitStatus(): void {
    for (const listener of this.listeners) {
      try {
        listener(this.status);
      } catch {
        // ignore listener errors
      }
    }
  }
}

export const signalRService = new SignalRServiceClass();

export function useSignalR() {
  const [status, setStatus] = React.useState<ConnectionStatus>(signalRService.getStatus());

  React.useEffect(() => {
    signalRService.connect();
    const unsub = signalRService.onStatusChange(setStatus);
    return () => {
      unsub();
      signalRService.disconnect();
    };
  }, []);

  return {
    status,
    isConnected: status === 'connected',
    on: signalRService.on.bind(signalRService),
    off: signalRService.off.bind(signalRService),
    invoke: signalRService.invoke.bind(signalRService),
    invokeDashboard: signalRService.invokeDashboard.bind(signalRService),
  };
}

export type { ConnectionStatus };
