import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { getCopyJobProgress } from '@/server/migration-copy'

export const dynamic = 'force-dynamic'

/** Poll REAL copy progress (destination bytes on disk vs measured source size). */
export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  const jobId = request.nextUrl.searchParams.get('id') || ''
  if (!jobId) return NextResponse.json({ error: 'Copy job id is required.' }, { status: 400 })
  return NextResponse.json(getCopyJobProgress(jobId))
}
