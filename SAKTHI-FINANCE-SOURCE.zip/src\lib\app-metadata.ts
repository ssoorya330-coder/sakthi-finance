'use client'

import pkg from '@/../package.json'
import buildInfo from './build-info.json'

let gpuInfo: string | null = null
async function detectGPU(): Promise<string | null> {
  if (gpuInfo) return gpuInfo
  try {
    const canvas = document.createElement('canvas')
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl')
    if (gl && 'getParameter' in gl) {
      const ext = gl.getExtension('WEBGL_debug_renderer_info')
      if (ext) {
        gpuInfo = gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)
        return gpuInfo
      }
    }
  } catch {}
  return null
}

let gpuPromise: Promise<string | null> | null = null
export function getGPU(): Promise<string | null> {
  if (!gpuPromise) gpuPromise = detectGPU()
  return gpuPromise
}

export interface AppMetadata {
  appName: string
  version: string
  description: string
  buildNumber: string
  buildTime: string
  gitHash: string
  releaseChannel: 'Development' | 'Beta' | 'Stable'
  environment: 'Development' | 'Production'
  lastUpdated: string
  reactVersion: string
  nextVersion: string
  typescriptVersion: string
  nodeVersion: string
  databaseType: string
  license: string
  company: string
  developer: string
  copyright: string
  supportEmail: string
  website: string
}

export interface SystemInfo {
  os: string
  browser: string
  screenResolution: string
  deviceMemory: string
  cpuThreads: number | null
  gpu: string | null
  language: string
  timeZone: string
  platform: string
}

let _metadata: AppMetadata | null = null
let _systemInfo: SystemInfo | null = null

export function getAppMetadata(): AppMetadata {
  if (_metadata) return _metadata

  const reactVersion = pkg.dependencies?.react?.replace('^', '') || '19.x'

  const nextVersion = pkg.dependencies?.next?.replace('^', '') || '16.x'
  const tsVersion = pkg.devDependencies?.typescript?.replace('^', '') || '5.x'

  const channel: AppMetadata['releaseChannel'] =
    process.env.NODE_ENV === 'production' ? 'Stable' : 'Development'

  const env: AppMetadata['environment'] =
    process.env.NODE_ENV === 'production' ? 'Production' : 'Development'

  _metadata = {
    appName: 'SAKTHI FINANCE',
    version: pkg.version || '1.0.0',
    description: pkg.description || '',
    buildNumber: buildInfo.buildTime ? new Date(buildInfo.buildTime).getTime().toString(36).toUpperCase() : 'DEV',
    buildTime: buildInfo.buildTime || new Date().toISOString(),
    gitHash: buildInfo.gitHash || 'development',
    releaseChannel: channel,
    environment: env,
    lastUpdated: buildInfo.buildTime || new Date().toISOString(),
    reactVersion,
    nextVersion,
    typescriptVersion: tsVersion,
    nodeVersion: typeof process !== 'undefined' && process.version ? process.version : '22.x',
    databaseType: 'SQLite (Offline)',
    license: 'Private Enterprise Software',
    company: 'Sakthi Finance',
    developer: 'Soorya S.',
    copyright: `© ${new Date().getFullYear()} Sakthi Finance. All rights reserved.`,
    supportEmail: 'support@sakthifinance.com',
    website: 'https://sakthifinance.com',
  }

  return _metadata
}

export function getSystemInfo(): SystemInfo {
  if (_systemInfo) return _systemInfo

  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : ''
  const platform = typeof navigator !== 'undefined' ? navigator.platform : ''

  const os = (() => {
    if (ua.includes('Windows')) return 'Windows'
    if (ua.includes('Mac OS')) return 'macOS'
    if (ua.includes('Linux')) return 'Linux'
    if (ua.includes('Android')) return 'Android'
    if (ua.includes('iOS') || ua.includes('iPhone') || ua.includes('iPad')) return 'iOS'
    return platform || 'Unknown'
  })()

  const browser = (() => {
    if (ua.includes('Edg/') || ua.includes('Edge/')) return 'Microsoft Edge'
    if (ua.includes('Chrome/')) return 'Google Chrome'
    if (ua.includes('Firefox/')) return 'Mozilla Firefox'
    if (ua.includes('Safari/')) return 'Safari'
    return 'Unknown'
  })()

  const screenRes = typeof window !== 'undefined'
    ? `${window.screen.width} × ${window.screen.height}`
    : ''

  const mem = typeof navigator !== 'undefined' && 'deviceMemory' in navigator
    ? `${(navigator as Navigator & { deviceMemory: number }).deviceMemory} GB`
    : 'Not available'

  const cpu = typeof navigator !== 'undefined' && 'hardwareConcurrency' in navigator
    ? navigator.hardwareConcurrency
    : null

  const lang = typeof navigator !== 'undefined' ? navigator.language : ''
  const tz = typeof Intl !== 'undefined'
    ? Intl.DateTimeFormat().resolvedOptions().timeZone
    : ''

  _systemInfo = {
    os,
    browser,
    screenResolution: screenRes,
    deviceMemory: mem,
    cpuThreads: cpu,
    gpu: null,
    language: lang,
    timeZone: tz,
    platform,
  }

  return _systemInfo
}

export function getAllInfoText(): string {
  const m = getAppMetadata()
  const s = getSystemInfo()
  const lines = [
    `=== ${m.appName} - Version Info ===`,
    '',
    'Application Information:',
    `  Name: ${m.appName}`,
    `  Version: ${m.version}`,
    `  Build: ${m.buildNumber}`,
    `  Channel: ${m.releaseChannel}`,
    `  Environment: ${m.environment}`,
    `  Build Date: ${new Date(m.buildTime).toLocaleString()}`,
    `  Last Updated: ${new Date(m.lastUpdated).toLocaleString()}`,
    `  Git Hash: ${m.gitHash}`,
    '',
    'Technology Stack:',
    `  React: ${m.reactVersion}`,
    `  Next.js: ${m.nextVersion}`,
    `  TypeScript: ${m.typescriptVersion}`,
    `  Node.js: ${m.nodeVersion}`,
    `  Database: ${m.databaseType}`,
    '',
    'System Information:',
    `  OS: ${s.os}`,
    `  Browser: ${s.browser}`,
    `  Screen: ${s.screenResolution}`,
    `  Memory: ${s.deviceMemory}`,
    `  CPU Threads: ${s.cpuThreads || 'N/A'}`,
    `  GPU: ${s.gpu || 'N/A'}`,
    `  Language: ${s.language}`,
    `  Time Zone: ${s.timeZone}`,
    '',
    'Developer Information:',
    `  Developer: ${m.developer}`,
    `  Company: ${m.company}`,
    `  License: ${m.license}`,
    `  Copyright: ${m.copyright}`,
    '',
    `Generated: ${new Date().toISOString()}`,
  ]
  return lines.join('\n')
}
