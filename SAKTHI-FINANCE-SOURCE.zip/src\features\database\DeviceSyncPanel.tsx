'use client'
import { useCallback, useEffect, useState } from 'react'
import { RefreshCw, Tablet, Download } from 'lucide-react'
import { useAuthStore } from '@/store/auth-store'
import { useCustomerStore } from '@/store/customer-store'
import { apiClient } from '@/services/api-client'
import { deviceMode, prepareDevice, synchronizeDevice, disableDevice, resolveConflict } from '@/lib/device-sync/browser'
import { downloadLocalRecovery, readWorkspace } from '@/lib/device-sync/local'
import { pending } from '@/lib/device-sync/model'
import type { SyncWorkspace } from '@/lib/device-sync/types'
import { useSyncConnection } from '@/lib/device-sync/use-connection'

export default function DeviceSyncPanel(_props: { connected: boolean }) {
  const user=useAuthStore(s=>s.userId)
  const {connected,message:connectionMessage}=useSyncConnection(user)
  const [workspace,setWorkspace]=useState<SyncWorkspace|null>(null)
  const [busy,setBusy]=useState(''),[message,setMessage]=useState(''),[enabled,setEnabled]=useState(false)
  const button='rounded-xl border border-[var(--primary)]/25 px-4 py-2 text-sm font-semibold text-[var(--primary)] disabled:opacity-40'
  const reload=useCallback(async()=>{
    if(!user)return
    setEnabled(deviceMode(user))
    try{setWorkspace(await readWorkspace(user))}catch(e){setMessage((e as Error).message)}
  },[user])
  useEffect(()=>{void reload();const change=()=>void reload();window.addEventListener('sf-device-sync-changed',change);window.addEventListener('storage',change);return()=>{window.removeEventListener('sf-device-sync-changed',change);window.removeEventListener('storage',change)}},[reload])
  const run=async(label:string,work:()=>Promise<any>)=>{
    if(busy)return;setBusy(label);setMessage('')
    try{const result=await work();setMessage(result?.message||`${label} completed.`);apiClient.clearCache();await useCustomerStore.getState().refresh()}
    catch(e){setMessage((e as Error).message)}finally{setBusy('');await reload()}
  }
  if(!user)return null
  const outstanding=workspace?.queue.filter(pending)||[]
  return <section aria-label="Device Synchronization" className="rounded-3xl border border-[var(--secondary)]/25 bg-gradient-to-br from-white to-[#FCFAF0] p-5 sm:p-6 space-y-4 shadow-sm">
    <div className="flex flex-wrap items-center justify-between gap-4"><div className="flex items-center gap-3"><span className="rounded-2xl bg-[var(--primary)]/10 p-3"><Tablet className="h-6 w-6 text-[var(--primary)]"/></span><div>
      <h2 className="text-lg font-bold text-[var(--primary)]">Device Sync</h2>
      <p className="mt-1 text-sm text-slate-500">Save here. Sync to your laptop when you’re ready.</p>
    </div></div><span className={`rounded-full px-3 py-1.5 text-xs font-semibold ${connected?'bg-emerald-50 text-emerald-700':'bg-amber-50 text-amber-800'}`}>{connected?'● Laptop database connected':'● Laptop database offline'}</span></div>
    <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl bg-[var(--primary)] p-5 text-white"><div><p className="text-xs text-white/70">Ready to upload</p><p className="mt-1 text-2xl font-bold">{outstanding.length} <span className="text-sm font-normal">pending records</span></p><p className="mt-1 text-xs text-white/70">Last sync: {workspace?.lastSync?new Date(workspace.lastSync).toLocaleDateString('en-IN'):'Not yet'}</p></div>
      <button className="inline-flex items-center gap-2 rounded-xl bg-[#F5E6B8] px-5 py-3 text-sm font-bold text-[var(--primary)] disabled:opacity-50" disabled={!!busy||!workspace||!connected} onClick={()=>run('Synchronization',()=>synchronizeDevice(user))}><RefreshCw size={17} className={busy==='Synchronization'?'animate-spin':''}/>{busy==='Synchronization'?'Synchronizing…':'Sync Now'}</button>
    </div>
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">{[['Customers',outstanding.filter(o=>o.kind==='customer').length],['Kanaku',outstanding.filter(o=>o.kind==='loan').length],['Payments',outstanding.filter(o=>o.kind==='payment').length],['Total pending',outstanding.length]].map(([label,count])=><div key={label} className="rounded-xl bg-[var(--background)] p-3"><p className="text-xs text-slate-500">{label}</p><p className="text-xl font-bold text-[var(--primary)]">{count}</p></div>)}</div>
    <p className="text-sm text-slate-600">{enabled?'Local mode: new entries stay on this device until synced.':'Online mode: entries save directly to the laptop.'}</p>
    {workspace&&<div className="grid gap-2 text-sm sm:grid-cols-3"><p>Last Sync: {workspace.lastSync?new Date(workspace.lastSync).toLocaleString('en-IN'):'Not yet'}</p><p>Snapshot customers: {workspace.snapshot.customers.length.toLocaleString('en-IN')}</p><p>Failed: {outstanding.filter(o=>o.status==='FAILED').length} · Conflicts: {outstanding.filter(o=>o.status==='CONFLICT').length}</p></div>}
    {enabled&&<p className="text-xs text-slate-500">Encrypted last-sync snapshot + pending changes. A successful sync replaces the snapshot and clears confirmed queue entries; the new snapshot stays available offline.</p>}
    <p role="status" className="text-sm text-slate-600">{connectionMessage}. Connect the tablet to the laptop’s network to sync; internet alone is not enough. The HDD stays on the laptop.</p>
    {enabled&&<label className="flex items-center gap-2 text-sm text-[var(--primary)]"><input type="checkbox" defaultChecked={localStorage.getItem(`sf-auto-sync:${user}`)==='on'} onChange={e=>{localStorage.setItem(`sf-auto-sync:${user}`,e.target.checked?'on':'off');window.dispatchEvent(new Event('sf-device-sync-changed'))}}/>Automatically sync saved entries when laptop storage is connected</label>}
    <div className="flex flex-wrap gap-2">
      <button className={button} disabled={!!busy||outstanding.length>0} onClick={()=>run('Prepare device',()=>prepareDevice(user))}>{workspace?'Refresh offline data':'Prepare for offline use'}</button>
      {enabled&&<button className={button} disabled={!!busy||outstanding.length>0} onClick={()=>run('Online mode',()=>disableDevice(user))}>Return to online mode</button>}
      <button className={button+' inline-flex items-center gap-2'} disabled={!!busy||!workspace} onClick={()=>run('Recovery copy',()=>downloadLocalRecovery(user))}><Download size={16}/>Download local recovery copy</button>
    </div>
    <details className="text-xs text-slate-500"><summary className="cursor-pointer">How offline sync works & device safety</summary><p className="mt-2">Prepare this tablet while connected through the same trusted HTTPS address. Sync merges into the laptop’s existing PostgreSQL storage; it never replaces the database. Device: {workspace?.deviceId||'Not prepared'}.</p><p className="mt-2 text-amber-800">Clearing site data, uninstalling the browser, or losing the device can erase unsynced records. Download recovery copies. Kanaku numbers are provisional until synced. Deletion requires online mode. Open the pages you need before leaving and verify they open with Wi-Fi off.</p></details>
    {message&&<p role="status" className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm whitespace-pre-wrap">{message}</p>}
    <details className="rounded-xl border border-slate-200 p-3"><summary className="cursor-pointer font-semibold text-sm">Pending records ({outstanding.length})</summary>
      {!outstanding.length&&<p className="mt-2 text-sm text-slate-500">No pending records on this browser.</p>}
      {outstanding.map(op=><div key={op.id} className="mt-3 rounded-xl bg-[var(--background)] p-3 text-sm space-y-2">
        <p className="font-semibold">{op.kind} · {op.data.full_name||`Customer ${workspace?.snapshot.customers.find(c=>String(c.id)===op.customerId)?.full_name||op.customerId}`} · {op.status}</p>
        <p>{new Date(op.recordedAt).toLocaleString('en-IN')}{op.kind==='payment'?` · ₹${op.data.amount} · ${op.data.payment_date}`:''}</p>
        {op.error&&<p className="text-red-700">{op.error}</p>}
        {op.status==='CONFLICT'&&<><div className="grid gap-2 md:grid-cols-2"><details><summary>Tablet version</summary><pre className="max-h-52 overflow-auto text-xs whitespace-pre-wrap">{JSON.stringify(op.data,null,2)}</pre></details><details><summary>Laptop version</summary><pre className="max-h-52 overflow-auto text-xs whitespace-pre-wrap">{JSON.stringify(op.serverRecord,null,2)}</pre></details></div>
          <button className={button} disabled={!!busy||!op.serverRevision} onClick={()=>run('Conflict review',()=>resolveConflict(user,op.id,'tablet'))}>Use Tablet Version</button>{' '}
          <button className={button} disabled={!!busy} onClick={()=>{if(window.confirm('Keep the laptop version? This tablet operation will not be uploaded. Its original contents remain in local history.'))void run('Conflict review',()=>resolveConflict(user,op.id,'laptop'))}}>Use Laptop Version</button></>}
      </div>)}
    </details>
    <details className="rounded-xl border border-slate-200 p-3"><summary className="cursor-pointer font-semibold text-sm">Sync History</summary>
      {!workspace?.history.length&&<p className="mt-2 text-sm text-slate-500">No synchronization attempts yet.</p>}
      {workspace?.history.map((h,i)=><p key={i} className="mt-3 border-t pt-2 text-xs text-slate-600">{new Date(h.date).toLocaleString('en-IN')} · {h.synced} confirmed · {h.duplicates} duplicate retries skipped · {h.failed} failed · {h.conflicts} conflicts<br/>{h.message}</p>)}
      {workspace?.queue.filter(o=>o.discarded).map(o=><details key={o.id} className="mt-2 text-xs"><summary>Kept laptop version · {o.kind} · {o.recordedAt}</summary><pre className="whitespace-pre-wrap">{JSON.stringify(o.data,null,2)}</pre></details>)}
    </details>
  </section>
}
