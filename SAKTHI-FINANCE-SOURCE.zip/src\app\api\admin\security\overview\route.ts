import { NextResponse } from 'next/server';
import { requireOwner } from '@/lib/api-utils';
import { dbQuery } from '@/server/database';

export const dynamic = 'force-dynamic';

const SECURITY_ACTIONS = [
  'LOGIN',
  'LOGIN_FAILED',
  'LOGOUT',
  'ROLE_CHANGED',
  'USER_STATUS_CHANGED',
  'DEVICE_LOGOUT',
  'UNAUTHORIZED_ACCESS',
  'SETTINGS_UPDATED',
  'USER_CREATED',
];

/**
 * Security overview aggregates for the Admin Access Security page.
 * Owner-only (Admin and Customer get 403). Empty tables yield zeros.
 */
export async function GET() {
  const auth = await requireOwner();
  if (auth.error) return auth.error;

  try {
    const [users, activeUsers, sessions, failed, events] = await Promise.all([
      dbQuery(`SELECT COUNT(*) AS c FROM users`),
      dbQuery(`SELECT COUNT(*) AS c FROM users WHERE is_active IS NOT FALSE`),
      dbQuery(`SELECT COUNT(*) AS c FROM refresh_tokens WHERE revoked_at IS NULL AND expires_at > NOW()`),
      dbQuery(`SELECT COUNT(*) AS c FROM audit_events WHERE action = 'LOGIN_FAILED'`),
      dbQuery(
        `SELECT created_at, action, performed_by, user_role, result
         FROM audit_events
         WHERE action = ANY($1)
         ORDER BY created_at DESC, seq DESC
         LIMIT 20`,
        [SECURITY_ACTIONS]
      ),
    ]);
    return NextResponse.json({
      totalUsers: Number(users.rows[0]?.c) || 0,
      activeUsers: Number(activeUsers.rows[0]?.c) || 0,
      activeSessions: Number(sessions.rows[0]?.c) || 0,
      failedLogins: Number(failed.rows[0]?.c) || 0,
      securityEvents: Array.isArray(events.rows) ? events.rows : [],
    });
  } catch (err: any) {
    console.error('[GET /api/admin/security/overview] Error:', err?.message || err);
    return NextResponse.json(
      { error: 'Unable to load security overview. Please try again.' },
      { status: 500 }
    );
  }
}
