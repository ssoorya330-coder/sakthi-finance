'use client'

import {
  forwardRef,
  useRef,
  useCallback,
  type ReactNode,
  type InputHTMLAttributes,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from 'react'
import { cn } from '@/lib/utils'

/*
 * ── Alignment constants ──
 *
 *   ┌──────┬────────────────────────────┐
 *   │ Icon │  Placeholder / Input Text   │
 *   └──────┴────────────────────────────┘
 *   ^16px  ^48px
 *   |20px|
 *
 * Icon : left-4 (16px), 20×20, vertically centered, pointer-events-none
 * Input: pl-12 (48px) when icon present, h-12 (48px), rounded-xl
 *
 * IMPORTANT: NEVER combine px-* with pl-* or pr-* in the same class list.
 *   tailwind-merge treats them as separate sub-groups and won't resolve
 *   the conflict. Use explicit pl-12 pr-4 instead of px-4 when an icon
 *   is present.
 */

const ICON_CENTER =
  'pointer-events-none absolute left-4 top-1/2 z-10 flex h-5 w-5 -translate-y-1/2 items-center justify-center'

const ICON_TOP =
  'pointer-events-none absolute left-4 top-4 z-10 flex h-5 w-5 items-center justify-center'

/* ─── IconInput ─── */

export interface IconInputProps
  extends InputHTMLAttributes<HTMLInputElement> {
  icon?: ReactNode
  error?: string | boolean
  rightAction?: ReactNode
}

export const IconInput = forwardRef<HTMLInputElement, IconInputProps>(
  ({ icon, error, className, disabled, rightAction, ...props }, ref) => {
    const hasRightAction = !!rightAction
    const padding = icon ? 'pl-12' : 'px-4'
    const rightPad = hasRightAction ? 'pr-[50px]' : 'pr-4'
    const state = error
      ? 'border-red-400 focus:border-red-500 focus:ring-2 focus:ring-red-100'
      : 'border-slate-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100'
    const disabledCls = disabled ? 'bg-slate-50 text-slate-500 cursor-not-allowed' : ''

    return (
      <div className="relative w-full">
        {icon && <span className={ICON_CENTER}>{icon}</span>}
        <input
          ref={ref}
          disabled={disabled}
          className={cn(
            'w-full h-[44px] rounded-xl border bg-white text-sm text-slate-900 placeholder:text-slate-400 outline-none transition-all duration-200',
            padding,
            rightPad,
            state,
            disabledCls,
            className,
          )}
          {...props}
        />
        {rightAction && (
          <div className="absolute right-1.5 top-1/2 z-10 -translate-y-1/2">
            {rightAction}
          </div>
        )}
      </div>
    )
  },
)
IconInput.displayName = 'IconInput'

/* ─── IconSelect ─── */

export interface IconSelectProps
  extends SelectHTMLAttributes<HTMLSelectElement> {
  icon?: ReactNode
  error?: string | boolean
}

export const IconSelect = forwardRef<HTMLSelectElement, IconSelectProps>(
  ({ icon, error, className, disabled, children, ...props }, ref) => {
    const basePadding = icon ? 'pl-12 pr-10' : 'px-4 pr-10'
    const state = error
      ? 'border-red-400 focus:border-red-500 focus:ring-2 focus:ring-red-100'
      : 'border-slate-200 focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/10'
    const disabledCls = disabled ? 'bg-slate-50 text-slate-500 cursor-not-allowed' : ''

    return (
      <div className="relative w-full">
        {icon && <span className={ICON_CENTER}>{icon}</span>}
        <select
          ref={ref}
          disabled={disabled}
          className={cn(
            'w-full h-12 rounded-xl border bg-white text-sm text-slate-900 placeholder:text-slate-400 outline-none transition-all duration-200 appearance-none cursor-pointer',
            basePadding,
            state,
            disabledCls,
            className,
          )}
          {...props}
        >
          {children}
        </select>
        <svg
          className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
          viewBox="0 0 20 20"
          fill="currentColor"
        >
          <path
            fillRule="evenodd"
            d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z"
            clipRule="evenodd"
          />
        </svg>
      </div>
    )
  },
)
IconSelect.displayName = 'IconSelect'

/* ─── IconTextarea ─── */

export interface IconTextareaProps
  extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  icon?: ReactNode
  error?: string | boolean
  maxHeight?: number
}

export const IconTextarea = forwardRef<HTMLTextAreaElement, IconTextareaProps>(
  ({ icon, error, className, disabled, maxHeight = 220, ...props }, ref) => {
    const padding = icon ? 'pl-12 pr-4' : 'px-4'
    const state = error
      ? 'border-red-400 focus:border-red-500 focus:ring-2 focus:ring-red-100'
      : 'border-slate-200 focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/10'
    const disabledCls = disabled ? 'bg-slate-50 text-slate-500 cursor-not-allowed' : ''

    const internalRef = useRef<HTMLTextAreaElement | null>(null)

    const setMergedRef = useCallback(
      (node: HTMLTextAreaElement | null) => {
        internalRef.current = node
        if (typeof ref === 'function') ref(node)
        else if (ref) (ref as React.MutableRefObject<HTMLTextAreaElement | null>).current = node
        if (node) {
          node.style.height = 'auto'
          node.style.height = `${Math.min(node.scrollHeight, maxHeight)}px`
        }
      },
      [ref, maxHeight],
    )

    const handleInput = useCallback(
      (e: React.FormEvent<HTMLTextAreaElement>) => {
        const el = e.currentTarget
        el.style.height = 'auto'
        el.style.height = `${Math.min(el.scrollHeight, maxHeight)}px`
      },
      [maxHeight],
    )

    return (
      <div className="relative w-full">
        {icon && <span className={ICON_TOP}>{icon}</span>}
        <textarea
          ref={setMergedRef}
          disabled={disabled}
          className={cn(
            'w-full rounded-xl border bg-white py-3 text-sm text-slate-900 placeholder:text-slate-400 outline-none transition-all duration-200 resize-none overflow-y-auto min-h-[44px]',
            padding,
            state,
            disabledCls,
            className,
          )}
          onInput={handleInput}
          rows={1}
          {...props}
        />
      </div>
    )
  },
)
IconTextarea.displayName = 'IconTextarea'
