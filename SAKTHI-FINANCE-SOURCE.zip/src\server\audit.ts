import crypto from 'crypto';
import { notifyAuditEvent } from './notification-events';
import { getPool, ensureSchema } from './database';

/**
 * Tamper-evident audit trail (append-only).
 *
 * Every record carries event_hash = SHA-256 over (previous hash + record
 * content), forming a hash chain that detects later modification or
 * deletion. This is tamper-EVIDENT detection — it does not claim
 * cryptographic immutability against a database superuser.
 *
 * Records are append-only: this module exposes no update/delete path.
 * Corrections are recorded as NEW events (e.g. PAYMENT_CORRECTED).
 */

export interface AuditQueryable {
  query: (text: string, params?: any[]) => Promise<{ rows: any[] }>;
}

export interface AuditActor {
  userId: string | null;
  name: string | null;
  role: string | null;
}

export interface AuditChange {
  field: string;
  label: string;
  before: any;
  after: any;
}

export interface RecordAuditInput {
  action: string;
  entityType: string;
  entityId?: string | number | null;
  customerId?: string | number | null;
  loanId?: string | number | null;
  paymentId?: string | number | null;
  actor: AuditActor;
  ipAddress?: string | null;
  clientInfo?: string | null;
  source?: string;
  reason?: string | null;
  result?: string;
  changes?: AuditChange[];
  before?: Record<string, any> | null;
  after?: Record<string, any> | null;
}

const strOrNull = (v: any): string | null =>
  v === undefined || v === null || v === '' ? null : String(v);

/** Keys that must never be written to the audit trail. */
const SECRET_KEY_RE = /passw|passwd|secret|token|otp|pin|api[_-]?key|private[_-]?key|session|credential|authorization/i;

function stripSecretsDeep(value: any): any {
  if (Array.isArray(value)) return value.map(stripSecretsDeep);
  if (value && typeof value === 'object' && !(value instanceof Date)) {
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(value)) {
      out[k] = SECRET_KEY_RE.test(k) ? '[REDACTED]' : stripSecretsDeep(v);
    }
    return out;
  }
  return value;
}

function valuesEqual(a: any, b: any): boolean {
  const na = a === null || a === undefined || a === '' ? null : a;
  const nb = b === null || b === undefined || b === '' ? null : b;
  if (na === null && nb === null) return true;
  if (typeof na === 'number' || typeof nb === 'number') return Number(na) === Number(nb);
  if (na instanceof Date || nb instanceof Date) {
    return new Date(na as any).getTime() === new Date(nb as any).getTime();
  }
  return String(na) === String(nb);
}

/**
 * Field-level diff between two row snapshots. Only fields present in
 * `fields` (or all shared keys when omitted) are compared.
 */
export function diffRecords(
  before: Record<string, any> | null | undefined,
  after: Record<string, any> | null | undefined,
  fields?: string[],
  labels?: Record<string, string>
): AuditChange[] {
  if (!before && !after) return [];
  const keys = fields || Array.from(new Set([...Object.keys(before || {}), ...Object.keys(after || {})]));
  const skip = new Set(['updated_at', 'created_at', 'user_id']);
  const out: AuditChange[] = [];
  for (const key of keys) {
    if (skip.has(key)) continue;
    const b = before ? (before as any)[key] : undefined;
    const a = after ? (after as any)[key] : undefined;
    if (valuesEqual(b, a)) continue;
    out.push({
      field: key,
      label: (labels && labels[key]) || key,
      before: b === undefined || b === null || b === '' ? null : b,
      after: a === undefined || a === null || a === '' ? null : a,
    });
  }
  return out;
}

export const CUSTOMER_LABELS: Record<string, string> = {
  full_name: 'Full Name',
  customer_code: 'Customer ID',
  phone_number: 'Phone',
  alternate_phone: 'Alternate Phone',
  address: 'Address',
  area_name: 'Area',
  city_name: 'City',
  business_name: 'Business',
  income: 'Income',
  status: 'Status',
};

export const LOAN_LABELS: Record<string, string> = {
  loan_amount: 'Loan Amount',
  interest_rate: 'Interest Rate',
  interest_amount: 'Interest Amount',
  total_amount: 'Total Amount',
  installment: 'Installment',
  installment_amount: 'Installment Amount',
  balance_amount: 'Balance Amount',
  received_amount: 'Received Amount',
  duration: 'Duration',
  loan_type: 'Loan Type',
  loan_date: 'Loan Date',
  disbursal_mode: 'Disbursal Mode',
  due_date: 'Due Date',
  remaining_days: 'Remaining Days',
  status: 'Status',
  notes: 'Notes',
  abort_reason: 'Abort Reason',
};

export const PAYMENT_LABELS: Record<string, string> = {
  amount: 'Amount',
  payment_date: 'Payment Date',
  payment_time: 'Payment Time',
  payment_method: 'Payment Method',
  payment_mode: 'Payment Mode',
  remarks: 'Remarks',
};

function hashEvent(parts: Array<string | null>): string {
  return crypto.createHash('sha256').update(parts.map((p) => p ?? '').join('|'), 'utf8').digest('hex');
}

function auditIdFor(seq: number, createdAt: Date): string {
  const d = createdAt instanceof Date ? createdAt : new Date(createdAt);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `AUD-${y}${m}${day}-${String(seq).padStart(6, '0')}`;
}

/**
 * Append one audit event. `q` may be a transaction client (the event then
 * commits/rolls back with the business change) or a pool wrapper.
 */
export async function recordAuditEvent(q: AuditQueryable, input: RecordAuditInput): Promise<any> {
  const prevRow = await q.query(`SELECT event_hash FROM audit_events ORDER BY seq DESC LIMIT 1`);
  const prevHash: string | null = prevRow.rows[0]?.event_hash ?? 'GENESIS';

  const changes = input.changes || [];
  const before = input.before ? stripSecretsDeep(input.before) : null;
  const after = input.after ? stripSecretsDeep(input.after) : null;
  const result = input.result || 'SUCCESS';
  const action = String(input.action || '').slice(0, 80);
  const entityType = String(input.entityType || '').slice(0, 40);

  const inserted = await q.query(
    `INSERT INTO audit_events
      (action, entity_type, entity_id, customer_id, loan_id, payment_id,
       performed_by, user_id, user_role, ip_address, client_info, source,
       reason, result, changes, before_data, after_data, prev_hash)
     VALUES
      ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15::jsonb,$16::jsonb,$17::jsonb,$18)
     RETURNING seq, created_at`,
    [
      action,
      entityType,
      strOrNull(input.entityId),
      strOrNull(input.customerId),
      strOrNull(input.loanId),
      strOrNull(input.paymentId),
      (input.actor.name || input.actor.userId || 'System')?.slice(0, 200),
      strOrNull(input.actor.userId),
      strOrNull(input.actor.role),
      strOrNull(input.ipAddress)?.slice(0, 64),
      strOrNull(input.clientInfo)?.slice(0, 300),
      (input.source || 'app').slice(0, 40),
      strOrNull(input.reason)?.slice(0, 1000),
      result.slice(0, 20),
      JSON.stringify(changes.map((c) => ({ field: c.field, label: c.label, before: c.before ?? null, after: c.after ?? null }))),
      before ? JSON.stringify(before) : null,
      after ? JSON.stringify(after) : null,
      prevHash,
    ]
  );
  const seq: number = inserted.rows[0].seq;
  const createdAt: Date = inserted.rows[0].created_at;
  const auditId = auditIdFor(seq, createdAt);
  const eventHash = hashEvent([
    prevHash,
    auditId,
    action,
    entityType,
    strOrNull(input.entityId),
    strOrNull(input.customerId),
    strOrNull(input.actor.userId),
    (input.actor.name || input.actor.userId || 'System')?.slice(0, 200),
    createdAt instanceof Date ? createdAt.toISOString() : new Date(createdAt).toISOString(),
    JSON.stringify(changes.map((c) => ({ field: c.field, label: c.label, before: c.before ?? null, after: c.after ?? null }))),
    result,
  ]);
  await q.query(`UPDATE audit_events SET audit_id = $1, event_hash = $2 WHERE seq = $3`, [auditId, eventHash, seq]);
  await notifyAuditEvent(q, input);
  return { seq, audit_id: auditId, created_at: createdAt, event_hash: eventHash };
}

const poolQueryable = (): AuditQueryable => ({
  query: (text: string, params?: any[]) => getPool().query(text, params).then((r) => ({ rows: r.rows })),
});

/**
 * Standalone (non-transactional) append. Best-effort: resolves null on
 * failure so a failed audit write never breaks the business operation
 * that already succeeded. Transactional paths should use recordAuditEvent
 * with the transaction client instead.
 */
export async function recordAuditStandalone(input: RecordAuditInput): Promise<any | null> {
  try {
    await ensureSchema();
    const client = await getPool().connect();
    try {
      await client.query('BEGIN');
      const row = await recordAuditEvent(
        { query: (t: string, p?: any[]) => client.query(t, p).then((r) => ({ rows: r.rows })) },
        input
      );
      await client.query('COMMIT');
      return row;
    } catch (e) {
      try {
        await client.query('ROLLBACK');
      } catch {}
      throw e;
    } finally {
      client.release();
    }
  } catch (e: any) {
    console.warn('[Audit] Failed to record event:', e?.message || e);
    return null;
  }
}

export function actorFromAuthUser(user: { userId?: string; email?: string; name?: string; role?: string } | null | undefined): AuditActor {
  if (!user) return { userId: null, name: 'System', role: null };
  return {
    userId: user.userId || null,
    name: user.name || user.email || user.userId || 'System',
    role: user.role || null,
  };
}

export function requestMeta(request: { headers: { get: (k: string) => string | null } }): {
  ip: string | null;
  client: string | null;
} {
  try {
    const ip =
      request.headers.get('x-forwarded-for')?.split(',')[0].trim() ||
      request.headers.get('x-real-ip') ||
      null;
    const ua = request.headers.get('user-agent') || null;
    return { ip, client: ua ? ua.slice(0, 300) : null };
  } catch {
    return { ip: null, client: null };
  }
}

/**
 * Recompute the hash chain and report integrity. Walks in seq order in
 * batches so large histories don't exhaust memory.
 */
export async function verifyAuditChain(opts?: { batchSize?: number; maxEvents?: number }): Promise<{
  ok: boolean;
  checked: number;
  total: number;
  failedAtSeq: number | null;
  failedAuditId: string | null;
  message: string;
}> {
  const batchSize = Math.min(Math.max(opts?.batchSize || 2000, 100), 10000);
  const maxEvents = opts?.maxEvents || 200000;
  await ensureSchema();
  const totalRes = await getPool().query(`SELECT COUNT(*) AS c FROM audit_events`);
  const total = Number(totalRes.rows[0]?.c) || 0;
  let prev: string | null = null;
  let checked = 0;
  let lastSeq = 0;
  for (;;) {
    const res = await getPool().query(
      `SELECT seq, audit_id, action, entity_type, entity_id, customer_id,
              performed_by, user_id, created_at, changes, result, prev_hash, event_hash
       FROM audit_events WHERE seq > $1 ORDER BY seq ASC LIMIT $2`,
      [lastSeq, batchSize]
    );
    if (res.rows.length === 0) break;
    for (const r of res.rows) {
      if (checked >= maxEvents) {
        return {
          ok: true,
          checked,
          total,
          failedAtSeq: null,
          failedAuditId: null,
          message: `Checked first ${checked.toLocaleString()} of ${total.toLocaleString()} events — all valid.`,
        };
      }
      const expectedPrev = prev === null ? 'GENESIS' : prev;
      if ((r.prev_hash ?? 'GENESIS') !== expectedPrev) {
        return {
          ok: false,
          checked,
          total,
          failedAtSeq: r.seq,
          failedAuditId: r.audit_id,
          message: `Chain link broken at ${r.audit_id || `seq ${r.seq}`} — a record may have been modified or removed.`,
        };
      }
      const changesJson = JSON.stringify(
        (Array.isArray(r.changes) ? r.changes : []).map((c: any) => ({
          field: c.field,
          label: c.label,
          before: c.before ?? null,
          after: c.after ?? null,
        }))
      );
      const expected = hashEvent([
        expectedPrev,
        r.audit_id,
        r.action,
        r.entity_type,
        r.entity_id,
        r.customer_id,
        r.user_id,
        r.performed_by,
        new Date(r.created_at).toISOString(),
        changesJson,
        r.result,
      ]);
      if (expected !== r.event_hash) {
        return {
          ok: false,
          checked,
          total,
          failedAtSeq: r.seq,
          failedAuditId: r.audit_id,
          message: `Content hash mismatch at ${r.audit_id || `seq ${r.seq}`} — the record may have been modified.`,
        };
      }
      prev = r.event_hash;
      lastSeq = r.seq;
      checked += 1;
    }
    if (res.rows.length < batchSize) break;
  }
  // Gap detection: a deleted TAIL is invisible to the chain walk above only
  // if it is also the newest... actually any deletion breaks linkage except
  // deleting the newest rows. Report the newest hash so reviewers can compare
  // across exports/backups.
  return {
    ok: true,
    checked,
    total,
    failedAtSeq: null,
    failedAuditId: null,
    message:
      total === 0
        ? 'No audit events recorded yet.'
        : `All ${checked.toLocaleString()} events verified — chain intact.`,
  };
}
