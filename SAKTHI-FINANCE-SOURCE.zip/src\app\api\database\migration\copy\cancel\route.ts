import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { cancelCopyJob } from '@/server/migration-copy'

export const dynamic = 'force-dynamic'

/** Cancel a running automatic copy. Never touches PostgreSQL or any data. */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const jobId = (body.jobId || '').trim()
    if (!jobId) return NextResponse.json({ error: 'Copy job id is required.' }, { status: 400 })
    return NextResponse.json({ ok: cancelCopyJob(jobId) })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: 'Cancel failed', details: err.message }, { status: 500 })
  }
}
