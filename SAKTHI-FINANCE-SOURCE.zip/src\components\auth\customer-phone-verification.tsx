'use client'

import { useState } from 'react'
import { Loader2, Phone } from 'lucide-react'
import { useAuthStore } from '@/store/auth-store'

export function CustomerPhoneVerification({ user, onVerified }: { user: { id: string; email: string; name: string }; onVerified: () => void }) {
  const setUser = useAuthStore((state) => state.setUser)
  const [phone, setPhone] = useState('')
  const [code, setCode] = useState('')
  const [appCode, setAppCode] = useState('')
  const [sent, setSent] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  async function submit(action: 'request' | 'verify') {
    setBusy(true); setError('')
    try {
      const response = await fetch('/api/auth/customer-phone-otp', {
        method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, phone, ...(action === 'verify' ? { code } : {}) }),
      })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'Unable to verify this phone number.')
      if (action === 'request') { setSent(true); setAppCode(data.applicationCode || ''); }
      else {
        const linkResponse = await fetch('/api/customer/link', {
          method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phone }),
        })
        const linkData = await linkResponse.json()
        if (!linkResponse.ok) throw new Error(linkData.error || 'Unable to link this customer account.')
        setUser({ userId: user.id, email: user.email, name: user.name, role: 'customer' })
        onVerified()
      }
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to verify this phone number.') }
    finally { setBusy(false) }
  }

  const inputClass = 'mt-1.5 w-full rounded-xl border border-[#E8E5E0] px-3 py-3 text-sm text-[var(--text-primary)] outline-none focus:ring-2 focus:ring-[var(--primary)]/30 disabled:bg-slate-50'
  return <section aria-labelledby="customer-phone-title" className="mb-6">
    <h3 id="customer-phone-title" className="font-semibold text-[var(--text-primary)] flex items-center gap-2"><Phone className="h-4 w-4" />Verify your mobile number</h3>
    <p className="text-sm text-[#6A6A72] mt-2 mb-5">Google sign-in succeeded. Confirm the mobile number registered to your customer account.</p>
    <form onSubmit={(event) => { event.preventDefault(); void submit(sent ? 'verify' : 'request') }} className="space-y-4">
      <label className="block text-sm font-medium text-[var(--text-primary)]" htmlFor="customer-phone">Phone number
        <input id="customer-phone" type="tel" autoComplete="tel" required disabled={sent || busy} value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="Registered mobile number" className={inputClass} />
      </label>
      {sent && <>
        <div className="rounded-xl border border-[var(--secondary)]/50 bg-[#FFFBEA] p-3 text-sm text-[#5D4A00]">Application verification code: <strong className="tracking-[0.25em]">{appCode}</strong></div>
        <label className="block text-sm font-medium text-[var(--text-primary)]" htmlFor="customer-phone-code">Enter the code
          <input id="customer-phone-code" inputMode="numeric" autoComplete="one-time-code" required pattern="[0-9]{6}" maxLength={6} autoFocus disabled={busy} value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, ''))} className={inputClass} />
        </label>
      </>}
      {error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}
      <button type="submit" disabled={busy} className="w-full flex justify-center items-center gap-2 rounded-xl bg-[var(--primary)] py-3 text-sm font-semibold text-white hover:bg-[#641717] disabled:opacity-50">{busy && <Loader2 className="h-4 w-4 animate-spin" />}{busy ? 'Please wait…' : sent ? 'Verify and continue' : 'Generate verification code'}</button>
    </form>
  </section>
}
