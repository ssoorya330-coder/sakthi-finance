/**
 * Usage: node scripts/desktop-electron/cdp-eval.mjs '<expression>' [--target=app|oauth|page:N]
 * Evaluates an expression in a live Electron renderer over CDP.
 * Default target: the app:// main window (falls back to the first page).
 */
import { get } from 'node:http'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const WebSocket = require('ws')

const args = process.argv.slice(2)
const targetArg = args.find((a) => a.startsWith('--target=')) ?? '--target=app'
const expr = args.filter((a) => !a.startsWith('--target=')).join(' ') || 'document.title'

function fetchJson(url) {
  return new Promise((resolve, reject) => {
    get(url, (res) => {
      let data = ''
      res.on('data', (c) => (data += c))
      res.on('end', () => resolve(JSON.parse(data)))
    }).on('error', reject)
  })
}

const targets = await fetchJson('http://127.0.0.1:9222/json')
const pages = targets.filter((t) => t.type === 'page')
let page
if (targetArg === '--target=app') {
  page = pages.find((t) => t.url.startsWith('app://')) ?? pages[0]
} else if (targetArg === '--target=oauth') {
  page = pages.find((t) => t.url.startsWith('https://accounts.google.com')) ?? pages[0]
} else {
  page = pages[Number(targetArg.split(':')[1] ?? 0)] ?? pages[0]
}
if (!page) {
  console.error('No page target found')
  process.exit(1)
}

const ws = new WebSocket(page.webSocketDebuggerUrl)
const result = await new Promise((resolve, reject) => {
  const timeout = setTimeout(() => reject(new Error('CDP eval timed out')), 15000)
  ws.on('open', () => {
    ws.send(JSON.stringify({ id: 1, method: 'Runtime.evaluate', params: { expression: expr, returnByValue: true, awaitPromise: true } }))
  })
  ws.on('message', (raw) => {
    const msg = JSON.parse(raw.toString())
    if (msg.id === 1) {
      clearTimeout(timeout)
      if (msg.error) reject(new Error(msg.error.message))
      else resolve(msg.result)
    }
  })
  ws.on('error', reject)
})
ws.close()

if (result.exceptionDetails) {
  console.error('Exception:', result.exceptionDetails.exception?.description ?? result.exceptionDetails.text)
  process.exit(1)
}
console.log(JSON.stringify(result.result?.value, null, 2))
