import { calculateKanaku } from '@/lib/kanaku'
import type { Row, SyncOperation, SyncSnapshot, SyncWorkspace } from './types'

const cents = (v: unknown) => Math.round(Number(v || 0) * 100)
const same = (a: unknown, b: unknown) => String(a) === String(b)
export const pending = (op: SyncOperation) => op.status !== 'SYNCED' && !op.discarded
export function loanGroup(snapshot: SyncSnapshot, customerId: string) {
  const customer = snapshot.customers.find(c => same(c.id, customerId))
  const normalized = (v: unknown) => String(v || '').trim().toLowerCase().replace(/\s+/g,' ')
  const match = (c: Row) => customer && ['full_name','phone_number','city_name','business_name'].every(k => normalized(c[k]) === normalized(customer[k]))
  const ids = new Set(snapshot.customers.filter(c => same(c.id,customerId) || match(c)).map(c => String(c.id)))
  return snapshot.loans.filter(l => ids.has(String(l.customer_id)))
}
function recalculate(s: SyncSnapshot, customerId: string) {
  for (const l of s.loans.filter(l=>same(l.customer_id,customerId))) {
    l.paid_amount = (cents(l.snapshot_paid_amount ?? l.legacy_paid_amount) + s.payments.filter(p => same(p.loan_id,l.loan_id)).reduce((n,p) => n+cents(p.amount),0))/100
    l.outstanding = Math.max(0,cents(l.total_amount)-cents(l.paid_amount))/100
    if (!l.outstanding && ['Active','Overdue'].includes(l.status)) l.status='Completed'
    else if(l.outstanding>0&&l.status==='Completed')l.status='Active'
  }
  for (const c of s.customers.filter(c=>same(c.id,customerId))) {
    const loans = s.loans.filter(l => same(l.customer_id,c.id))
    if (!loans.length) continue
    const chosen = loans.find(l => l.outstanding>0 && ['Active','Overdue'].includes(l.status)) || loans[loans.length-1]
    for (const key of ['loan_id','loan_date','due_date','loan_type','duration','interest_rate','installment_amount','cycle_number','kanaku_number']) c[key]=chosen[key]
    for (const key of ['loan_amount','interest_amount','total_amount']) c[key]=loans.reduce((n,l) => n+Number(l[key]||0),0)
    c.loan_count=loans.length
    c.schedules=loans.map(l=>({loanDate:l.loan_date,dueDate:l.due_date,loanType:l.loan_type,duration:l.duration}))
    if(c.status!=='Aborted')c.status=loans.every(l=>cents(l.outstanding)===0&&l.status!=='Aborted')?'Completed':loans.some(l=>cents(l.outstanding)>0&&l.status!=='Aborted')?'Active':chosen.status
  }
}
export function applyLocal(s: SyncSnapshot, op: SyncOperation) {
  const d=structuredClone(op.data)
  if (op.kind==='customer') {
    const names={area_name:d.area,city_name:d.city,business_name:d.business}
    if(op.method==='POST') {
      s.customers.push({...d,...names,id:op.recordId,customer_code:`Pending-${op.recordId.slice(0,8)}`,user_id:s.userId,created_at:op.recordedAt,updated_at:op.recordedAt})
      const loanOp={...op,kind:'loan' as const,recordId:d.__localLoanId,customerId:op.recordId}
      applyLocal(s,loanOp)
      const initial=s.loans.find(l=>l.loan_id===d.__localLoanId)!
      for(const field of ['loan_amount','interest_rate','interest_amount','total_amount','installment_amount','remaining_days','loan_date','due_date','duration','loan_type','status'])if(d[field]!==undefined)initial[field]=d[field]
    } else {
      const c=s.customers.find(c=>same(c.id,op.recordId)); if(!c) throw new Error('Customer not available offline.')
      Object.assign(c,d,Object.fromEntries(Object.entries(names).filter(([,v])=>v!==undefined)),{updated_at:op.recordedAt})
      const loans=s.loans.filter(l=>same(l.customer_id,c.id))
      if(loans.length===1) {
        const loan=loans[0]
        for(const k of ['loan_amount','interest_rate','interest_amount','total_amount','loan_date','due_date','duration','loan_type','installment_amount','status','abort_reason']) if(d[k]!==undefined) loan[k]=d[k]
      }
    }
  } else if(op.kind==='loan') {
    if(op.method==='POST') {
      const v=calculateKanaku(d), group=loanGroup(s,op.customerId)
      const current=Math.max(1,...group.map(l=>Number(l.cycle_number)||1))
      const currentLoans=group.filter(l=>Number(l.cycle_number)===current)
      const closed=currentLoans.length>0&&currentLoans.every(l=>l.status==='Completed'&&cents(l.outstanding)===0)
      const cycle=closed?current+1:current
      const number=1+Math.max(0,...group.filter(l=>Number(l.cycle_number)===cycle).map(l=>Number(l.kanaku_number)||0))
      s.loans.push({...d,loan_id:op.recordId,customer_id:op.customerId,user_id:s.userId,cycle_number:cycle,kanaku_number:number,
        loan_amount:v.amount,interest_amount:v.interest,total_amount:v.total,installment:v.installment,installment_amount:v.installment,
        due_date:v.dueDate,status:'Active',legacy_paid_amount:0,created_at:op.recordedAt,updated_at:op.recordedAt})
    } else {
      const l=s.loans.find(l=>same(l.loan_id,op.recordId)); if(!l)throw new Error('Kanaku not available offline.')
      if(d.status==='Completed'&&cents(l.outstanding)>0)throw new Error('Receive the outstanding amount before completing this Kanaku.')
      Object.assign(l,d,{updated_at:op.recordedAt})
    }
  } else {
    if(!/^\d+(\.\d{1,2})?$/.test(String(d.amount))||cents(d.amount)<=0)throw new Error('Enter a positive amount with up to two decimal places.')
    if(!/^\d{4}-\d{2}-\d{2}$/.test(String(d.payment_date)))throw new Error('Payment date is required.')
    const previous=s.payments.find(p=>same(p.payment_id,op.recordId))
    const loan=s.loans.find(l=>same(l.loan_id,d.loan_id||previous?.loan_id))
    if(!loan||!same(loan.customer_id,op.customerId))throw new Error('Choose a Kanaku belonging to this customer.')
    if(cents(d.amount)>cents(loan.outstanding)+cents(previous?.amount))throw new Error('Received amount exceeds this Kanaku balance.')
    const payment={...previous,...d,payment_id:op.recordId,loan_id:loan.loan_id,customer_id:op.customerId,user_id:s.userId,created_at:previous?.created_at||op.recordedAt}
    if(previous)Object.assign(previous,payment);else s.payments.push(payment)
  }
  recalculate(s,op.customerId)
}
export function materialize(workspace: SyncWorkspace): SyncSnapshot {
  const result=structuredClone(workspace.snapshot)
  for(const op of workspace.queue.filter(op => pending(op) || (op.status==='SYNCED'&&!op.snapshotApplied&&!op.discarded))) {
    const copy={...op,recordId:workspace.mappings[op.recordId]||op.recordId,customerId:workspace.mappings[op.customerId]||op.customerId,data:{...op.data}}
    if(copy.data.loan_id)copy.data.loan_id=workspace.mappings[copy.data.loan_id]||copy.data.loan_id
    if(copy.data.__localLoanId)copy.data.__localLoanId=workspace.mappings[copy.data.__localLoanId]||copy.data.__localLoanId
    // Conflict entries remain in the queue even when they cannot be applied to
    // the latest server snapshot. Never discard an invalid pending operation.
    try { applyLocal(result,copy) } catch { /* shown for review in Sync */ }
  }
  return result
}
