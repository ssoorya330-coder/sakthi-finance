'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'
import AdminSectionShell, { AdminEmpty, AdminError, AdminLoading } from './AdminSectionShell'

interface SystemRow {
  seq?: number
  audit_id?: string | null
  created_at?: string | null
  action?: string | null
  entity_type?: string | null
  entity_ref?: string | null
  performed_by?: string | null
  user_role?: string | null
  ip_address?: string | null
  reason?: string | null
  result?: string | null
}

const fmtDT = (iso: string | null | undefined) => {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true,
    })
  } catch {
    return '—'
  }
}

export default function SystemActivityContent() {
  const [events, setEvents] = useState<SystemRow[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(true)
  const [failed, setFailed] = useState<null | 'denied' | 'error'>(null)
  const [retrying, setRetrying] = useState(false)
  const [q, setQ] = useState('')
  const mountedRef = useRef(true)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const load = useCallback(async (p: number, query: string, isRetry = false) => {
    if (isRetry) setRetrying(true)
    else setLoading(true)
    setFailed(null)
    try {
      const sp = new URLSearchParams({ kind: 'system', page: String(p), limit: '25' })
      if (query.trim()) sp.set('q', query.trim())
      const res = await fetch(`/api/admin/activity?${sp.toString()}`, { credentials: 'include' })
      if (res.status === 401 || res.status === 403) {
        if (mountedRef.current) setFailed('denied')
        return
      }
      if (!res.ok) throw new Error(`Request failed (${res.status})`)
      const data = await res.json().catch(() => null)
      if (mountedRef.current) {
        setEvents(Array.isArray(data?.events) ? data.events : [])
        setTotal(Number(data?.total) || 0)
        setTotalPages(Number(data?.totalPages) || 1)
        setPage(Number(data?.page) || p)
      }
    } catch {
      if (mountedRef.current) setFailed('error')
    } finally {
      if (mountedRef.current) {
        setLoading(false)
        setRetrying(false)
      }
    }
  }, [])

  useEffect(() => {
    mountedRef.current = true
    load(1, '')
    return () => {
      mountedRef.current = false
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [load])

  const onSearch = (v: string) => {
    setQ(v)
    if (timerRef.current) clearTimeout(timerRef.current)
    timerRef.current = setTimeout(() => load(1, v), 500)
  }

  return (
    <AdminSectionShell title="System Activity" subtitle="View important administrative and system actions" icon="system">
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
        <div className="flex flex-wrap gap-2">
          <input
            value={q}
            onChange={(e) => onSearch(e.target.value)}
            placeholder="Search action, user, entity, IP…"
            className={cn(
              'flex-1 min-w-[200px] px-3 py-2 rounded-xl border border-slate-300 text-sm',
              'focus:ring-2 focus:ring-[var(--primary)]/30 focus:outline-none bg-white'
            )}
          />
          <button onClick={() => load(1, q)} className="px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222]">Apply</button>
          <button onClick={() => { setQ(''); load(1, '') }} className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-medium hover:bg-slate-50">Clear</button>
        </div>
      </div>

      {loading && <AdminLoading />}
      {!loading && failed === 'denied' && (
        <AdminError message="You are not authorized to access this page." onRetry={() => load(page, q, true)} retrying={retrying} />
      )}
      {!loading && failed === 'error' && (
        <AdminError message="Unable to connect to the database. Please try again." onRetry={() => load(page, q, true)} retrying={retrying} />
      )}
      {!loading && !failed &&
        (events.length === 0 ? (
          <AdminEmpty message="No system activity recorded yet" />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-bold text-slate-900">
                System Events <span className="text-slate-400 font-semibold">({total.toLocaleString('en-IN')})</span>
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm min-w-[1020px]">
                <thead>
                  <tr className="bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)] text-left">
                    {['ID', 'Timestamp', 'User', 'Role', 'Action', 'Entity', 'Details', 'IP Address', 'Status'].map((h) => (
                      <th key={h} className="px-3 py-2.5 text-[11px] font-bold uppercase tracking-wider text-[#F3DFA7] whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {events.map((e, i) => (
                    <tr key={e.audit_id || e.seq || i} className="hover:bg-slate-50">
                      <td className="px-3 py-2.5 text-xs font-mono text-slate-500 whitespace-nowrap">
                        {e.audit_id ? `${e.audit_id.slice(0, 8)}…` : e.seq != null ? `#${e.seq}` : '—'}
                      </td>
                      <td className="px-3 py-2.5 text-xs text-slate-600 tabular-nums whitespace-nowrap">{fmtDT(e.created_at)}</td>
                      <td className="px-3 py-2.5 text-xs font-bold text-slate-900 whitespace-nowrap">{e.performed_by || '—'}</td>
                      <td className="px-3 py-2.5 text-xs text-slate-600 capitalize whitespace-nowrap">{e.user_role || '—'}</td>
                      <td className="px-3 py-2.5 text-xs font-semibold text-slate-800 whitespace-nowrap">{(e.action || '—').replace(/_/g, ' ')}</td>
                      <td className="px-3 py-2.5 text-xs text-slate-600 whitespace-nowrap">
                        {e.entity_type || '—'}{e.entity_ref ? ` (${String(e.entity_ref).slice(0, 8)})` : ''}
                      </td>
                      <td className="px-3 py-2.5 text-xs text-slate-500 max-w-[220px] truncate" title={e.reason || ''}>{e.reason || '—'}</td>
                      <td className="px-3 py-2.5 text-xs font-mono text-slate-500 whitespace-nowrap">{e.ip_address || '—'}</td>
                      <td className="px-3 py-2.5">
                        <span className={cn(
                          'inline-flex items-center px-2 py-0.5 rounded-lg text-[11px] font-bold border whitespace-nowrap',
                          e.result === 'FAILED'
                            ? 'bg-red-50 text-red-700 border-red-200'
                            : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        )}>
                          {e.result || '—'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="px-4 py-3 border-t border-slate-100 flex items-center justify-between">
              <p className="text-xs text-slate-500">Page {page} of {totalPages}</p>
              <div className="flex gap-2">
                <button disabled={page <= 1 || loading} onClick={() => load(page - 1, q)} className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold hover:bg-slate-50 disabled:opacity-40">Prev</button>
                <button disabled={page >= totalPages || loading} onClick={() => load(page + 1, q)} className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold hover:bg-slate-50 disabled:opacity-40">Next</button>
              </div>
            </div>
          </div>
        ))}
    </AdminSectionShell>
  )
}
