/**
 * Indian mobile-number normalization shared by the OTP flow (server) and
 * the login UI (client). Pure functions — safe to import anywhere.
 *
 * Canonical form: 10 digits, starting 6–9.
 * Accepted inputs: 9876543210, +919876543210, +91 9876543210, +91-9876543210,
 * 09876543210.
 */

export function normalizePhone(raw: string | null | undefined): string | null {
  if (!raw) return null;
  let digits = String(raw).replace(/\D/g, '');
  if (digits.length === 12 && digits.startsWith('91')) {
    digits = digits.slice(2);
  } else if (digits.length === 11 && digits.startsWith('0')) {
    digits = digits.slice(1);
  }
  if (!/^[6-9]\d{9}$/.test(digits)) return null;
  return digits;
}

/** Last-2-digits masking for logs/audit. Never log full numbers. */
export function maskPhone(normalized: string | null | undefined): string {
  if (!normalized) return 'unknown';
  return `******${normalized.slice(-2)}`;
}
