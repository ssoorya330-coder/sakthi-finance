/** Delete only this app's disposable Cache Storage entries, never IndexedDB or login storage. */
export async function clearAppCache(storage?: Pick<CacheStorage, 'keys' | 'delete'>) {
  if (!storage) return { cleared: 0, failed: 0 };
  const names = (await storage.keys()).filter((name) => name.startsWith('sakthi-finance-') && !name.startsWith('sakthi-finance-offline-'));
  const results = await Promise.allSettled(names.map((name) => storage.delete(name)));
  return {
    cleared: results.filter((result) => result.status === 'fulfilled' && result.value).length,
    failed: results.filter((result) => result.status === 'rejected').length,
  };
}
