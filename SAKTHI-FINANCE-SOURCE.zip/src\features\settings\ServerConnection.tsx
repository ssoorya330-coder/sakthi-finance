'use client'
import { useEffect, useState } from 'react'

export default function ServerConnection() {
  const [url,setUrl]=useState(''),[message,setMessage]=useState('')
  useEffect(()=>{setUrl(localStorage.getItem('sf-server-url')||process.env.NEXT_PUBLIC_SAKTHI_SERVER_URL||location.origin)},[])
  return <section className="mb-4 space-y-3 rounded-2xl border border-[var(--secondary)]/25 bg-white p-5">
    <h2 className="font-bold text-[var(--primary)]">Server Connection</h2>
    <label className="block text-sm">Laptop HTTPS address<input value={url} onChange={e=>setUrl(e.target.value)} className="mt-2 w-full rounded-xl border p-3" placeholder="https://your-laptop-address"/></label>
    <button className="rounded-xl bg-[var(--primary)] px-4 py-2 text-white" onClick={()=>{
      try{const value=new URL(url);if(value.protocol!=='https:'&&!(value.protocol==='http:'&&value.hostname==='localhost'))throw new Error();if(value.username||value.password)throw new Error();localStorage.setItem('sf-server-url',value.origin);setUrl(value.origin);setMessage('Address saved. Access the application at this address before preparing offline use. Existing local data stays with its original address.')}
      catch{setMessage('Enter a trusted HTTPS laptop address, without credentials.')}
    }}>Save address</button>
    <p className="text-xs text-slate-500">Current server: {typeof location!=='undefined'?location.origin:''}. Sync uses this application’s authenticated server. Sync pending work before moving to another address; browser storage does not move between addresses.</p>
    {message&&<p role="status" className="text-sm">{message}</p>}
  </section>
}
