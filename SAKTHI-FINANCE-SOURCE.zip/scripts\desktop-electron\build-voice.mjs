import { mkdir, copyFile, readdir } from 'node:fs/promises'
import { createReadStream } from 'node:fs'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import path from 'node:path'

const source = path.resolve('desktop/voice-runtime')
const native = path.resolve('dist-electron/native')
await mkdir(path.join(native, 'voice'), { recursive: true })
const digest = createHash('sha256')
for await (const chunk of createReadStream(path.join(source, 'ggml-small-q5_1.bin'))) digest.update(chunk)
if (digest.digest('hex') !== 'ae85e4a935d7a567bd102fe55afc16bb595bdb618e11b2fc7591bc08120411bb') throw Error('Offline speech model checksum mismatch; run fetch-voice-runtime.ps1')
const bin = path.join(source, 'bin/Release')
for (const file of await readdir(bin)) {
  if (file === 'whisper-cli.exe' || /^(ggml(?:-base|-cpu-[a-z0-9]+)?|whisper)\.dll$/.test(file)) await copyFile(path.join(bin, file), path.join(native, 'voice', file))
}
for (const file of ['ggml-small-q5_1.bin', 'whisper-cpp-LICENSE.txt', 'whisper-model-LICENSE.txt']) await copyFile(path.join(source, file), path.join(native, 'voice', file))
const compiler = path.join(process.env.WINDIR || 'C:/Windows', 'Microsoft.NET/Framework64/v4.0.30319/csc.exe')
execFileSync(compiler, ['/nologo', '/target:exe', '/platform:x64', '/reference:System.Web.Extensions.dll', `/out:${path.join(native, 'SakthiAudio.exe')}`, path.resolve('electron/native/AudioCapture.cs')], { stdio: 'inherit', windowsHide: true })
console.log('Offline model verified; in-memory audio helper compiled.')
