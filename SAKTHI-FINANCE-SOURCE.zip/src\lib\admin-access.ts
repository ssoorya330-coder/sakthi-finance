import { redirect } from 'next/navigation';
import { getFullUserFromToken } from '@/config/supabase-auth';
import { isDeveloperEmail } from '@/config/developer-access';

/**
 * Server-side gate for `/dashboard/admin-access` pages.
 *
 * Only the configured developer emails may enter. Owner/Admin roles alone
 * never grant this capability. Disabled accounts are rejected as well.
 *
 * Reads the authenticated user's role from the trusted server-side
 * session/database source (never from the browser). Unauthenticated
 * visitors go to `/login`. Use in server components only.
 */
export async function requireAdminAccessPage(): Promise<{
  userId: string;
  email: string;
  name: string;
  role: 'owner';
}> {
  const user = await getFullUserFromToken(true);
  if (!user) {
    redirect('/login?next=/dashboard/admin-access');
  }
  if (!user.isActive || user.role !== 'owner') {
    redirect('/dashboard');
  }
  return { userId: user.userId, email: user.email, name: user.name, role: 'owner' };
}
