import { NextRequest, NextResponse } from 'next/server'
import { dbQuery } from '@/server/database'
import { requireAuthWithPermission } from '@/lib/api-utils'

export async function GET(request: NextRequest, { params }: { params: Promise<{ type: string }> }) {
  const auth = await requireAuthWithPermission('reports:read');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const { type } = await params
    const userId = user.userId
    const endDate = new Date().toISOString().split('T')[0]
    const now = new Date()

    let startDate: string
    switch (type) {
      case 'Daily': startDate = endDate; break
      case 'Weekly': {
        const weekAgo = new Date(now)
        weekAgo.setDate(weekAgo.getDate() - 7)
        startDate = weekAgo.toISOString().split('T')[0]
        break
      }
      case 'Monthly': startDate = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0]; break
      case 'Yearly': startDate = `${now.getFullYear()}-01-01`; break
      default: startDate = endDate
    }

    let userFilter = ''
    const sqlParams: any[] = [startDate, endDate]
    let paramIdx = 3
    if (userId) { userFilter = ` AND user_id = $${paramIdx++}`; sqlParams.push(userId) }

    const [collections, customers] = await Promise.all([
      dbQuery(`SELECT COALESCE(SUM(amount), 0) as total, COUNT(*) as count FROM daily_collection WHERE collection_date BETWEEN $1 AND $2${userFilter}`, sqlParams),
      dbQuery(`SELECT COUNT(*) as new_customers FROM customers WHERE created_at::date BETWEEN $1 AND $2${userFilter}`, sqlParams),
    ])

    return NextResponse.json({
      reportType: type,
      startDate,
      endDate,
      totalCollection: parseFloat(collections.rows[0].total),
      paymentCount: parseInt(collections.rows[0].count, 10),
      newCustomers: parseInt(customers.rows[0].new_customers, 10),
    })
  } catch (err: any) {
    console.error('[GET /api/reports/[type]] Error:', err.message)
    return NextResponse.json(
      { error: 'Failed to generate report', details: err.message },
      { status: 500 }
    )
  }
}

