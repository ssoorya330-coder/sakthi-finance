import { NextRequest, NextResponse } from 'next/server'
import { desktopGoogleBroker, desktopGoogleExchange, validDesktopOrigin } from '@/lib/auth/desktop-google'

export const runtime = 'nodejs'

export async function POST(request: NextRequest) {
  const json = (body: unknown, status = 200) => NextResponse.json(body, { status, headers: { 'Cache-Control': 'no-store' } })
  if (!validDesktopOrigin(request)) return json({ error: 'Desktop sign-in requires the local application origin.' }, 403)
  if (Number(request.headers.get('content-length') || 0) > 1024) return json({ error: 'Request too large' }, 413)
  let body
  try {
    const text = await request.text()
    if (text.length > 1024) return json({ error: 'Request too large' }, 413)
    body = JSON.parse(text)
  } catch { return json({ error: 'Invalid request' }, 400) }
  if (body?.action === 'start') {
    const client = process.env.GOOGLE_DESKTOP_CLIENT_ID
    const secret = process.env.GOOGLE_DESKTOP_CLIENT_SECRET
    if (!client || !secret) return json({ error: 'Desktop Google sign-in is not configured. Set GOOGLE_DESKTOP_CLIENT_ID and the replacement GOOGLE_DESKTOP_CLIENT_SECRET in the private server environment.' }, 503)
    try { return json(await desktopGoogleBroker.start(client, desktopGoogleExchange(client, secret))) }
    catch (error) { return json({ error: error instanceof Error ? error.message : 'Unable to start sign-in' }, 503) }
  }
  if (typeof body?.ticket !== 'string' || !/^[\w-]{43}$/.test(body.ticket)) return json({ error: 'Invalid sign-in ticket' }, 400)
  if (body.action === 'poll') return json(desktopGoogleBroker.poll(body.ticket))
  if (body.action === 'cancel') { desktopGoogleBroker.cancel(body.ticket); return json({ cancelled: true }) }
  return json({ error: 'Invalid action' }, 400)
}
