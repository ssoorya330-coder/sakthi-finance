'use client'

import { useState, useRef, useMemo, useEffect, forwardRef, type InputHTMLAttributes, type MutableRefObject } from 'react'
import { CalendarDays } from 'lucide-react'
import { format } from 'date-fns'
import { cn } from '@/lib/utils'
import CalendarGrid, { DatePickerDropdown, CalendarNav, CalendarFooter } from './calendar'

export interface DateInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  error?: string | boolean
  compact?: boolean
  showIcon?: boolean
}

export const DateInput = forwardRef<HTMLInputElement, DateInputProps>(
  (
    {
      error,
      className,
      disabled,
      compact = false,
      showIcon = true,
      value,
      onChange,
      onBlur,
      name,
      defaultValue,
      ...props
    },
    forwardedRef,
  ) => {
    const formRegisterRef = (props as Record<string, unknown>).ref
    const [isOpen, setIsOpen] = useState(false)
    const [localValue, setLocalValue] = useState('')
    const triggerRef = useRef<HTMLButtonElement>(null)

    const isControlled = value !== undefined
    const effectiveValue = isControlled ? (value as string) : localValue

    const parsedDate = useMemo(() => {
      if (!effectiveValue) return null
      try {
        const d = new Date(effectiveValue + (effectiveValue.includes('T') ? '' : 'T00:00:00'))
        return isNaN(d.getTime()) ? null : d
      } catch {
        return null
      }
    }, [effectiveValue])

    const [viewDate, setViewDate] = useState(parsedDate || new Date())

    useEffect(() => {
      if (parsedDate) setViewDate(parsedDate)
    }, [effectiveValue])

    const displayValue = parsedDate ? format(parsedDate, 'dd-MM-yyyy') : ''

    const handleOpen = () => {
      if (disabled) return
      setIsOpen(open => !open)
    }

    const handleClose = () => setIsOpen(false)

    const selectDate = (date: Date) => {
      const isoDate = format(date, 'yyyy-MM-dd')
      if (!isControlled) setLocalValue(isoDate)
      if (onChange) {
        onChange({
          target: { value: isoDate, name },
          currentTarget: { value: isoDate, name },
          type: 'change',
        } as React.ChangeEvent<HTMLInputElement>)
      }
      // react-hook-form's register() returns the SAME function for onChange
      // and onBlur, and that handler unconditionally reads event.target.name.
      // A bare {} therefore crashes with "Cannot read properties of undefined
      // (reading 'name')", so emit a real blur-shaped event instead.
      if (onBlur) {
        onBlur({
          target: { value: isoDate, name },
          currentTarget: { value: isoDate, name },
          type: 'blur',
        } as React.FocusEvent<HTMLInputElement>)
      }
      setIsOpen(false)
    }

    const handleDayClick = (day: number) => {
      selectDate(new Date(viewDate.getFullYear(), viewDate.getMonth(), day))
    }

    const handleToday = () => selectDate(new Date())

    const handleClear = () => {
      if (!isControlled) setLocalValue('')
      if (onChange) {
        onChange({
          target: { value: '', name },
          currentTarget: { value: '', name },
          type: 'change',
        } as React.ChangeEvent<HTMLInputElement>)
      }
      // Same contract as selectDate: the blur receiver requires a real
      // event.target ({ name, value }), never a bare {}.
      if (onBlur) {
        onBlur({
          target: { value: '', name },
          currentTarget: { value: '', name },
          type: 'blur',
        } as React.FocusEvent<HTMLInputElement>)
      }
      setIsOpen(false)
    }

    const height = compact ? 'h-9' : 'h-[44px]'
    const textSize = compact ? 'text-xs' : 'text-sm'
    const state = error ? 'border-red-400' : 'border-[#E6DFD1]'
    const focusState = error
      ? 'focus:border-red-500 focus:ring-2 focus:ring-red-100'
      : 'focus:border-[#BA7517] focus-visible:ring-2 focus-visible:ring-[#BA7517]/30'
    const disabledCls = disabled ? 'bg-slate-50 text-slate-500 cursor-not-allowed' : ''

    return (
      <div className="relative w-full group">
        <input
          type="hidden"
          name={name}
          value={effectiveValue}
          onChange={() => {}}
          onBlur={() => {}}
          ref={(el) => {
            if (typeof formRegisterRef === 'function') formRegisterRef(el)
            if (typeof forwardedRef === 'function') forwardedRef(el)
            else if (forwardedRef)
              (forwardedRef as MutableRefObject<HTMLInputElement | null>).current = el
          }}
        />

        <button
          ref={triggerRef}
          type="button"
          disabled={disabled}
          onClick={handleOpen}
          aria-expanded={isOpen}
          aria-haspopup="dialog"
          className={cn(
            `w-full ${height} rounded-[10px] border-[0.5px] bg-white pr-4
             ${textSize} text-left outline-none transition-all duration-200
             active:scale-[0.99] flex items-center gap-2.5`,
            showIcon ? 'pl-12' : 'px-3',
            state,
            disabled
              ? 'text-slate-500 cursor-not-allowed'
              : 'text-[#A69A82] cursor-pointer hover:bg-[#FFFCF6] hover:border-[#BA7517] hover:text-[#1E1B14]',
            focusState,
            disabledCls,
            className,
          )}
        >
          {showIcon && (
            <span className="absolute left-3 top-1/2 z-10 -translate-y-1/2 flex items-center justify-center pointer-events-none">
              <span className="w-7 h-7 rounded-[7px] bg-[#2B2C2A] flex items-center justify-center transition-all duration-200 group-hover:scale-105 group-hover:rotate-[2deg]">
                <CalendarDays className="w-3.5 h-3.5 text-[#FAC775]" />
              </span>
            </span>
          )}
          <span className={parsedDate ? 'text-[#1E1B14]' : 'text-[#A69A82]'}>
            {displayValue || 'Select date'}
          </span>
        </button>

        <DatePickerDropdown isOpen={isOpen} onClose={handleClose} anchorRef={triggerRef}>
          <CalendarNav
            viewDate={viewDate}
            onPrev={() => setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1))}
            onNext={() => setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1))}
            format="long"
          />
          <CalendarGrid viewDate={viewDate} selectedDate={parsedDate} onDayClick={handleDayClick} />
          <CalendarFooter onToday={handleToday} onClear={handleClear} />
        </DatePickerDropdown>
      </div>
    )
  },
)
DateInput.displayName = 'DateInput'
