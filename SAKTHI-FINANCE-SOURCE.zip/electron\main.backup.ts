import { app, BrowserWindow, dialog, shell, protocol, net } from 'electron'

import path from 'node:path'

import { pathToFileURL } from 'node:url'

import { existsSync, readFileSync, statSync } from 'node:fs'

import { trustedRenderer, rendererFile } from './policy'

import { logEvent } from './logging'

import { firstRunSetup } from './first-run'

import { startManagedDatabase, stopManagedDatabase, type ManagedDatabase } from './managed-postgres'

import { validateRuntimeConfig, databaseProbeConfig } from '../scripts/desktop/runtime-config.mjs'



/**

 * Sakthi Finance — Electron main process.

 *

 * Production loads the bundled static export from application files

 * (loadFile). No HTTP server is started: data flows renderer → preload →

 * IPC → in-process API bridge (existing handlers) → PostgreSQL.

 *

 * Development mode (SAKTHI_ELECTRON_DEV=1) may load the Next dev server for

 * hot reload — production never does.

 *

 * IMPORTANT: auth modules read signing keys at require time, so the private

 * runtime configuration is loaded before they are imported (lazy require).

 */



const isDev = !app.isPackaged && process.env.SAKTHI_ELECTRON_DEV === '1'



// Static-export assets are emitted with absolute /_next/... URLs, which do

// not resolve over file:// . A custom app:// scheme serves the bundled

// out-desktop-build directory as an http-like origin (absolute paths,

// correct MIME types) while keeping webSecurity enabled.

const RENDERER_ROOT = path.join(__dirname, '../out-desktop-build')

const MIME_TYPES: Record<string, string> = {

  '.html': 'text/html',

  '.js': 'text/javascript',

  '.mjs': 'text/javascript',

  '.css': 'text/css',

  '.json': 'application/json',

  '.svg': 'image/svg+xml',

  '.png': 'image/png',

  '.jpg': 'image/jpeg',

  '.jpeg': 'image/jpeg',

  '.gif': 'image/gif',

  '.webp': 'image/webp',

  '.ico': 'image/x-icon',

  '.woff': 'font/woff',

  '.woff2': 'font/woff2',

  '.ttf': 'font/ttf',

  '.map': 'application/json',

  '.txt': 'text/plain',

  '.webmanifest': 'application/manifest+json',

}



protocol.registerSchemesAsPrivileged([

  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } },

])



function resolveRendererFile(urlPath: string): string | null {

  try {

    const candidate = rendererFile(RENDERER_ROOT, urlPath)

    if (!candidate) return null

    // Directories must NOT match existsSync — net.fetch on a directory 404s.

    const stat = existsSync(candidate) ? statSync(candidate) : null

    if (stat?.isFile()) return candidate

    // Clean-URL fallbacks: /dashboard -> dashboard.html, then /dashboard/index.html
