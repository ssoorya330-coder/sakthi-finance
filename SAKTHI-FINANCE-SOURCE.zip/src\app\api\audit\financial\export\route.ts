import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import {
  fy,
  fyOf,
  fyPeriodLabel,
  availableFinancialYears,
  overallSummary,
  customerSummary,
  loanDetails,
  transactionLedger,
  reconcile,
  dataQualityChecks,
} from '@/server/financial-audit'
import {
  buildFinancialWorkbook,
  summaryCsv,
  customersCsv,
  loansCsv,
  ledgerCsv,
  cashCsv,
} from '@/server/financial-report'
import { cashTransactions } from '@/server/cash-audit'

export const dynamic = 'force-dynamic'

const MAX_ROWS = 100000;

/**
 * Financial audit export (same FY scope as the on-screen report):
 * - format=xlsx → Overall Summary + Customer Summary + Loan Details +
 *   Transaction Ledger + Reconciliation + Cash Transactions + Flagged
 * - format=csv&section=summary|customers|loans|ledger|cash
 */
export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('audit:read')
  if (auth.error) return auth.error

  try {
    const searchParams = new URL(request.url).searchParams
    const format = (searchParams.get('format') || 'xlsx').toLowerCase()
    if (format !== 'xlsx' && format !== 'csv') {
      return NextResponse.json({ error: 'Format must be xlsx or csv.' }, { status: 400 })
    }
    const years = await availableFinancialYears(auth.user.userId)
    const fyParam = parseInt(searchParams.get('fy') || '', 10)
    const selected = years.some((y) => y.startYear === fyParam) ? fy(fyParam) : fyOf()

    const [overall, customers, loans, ledgerData, dataQuality] = await Promise.all([
      overallSummary(auth.user.userId, selected),
      customerSummary(auth.user.userId, selected),
      loanDetails(auth.user.userId, selected),
      transactionLedger(auth.user.userId, selected, 1, MAX_ROWS),
      dataQualityChecks(auth.user.userId, selected),
    ])
    // Defensive: every dataset must be a real array before workbook gen.
    const safeCustomers = Array.isArray(customers) ? customers : []
    const safeLoans = Array.isArray(loans) ? loans : []
    const safeLedger = Array.isArray(ledgerData.rows) ? ledgerData.rows : []
    const reconciliation = reconcile(overall, safeCustomers, safeLoans, safeLedger)
    const generatedAt = new Date().toISOString()
    const stamp = generatedAt.slice(0, 10)
    // Filenames must be header-safe ASCII (FY labels contain an en-dash).
    const safeFy = `FY${selected.startYear}-${String((selected.startYear + 1) % 100).padStart(2, '0')}`
    console.log(
      `[Audit Export] FY ${selected.label} Overall Summary rows: 15, ` +
        `Customer Summary rows: ${safeCustomers.length}, Loan Details rows: ${safeLoans.length}, ` +
        `Transaction Ledger rows: ${safeLedger.length}`
    )

    if (format === 'csv') {
      const section = (searchParams.get('section') || 'ledger').toLowerCase()
      if (section === 'summary') {
        return new NextResponse(summaryCsv(overall), {
          status: 200,
          headers: {
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': `attachment; filename="sakthi-finance-overall-summary-${safeFy}-${stamp}.csv"`,
          },
        })
      }
      if (section === 'customers') {
        return new NextResponse(customersCsv(safeCustomers), {
          status: 200,
          headers: {
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': `attachment; filename="sakthi-finance-customer-summary-${safeFy}-${stamp}.csv"`,
          },
        })
      }
      if (section === 'loans') {
        return new NextResponse(loansCsv(safeLoans), {
          status: 200,
          headers: {
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': `attachment; filename="sakthi-finance-loan-details-${safeFy}-${stamp}.csv"`,
          },
        })
      }
      if (section === 'cash') {
        const cash = await cashTransactions(auth.user.userId, selected, {}, 1, MAX_ROWS)
        return new NextResponse(cashCsv(cash.rows), {
          status: 200,
          headers: {
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': `attachment; filename="sakthi-finance-cash-transactions-${safeFy}-${stamp}.csv"`,
          },
        })
      }
      return new NextResponse(ledgerCsv(safeLedger), {
        status: 200,
        headers: {
          'Content-Type': 'text/csv; charset=utf-8',
          'Content-Disposition': `attachment; filename="sakthi-finance-ledger-${safeFy}-${stamp}.csv"`,
        },
      })
    }

    const cash = await cashTransactions(auth.user.userId, selected, {}, 1, MAX_ROWS)
    const safeCash = Array.isArray(cash.rows) ? cash.rows : []
    console.log(
      `[Audit Export] Cash Transactions rows: ${safeCash.length}, ` +
        `Flagged Cash Transactions rows: ${safeCash.filter((r) => r.flagged).length}`
    )
    const buf = buildFinancialWorkbook({
      fy: selected,
      period: fyPeriodLabel(selected),
      generatedAt,
      generatedBy: auth.user.email || auth.user.userId,
      overall,
      customers: safeCustomers,
      loans: safeLoans,
      ledger: safeLedger,
      reconciliation,
      dataQuality,
      cash: safeCash,
    })
    return new NextResponse(new Uint8Array(buf), {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="sakthi-finance-financial-audit-${safeFy}-${stamp}.xlsx"`,
      },
    })
  } catch (err: any) {
    return NextResponse.json({ error: 'Financial export failed', details: err.message }, { status: 500 })
  }
}
