import type { Customer, PaymentRecord } from '@/types/customer.types'

export type EntryKind = 'Added' | 'Paid' | 'Completed' | 'Aborted'
export interface CustomerEntry {
  id: string
  customer: Customer
  kind: EntryKind
  date: string
  recordedAt?: string
  amount: number | null
  detail: string
}

function day(value?: string): string {
  if (!value) return ''
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value
  const parsed = new Date(value)
  return Number.isNaN(parsed.getTime()) ? '' : new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).format(parsed)
}

/** Saved business records only: pending Received Amount inputs are not payments. */
export function buildCustomerEntries(customers: Customer[], payments: PaymentRecord[]): CustomerEntry[] {
  const lookup = new Map(customers.map(customer => [customer.id, customer]))
  const entries: CustomerEntry[] = []
  for (const customer of customers) {
    entries.push({ id: `added:${customer.id}`, customer, kind: 'Added', date: day(customer.createdAt), amount: null, detail: 'Customer added' })
    if (customer.status === 'Completed') {
      entries.push({ id: `completed:${customer.id}`, customer, kind: 'Completed', date: day(customer.completedAt), amount: null, detail: 'Payment completed / account closed' })
    }
    if (customer.status === 'Aborted') {
      entries.push({ id: `aborted:${customer.id}`, customer, kind: 'Aborted', date: day(customer.abortedAt), amount: null, detail: customer.abortReason || 'Account aborted' })
    }
  }
  for (const payment of payments) {
    const customer = lookup.get(payment.customerId)
    if (!customer) continue
    entries.push({ id: `paid:${payment.id}`, customer, kind: 'Paid', date: day(payment.paymentDate), amount: payment.paymentAmount, detail: [payment.paymentTime, payment.paymentMethod, payment.remarks].filter(Boolean).join(' · ') })
  }
  const paymentTimes = new Map(payments.map(payment => [`paid:${payment.id}`, payment.createdAt]))
  for (const entry of entries) {
    entry.recordedAt = entry.kind === 'Paid' ? paymentTimes.get(entry.id)
      : entry.kind === 'Added' ? entry.customer.createdAt
      : entry.kind === 'Completed' ? entry.customer.completedAt : entry.customer.abortedAt
  }
  const time = (entry: CustomerEntry) => {
    const parsed = Date.parse(entry.recordedAt || `${entry.date}T00:00:00+05:30`)
    return Number.isFinite(parsed) ? parsed : -Infinity
  }
  // Stable ties preserve source order when recorded timestamps are identical.
  return entries.sort((a, b) => time(a) === time(b) ? 0 : time(a) > time(b) ? -1 : 1)
}
