import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { createServerClient } from '@supabase/ssr'

const ACCESS_COOKIE_NAME = 'sf_access'
const REFRESH_COOKIE_NAME = 'sf_refresh'

// Routes that never require authentication.
const PUBLIC_ROUTES = [
  '/login',
  '/about',
  '/api/auth',
  '/api/database/status',
  '/manifest.json',
  '/sw.js',
  '/wasm/',
  '/_next',
]

// App pages that require a valid session. API authorization itself is
// enforced inside each API route via requireAuth(); the proxy only ensures
// unauthenticated page visits are sent to /login.
const PROTECTED_PREFIXES = ['/dashboard', '/database']

function isPublicRoute(pathname: string): boolean {
  return PUBLIC_ROUTES.some((route) =>
    route.endsWith('/') ? pathname.startsWith(route) : pathname === route || pathname.startsWith(route + '/')
  )
}

function isProtectedRoute(pathname: string): boolean {
  return PROTECTED_PREFIXES.some(
    (route) => pathname === route || pathname.startsWith(route + '/')
  )
}

function hasSessionCookie(request: NextRequest): boolean {
  if (
    request.cookies.get(ACCESS_COOKIE_NAME)?.value ||
    request.cookies.get(REFRESH_COOKIE_NAME)?.value
  ) {
    return true;
  }
  // Supabase Auth session cookies (sb-*) count as a session too.
  try {
    return request.cookies.getAll().some((c) => c.name.startsWith('sb-') && c.value);
  } catch {
    return false;
  }
}

export default async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Best-effort Supabase session refresh so sb-* cookies stay valid. Never
  // blocks navigation; app-JWT cookies remain the primary gate and API routes
  // re-verify identity server-side.
  let supabaseResponse: NextResponse | null = null;
  if (
    process.env.NEXT_PUBLIC_SUPABASE_URL &&
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  ) {
    try {
      supabaseResponse = NextResponse.next({ request });
      const supabase = createServerClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
        {
          cookies: {
            getAll() {
              return request.cookies.getAll();
            },
            setAll(cookiesToSet) {
              cookiesToSet.forEach(({ name, value, options }) => {
                supabaseResponse!.cookies.set(name, value, options);
              });
            },
          },
        }
      );
      await supabase.auth.getUser();
    } catch {
      supabaseResponse = null;
    }
  }

  // Never interfere with API responses — API routes return 401/403 JSON
  // themselves via requireAuth(). Only guard page navigations.
  if (pathname.startsWith('/api/')) {
    const response = supabaseResponse ?? NextResponse.next()
    response.headers.set(
      'Cache-Control',
      'no-store, no-cache, must-revalidate, proxy-revalidate'
    )
    response.headers.set('Pragma', 'no-cache')
    response.headers.set('Expires', '0')
    return response
  }

  if (pathname === '/') {
    // Send unauthenticated visitors straight to /login so a logged-out
    // user never lands on the dashboard.
    if (!hasSessionCookie(request)) {
      return NextResponse.redirect(new URL('/login', request.url))
    }
    return NextResponse.redirect(new URL('/dashboard', request.url))
  }

  if (isPublicRoute(pathname)) {
    const response = supabaseResponse ?? NextResponse.next()
    response.headers.set(
      'Cache-Control',
      'no-store, no-cache, must-revalidate, proxy-revalidate'
    )
    response.headers.set('Pragma', 'no-cache')
    response.headers.set('Expires', '0')
    return response
  }

  if (isProtectedRoute(pathname) && !hasSessionCookie(request)) {
    const loginUrl = new URL('/login', request.url)
    loginUrl.searchParams.set('next', pathname)
    return NextResponse.redirect(loginUrl)
  }
  const response = supabaseResponse ?? NextResponse.next()

  response.headers.set(
    'Cache-Control',
    'no-store, no-cache, must-revalidate, proxy-revalidate'
  )
  response.headers.set('Pragma', 'no-cache')
  response.headers.set('Expires', '0')

  return response
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|wasm)$).*)',
  ],
}
