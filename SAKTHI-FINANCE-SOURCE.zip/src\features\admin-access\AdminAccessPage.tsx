'use client'

import { useRouter } from 'next/navigation'
import {
  Activity,
  ChevronRight,
  HeartPulse,
  History,
  KeyRound,
  LockKeyhole,
  MonitorSmartphone,
  ScanSearch,
  Settings2,
  ShieldCheck,
  UserCog,
  Users,
} from 'lucide-react'
import { useSidebarStore } from '@/store/sidebar-store'

interface AdminAccessPageProps {
  userName: string
  role: 'owner'
}

interface ModuleDef {
  id: string
  title: string
  description: string
  href: string
  icon: React.FC<{ className?: string }>
}

interface ModuleGroup {
  label: string
  modules: ModuleDef[]
}

const GROUPS: ModuleGroup[] = [
  {
    label: 'Users & Access',
    modules: [
      {
        id: 'users',
        title: 'Users & Roles',
        description: 'Manage users and assign permitted roles.',
        href: '/dashboard/admin-access/users',
        icon: Users,
      },
      {
        id: 'accounts',
        title: 'Account Management',
        description: 'Activate, suspend, and manage user accounts.',
        href: '/dashboard/admin-access/accounts',
        icon: UserCog,
      },
    ],
  },
  {
    label: 'Security',
    modules: [
      {
        id: 'security',
        title: 'Security Overview',
        description: 'Users, sessions, and recent security events.',
        href: '/dashboard/admin-access/security',
        icon: ShieldCheck,
      },
      {
        id: 'permissions',
        title: 'Permission Management',
        description: 'Role permissions enforced server-side.',
        href: '/dashboard/admin-access/permissions',
        icon: LockKeyhole,
      },
      {
        id: 'security-settings',
        title: 'Security Settings',
        description: 'Session timeout and session limits.',
        href: '/dashboard/admin-access/security-settings',
        icon: Settings2,
      },
    ],
  },
  {
    label: 'Monitoring',
    modules: [
      {
        id: 'account-monitor',
        title: 'Account Monitor',
        description: 'Customer counts, Kanaku, received payments and balances by account.',
        href: '/dashboard/admin-access/account-monitor',
        icon: Activity,
      },
      {
        id: 'login-activity',
        title: 'Login Activity',
        description: 'Monitor logins, devices, and access.',
        href: '/dashboard/admin-access/login-activity',
        icon: History,
      },
      {
        id: 'devices',
        title: 'Device Management',
        description: 'Active sessions and device logout.',
        href: '/dashboard/admin-access/devices',
        icon: MonitorSmartphone,
      },
    ],
  },
  {
    label: 'System',
    modules: [
      {
        id: 'system-activity',
        title: 'System Activity',
        description: 'Administrative and system actions.',
        href: '/dashboard/admin-access/system-activity',
        icon: Activity,
      },
      {
        id: 'system-health',
        title: 'System Health',
        description: 'App, database, and audit status.',
        href: '/dashboard/admin-access/system-health',
        icon: HeartPulse,
      },
    ],
  },
  {
    label: 'Data Access',
    modules: [
      {
        id: 'data-access',
        title: 'Data Access Monitor',
        description: 'Track access to business data.',
        href: '/dashboard/admin-access/data-access',
        icon: ScanSearch,
      },
    ],
  },
]

export default function AdminAccessPage(_props: AdminAccessPageProps) {
  const router = useRouter()
  const toggleSidebar = useSidebarStore((s) => s.toggleSidebar)

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-[1400px] mx-auto space-y-5">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              onClick={toggleSidebar}
              aria-label="Open menu"
              className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors active:scale-95 shadow-sm flex-shrink-0"
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round">
                <path d="M3 5h14" />
                <path d="M3 10h14" />
                <path d="M3 15h14" />
              </svg>
            </button>
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
              <KeyRound className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">Admin Access</h1>
              <p className="text-xs sm:text-sm text-slate-500">Manage administrative functions and user access</p>
            </div>
          </div>
          <span
            className="inline-flex items-center px-3 py-1.5 rounded-xl text-[11px] font-bold border bg-[var(--primary-soft)] text-[var(--primary)] border-[#E8CFCF]"
          >
            Signed in as Developer — administration access
          </span>
        </div>

        {/* Module groups */}
        {GROUPS.map((g) => (
          <div key={g.label}>
            <div className="flex items-center gap-2 px-1 mb-2">
              <span className="text-[11px] font-bold uppercase tracking-[0.12em] text-slate-400">{g.label}</span>
              <div className="flex-1 h-px bg-slate-200" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {g.modules.map((s) => (
                <button
                  key={s.id}
                  onClick={() => router.push(s.href)}
                  className="group flex items-center gap-4 rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm hover:border-[#E8CFCF] hover:bg-[var(--primary-soft)]/40 hover:shadow-md transition-all"
                >
                  <span className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-md shadow-[var(--primary)]/20 flex-shrink-0">
                    <s.icon className="w-5 h-5 text-white" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-bold text-slate-900">{s.title}</span>
                    <span className="block text-xs text-slate-500 mt-0.5">{s.description}</span>
                  </span>
                  <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-[var(--primary)] group-hover:translate-x-0.5 transition-all flex-shrink-0" />
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
