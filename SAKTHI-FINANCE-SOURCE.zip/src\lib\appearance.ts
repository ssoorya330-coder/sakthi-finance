export const THEME_KEY = 'sakthi-appearance-v1'
// Action colors are deeper than decorative swatches for white-label contrast.
export const THEMES = [
  { id: 'classic', name: 'Sakthi Classic', colors: ['#7F1D1D','#D4AF37','#E8C15A','#FDF2F2','#F7F9EC'], text: '#27253B', action: '#7F1D1D' },
  { id: 'ocean', name: 'Pastel Ocean', colors: ['#3B82F6','#60A5FA','#93C5FD','#DBEAFE','#F5FAFF'], text: '#172554', action: '#1D4ED8' },
  { id: 'mint', name: 'Mint Meadow', colors: ['#10B981','#34D399','#6EE7B7','#D1FAE5','#F5FFF9'], text: '#065F46', action: '#047857' },
  { id: 'rose', name: 'Rose Blush', colors: ['#E11D48','#F43F5E','#FB7185','#FECDD3','#FFF7F8'], text: '#881337', action: '#BE123C' },
  { id: 'lavender', name: 'Lavender Mist', colors: ['#6366F1','#818CF8','#A78BFA','#DDD6FE','#F8F7FF'], text: '#312E81', action: '#4338CA' },
  { id: 'aqua', name: 'Aqua Mint', colors: ['#06B6D4','#22D3EE','#2DD4BF','#CCFBF1','#F4FEFF'], text: '#164E63', action: '#0E7490' },
  { id: 'peach', name: 'Sunrise Peach', colors: ['#F97316','#F59E0B','#FB923C','#FED7AA','#FFFAF5'], text: '#7C2D12', action: '#C2410C' },
] as const
export type ThemeId = typeof THEMES[number]['id']
export function themeTokens(id: string): Record<string, string> {
  const theme = THEMES.find(t => t.id === id) ?? THEMES[0]
  const [primary, secondary, accent, soft, background] = theme.colors
  return {
    '--background': background, '--surface': '#FFFFFF', '--surface-secondary': soft,
    '--primary': theme.action, '--primary-hover': theme.text, '--primary-soft': soft,
    '--secondary': secondary, '--accent': accent, '--text-primary': theme.text,
    '--text-secondary': '#475569', '--text-muted': '#64748B', '--border': soft, '--border-soft': background,
    '--sidebar-background': theme.id === 'classic' ? 'linear-gradient(180deg,#7F1D1D,#430F0F)' : `linear-gradient(155deg,${background},${soft})`,
    '--sidebar-text': theme.id === 'classic' ? '#FFFFFF' : theme.text,
    '--sidebar-active': theme.id === 'classic' ? '#FFD88E' : '#FFFFFF',
    '--chart-1': primary, '--chart-2': secondary, '--chart-3': accent, '--chart-4': theme.action,
    '--success': '#15803D', '--warning': '#A16207', '--danger': '#B91C1C', '--info': '#1D4ED8',
    '--color-bg-primary': background, '--color-bg-secondary': soft, '--color-bg-hover': soft,
    '--color-wine-500': theme.action, '--color-wine-600': theme.text, '--color-wine-50': soft,
    '--color-text-primary': theme.text, '--color-text-secondary': '#475569',
  }
}
