import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
  }).format(amount);
}

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function generateDeviceId(): string {
  if (typeof window === 'undefined') return 'server';
  const stored = localStorage.getItem('sf_device_id');
  if (stored) return stored;
  const id = crypto.randomUUID();
  localStorage.setItem('sf_device_id', id);
  return id;
}
