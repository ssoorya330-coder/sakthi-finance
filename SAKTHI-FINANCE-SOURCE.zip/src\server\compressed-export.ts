import { gzip } from 'node:zlib';
import { promisify } from 'node:util';

const gzipAsync = promisify(gzip);

/** Lossless, compact JSON archive. Financial values retain JSON's existing representation. */
export async function compressJsonExport(payload: unknown): Promise<Uint8Array> {
  const bytes = await gzipAsync(Buffer.from(JSON.stringify(payload), 'utf8'), { level: 9 });
  return new Uint8Array(bytes);
}
