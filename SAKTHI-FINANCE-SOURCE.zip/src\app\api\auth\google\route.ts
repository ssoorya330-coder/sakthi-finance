import { NextRequest, NextResponse } from 'next/server';
import { OAuth2Client } from 'google-auth-library';
import { googleVerificationError } from '@/lib/auth/google-errors';
import { z } from 'zod';
import { dbQuery } from '@/server/database';
import { recordAuditStandalone } from '@/server/audit';
import {
  signAccessToken,
  signRefreshToken,
  storeRefreshToken,
  pruneSessionsBeyondLimit,
  ACCESS_COOKIE_NAME,
  REFRESH_COOKIE_NAME,
  REFRESH_TOKEN_TTL_SECONDS,
  cookieOptions,
  type TokenPayload,
} from '@/lib/auth/tokens';
import {
  getSessionTimeoutMinutes,
  getMaxSessionsPerUser,
  DEFAULT_SESSION_TIMEOUT_MINUTES,
  DEFAULT_MAX_SESSIONS,
} from '@/server/app-settings';

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '';
const googleClient = new OAuth2Client(GOOGLE_CLIENT_ID);

const idTokenSchema = z.object({
  client_type: z.enum(['web', 'desktop']).default('web'),
  id_token: z.string().min(1, 'ID token is required'),
  mode: z.enum(['signin', 'signup']).default('signin'),
  display_name: z.string().trim().min(1, 'Please enter your name').max(100, 'Name must be 100 characters or fewer').regex(/^[^\u0000-\u001f\u007f]+$/, 'Please enter a valid name').optional(),
});

interface GoogleUserRow {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  role: string;
  role_id: number | null;
  is_active: boolean;
  avatar_url: string | null;
  google_id: string | null;
}

async function verifyGoogleIdToken(
  id_token: string,
  clientType: 'web' | 'desktop' = 'web'
): Promise<
  | {
      ok: true;
      payload: { sub: string; email: string; name: string; picture: string };
    }
  | { ok: false; error: string; status: number }
> {
  const audience = clientType === 'desktop' ? process.env.GOOGLE_DESKTOP_CLIENT_ID : GOOGLE_CLIENT_ID;
  if (!audience) {
    return { ok: false, error: 'Google client ID is not configured on the server', status: 500 };
  }
  if (clientType === 'web' && GOOGLE_CLIENT_ID !== process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID) {
    return { ok: false, error: 'Google client configuration does not match. Contact the administrator.', status: 500 };
  }
  try {
    const ticket = await googleClient.verifyIdToken({
      idToken: id_token,
      audience,
    });
    const payload = ticket.getPayload();
    if (!payload) return { ok: false, error: 'Invalid ID token', status: 401 };
    if (payload.aud !== audience) {
      return { ok: false, error: 'Token audience mismatch', status: 401 };
    }
    if (payload.email_verified !== true) {
      return { ok: false, error: 'Email not verified by Google', status: 401 };
    }
    return {
      ok: true,
      payload: {
        sub: payload.sub,
        email: payload.email || '',
        name: payload.name || (payload.email ? payload.email.split('@')[0] : ''),
        picture: payload.picture || '',
      },
    };
  } catch (err) {
    const failure = googleVerificationError(err, id_token);
    if (process.env.NODE_ENV === 'development') console.warn('[Auth/Google] Verification failed', failure.diagnostic);
    return { ok: false, error: failure.error, status: failure.status };
  }
}

async function findUserByGoogle(googleId: string, email: string): Promise<GoogleUserRow | null> {
  // Case-insensitive + whitespace-tolerant email match. Never trust a
  // browser-supplied email — callers must pass the verified Google payload email.
  const result = await dbQuery<GoogleUserRow>(
    `SELECT u.id, u.user_id, u.email, u.full_name, r.role_name as role, u.role_id, u.is_active, u.avatar_url, u.google_id
     FROM users u
     LEFT JOIN roles r ON u.role_id = r.role_id
     WHERE u.google_id = $1 OR LOWER(TRIM(u.email)) = LOWER(TRIM($2)) OR LOWER(TRIM(u.google_email)) = LOWER(TRIM($2))
     LIMIT 1`,
    [googleId, email]
  );
  return result.rows[0] || null;
}

/**
 * Auto-provision a first-time user for ANY verified Google email. There is no
 * email whitelist: every Google account that passes server-side token
 * verification gets a row in the existing `users` table (role: customer),
 * which owners/admins can manage afterwards. Safe under race conditions via
 * ON CONFLICT.
 */
async function provisionGoogleUser(
  googleId: string,
  email: string,
  name: string,
  picture: string
): Promise<GoogleUserRow | null> {
  const cleanEmail = email.trim();
  try {
    const roleResult = await dbQuery<{ role_id: number }>(
      'SELECT role_id FROM roles WHERE role_name = $1',
      ['owner']
    );
    const roleId = roleResult.rows[0]?.role_id ?? null;
    const userId = `user-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    await dbQuery(
      `INSERT INTO users (user_id, email, google_email, full_name, role, role_id, is_active, avatar_url, google_id, provider)
       VALUES ($1, $2, $2, $3, 'owner', $4, true, $5, $6, 'google')
       ON CONFLICT (email) DO NOTHING`,
      [userId, cleanEmail, name || cleanEmail.split('@')[0], roleId, picture || null, googleId]
    );

    // Link google_id when the row already existed by email (e.g. seeded by admin).
    await dbQuery(
      `UPDATE users SET google_id = COALESCE(google_id, $1), google_email = COALESCE(google_email, $2)
       WHERE LOWER(TRIM(email)) = LOWER(TRIM($2)) AND google_id IS NULL`,
      [googleId, cleanEmail]
    ).catch(() => {});

    return await findUserByGoogle(googleId, cleanEmail);
  } catch (err) {
    console.warn(
      '[Auth/Google] Failed to auto-provision Google user:',
      err instanceof Error ? err.message : err
    );
    return null;
  }
}

async function buildTokenResponse(user: GoogleUserRow, request: NextRequest) {
  if (!['owner', 'admin'].includes(user.role)) {
    return NextResponse.json({ error: 'This login role is no longer supported. Contact the account owner.', code: 'not_authorized' }, { status: 403 });
  }
  const userId = user.user_id || user.id;
  const name = user.full_name || user.email?.split('@')[0] || '';
  const picture = user.avatar_url || '';
  const role = user.role === 'collector' ? 'employee' : user.role || 'employee';

  const tokenPayload: TokenPayload = {
    sub: userId,
    email: user.email,
    name,
    role,
    provider: 'google',
    picture,
  };

  // Owner-configured session timeout (enforced: access-token expiry + cookie).
  const timeoutMinutes = await getSessionTimeoutMinutes().catch(
    () => DEFAULT_SESSION_TIMEOUT_MINUTES
  );
  const accessToken = signAccessToken(tokenPayload, timeoutMinutes);
  const refreshToken = signRefreshToken(tokenPayload);

  const userAgent = request.headers.get('user-agent') || undefined;
  const ipAddress =
    request.headers.get('x-forwarded-for')?.split(',')[0].trim() ||
    request.headers.get('x-real-ip') ||
    undefined;

  // Persist the refresh token (session record with device/IP metadata) and
  // capture its row id so the LOGIN audit references the real session.
  let sessionId: string | null = null;
  try {
    await storeRefreshToken(userId, refreshToken, { userAgent, ipAddress });
    const latest = await dbQuery<{ id: string }>(
      `SELECT id FROM refresh_tokens WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1`,
      [userId]
    );
    sessionId = latest.rows[0]?.id || null;
  } catch (err) {
    return NextResponse.json({ error: 'Unable to save your session. Please retry.', code: 'db_unavailable' }, { status: 503 });
  }

  // Enforce the Owner-configured per-user active-session cap.
  try {
    const maxSessions = await getMaxSessionsPerUser().catch(() => DEFAULT_MAX_SESSIONS);
    await pruneSessionsBeyondLimit(userId, maxSessions);
  } catch (err) {
    console.warn('[Auth/Google] Failed to enforce session cap:', err);
  }

  // Update last_login_at
  dbQuery('UPDATE users SET last_login_at = NOW() WHERE user_id = $1', [userId]).catch(() => {});

  // Audit: successful login (fire-and-forget — never blocks sign-in).
  try {
    const ip = ipAddress || null;
    recordAuditStandalone({
      action: 'LOGIN',
      entityType: 'auth',
      entityId: userId,
      actor: { userId, name, role },
      ipAddress: ip,
      clientInfo: request.headers.get('user-agent')?.slice(0, 300) || null,
      result: 'SUCCESS',
      changes: [
        { field: 'email', label: 'Email', before: null, after: user.email },
        ...(sessionId
          ? [{ field: 'session', label: 'Session ID', before: null, after: String(sessionId).slice(0, 8) }]
          : []),
      ],
    });
  } catch {}

  const response = NextResponse.json({
    user: {
      id: userId,
      email: user.email,
      name,
      picture,
      role,
    },
    access_token: accessToken,
    access_token_expires_in: timeoutMinutes * 60,
  });

  response.cookies.set(ACCESS_COOKIE_NAME, accessToken, cookieOptions(timeoutMinutes * 60, true));
  response.cookies.set(REFRESH_COOKIE_NAME, refreshToken, cookieOptions(REFRESH_TOKEN_TTL_SECONDS, true));

  return response;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    if (process.env.NODE_ENV === 'development') console.info('[Auth/Google] Verification request', {
      googleClientIdExists: Boolean(GOOGLE_CLIENT_ID),
      credentialReceived: typeof body?.id_token === 'string' && body.id_token.length > 0,
      credentialLength: typeof body?.id_token === 'string' ? body.id_token.length : 0,
    });
    const parsed = idTokenSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.errors[0].message, code: 'invalid_input' },
        { status: 400 }
      );
    }

    const { id_token, mode } = parsed.data;
    const verified = await verifyGoogleIdToken(id_token, parsed.data.client_type);
    if (!verified.ok) {
      return NextResponse.json(
        { error: verified.error, code: verified.status === 503 ? 'google_unavailable' : verified.status === 500 ? 'google_not_configured' : 'invalid_token' },
        { status: verified.status }
      );
    }

    const { sub: googleId, email: verifiedEmail, name, picture } = verified.payload;
    // Use ONLY the server-verified Google email. Never trust browser-supplied email.
    const email = (verifiedEmail || '').trim();
    if (!email) {
      return NextResponse.json(
        { error: 'Google account must have an email', code: 'missing_email' },
        { status: 400 }
      );
    }

    let dbAvailable = true;
    let existing: GoogleUserRow | null = null;
    try {
      existing = await findUserByGoogle(googleId, email);
    } catch (dbErr) {
      const message = dbErr instanceof Error ? dbErr.message : 'Unknown database error';
      console.warn('[Auth/Google] Database unavailable:', message);
      dbAvailable = false;
      if (mode === 'signup') {
        return NextResponse.json(
          {
            error: 'Sign-up is currently unavailable because the user database is not reachable.',
            code: 'db_unavailable',
          },
          { status: 503 }
        );
      }
      return NextResponse.json({ error: 'Your account database is unavailable. Please retry when storage is connected.', code: 'db_unavailable' }, { status: 503 });
    }

    if (mode === 'signin') {
      if (!existing) {
        if (!parsed.data.display_name) {
          return NextResponse.json({ code: 'name_required' }, { status: 200 });
        }
        // First login with this Google account — auto-provision it into the
        // existing users table (role: customer) so owners/admins can manage
        // it afterwards. No email whitelist: any verified Google account is
        // allowed.
        existing = await provisionGoogleUser(googleId, email, parsed.data.display_name, picture);
        if (!existing) {
          // Provisioning failed (database write error) — not an
          // authorization decision.
          return NextResponse.json(
            {
              error: 'Could not create your account right now. Please try again.',
              code: 'db_unavailable',
            },
            { status: 503 }
          );
        }
      }
      // Link google_id on first login when the row was seeded by email only.
      if (dbAvailable && existing && !existing.google_id) {
        await dbQuery(
          'UPDATE users SET google_id = $1 WHERE LOWER(TRIM(email)) = LOWER(TRIM($2)) AND google_id IS NULL',
          [googleId, existing.email]
        ).catch(() => {});
        existing.google_id = googleId;
      }
      // Check if account is active
      if (existing.is_active === false) {
        try {
          recordAuditStandalone({
            action: 'LOGIN_FAILED',
            entityType: 'auth',
            entityId: existing.user_id,
            actor: { userId: existing.user_id, name: existing.full_name || email, role: existing.role || null },
            ipAddress:
              request.headers.get('x-forwarded-for')?.split(',')[0].trim() ||
              request.headers.get('x-real-ip') ||
              null,
            clientInfo: request.headers.get('user-agent')?.slice(0, 300) || null,
            reason: 'Account disabled',
            result: 'FAILED',
          });
        } catch {}
        return NextResponse.json(
          {
            error: 'Your account has been disabled. Please contact the administrator.',
            code: 'account_disabled',
          },
          { status: 403 }
        );
      }
      return await buildTokenResponse(existing, request);
    }

    // Signup mode - do NOT auto-create users
    if (existing) {
      return NextResponse.json(
        {
          error: 'Account already exists. Please sign in instead.',
          code: 'account_exists',
          email: existing.email,
        },
        { status: 409 }
      );
    }

    // Signup blocked - admin must add users manually
    return NextResponse.json(
      {
        error: 'Self-registration is disabled. Please contact the administrator to get access.',
        code: 'signup_disabled',
      },
      { status: 403 }
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    console.error('[Auth/Google] Error:', message);
    return NextResponse.json(
      { error: 'Authentication failed', code: 'auth_error' },
      { status: 500 }
    );
  }
}
