import type { SpeechRecognition, SpeechRecognitionEvent, SpeechRecognitionErrorEvent } from '@/types/speech'
import type { VoiceEvent } from '../../../electron/speech'

/** Adapts native events to the existing voice hook; browser behavior is unchanged. */
export class DesktopSpeechRecognition extends EventTarget implements SpeechRecognition {
  continuous = true; interimResults = true; maxAlternatives = 1; lang = 'en-IN'
  phrases: string[] = []
  onaudiostart: SpeechRecognition['onaudiostart'] = null
  onsoundstart: SpeechRecognition['onsoundstart'] = null
  onspeechstart: SpeechRecognition['onspeechstart'] = null
  onspeechend: SpeechRecognition['onspeechend'] = null
  onaudioend: SpeechRecognition['onaudioend'] = null
  onprocessing: SpeechRecognition['onprocessing'] = null
  onstart: SpeechRecognition['onstart'] = null
  onresult: SpeechRecognition['onresult'] = null
  onnomatch: SpeechRecognition['onnomatch'] = null
  onerror: SpeechRecognition['onerror'] = null
  onend: SpeechRecognition['onend'] = null
  private id = ''
  private unsubscribe?: () => void
  private finals: string[] = []
  start() {
    if (this.id) throw new DOMException('Already listening', 'InvalidStateError')
    const voice = window.sakthi!.voice
    const id = this.id = crypto.randomUUID()
    this.finals = []
    this.unsubscribe = voice.onEvent((event: VoiceEvent) => {
      if (event.id !== this.id) return
      if (event.type === 'ready') { this.onstart?.call(this, new Event('start')); this.onaudiostart?.(new Event('audiostart')) }
      if (event.type === 'sound') { this.onsoundstart?.(new Event('soundstart')); this.onspeechstart?.(new Event('speechstart')) }
      if (event.type === 'processing') { this.onspeechend?.(new Event('speechend')); this.onaudioend?.(new Event('audioend')); this.onprocessing?.(new Event('processing')) }
      if (event.type === 'result' || event.type === 'interim') {
        this.onsoundstart?.(new Event('soundstart'))
        if (event.type === 'result' && event.text) this.finals.push(event.text)
        // Whisper's plain-text adapter has no calibrated confidence: do not invent 100% certainty.
        const entries = this.finals.map(text => ({ 0: { transcript: text, confidence: 0 }, length: 1, isFinal: true }))
        if (event.type === 'interim' && event.text) entries.push({ 0: { transcript: event.text, confidence: 0 }, length: 1, isFinal: false })
        this.onresult?.call(this, Object.assign(new Event('result'), { results: entries, resultIndex: 0 }) as unknown as SpeechRecognitionEvent)
      }
      if (event.type === 'error') this.fail(event.error || 'unknown')
      if (event.type === 'end') this.end()
    })
    void voice.start(id, this.lang, this.phrases).catch(() => { if (this.id === id) { this.fail('helper-unavailable'); this.end() } })
  }
  private fail(error: string) { this.onerror?.call(this, Object.assign(new Event('error'), { error }) as SpeechRecognitionErrorEvent) }
  private end() { if (!this.id) return; this.unsubscribe?.(); this.unsubscribe = undefined; this.id = ''; this.onend?.call(this, new Event('end')) }
  stop() { if (this.id) void window.sakthi!.voice.stop(this.id).catch(() => this.end()) }
  abort() { const id = this.id; if (!id) return; this.unsubscribe?.(); this.unsubscribe = undefined; this.id = ''; void window.sakthi!.voice.cancel(id).catch(() => {}) }
}
