// All fixtures and DDL are rolled back; no application records are changed.
const fs = require('node:fs');
const vm = require('node:vm');
const ts = require('typescript');
const assert = require('node:assert/strict');
require('dotenv').config({ quiet: true });
const { Client } = require('pg');
const out = {};
vm.runInNewContext(ts.transpileModule(fs.readFileSync('src/server/kanaku-schema.ts', 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText, { exports: out });
(async () => {
  const db = new Client({ connectionString: process.env.DATABASE_URL });
  await db.connect();
  try {
    await db.query('BEGIN');
    const schema = 'kanaku_test_' + Date.now();
    await db.query(`CREATE SCHEMA ${schema}`);
    await db.query(`SET LOCAL search_path TO ${schema}, public`);
    await db.query(`CREATE TABLE customers (id INTEGER PRIMARY KEY, user_id TEXT, full_name TEXT DEFAULT 'soorya', phone_number TEXT DEFAULT '7418169824', city_id INTEGER DEFAULT 1, business_id INTEGER DEFAULT 1, status TEXT DEFAULT 'Active', updated_at TIMESTAMPTZ);
      CREATE TABLE loans (loan_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), customer_id INTEGER, user_id TEXT, loan_amount NUMERIC DEFAULT 100, total_amount NUMERIC DEFAULT 100, received_amount NUMERIC DEFAULT 0, balance_amount NUMERIC DEFAULT 100, status TEXT DEFAULT 'Active', created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ, completed_at TIMESTAMPTZ);
      CREATE TABLE payments (payment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), loan_id UUID, customer_id INTEGER, user_id TEXT, amount NUMERIC);
      INSERT INTO customers(id,user_id) VALUES (1,'owner'), (2,'other');
      INSERT INTO loans(customer_id,user_id) VALUES (1,'owner');`);
    await db.query(out.kanakuMigration);
    const loan = async () => (await db.query("INSERT INTO loans(customer_id,user_id) VALUES(1,'owner') RETURNING *")).rows[0];
    const second = await loan();
    assert.equal(second.cycle_number, 1); assert.equal(second.kanaku_number, 2);
    const first = (await db.query('SELECT * FROM loans WHERE kanaku_number = 1')).rows[0];
    await db.query("INSERT INTO payments(loan_id,customer_id,user_id,amount) VALUES($1,1,'owner',100)", [first.loan_id]);
    const third = await loan(); assert.equal(third.kanaku_number, 3); assert.equal(third.cycle_number, 1);
    for (const l of [second, third]) await db.query("INSERT INTO payments(loan_id,customer_id,user_id,amount) VALUES($1,1,'owner',100)", [l.loan_id]);
    assert.equal((await db.query('SELECT status FROM kanaku_cycles WHERE cycle_number=1')).rows[0].status, 'Completed');
    const next = await loan(); assert.equal(next.cycle_number, 2); assert.equal(next.kanaku_number, 1); assert.notEqual(next.loan_id, first.loan_id);
    async function rejects(sql, params) {
      await db.query('SAVEPOINT rejected');
      await assert.rejects(db.query(sql, params));
      await db.query('ROLLBACK TO SAVEPOINT rejected');
    }
    await rejects('DELETE FROM loans WHERE loan_id=$1', [first.loan_id]);
    await rejects('UPDATE loans SET kanaku_number=99 WHERE loan_id=$1', [next.loan_id]);
    await rejects("INSERT INTO payments(loan_id,customer_id,user_id,amount) VALUES($1,1,'owner',101)", [next.loan_id]);
    await rejects("INSERT INTO loans(customer_id,user_id) VALUES(1,'other')");
    await rejects("UPDATE loans SET status='Completed' WHERE loan_id=$1", [next.loan_id]);
    await rejects('DELETE FROM payments');
    assert.equal((await db.query('SELECT COUNT(*)::int AS n FROM loans')).rows[0].n, 4);
    assert.equal((await db.query('SELECT COUNT(*)::int AS n FROM payments')).rows[0].n, 3);
    await db.query(out.kanakuMigration);
    assert.equal((await db.query('SELECT cycle_number FROM loans WHERE loan_id=$1', [next.loan_id])).rows[0].cycle_number, 2);
    await db.query("INSERT INTO customers(id,user_id) VALUES (3,'owner'),(4,'owner'),(5,'different-owner')");
    await db.query("UPDATE customers SET city_id=2 WHERE id=4");
    const same = (await db.query("INSERT INTO loans(customer_id,user_id) VALUES (3,'owner') RETURNING *")).rows[0];
    assert.equal(same.cycle_number, 2); assert.equal(same.kanaku_number, 2);
    const different = (await db.query("INSERT INTO loans(customer_id,user_id) VALUES (4,'owner'),(5,'different-owner') RETURNING *")).rows;
    assert.ok(different.every(row => row.cycle_number === 1 && row.kanaku_number === 1));
    await db.query("INSERT INTO customers(id,user_id) VALUES (6,'owner'),(7,'owner'),(8,'owner'),(9,'owner')");
    await db.query("UPDATE customers SET full_name='another name' WHERE id=6");
    await db.query("UPDATE customers SET phone_number='9876543210' WHERE id=7");
    await db.query("UPDATE customers SET business_id=2 WHERE id=8");
    const distinct = (await db.query("INSERT INTO loans(customer_id,user_id) VALUES (6,'owner'),(7,'owner'),(8,'owner') RETURNING *")).rows;
    assert.ok(distinct.every(row => row.cycle_number === 1 && row.kanaku_number === 1));
    await db.query("INSERT INTO payments(loan_id,customer_id,user_id,amount) VALUES ($1,1,'owner',100),($2,3,'owner',100)", [next.loan_id,same.loan_id]);
    const nextGroupCycle = (await db.query("INSERT INTO loans(customer_id,user_id) VALUES (9,'owner') RETURNING *")).rows[0];
    assert.equal(nextGroupCycle.cycle_number, 3); assert.equal(nextGroupCycle.kanaku_number, 1);
    console.log('PASS: backfill, numbering, partial cycle, completion, reset, unique IDs, ownership, overpayment, immutable history, idempotent migration.');
  } finally { await db.query('ROLLBACK'); await db.end(); }
})().catch(error => { console.error(error.message); process.exitCode = 1; });
