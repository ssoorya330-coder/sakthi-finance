import path from 'node:path'
export function trustedRenderer(url: string, dev = false): boolean {
  try {
    const parsed = new URL(url)
    return !parsed.username && !parsed.password && (dev ? parsed.origin === 'http://localhost:3000' : parsed.protocol === 'app:' && parsed.host === 'sakthi.local')
  } catch { return false }
}
export interface ApiCall {
  path: string; method?: string; body?: unknown
  query?: Record<string, string | number | boolean | undefined>
  form?: Array<{ name: string; value?: string; bytes?: number[]; filename?: string; type?: string }>
}
export function validCall(value: unknown): value is ApiCall {
  if (!value || typeof value !== 'object') return false
  const call = value as ApiCall
  if (typeof call.path !== 'string' || call.path.length > 2048 || !/^\/[A-Za-z0-9_/-]+$/.test(call.path)) return false
  if (!['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'].includes(call.method || 'GET')) return false
  try { return Buffer.byteLength(JSON.stringify(call)) <= 32 * 1024 * 1024 } catch { return false }
}
export function matchRoute(routes: string[], target: string): { key: string; params: Record<string, string> } | null {
  if (routes.includes(target)) return { key: target, params: {} }
  for (const key of routes) {
    const parts = key.split('/'), input = target.split('/')
    if (parts.length !== input.length) continue
    const params: Record<string, string> = {}
    if (parts.every((part, i) => {
      if (/^\[[A-Za-z][A-Za-z0-9]*\]$/.test(part) && input[i]) { params[part.slice(1, -1)] = input[i]; return true }
      return part === input[i]
    })) return { key, params }
  }
  return null
}
export function rendererFile(root: string, pathname: string): string | null {
  try {
    const decoded = decodeURIComponent(pathname)
    if (decoded.includes('\\') || decoded.includes('\0') || decoded.split('/').includes('..')) return null
    const file = path.resolve(root, '.' + decoded), relative = path.relative(root, file)
    return relative.startsWith('..') || path.isAbsolute(relative) ? null : file
  } catch { return null }
}
