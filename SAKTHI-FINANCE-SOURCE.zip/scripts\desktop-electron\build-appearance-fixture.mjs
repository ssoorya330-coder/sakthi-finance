import { build } from 'esbuild'
await build({entryPoints:['scripts/desktop-electron/appearance-ui-fixture.tsx'],bundle:true,platform:'browser',format:'iife',jsx:'automatic',define:{'process.env.NODE_ENV':'"production"'},outfile:'test-reports/appearance-ui-bundle.js'})
