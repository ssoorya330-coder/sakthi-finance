import { NextRequest, NextResponse } from 'next/server';
import { requireAuthWithPermission } from '@/lib/api-utils';
import { availableFinancialYears, overallSummary, customerSummary, loanDetails, transactionLedger, dataQualityChecks, reconcile, fyPeriodLabel } from '@/server/financial-audit';
import { cashTransactions } from '@/server/cash-audit';
import { yearlyReportFiles, buildReportArchive, type ArchiveFile } from '@/server/report-archive';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** Fetch every page; fail rather than silently truncate a financial report. */
async function allRows<T>(fetchPage: (page: number, size: number) => Promise<{ rows: T[]; total: number }>, signal: AbortSignal): Promise<T[]> {
  const result: T[] = [];
  let expected: number | undefined;
  for (let page = 1; ; page++) {
    signal.throwIfAborted();
    const batch = await fetchPage(page, 5000);
    if (batch.total > 200000) throw new Error('Report too large for one archive. Export an individual financial year from Financial Audit.');
    if (expected !== undefined && batch.total !== expected) throw new Error('Records changed during export. Please retry when data entry has finished.');
    expected = batch.total;
    result.push(...batch.rows);
    if (result.length === expected) return result;
    if (!batch.rows.length || result.length > expected) throw new Error('Unable to collect the complete report. Please retry.');
  }
}

export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('audit:read');
  if (auth.error) return auth.error;
  try {
    const userId = auth.user.userId;
    const years = await availableFinancialYears(userId);
    const generatedAt = new Date().toISOString();
    const files: ArchiveFile[] = [];
    let size = 0;
    for (const year of years) {
      request.signal.throwIfAborted();
      // Reuse the same owner-scoped business queries as Financial Audit.
      const [overall, customers, loans, ledger, cash, dataQuality] = await Promise.all([
        overallSummary(userId, year), customerSummary(userId, year), loanDetails(userId, year),
        allRows((page, limit) => transactionLedger(userId, year, page, limit), request.signal),
        allRows((page, limit) => cashTransactions(userId, year, {}, page, limit), request.signal),
        dataQualityChecks(userId, year),
      ]);
      const yearly = yearlyReportFiles({ fy: year, period: fyPeriodLabel(year), generatedAt,
        generatedBy: auth.user.email || userId, overall, customers, loans, ledger, cash,
        reconciliation: reconcile(overall, customers, loans, ledger), dataQuality });
      size += yearly.reduce((sum, file) => sum + file.data.length, 0);
      if (size > 100 * 1024 * 1024) throw new Error('Report archive exceeds 100 MB before compression. Export individual financial years from Financial Audit.');
      files.push(...yearly);
    }
    request.signal.throwIfAborted();
    const archive = buildReportArchive(files, Math.min(...years.map(y => y.startYear)), Math.max(...years.map(y => y.startYear)) + 1, generatedAt);
    return new NextResponse(new Uint8Array(archive.bytes), { headers: {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${archive.filename}"`,
      'Cache-Control': 'private, no-store',
      'X-Content-Type-Options': 'nosniff',
    } });
  } catch (error) {
    console.error('[Report Archive] Generation failed', error);
    const message = error instanceof Error ? error.message : '';
    const expected = /^(Report too large|Records changed|Unable to collect|Report archive exceeds)/.test(message);
    return NextResponse.json({ error: expected ? message : 'Unable to generate the report archive. Please try again.' }, { status: 500 });
  }
}
