import type { Variants } from 'framer-motion';

export const SPLASH_LOGO: Variants = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] },
  },
  exit: {
    opacity: 0,
    scale: 0.65,
    y: -60,
    transition: { duration: 0.6, ease: [0.7, 0, 0.84, 0] },
  },
};

export const LOGO_GLOW: Variants = {
  hidden: { opacity: 0, scale: 0.6 },
  visible: {
    opacity: [0, 0.6, 0.4],
    scale: [0.6, 1.3, 1.0],
    transition: { duration: 1.0, ease: [0.22, 1, 0.36, 1] },
  },
  exit: { opacity: 0, scale: 0.8, transition: { duration: 0.3 } },
};

export const LEFT_PANEL: Variants = {
  hidden: { opacity: 0, x: -60 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
  },
  exit: {
    opacity: 0,
    x: -40,
    transition: { duration: 0.3, ease: 'easeIn' },
  },
};

export const RIGHT_PANEL: Variants = {
  hidden: { opacity: 0, x: 60 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.6, delay: 0.1, ease: [0.22, 1, 0.36, 1] },
  },
  exit: {
    opacity: 0,
    x: 40,
    transition: { duration: 0.3, ease: 'easeIn' },
  },
};

export const CARD_ENTER: Variants = {
  hidden: { opacity: 0, y: 20, scale: 0.97 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] },
  },
  exit: {
    opacity: 0,
    y: -15,
    scale: 0.98,
    transition: { duration: 0.25, ease: 'easeIn' },
  },
};

export const BADGE_ENTER: Variants = {
  hidden: { opacity: 0, scale: 0.8, y: -8 },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: { duration: 0.4, delay: 0.2, ease: [0.22, 1, 0.36, 1] },
  },
};

export const STAGGER_CONTAINER: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.06,
      delayChildren: 0.1,
    },
  },
};

export const STAGGER_CHILD: Variants = {
  hidden: { opacity: 0, y: 10 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.35, ease: [0.22, 1, 0.36, 1] },
  },
};
