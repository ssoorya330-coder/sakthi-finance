import { contextBridge, ipcRenderer } from 'electron'

/**
 * The ONLY bridge between the renderer and the main process. No ipcRenderer,
 * fs, child_process, tokens, environment or process access is exposed.
 */

const api = {
  tablet: {
    status: () => ipcRenderer.invoke('tablet:status'),
    enable: (environment: 'development'|'production') => ipcRenderer.invoke('tablet:enable',environment),
    disable: () => ipcRenderer.invoke('tablet:disable'),
    code: () => ipcRenderer.invoke('tablet:code'),
    decide: (requestId:string,approve:boolean) => ipcRenderer.invoke('tablet:decide',{requestId,approve}),
    revoke: (id:string) => ipcRenderer.invoke('tablet:revoke',id),
  },
  updates: {
    onlineStatus: () => ipcRenderer.invoke('updates:online-status'),
    check: () => ipcRenderer.invoke('updates:check'),
    download: () => ipcRenderer.invoke('updates:download'),
    restart: () => ipcRenderer.invoke('updates:restart'),
    onEvent: (callback: (state: import('./online-updates').OnlineUpdateStatus) => void) => {
      const listener = (_event: Electron.IpcRendererEvent, state: import('./online-updates').OnlineUpdateStatus) => callback(state)
      ipcRenderer.on('updates:online-event', listener)
      return () => ipcRenderer.removeListener('updates:online-event', listener)
    },
    status: () => ipcRenderer.invoke('updates:status'),
    select: () => ipcRenderer.invoke('updates:select'),
    install: () => ipcRenderer.invoke('updates:install'),
  },
  voice: {
    start: (id: string, lang: string, phrases?: string[]) => ipcRenderer.invoke('voice:start', { id, lang, phrases }),
    resetPermission: () => ipcRenderer.invoke('voice:resetPermission'),
    stop: (id: string) => ipcRenderer.invoke('voice:stop', id),
    cancel: (id: string) => ipcRenderer.invoke('voice:cancel', id),
    onEvent: (callback: (event: import('./speech').VoiceEvent) => void) => {
      const listener = (_event: Electron.IpcRendererEvent, value: import('./speech').VoiceEvent) => callback(value)
      ipcRenderer.on('voice:event', listener)
      return () => ipcRenderer.removeListener('voice:event', listener)
    },
  },
  // Session
  startSignIn: () => ipcRenderer.invoke('auth:start'),
  cancelSignIn: () => ipcRenderer.invoke('auth:cancel'),
  restoreSession: () => ipcRenderer.invoke('auth:restore'),
  setName: (name: string) => ipcRenderer.invoke('auth:setName', name),
  logout: () => ipcRenderer.invoke('auth:logout'),

  // Data (runs existing application handlers in the main process)
  api: (call: { path: string; method?: string; body?: unknown; query?: Record<string, string | number | boolean | undefined> }) =>
    ipcRenderer.invoke('api:call', call),

  // Files / exports
  chooseDirectory: () => ipcRenderer.invoke('dialog:chooseDirectory'),
  chooseSavePath: (options: { defaultName?: string; filters?: Array<{ name: string; extensions: string[] }> }) =>
    ipcRenderer.invoke('dialog:chooseSavePath', options),
  writeExport: (payload: { path: string; data: string; encoding?: 'utf8' | 'base64' }) =>
    ipcRenderer.invoke('export:write', payload),

  // Info
  appInfo: () => ipcRenderer.invoke('app:info'),
  platform: process.platform,
}

export type SakthiDesktopApi = typeof api

contextBridge.exposeInMainWorld('sakthi', api)
contextBridge.exposeInMainWorld('sakthiFinance', api)
