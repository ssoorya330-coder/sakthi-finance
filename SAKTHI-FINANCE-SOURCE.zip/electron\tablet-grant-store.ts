import { readFile, open, rename, mkdir } from 'node:fs/promises'
import path from 'node:path'
import { randomUUID } from 'node:crypto'
import type { GrantStore, TabletGrant, PairingScope } from './tablet-pairing'

export interface PrivateCodec { encrypt(value:string):Buffer; decrypt(value:Buffer):string }
/** Single-process durable encrypted grant store. Writes are serialized and synced
 * before atomic replacement. A failed write never updates the in-memory state. */
export class TabletGrantStore implements GrantStore {
  private queue:Promise<unknown>=Promise.resolve()
  constructor(private file:string,private codec:PrivateCodec) {}
  private serial<T>(task:()=>Promise<T>):Promise<T> {
    const result=this.queue.then(task,task);this.queue=result.catch(()=>{});return result
  }
  private async read():Promise<TabletGrant[]> {
    let bytes:Buffer
    try {bytes=await readFile(this.file)}catch(e){if((e as NodeJS.ErrnoException).code==='ENOENT')return[];throw e}
    const value=JSON.parse(this.codec.decrypt(bytes))
    if(value.version!==1||!Array.isArray(value.grants)||value.grants.length>1000)throw Error('Invalid trusted device store')
    for(const g of value.grants) {
      if(!g||typeof g.tokenHash!=='string'||!/^[0-9a-f]{64}$/.test(g.tokenHash)||
        !['ownerId','googleSubject','laptopId','databaseId','deviceId','deviceName'].every(k=>typeof g[k]==='string'&&g[k].length>0)||
        !['development','production'].includes(g.environment)||!Number.isFinite(g.approvedAt))throw Error('Invalid trusted device grant')
    }
    return value.grants
  }
  private async write(grants:TabletGrant[]) {
    await mkdir(path.dirname(this.file),{recursive:true})
    const temp=this.file+'.'+randomUUID()+'.tmp'
    const handle=await open(temp,'wx',0o600)
    try {await handle.writeFile(this.codec.encrypt(JSON.stringify({version:1,grants})));await handle.sync()}
    finally{await handle.close()}
    await rename(temp,this.file)
  }
  save(grant:TabletGrant) {
    return this.serial(async()=>{
      const grants=await this.read()
      // Keep one active credential per device and exact environment/account.
      const next=grants.filter(g=>!this.matches(g,grant)||g.deviceId!==grant.deviceId)
      if(next.length>=1000)throw Error('Device limit exceeded')
      next.push({...grant});await this.write(next)
    })
  }
  find(tokenHash:string) {return this.serial(async()=> (await this.read()).find(g=>g.tokenHash===tokenHash)??null)}
  revoke(scope:PairingScope,deviceId:string) {return this.serial(async()=>this.write((await this.read()).filter(g=>!this.matches(g,scope)||g.deviceId!==deviceId)))}
  list(scope:PairingScope) {return this.serial(async()=>(await this.read()).filter(g=>this.matches(g,scope)).map(({tokenHash,...g})=>g))}
  private matches(a:PairingScope,b:PairingScope) {
    return a.ownerId===b.ownerId&&a.googleSubject===b.googleSubject&&a.laptopId===b.laptopId&&a.databaseId===b.databaseId&&a.environment===b.environment
  }
}
