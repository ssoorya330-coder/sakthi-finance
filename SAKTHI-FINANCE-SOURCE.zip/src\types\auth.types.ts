export type UserRole = 'owner' | 'admin' | 'manager' | 'employee' | 'viewer';

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  roleId?: number;
  isActive?: boolean;
}
