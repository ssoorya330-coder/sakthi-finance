import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs'
import { randomBytes } from 'node:crypto'
import path from 'node:path'
import os from 'node:os'

/**
 * One-time helper: writes the private desktop runtime config
 * (%APPDATA%/com.sakthifinance.desktop/runtime.json) from the project .env
 * values, generating fresh signing keys when absent. Values are never
 * printed. Re-run safely: existing non-empty values are kept.
 */

const dir = path.join(os.homedir(), 'AppData', 'Roaming', 'com.sakthifinance.desktop')
const file = path.join(dir, 'runtime.json')
mkdirSync(dir, { recursive: true })

let existing = {}
if (existsSync(file)) {
  try {
    existing = JSON.parse(readFileSync(file, 'utf8'))
  } catch {
    existing = {}
  }
}

function parseEnvFile(name) {
  try {
    const out = {}
    for (const line of readFileSync(name, 'utf8').split(/\r?\n/)) {
      const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/)
      if (match) out[match[1]] = match[2].replace(/^["']|["']$/g, '')
    }
    return out
  } catch {
    return {}
  }
}

const env = { ...parseEnvFile('.env'), ...parseEnvFile('.env.local') }

// DB: accept either DATABASE_URL or discrete DB_* values.
const config = { ...existing }
if (!config.DATABASE_URL && env.DATABASE_URL) config.DATABASE_URL = env.DATABASE_URL
for (const key of ['DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']) {
  if (!config[key] && env[key]) config[key] = env[key]
}
// Desktop Google OAuth client (loopback sign-in flow).
if (!config.GOOGLE_DESKTOP_CLIENT_ID && env.GOOGLE_DESKTOP_CLIENT_ID) config.GOOGLE_DESKTOP_CLIENT_ID = env.GOOGLE_DESKTOP_CLIENT_ID
if (!config.GOOGLE_DESKTOP_CLIENT_SECRET && env.GOOGLE_DESKTOP_CLIENT_SECRET) config.GOOGLE_DESKTOP_CLIENT_SECRET = env.GOOGLE_DESKTOP_CLIENT_SECRET
// Signing keys: generate strong random values when missing.
for (const key of ['JWT_ACCESS_SECRET', 'JWT_REFRESH_SECRET']) {
  if (!config[key]) config[key] = randomBytes(48).toString('base64url')
}

writeFileSync(file, JSON.stringify(config, null, 2), { mode: 0o600 })

// Report only key names and whether each has a value — never the values.
const summary = Object.fromEntries(Object.keys(config).map((k) => [k, Boolean(config[k])]))
console.log('runtime.json written:', file)
console.log('keys:', JSON.stringify(summary))
