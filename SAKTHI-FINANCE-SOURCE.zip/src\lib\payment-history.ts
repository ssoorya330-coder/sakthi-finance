import type { PaymentRecord } from '@/types/customer.types'

export function paymentDateInIndia(date = new Date()): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).format(date)
}

export function mapPayment(row: Record<string, any>): PaymentRecord {
  return {
    id: String(row.payment_id), customerId: String(row.customer_id),
    paymentAmount: Number(row.amount) || 0,
    paymentDate: String(row.payment_date || '').slice(0, 10),
    paymentTime: String(row.payment_time || '').slice(0, 8),
    paymentMethod: row.payment_mode === 'PhonePe' ? 'PhonePe' : row.payment_method || row.payment_mode || 'Cash',
    remainingBalance: Number(row.remaining_balance) || 0,
    remarks: row.remarks || '', collectedBy: row.collected_by || '',
    createdAt: String(row.created_at || ''),
  }
}

/** Calculate the ledger before applying display filters or pagination. */
export function customerPaymentLedger(history: PaymentRecord[], customerId: string, total: number): PaymentRecord[] {
  const ordered = history.filter((p) => p.customerId === customerId).sort((a, b) =>
    a.paymentDate.localeCompare(b.paymentDate) || a.paymentTime.localeCompare(b.paymentTime) ||
    a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id))
  let paid = 0
  return ordered.map((p) => {
    paid = Math.round((paid + p.paymentAmount) * 100) / 100
    return { ...p, remainingBalance: Math.max(0, Math.round((total - paid) * 100) / 100) }
  })
}
