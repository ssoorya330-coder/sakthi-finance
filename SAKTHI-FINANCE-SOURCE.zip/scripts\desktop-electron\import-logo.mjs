// Package the supplied artwork unchanged; only size/format conversion for ICO.
import sharp from 'sharp'
import { copyFile, mkdir, writeFile } from 'node:fs/promises'
import path from 'node:path'
const source = process.argv[2]
if (!source) throw Error('Supply the new logo image path')
const targets = ['public/sakthi-brand.png', 'public/icons/sakthi-finance-logo.png', 'desktop/electron-assets/icon.png', 'desktop/electron-assets/icon.ico']
const backup = path.join('.backups', 'logo-before-' + Date.now())
await mkdir(backup, { recursive: true })
for (const target of targets) await copyFile(target, path.join(backup, target.replaceAll('/', '_')))
for (const target of targets.filter(file => file.endsWith('.png'))) await copyFile(source, target)
const sizes = [16, 24, 32, 48, 64, 128, 256]
const images = await Promise.all(sizes.map(size => sharp(source).resize(size, size, { fit: 'contain' }).png().toBuffer()))
const header = Buffer.alloc(6 + images.length * 16)
header.writeUInt16LE(1, 2); header.writeUInt16LE(images.length, 4)
let offset = header.length
images.forEach((image, index) => {
  const pos = 6 + index * 16, size = sizes[index]
  header[pos] = size === 256 ? 0 : size; header[pos + 1] = header[pos]
  header.writeUInt16LE(1, pos + 4); header.writeUInt16LE(32, pos + 6)
  header.writeUInt32LE(image.length, pos + 8); header.writeUInt32LE(offset, pos + 12)
  offset += image.length
})
await writeFile('desktop/electron-assets/icon.ico', Buffer.concat([header, ...images]))
console.log('Supplied logo copied; seven Windows icon sizes generated. Old logo preserved in ' + backup)
