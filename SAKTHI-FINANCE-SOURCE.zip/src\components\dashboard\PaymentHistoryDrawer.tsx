'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { X, FileSpreadsheet, Printer } from 'lucide-react'
import CustomerKanaku from './CustomerKanakuCycles'
import { useCustomerStore } from '@/store/customer-store'
import { useAuthStore } from '@/store/auth-store'
import { hasPermission } from '@/config/rbac'
import { useToastStore } from '@/store/toast-store'
import { apiClient } from '@/services/api-client'
import { formatCurrency as money, formatDateDMY as date } from '@/features/dashboard/dashboard.styles'
import { formatCustomerCode } from '@/utils/customer-id'
import { formatLoanDisplayId } from '@/utils/loan-display-id'
import { customerPaymentPrintHtml } from '@/lib/customer-payment-report'
import { downloadExcel } from '@/lib/download-excel'
import { fetchKanakuPayments, kanakuLabel, nextKanakuDueDate, type HistoryKanaku } from '@/lib/kanaku-payment-history'
import type { Customer, PaymentRecord } from '@/types/customer.types'

interface PaymentHistoryDrawerProps { customer: Customer | null; isOpen: boolean; onClose: () => void }
const button = 'inline-flex items-center justify-center gap-2 rounded-xl border border-[var(--primary)]/25 bg-white px-3 py-2 text-sm font-semibold text-[var(--primary)] hover:bg-[var(--primary-soft)] disabled:opacity-40'
const panel = 'rounded-2xl border border-[var(--secondary)]/20 bg-white p-4'
const recordedAt = (record: PaymentRecord) => {
  const value = new Date(record.createdAt)
  return Number.isFinite(value.getTime()) ? value.toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }) : '—'
}

export default function PaymentHistoryDrawer({ customer: selectedCustomer, isOpen, onClose }: PaymentHistoryDrawerProps) {
  const role = useAuthStore(state => state.role)
  const customers = useCustomerStore(state => state.customers)
  const customer = customers.find(item => item.id === selectedCustomer?.id) ?? selectedCustomer
  const addToast = useToastStore(state => state.addToast)
  const [tab, setTab] = useState<'kanaku' | 'payments' | 'overview'>('payments')
  const [catalog, setCatalog] = useState<{ customerId: string; loans: HistoryKanaku[] } | null>(null)
  const [loanId, setLoanId] = useState('')
  const [loanError, setLoanError] = useState('')
  const [paymentError, setPaymentError] = useState('')
  const [loadingLoans, setLoadingLoans] = useState(false)
  const [loaded, setLoaded] = useState<{ key: string; records: PaymentRecord[] } | null>(null)
  const [retry, setRetry] = useState(0)
  const main = useRef<HTMLDivElement>(null)
  const loans = catalog?.customerId === customer?.id ? catalog?.loans ?? [] : []
  const loan = loans.find(item => String(item.loan_id) === loanId)
  const selectionKey = loan ? JSON.stringify([customer?.id, loan.customer_id, loan.loan_id]) : ''
  const ready = !!selectionKey && loaded?.key === selectionKey
  const payments = useMemo(() => ready ? loaded!.records : [], [ready, loaded])
  const paid = loan ? Number(loan.paid_amount ?? payments.reduce((sum, record) => sum + record.paymentAmount, 0)) : 0
  const balance = loan ? Number(loan.outstanding ?? Math.max(0, Number(loan.total_amount) - paid)) : 0
  const nextDue = loan ? nextKanakuDueDate(loan) : null
  const reportCustomer: Customer | null = loan && customer ? {
    ...(customers.find(item => String(item.id) === String(loan.customer_id)) ?? customer),
    id: String(loan.customer_id),
    customerCode: customers.find(item => String(item.id) === String(loan.customer_id))?.customerCode
      ?? (String(loan.customer_id) === String(customer.id) ? customer.customerCode : String(loan.customer_id)),
    loanId: String(loan.loan_id), loanAmount: String(loan.loan_amount), totalAmount: Number(loan.total_amount),
    interestRate: String(loan.interest_rate), loanDate: loan.loan_date, dueDate: loan.due_date,
  } : null

  useEffect(() => {
    if (!isOpen || !customer) return
    let cancelled = false
    setLoadingLoans(true); setLoanError(''); setLoaded(null); setCatalog(null); setLoanId('')
    apiClient.fetchLoans({ customerId: customer.id }).then(result => {
      if (cancelled) return
      const items = result.data as HistoryKanaku[]
      setCatalog({ customerId: customer.id, loans: items })
      setLoanId(String(items.find(item => String(item.loan_id) === String(customer.loanId))?.loan_id ?? items[0]?.loan_id ?? ''))
    }).catch(error => { if (!cancelled) setLoanError(error?.response?.data?.error || 'Could not load Kanaku. Please retry.') })
      .finally(() => { if (!cancelled) setLoadingLoans(false) })
    return () => { cancelled = true }
  }, [isOpen, customer?.id, retry])

  useEffect(() => {
    setTab('payments')
  }, [isOpen, customer?.id])

  useEffect(() => {
    setLoaded(null); setPaymentError('')
    if (!isOpen || !loan || !selectionKey) return
    let cancelled = false
    fetchKanakuPayments(apiClient, loan).then(records => {
      if (!cancelled) setLoaded({ key: selectionKey, records })
    }).catch(error => { if (!cancelled) setPaymentError(error?.response?.data?.error || 'Could not load this Kanaku’s payments. Please retry.') })
    return () => { cancelled = true }
  }, [isOpen, selectionKey, retry])

  const select = useCallback((id: string) => {
    setLoanId(id); setTab('payments')
    requestAnimationFrame(() => main.current?.scrollTo({ top: 0, behavior: 'smooth' }))
  }, [])

  const exportPrint = () => {
    if (!reportCustomer || !loan || !ready || paymentError) return
    const report = window.open('', '_blank')
    if (!report) { addToast('Allow pop-ups to print the selected Kanaku statement.', 'error'); return }
    report.opener = null
    report.document.open()
    report.document.write(customerPaymentPrintHtml(reportCustomer, payments, { includeReceiptId: false }))
    const label = report.document.createElement('p')
    label.textContent = kanakuLabel(loan) + ' · Loan ID: ' + formatLoanDisplayId(loan.kanaku_number) + ' · Paid: ' + money(paid) + ' · Balance: ' + money(balance)
    report.document.querySelector('.identity')?.appendChild(label)
    report.document.title = kanakuLabel(loan) + ' - ' + reportCustomer.fullName
    report.document.close()
    void report.document.fonts.ready.then(() => { if (!report.closed) { report.focus(); report.print() } })
  }
  const exportExcel = () => {
    if (!reportCustomer || !loan || !ready || paymentError) return
    void downloadExcel('kanaku-' + loan.loan_id + '.xlsx', 'Sakthi Finance - ' + kanakuLabel(loan),
      ['Customer ID', 'Customer Name', 'Cycle', 'Kanaku', 'Loan ID', 'Payment Date', 'Amount', 'Payment Mode', 'Remarks', 'Recorded By', 'Recorded Date'],
      payments.map(record => [formatCustomerCode(reportCustomer.customerCode), reportCustomer.fullName, loan.cycle_number ?? '', loan.kanaku_number ?? '', formatLoanDisplayId(loan.kanaku_number), date(record.paymentDate), record.paymentAmount, record.paymentMethod, record.remarks, record.collectedBy, recordedAt(record)]),
      ['Customer ID: ' + formatCustomerCode(reportCustomer.customerCode), 'Customer Name: ' + reportCustomer.fullName, kanakuLabel(loan), 'Loan ID: ' + formatLoanDisplayId(loan.kanaku_number), 'Paid: ' + money(paid), 'Balance: ' + money(balance)])
  }
  const cards = loan ? [
    ['Kanaku No.', kanakuLabel(loan)], ['Status', loan.status], ['Loan Amount', money(Number(loan.loan_amount))],
    ['Interest %', Number(loan.interest_rate) + '%'], ['Installment', money(Number(loan.installment_amount || loan.installment || 0))],
    ['Loan Date', loan.loan_date ? date(loan.loan_date) : '—'], ['Due Date', loan.due_date ? date(loan.due_date) : '—'],
    ['Loan Type', loan.loan_type || '—'],
    ['Paid Amount', money(paid)], ['Balance', money(balance)],
  ] : []
  const paymentTable = (records: PaymentRecord[]) => <div className="overflow-x-auto rounded-xl border border-[var(--secondary)]/20">
    <table className="w-full min-w-[800px] text-left text-sm">
      <thead className="bg-[var(--primary)] text-[#F6E7AF]"><tr>{['#', 'Payment Date', 'Amount', 'Payment Mode', 'Remarks', 'Recorded By', 'Recorded Date'].map(title => <th key={title} className="px-3 py-3 whitespace-nowrap">{title}</th>)}</tr></thead>
      <tbody>{records.map((record, index) => <tr key={record.id} className="border-b border-[var(--secondary)]/15 odd:bg-white even:bg-[#FCFBF4]">
        <td className="p-3">{index + 1}</td>
        <td className="p-3 whitespace-nowrap">{date(record.paymentDate)}</td>
        <td className="p-3 font-semibold whitespace-nowrap">{money(record.paymentAmount)}</td>
        <td className="p-3">{record.paymentMethod}</td>
        <td className="p-3 whitespace-pre-wrap">{record.remarks || '—'}</td>
        <td className="p-3">{record.collectedBy || '—'}</td>
        <td className="p-3 whitespace-nowrap">{recordedAt(record)}</td>
      </tr>)}</tbody>
    </table>
  </div>
  const statement = loan ? (<section aria-label="Selected Kanaku statement" className={panel + ' space-y-3'}>
            <h3 className="font-bold text-[var(--primary)]">{kanakuLabel(loan)} · Statement</h3><p className="break-all text-xs text-slate-500">Loan ID: {formatLoanDisplayId(loan.kanaku_number)} · Customer ID: {reportCustomer?.customerCode}</p>
            <p className="text-sm">Loan total: {money(Number(loan.total_amount))} · Paid: {money(paid)} · Balance: {money(balance)}</p>
            {'snapshot_paid_amount' in loan && <p className="text-sm text-amber-800">Offline snapshot: paid and balance include earlier payments. Only payments entered since the last sync are listed here. Full history remains on the laptop.</p>}
            {Number(loan.legacy_paid_amount || 0) > 0 && <p className="text-xs text-slate-500">Paid includes a preserved opening balance of {money(Number(loan.legacy_paid_amount))}.</p>}
            {paymentError ? <p role="alert" className="text-red-700">{paymentError} <button className={button} onClick={() => setRetry(value => value + 1)}>Retry</button></p> : !ready ? <p role="status">Loading selected Kanaku payments…</p> : payments.length ? paymentTable(payments) : <p>No payments recorded for this Kanaku yet.</p>}
            <div className="flex flex-wrap gap-2"><button className={button} disabled={!ready || !!paymentError} onClick={exportPrint}><Printer size={16} />Print / PDF</button><button className={button} disabled={!ready || !!paymentError} onClick={exportExcel}><FileSpreadsheet size={16} />Export Excel</button></div>
          </section>) : null
  if (!customer) return null
  return <AnimatePresence>{isOpen && <>
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[var(--z-modal)]" onClick={onClose} />
    <motion.div role="dialog" aria-modal="true" aria-label="Customer Details" initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} className="fixed top-0 right-0 h-full w-full max-w-[1100px] bg-[var(--background)] z-[var(--z-modal)] shadow-2xl flex flex-col">
      <header className="flex items-start justify-between gap-3 border-b border-[var(--secondary)]/20 bg-white px-6 py-4">
        <div><h2 className="text-lg font-bold text-[var(--primary)]">{customer.fullName}</h2><p className="text-sm text-slate-500">Customer {formatCustomerCode(customer.customerCode)} · {customer.mobileNumber}</p></div>
        <button className={button} aria-label="Close customer details" onClick={onClose}><X size={18} /></button>
      </header>
      <div role="tablist" aria-label="Customer details tabs" className="flex flex-wrap gap-2 border-b border-[var(--secondary)]/20 px-5 py-3">
        <button role="tab" id="history-tab" aria-controls="history-panel" aria-selected={tab === 'payments'} onClick={() => setTab('payments')} className={button + (tab === 'payments' ? ' !bg-[var(--primary)] !text-white' : '')}>Payment History</button>
        <button role="tab" id="kanaku-tab" aria-controls="kanaku-panel" aria-selected={tab === 'kanaku'} onClick={() => setTab('kanaku')} className={button + (tab === 'kanaku' ? ' !bg-[var(--primary)] !text-white' : '')}>Kanaku</button>
        <button role="tab" id="overview-tab" aria-controls="overview-panel" aria-selected={tab === 'overview'} onClick={() => setTab('overview')} className={button + (tab === 'overview' ? ' !bg-[var(--primary)] !text-white' : '')}>Kanaku Overview</button>
      </div>
      {tab === 'kanaku' && <div role="tabpanel" id="kanaku-panel" aria-labelledby="kanaku-tab" className="flex-1 min-h-0 overflow-y-auto">
        <div className="px-5 pt-5">
        {loanError && <p role="alert" className="text-red-700">{loanError} <button className={button} onClick={() => setRetry(value => value + 1)}>Retry</button></p>}
        <label className="block text-sm font-semibold text-[var(--primary)]">Select Kanaku
          <select disabled={loadingLoans || !loans.length} value={loanId} onChange={event => setLoanId(event.target.value)} className="mt-2 w-full rounded-xl border border-[var(--primary)]/25 bg-white p-3 text-sm text-slate-900">
            {!loans.length && <option value="">{loadingLoans ? 'Loading Kanaku…' : 'No Kanaku records'}</option>}
            {loans.map(item => <option key={item.loan_id} value={item.loan_id}>{kanakuLabel(item)}{String(item.loan_id) === loanId ? ' (Current)' : ''} · {item.status}</option>)}
          </select>
        </label>
        </div>
        <CustomerKanaku key={customer.id} customerId={customer.id} readOnly onViewPayments={select} paymentHistory={statement} view="summary" />
      </div>}
      {tab === 'overview' && <div role="tabpanel" id="overview-panel" aria-labelledby="overview-tab" className="flex-1 min-h-0 overflow-y-auto">
        <CustomerKanaku key={customer.id} customerId={customer.id} readOnly={!hasPermission(role, 'loans:create')} onViewPayments={select} onChanged={() => setRetry(value => value + 1)} view="overview" />
      </div>}
      <div ref={main} hidden={tab !== 'payments'} role="tabpanel" id="history-panel" aria-labelledby="history-tab" className="flex-1 min-h-0 overflow-y-auto p-4 sm:p-6 space-y-5">
        <h3 className="font-bold text-[var(--primary)]">Payment History{loan ? ` — ${kanakuLabel(loan)} (Current)` : ''}</h3>
        {loanError && <p role="alert" className="text-red-700">{loanError} <button className={button} onClick={() => setRetry(value => value + 1)}>Retry</button></p>}
        {loadingLoans && <p role="status">Loading Kanaku…</p>}
        {!loadingLoans && !loanError && !loans.length && <p className={panel}>No Kanaku records for this customer.</p>}
        {loan && <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">{cards.map(([label, value]) => <div key={label} className={panel}><p className="text-xs text-slate-500">{label}</p><p className="mt-1 break-words font-semibold text-[var(--primary)]">{value}</p></div>)}</div>
          <div className={panel + ' flex flex-wrap items-center justify-between gap-4'}>
            <div><p className="text-xs text-slate-500">Total Payments</p><strong>{ready ? payments.length : '—'}</strong></div>
            <div><p className="text-xs text-slate-500">Total Amount Paid</p><strong>{money(paid)}</strong></div>
            <div><p className="text-xs text-slate-500">Next Due Date</p><strong>{nextDue ? date(nextDue) : '—'}</strong></div>
          </div>
          {statement}
        </>}
      </div>
    </motion.div>
  </>}</AnimatePresence>
}
