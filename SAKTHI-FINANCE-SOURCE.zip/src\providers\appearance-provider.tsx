'use client'
import { createContext, useContext, useEffect, useState } from 'react'
import { THEMES, THEME_KEY, themeTokens, type ThemeId } from '@/lib/appearance'
const Appearance = createContext({ theme: 'classic' as ThemeId, select: (_id: ThemeId) => {}, storageWarning: false })
export const useAppearance = () => useContext(Appearance)
export function AppearanceProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<ThemeId>('classic')
  const [storageWarning, setStorageWarning] = useState(false)
  function apply(id: ThemeId) {
    const root = document.documentElement
    root.dataset.appearance = id
    for (const [name, value] of Object.entries(themeTokens(id))) root.style.setProperty(name, value)
    setTheme(id)
  }
  useEffect(() => {
    try { const saved = localStorage.getItem(THEME_KEY); apply(THEMES.find(t => t.id === saved)?.id ?? 'classic') }
    catch { apply('classic'); setStorageWarning(true) }
  }, [])
  function select(id: ThemeId) {
    apply(id)
    try { localStorage.setItem(THEME_KEY, id); setStorageWarning(false) } catch { setStorageWarning(true) }
  }
  return <Appearance.Provider value={{ theme, select, storageWarning }}>{children}</Appearance.Provider>
}
