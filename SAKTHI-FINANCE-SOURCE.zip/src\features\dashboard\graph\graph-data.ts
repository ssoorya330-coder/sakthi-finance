import type { Customer, PaymentRecord } from '@/types/customer.types'
import type {
  GraphDataPoint,
  GraphDateRange,
  Granularity,
  MetricKey,
  RangeKey,
} from './graph.types'

const DAY_MS = 86_400_000

export function startOfDay(d: Date): Date {
  const r = new Date(d)
  r.setHours(0, 0, 0, 0)
  return r
}

function endOfDay(d: Date): Date {
  const r = new Date(d)
  r.setHours(23, 59, 59, 999)
  return r
}

function parseDate(dateStr?: string): Date | null {
  if (!dateStr) return null
  const d = new Date(dateStr)
  return isNaN(d.getTime()) ? null : d
}

function pad(n: number): string {
  return String(n).padStart(2, '0')
}

export function toDayKey(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}

function toMonthKey(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`
}

export function formatDayShort(d: Date): string {
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
}

export function formatDayFull(d: Date): string {
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
}

function formatMonthLabel(d: Date): string {
  return d.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })
}

export function formatCompact(v: number): string {
  const abs = Math.abs(v)
  if (abs >= 1e7) return `${(v / 1e7).toFixed(1)}Cr`
  if (abs >= 1e5) return `${(v / 1e5).toFixed(1)}L`
  if (abs >= 1e3) return `${(v / 1e3).toFixed(0)}k`
  return `${Math.round(v)}`
}

export function getPresetRanges(now = new Date()): Record<Exclude<RangeKey, 'custom'>, GraphDateRange> {
  const today = startOfDay(now)
  const yesterday = new Date(today)
  yesterday.setDate(today.getDate() - 1)

  const last7Start = new Date(today)
  last7Start.setDate(today.getDate() - 6)

  const last30Start = new Date(today)
  last30Start.setDate(today.getDate() - 29)

  const last1yStart = new Date(today)
  last1yStart.setDate(today.getDate() - 364)

  const currentMonthStart = new Date(now.getFullYear(), now.getMonth(), 1)
  const last3mStart = new Date(currentMonthStart.getFullYear(), currentMonthStart.getMonth() - 2, 1)
  const last6mStart = new Date(currentMonthStart.getFullYear(), currentMonthStart.getMonth() - 5, 1)

  return {
    today: { start: today, end: today },
    yesterday: { start: yesterday, end: yesterday },
    last7: { start: last7Start, end: today },
    last30: { start: last30Start, end: today },
    last3m: { start: last3mStart, end: today },
    last6m: { start: last6mStart, end: today },
    last1y: { start: last1yStart, end: today },
  }
}

export function getDefaultCustomRange(): GraphDateRange {
  const end = startOfDay(new Date())
  const start = new Date(end)
  start.setDate(end.getDate() - 29)
  return { start, end }
}

export function resolveGranularity(key: RangeKey, range: GraphDateRange): Granularity {
  if (key === 'custom') {
    const spanDays = Math.round((range.end.getTime() - range.start.getTime()) / DAY_MS) + 1
    return spanDays <= 62 ? 'daily' : 'monthly'
  }
  return key === 'last3m' || key === 'last6m' ? 'monthly' : 'daily'
}

interface LoanBucket {
  given: number
  interest: number
  total: number
}

export function buildGraphData(
  range: GraphDateRange,
  granularity: Granularity,
  customers: Customer[],
  paymentHistory: PaymentRecord[]
): GraphDataPoint[] {
  const start = startOfDay(range.start)
  const end = endOfDay(range.end)
  if (start.getTime() > end.getTime()) return []

  const loansByDay = new Map<string, LoanBucket>()
  const loansByMonth = new Map<string, LoanBucket>()

  const addLoan = (
    map: Map<string, LoanBucket>,
    key: string,
    given: number,
    interest: number,
    total: number
  ) => {
    const cur = map.get(key) ?? { given: 0, interest: 0, total: 0 }
    cur.given += given
    cur.interest += interest
    cur.total += total
    map.set(key, cur)
  }

  for (const c of customers) {
    const d = parseDate(c.loanDate)
    if (!d) continue
    if (d < start || d > end) continue
    const given = Number(c.loanAmount) || 0
    const interest = Number(c.interestAmount) || 0
    const total = c.totalAmount || 0
    addLoan(loansByDay, toDayKey(d), given, interest, total)
    addLoan(loansByMonth, toMonthKey(d), given, interest, total)
  }

  const payByDay = new Map<string, number>()
  const payByMonth = new Map<string, number>()
  for (const p of paymentHistory) {
    const d = parseDate(p.paymentDate)
    if (!d) continue
    if (d < start || d > end) continue
    const amt = Number(p.paymentAmount) || 0
    const dayKey = toDayKey(d)
    const monthKey = toMonthKey(d)
    payByDay.set(dayKey, (payByDay.get(dayKey) ?? 0) + amt)
    payByMonth.set(monthKey, (payByMonth.get(monthKey) ?? 0) + amt)
  }

  const points: GraphDataPoint[] = []
  let cumulativeDue = 0
  let cumulativePaid = 0

  if (granularity === 'daily') {
    const cursor = new Date(start)
    while (cursor.getTime() <= end.getTime()) {
      const dayKey = toDayKey(cursor)
      const loan = loansByDay.get(dayKey)
      const received = payByDay.get(dayKey) ?? 0
      cumulativeDue += loan?.total ?? 0
      cumulativePaid += received
      points.push({
        date: dayKey,
        label: formatDayShort(cursor),
        fullLabel: formatDayFull(cursor),
        amountGiven: loan?.given ?? 0,
        amountReceived: received,
        interestEarned: loan?.interest ?? 0,
        remainingBalance: Math.max(0, cumulativeDue - cumulativePaid),
        todayCollection: received,
      })
      cursor.setDate(cursor.getDate() + 1)
    }
  } else {
    const endMonth = new Date(end.getFullYear(), end.getMonth(), 1)
    const cursor = new Date(start.getFullYear(), start.getMonth(), 1)
    while (cursor.getTime() <= endMonth.getTime()) {
      const monthKey = toMonthKey(cursor)
      const loan = loansByMonth.get(monthKey)
      const received = payByMonth.get(monthKey) ?? 0
      cumulativeDue += loan?.total ?? 0
      cumulativePaid += received
      points.push({
        date: monthKey,
        label: formatMonthLabel(cursor),
        fullLabel: formatMonthLabel(cursor),
        amountGiven: loan?.given ?? 0,
        amountReceived: received,
        interestEarned: loan?.interest ?? 0,
        remainingBalance: Math.max(0, cumulativeDue - cumulativePaid),
        todayCollection: received,
      })
      cursor.setMonth(cursor.getMonth() + 1)
    }
  }

  return points
}

export function isGraphDataEmpty(points: GraphDataPoint[]): boolean {
  if (points.length === 0) return true
  return points.every(
    (p) =>
      p.amountGiven === 0 &&
      p.amountReceived === 0 &&
      p.interestEarned === 0 &&
      p.remainingBalance === 0 &&
      p.todayCollection === 0
  )
}

export function sumMetric(points: GraphDataPoint[], key: MetricKey): number {
  return points.reduce((sum, p) => sum + p[key], 0)
}
