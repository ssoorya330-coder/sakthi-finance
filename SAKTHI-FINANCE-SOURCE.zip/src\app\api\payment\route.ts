import { resolveCustomerId } from '@/server/customer-identity'
import { NextRequest, NextResponse } from 'next/server'
import { dbQuery, dbTransaction } from '@/server/database'
import { requireAuthWithPermission, isCustomerOwnedBy, isLoanOwnedBy } from '@/lib/api-utils'
import {
  actorFromAuthUser,
  requestMeta,
  recordAuditEvent,
  recordAuditStandalone,
  PAYMENT_LABELS,
} from '@/server/audit'
import {
  PAYMENT_MODES,
  checkRepaymentCompliance,
  getCashThreshold,
  recordCashFlagEvent,
} from '@/server/cash-compliance'
import { fyOf } from '@/server/financial-audit'

export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('payments:create');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const userId = user.userId
    const body = await request.json()
    const { loan_id, customer_id: rawCustomerId, amount, payment_date, payment_time, payment_method, payment_mode, remarks, reason } = body
    if (typeof loan_id !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(loan_id)) {
      return NextResponse.json({ error: 'Select a valid Kanaku before saving the payment.' }, { status: 400 })
    }
    const customer_id = await resolveCustomerId(rawCustomerId)
    if (!Number.isFinite(Number(amount)) || Number(amount) <= 0 || !/^\d+(\.\d{1,2})?$/.test(String(amount))) {
      return NextResponse.json({ error: 'Enter a positive payment amount with up to two decimal places.' }, { status: 400 })
    }

    // Owner-scoped: payments (and their balance/status side effects) may only
    // touch the caller's own customer and loan. Never trust these ids blindly.
    if (!customer_id || !(await isCustomerOwnedBy(customer_id, userId))) {
      return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
    }
    if (loan_id && !(await isLoanOwnedBy(loan_id, userId))) {
      return NextResponse.json({ error: 'Loan not found' }, { status: 404 })
    }
    if (loan_id) {
      const matchingLoan = await dbQuery('SELECT loan_id FROM loans WHERE loan_id = $1 AND customer_id = $2 AND user_id = $3', [loan_id, customer_id, userId])
      if (!matchingLoan.rows.length) return NextResponse.json({ error: 'Loan does not belong to this customer' }, { status: 400 })
    }

    const meta = requestMeta(request)
    const actor = actorFromAuthUser(user)
    const payMode = payment_mode === undefined || payment_mode === null || payment_mode === ''
      ? (payment_method || 'Cash')
      : String(payment_mode)
    if (!(PAYMENT_MODES as readonly string[]).includes(payMode)) {
      return NextResponse.json({ error: 'Payment mode must be Cash, Bank, UPI, PhonePe or Cheque.' }, { status: 400 })
    }
    const threshold = await getCashThreshold()
    const currentFy = fyOf()
    // Payment insert + loan balance update + creation audit commit atomically:
    // a payment must never exist without its audit record.
    const { payment, payments, repaymentCheck } = await dbTransaction(async (tx) => {
      // Serialize payments for this customer so simultaneous saves cannot
      // both spend the same outstanding balance.
      await tx.query('SELECT id FROM customers WHERE id = $1 AND user_id = $2 FOR UPDATE', [customer_id, userId])
      const outstanding = await tx.query(
        `SELECT GREATEST(0, COALESCE((SELECT SUM(outstanding) FROM kanaku_loan_balances WHERE customer_id = $1 AND user_id = $2), 0)) AS balance`,
        [customer_id, userId]
      )
      const balance = Number(outstanding.rows[0]?.balance) || 0
      if (Math.round(Number(amount) * 100) > Math.round(balance * 100)) {
        throw Object.assign(new Error(`Received amount exceeds the remaining balance of ${balance.toFixed(2)}. Correct the amount and save again.`), { status: 400 })
      }
      if (loan_id) {
        const loanBalance = await tx.query(
          `SELECT outstanding AS balance FROM kanaku_loan_balances WHERE loan_id = $1 AND customer_id = $2 AND user_id = $3`,
          [loan_id, customer_id, userId]
        )
        if (!loanBalance.rows.length || Math.round(Number(amount) * 100) > Math.round(Number(loanBalance.rows[0].balance) * 100)) {
          throw Object.assign(new Error('Received amount exceeds this Kanaku balance. Refresh and correct the amount.'), { status: 400 })
        }
      }
      // History-based compliance check BEFORE insert (FY cumulative needs the
      // pre-insert total; the rule accounts for the new payment itself).
      const check = await checkRepaymentCompliance(
        tx,
        {
          userId,
          customerId: customer_id,
          amount: Number(amount) || 0,
          mode: payMode,
          fyFrom: currentFy.from,
          fyTo: currentFy.to,
        },
        threshold
      )
      const targets = await tx.query(
        `SELECT loan_id, outstanding FROM kanaku_loan_balances WHERE customer_id = $1 AND user_id = $2 AND outstanding > 0
          AND ($3::uuid IS NULL OR loan_id = $3) ORDER BY cycle_number, kanaku_number`, [customer_id, userId, loan_id || null]
      )
      let pending = Math.round(Number(amount) * 100)
      const payments: any[] = []
      for (const target of targets.rows) {
        if (!pending) break
        const allocated = Math.min(pending, Math.round(Number(target.outstanding) * 100)) / 100
        pending -= Math.round(allocated * 100)
      const result = await tx.query(
        `INSERT INTO payments (loan_id, customer_id, amount, payment_date, payment_time, payment_method, payment_mode, remarks, user_id, is_flagged, flag_reason)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
        [target.loan_id, customer_id, allocated, payment_date, payment_time || null, payment_method || 'Cash', payMode, remarks || null, userId, check.flagged, check.reason]
      )
      const row = result.rows[0]

      const after = {
        amount: allocated, payment_date: payment_date || null,
        payment_time: payment_time || null, payment_method: payment_method || 'Cash',
        payment_mode: payMode, remarks: remarks || null,
      }
      await recordAuditEvent(tx, {
        action: 'PAYMENT_RECORDED',
        entityType: 'payment',
        entityId: row.payment_id,
        customerId: customer_id,
        loanId: target.loan_id,
        paymentId: row.payment_id,
        actor,
        ipAddress: meta.ip,
        clientInfo: meta.client,
        reason: typeof reason === 'string' ? reason : null,
        result: 'SUCCESS',
        changes: Object.entries(after)
          .filter(([, v]) => v !== null)
          .map(([field, v]) => ({ field, label: PAYMENT_LABELS[field] || field, before: null, after: v })),
        after,
      })
      if (check.flagged) {
        await recordCashFlagEvent(tx, {
          action: 'CASH_PAYMENT_FLAGGED',
          entityType: 'payment',
          entityId: row.payment_id,
          customerId: customer_id,
          loanId: target.loan_id,
          paymentId: row.payment_id,
          actor,
          ip: meta.ip,
          client: meta.client,
          threshold,
          amount: allocated,
          reason: check.reason as string,
          after: { ...after, is_flagged: true },
        })
      }
      payments.push({ ...row, collected_by: user.name, payment_date })
      }
      if (pending > 0 || !payments.length) throw Object.assign(new Error('Could not allocate the amount to current Kanaku balances. Refresh and retry.'), { status: 400 })
      return { payment: payments[0], payments, repaymentCheck: check }
    })

    if (payment_date) {
      await dbQuery(
        `INSERT INTO daily_collection (collection_date, customer_id, amount, payment_method, remarks, user_id) VALUES ($1,$2,$3,$4,$5,$6)`,
        [payment_date, customer_id, amount || 0, payment_method || 'Cash', remarks || null, userId]
      ).catch(() => {})
    }

    return NextResponse.json({
      ...payment,
      payments,
      payment_date,
      collected_by: user.name,
      cashCompliance: repaymentCheck.flagged
        ? {
            flagged: true, kind: 'repayment', threshold,
            reason: repaymentCheck.reason, details: repaymentCheck.details,
            fyCashBefore: repaymentCheck.fyCashBefore, fyCashAfter: repaymentCheck.fyCashAfter,
          }
        : { flagged: false, kind: 'repayment', threshold },
    }, { status: 201 })
  } catch (err: any) {
    console.error('[POST /api/payment] Error:', err.message)
    return NextResponse.json(
      { error: err.status === 400 ? err.message : 'Failed to record payment', details: err.message },
      { status: err.status === 400 ? 400 : 500 }
    )
  }
}
