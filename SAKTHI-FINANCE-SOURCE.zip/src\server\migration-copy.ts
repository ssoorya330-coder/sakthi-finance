import { spawn, type ChildProcess } from 'child_process';
import crypto from 'crypto';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { dirSizeBytes, getDataDirectory } from './storage';

/**
 * Automatic data-directory copy jobs for the one-click migration flow.
 *
 * Uses native robocopy (multithreaded, preserves NTFS ACLs via /COPYALL)
 * while PostgreSQL is stopped. Progress is REAL: destination bytes measured
 * on disk divided by the pre-measured source size — no timers, no guessing.
 *
 * Single-process in-memory job store (the app runs as one desktop server).
 */

export type CopyJobStatus = 'running' | 'done' | 'failed' | 'cancelled';

export interface CopyJobProgress {
  status: CopyJobStatus;
  copiedBytes: number | null;
  totalBytes: number | null;
  /** 0–100, from actual bytes on disk. Null until the first measurement. */
  percent: number | null;
  exitCode: number | null;
  error: string | null;
}

interface CopyJob {
  id: string;
  src: string;
  dest: string;
  totalBytes: number;
  proc: ChildProcess | null;
  status: CopyJobStatus;
  exitCode: number | null;
  error: string | null;
  startedAt: number;
  lastMeasureAt: number;
  lastCopiedBytes: number | null;
}

const jobs = new Map<string, CopyJob>();

const MIN_MEASURE_INTERVAL_MS = 1500;
const MAX_JOB_AGE_MS = 6 * 60 * 60 * 1000;

function cleanupStaleJobs() {
  const now = Date.now();
  for (const [id, job] of jobs) {
    if (job.status !== 'running' && now - job.startedAt > MAX_JOB_AGE_MS) {
      jobs.delete(id);
    }
  }
}

function sanitizeDir(input: string): string | null {
  const raw = (input || '').trim();
  if (!raw) return null;
  // PostgreSQL reports paths with forward slashes (SHOW data_directory) —
  // normalize first so detected paths validate. Never reject a path merely
  // for slash style or for living under Program Files.
  const trimmed = raw.replace(/\//g, '\\');
  // Absolute Windows path only (e.g. D:\PostgreSQL\data). No UNC, no shell chars.
  if (!/^[A-Za-z]:\\/.test(trimmed)) return null;
  if (/["`$&|<>^]/.test(trimmed)) return null;
  return path.win32.normalize(trimmed).replace(/\\$/, '');
}

/**
 * Start an automatic copy. Throws on validation failure.
 * Safety: refuses unless PostgreSQL is stopped (checked by the caller via
 * the service route AND re-checked here against the live data directory is
 * not required — the service check lives in the API route).
 */
export async function startCopyJob(
  source: string,
  destination: string,
  opts?: { totalBytes?: number | null }
): Promise<{ jobId: string; totalBytes: number }> {
  if (os.platform() !== 'win32') {
    throw new Error('Automatic copy is only supported on Windows. Copy manually with robocopy.');
  }
  cleanupStaleJobs();

  const src = sanitizeDir(source);
  const dest = sanitizeDir(destination);
  if (!src) {
    throw new Error(
      'Could not determine the PostgreSQL data directory (the detected source path is not a valid absolute local path).'
    );
  }
  if (!dest) throw new Error('Invalid destination directory.');
  if (src.toLowerCase() === dest.toLowerCase()) {
    throw new Error('Destination must differ from the current data directory.');
  }
  if (dest.toLowerCase().startsWith(src.toLowerCase() + '\\')) {
    throw new Error('Destination must not be inside the current data directory.');
  }

  // Source must be the live data directory and readable.
  const liveDir = await getDataDirectory();
  if (liveDir) {
    const liveNorm = liveDir.replace(/\//g, '\\').toLowerCase().replace(/\\$/, '');
    if (liveNorm !== src.toLowerCase()) {
      throw new Error('Source is no longer the active data directory. Re-detect and retry.');
    }
  }
  try {
    fs.accessSync(src, fs.constants.R_OK);
    const st = fs.statSync(/* turbopackIgnore: true */ src);
    if (!st.isDirectory()) throw new Error('not a directory');
    // Source must look like a PostgreSQL cluster (works while stopped).
    fs.accessSync(path.join(src, 'PG_VERSION'), fs.constants.R_OK);
  } catch {
    throw new Error('Source does not look like a PostgreSQL data directory (PG_VERSION not readable).');
  }

  // Destination: must be empty (or creatable). Never merge into a non-empty dir.
  try {
    const st = fs.statSync(/* turbopackIgnore: true */ dest);
    if (!st.isDirectory()) throw new Error('Destination exists but is not a folder.');
    const entries = fs.readdirSync(/* turbopackIgnore: true */ dest);
    if (entries.length > 0) throw new Error('Destination folder must be empty.');
  } catch (e: any) {
    if (e?.code !== 'ENOENT') throw e?.message ? e : new Error('Destination cannot be used.');
    try {
      fs.mkdirSync(dest, { recursive: true });
    } catch {
      throw new Error('Destination cannot be created. Check permissions or copy manually.');
    }
  }
  try {
    fs.accessSync(dest, fs.constants.W_OK);
  } catch {
    throw new Error('Destination is not writable. Check permissions or copy manually.');
  }

  // Single pre-measurement of the source (one walk — reused for progress).
  let total = opts?.totalBytes;
  if (typeof total !== 'number' || total <= 0) {
    total = dirSizeBytes(src) ?? 0;
  }
  if (!total || total <= 0) {
    throw new Error('Could not measure the source data directory.');
  }

  const robocopy = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'robocopy.exe');
  const args = [
    src,
    dest,
    '/MIR',
    '/COPYALL',
    '/DCOPY:DAT',
    '/MT:32',
    '/J',
    '/R:2',
    '/W:2',
    '/XJ',
    '/NP',
    '/NFL',
    '/NDL',
  ];

  const id = crypto.randomBytes(12).toString('hex');
  const job: CopyJob = {
    id,
    src,
    dest,
    totalBytes: total,
    proc: null,
    status: 'running',
    exitCode: null,
    error: null,
    startedAt: Date.now(),
    lastMeasureAt: 0,
    lastCopiedBytes: null,
  };

  let proc: ChildProcess;
  try {
    proc = spawn(robocopy, args, { windowsHide: true, stdio: 'ignore' });
  } catch (e: any) {
    throw new Error(`Could not start the copy: ${String(e?.message || e).slice(0, 200)}`);
  }
  job.proc = proc;
  jobs.set(id, job);

  proc.on('error', (e) => {
    job.status = 'failed';
    job.error = `Copy process failed to start: ${String((e as any)?.message || e).slice(0, 200)}`;
  });
  proc.on('close', (code) => {
    // Robocopy exit codes 0–7 = success (files copied / extra files / mismatch
    // flags are informational). 8+ = real failure.
    const exit = typeof code === 'number' ? code : -1;
    job.exitCode = exit;
    if (job.status === 'running') {
      if (exit >= 0 && exit <= 7) {
        job.status = 'done';
        job.lastCopiedBytes = job.totalBytes;
      } else {
        job.status = 'failed';
        job.error = `Copy failed (robocopy exit code ${exit}). No data was deleted; the original directory is untouched.`;
      }
    }
  });

  return { jobId: id, totalBytes: total };
}

export function getCopyJobProgress(jobId: string): CopyJobProgress {
  const job = jobs.get(jobId);
  if (!job) {
    return { status: 'failed', copiedBytes: null, totalBytes: null, percent: null, exitCode: null, error: 'Unknown copy job.' };
  }
  if (job.status !== 'running') {
    const copied = job.status === 'done' ? job.totalBytes : job.lastCopiedBytes;
    return {
      status: job.status,
      copiedBytes: copied,
      totalBytes: job.totalBytes,
      percent: job.status === 'done' ? 100 : copied !== null ? Math.min(99, Math.floor((copied / job.totalBytes) * 100)) : null,
      exitCode: job.exitCode,
      error: job.error,
    };
  }
  // Throttle full-tree measurements; the walker is metadata-only but O(n).
  const now = Date.now();
  if (now - job.lastMeasureAt >= MIN_MEASURE_INTERVAL_MS) {
    job.lastMeasureAt = now;
    try {
      const size = dirSizeBytes(job.dest);
      if (size !== null) job.lastCopiedBytes = size;
    } catch {
      // Keep the previous measurement; a transient miss must not fail the job.
    }
  }
  const copied = job.lastCopiedBytes;
  return {
    status: 'running',
    copiedBytes: copied,
    totalBytes: job.totalBytes,
    percent: copied === null ? null : Math.min(99, Math.floor((copied / job.totalBytes) * 100)),
    exitCode: null,
    error: null,
  };
}

export function cancelCopyJob(jobId: string): boolean {
  const job = jobs.get(jobId);
  if (!job || job.status !== 'running') return false;
  try {
    // Stop the robocopy process only — never touches postgres.exe.
    job.proc?.kill();
  } catch {
    return false;
  }
  job.status = 'cancelled';
  job.error = 'Copy cancelled. The original data directory was not modified.';
  return true;
}
