'use client'

import { motion } from 'framer-motion'
import { Landmark, Tag, Layers } from 'lucide-react'
import { getAppMetadata } from '@/lib/app-metadata'
import OnlineUpdateSettings from '@/components/ui/online-update-details'

/** Application section. Name/version come from package metadata — never invented. */
export default function ApplicationSection() {
  const meta = getAppMetadata()

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-white rounded-[20px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] overflow-hidden"
    >
      <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-[var(--primary-soft)] flex items-center justify-center">
          <Landmark className="w-4 h-4 text-[var(--primary)]" />
        </div>
        <div>
          <h2 className="text-base font-semibold text-slate-900">Application</h2>
          <p className="text-xs text-slate-500 mt-0.5">About this installation</p>
        </div>
      </div>

      <div className="p-5 grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="rounded-xl bg-slate-50 border border-slate-100 px-4 py-3">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1">
            <Landmark className="w-3 h-3" /> Name
          </p>
          <p className="text-sm font-bold text-slate-900 mt-1">{meta.appName}</p>
        </div>
        <div className="rounded-xl bg-slate-50 border border-slate-100 px-4 py-3">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1">
            <Tag className="w-3 h-3" /> Version
          </p>
          <p className="text-sm font-bold text-slate-900 mt-1">v{meta.version}</p>
        </div>
        <div className="rounded-xl bg-slate-50 border border-slate-100 px-4 py-3">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1">
            <Layers className="w-3 h-3" /> Channel
          </p>
          <p className="text-sm font-bold text-slate-900 mt-1">{meta.releaseChannel}</p>
        </div>
      </div>
      <OnlineUpdateSettings />
    </motion.div>
  )
}
