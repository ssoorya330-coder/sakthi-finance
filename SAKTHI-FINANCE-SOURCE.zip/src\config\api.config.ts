export const API_CONFIG = {
  // Same-origin by default: the Next.js dev server (port 3000) serves both
  // the app and the /api/* routes. No hardcoded localhost:5000 fallback —
  // .NET backend was never the target.
  baseUrl: process.env.NEXT_PUBLIC_API_URL || '',
  wsUrl: process.env.NEXT_PUBLIC_WS_URL || '',
  timeout: 30000,
  retryAttempts: 3,
  retryDelay: 1000,
}

export const MEILISEARCH_CONFIG = {
  host: process.env.NEXT_PUBLIC_MEILISEARCH_HOST || '',
  apiKey: process.env.NEXT_PUBLIC_MEILISEARCH_API_KEY || '',
}

export const SENTRY_CONFIG = {
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN || '',
  environment: process.env.NODE_ENV || 'development',
}

export const POSTHOG_CONFIG = {
  key: process.env.NEXT_PUBLIC_POSTHOG_KEY || '',
  host: process.env.NEXT_PUBLIC_POSTHOG_HOST || 'https://app.posthog.com',
}
