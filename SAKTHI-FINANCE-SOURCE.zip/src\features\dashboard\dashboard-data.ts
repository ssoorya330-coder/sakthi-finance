import type { Customer, PaymentRecord } from '@/types/customer.types'
import type {
  LoanAnalyticsPoint,
  CollectionPerformancePoint,
  CustomerGrowthPoint,
  LoanStatusData,
  PaymentDistributionData,
  KypMiniCardData,
} from './dashboard.types'

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

function debugLog(label: string, ...args: unknown[]) {
  if (typeof window !== 'undefined' && process.env.NODE_ENV === 'development') {
    console.log(`[DashboardData] ${label}`, ...args)
  }
}

export function logQueryResult(source: string, query: string, result: unknown) {
  if (typeof window !== 'undefined' && process.env.NODE_ENV === 'development') {
    console.log(`[DashboardDB] ${source} | ${query}`, result)
  }
}

function parseDate(dateStr: string): Date | null {
  if (!dateStr) return null
  const d = new Date(dateStr)
  return isNaN(d.getTime()) ? null : d
}

function sameDay(a: Date, b: Date): boolean {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  )
}

function sameMonth(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth()
}

function getMonday(date: Date): Date {
  const d = new Date(date)
  const day = d.getDay()
  const diff = d.getDate() - day + (day === 0 ? -6 : 1)
  d.setDate(diff)
  return d
}

function startOfDay(date: Date): Date {
  const d = new Date(date)
  d.setHours(0, 0, 0, 0)
  return d
}

function endOfDay(date: Date): Date {
  const d = new Date(date)
  d.setHours(23, 59, 59, 999)
  return d
}

export function getTodayCollection(customers: Customer[], paymentHistory: PaymentRecord[]): number {
  const now = new Date()
  const total = paymentHistory
    .filter((p) => {
      const d = parseDate(p.paymentDate)
      return d && sameDay(d, now)
    })
    .reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
  debugLog('TodayCollection', { total, paymentsToday: paymentHistory.filter((p) => { const d = parseDate(p.paymentDate); return d && sameDay(d, now) }).length })
  return total
}

export function getYesterdayCollection(paymentHistory: PaymentRecord[]): number {
  const yesterday = new Date()
  yesterday.setDate(yesterday.getDate() - 1)
  return paymentHistory
    .filter((p) => {
      const d = parseDate(p.paymentDate)
      return d && sameDay(d, yesterday)
    })
    .reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
}

export function computeLoanAnalytics(customers: Customer[]): LoanAnalyticsPoint[] {
  const grouped: Record<string, { disbursed: number; collected: number; pending: number }> = {}

  for (const c of customers) {
    const loanDate = parseDate(c.loanDate || '')
    if (!loanDate) continue
    const key = `${loanDate.getFullYear()}-${loanDate.getMonth()}`
    if (!grouped[key]) grouped[key] = { disbursed: 0, collected: 0, pending: 0 }
    grouped[key].disbursed += Number(c.loanAmount) || 0
    grouped[key].collected += c.totalAmount || 0
    grouped[key].pending += (Number(c.totalAmount) || 0) - (Number(c.loanAmount) || 0)
  }

  return Object.entries(grouped)
    .sort(([a], [b]) => {
      const [ay, am] = a.split('-').map(Number)
      const [by, bm] = b.split('-').map(Number)
      return ay - by || am - bm
    })
    .slice(-7)
    .map(([key, val]) => {
      const [, m] = key.split('-').map(Number)
      return { month: MONTHS[m], ...val }
    })
}

export function computeCollectionPerformance(paymentHistory: PaymentRecord[]): CollectionPerformancePoint[] {
  const now = new Date()
  const monday = getMonday(now)

  const daily: Record<number, number> = {}
  for (let i = 0; i < 7; i++) daily[i] = 0

  for (const p of paymentHistory) {
    const d = parseDate(p.paymentDate)
    if (!d) continue
    if (d < monday || d > endOfDay(now)) continue
    const dayIdx = (d.getDay() + 6) % 7
    daily[dayIdx] += p.paymentAmount || 0
  }

  const totalCollected = Object.values(daily).reduce((s, v) => s + v, 0)
  const daysWithData = Object.values(daily).filter((v) => v > 0).length || 1
  const avgDaily = totalCollected / daysWithData

  return DAYS.map((day, i) => ({
    day,
    target: Math.round(avgDaily),
    actual: daily[i],
  }))
}

export function computeCustomerGrowth(customers: Customer[]): CustomerGrowthPoint[] {
  const sorted = [...customers].sort(
    (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  )

  const grouped: Record<string, number> = {}
  for (const c of sorted) {
    const d = parseDate(c.createdAt)
    if (!d) continue
    const key = `${d.getFullYear()}-${d.getMonth()}`
    grouped[key] = (grouped[key] || 0) + 1
  }

  let cumulative = 0
  return Object.entries(grouped)
    .sort(([a], [b]) => {
      const [ay, am] = a.split('-').map(Number)
      const [by, bm] = b.split('-').map(Number)
      return ay - by || am - bm
    })
    .slice(-7)
    .map(([key, count]) => {
      cumulative += count
      const [, m] = key.split('-').map(Number)
      return { month: MONTHS[m], newCustomers: count, totalCustomers: cumulative }
    })
}

export function computeLoanStatus(customers: Customer[]): LoanStatusData[] {
  const counts: Record<string, number> = {}
  for (const c of customers) {
    counts[c.status] = (counts[c.status] || 0) + 1
  }

  const colorMap: Record<string, string> = {
    Active: '#3B82F6',
    Completed: '#10B981',
    Overdue: '#F59E0B',
    Aborted: '#F43F5E',
  }

  return Object.entries(counts)
    .filter(([, v]) => v > 0)
    .map(([name, value]) => ({
      name,
      value,
      color: colorMap[name] || '#94A3B8',
    }))
}

export function computePaymentDistribution(paymentHistory: PaymentRecord[]): PaymentDistributionData[] {
  const colorMap: Record<string, string> = {
    Cash: '#7F1D1D',
    UPI: '#D4AF37',
    'Bank Transfer': '#7F1D1D',
    Cheque: '#9B1D1D',
    Other: '#94A3B8',
  }

  const grouped: Record<string, number> = {}
  for (const p of paymentHistory) {
    const method = p.paymentMethod || 'Other'
    grouped[method] = (grouped[method] || 0) + (p.paymentAmount || 0)
  }

  return Object.entries(grouped)
    .filter(([, v]) => v > 0)
    .map(([name, value]) => ({
      name,
      value,
      color: colorMap[name] || '#94A3B8',
    }))
}

export interface CollectionOverviewDataPoint {
  day: string
  date: string
  amountGiven: number
  amountReceived: number
  paymentCollected: number
  interestAmount: number
  balanceAmount: number
  totalLoanAmount: number
  totalAmount: number
}

function formatDateShort(date: Date): string {
  return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
}

function formatDateFull(date: Date): string {
  return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
}

function aggregateForDate(
  date: Date,
  customers: Customer[],
  paymentHistory: PaymentRecord[]
): CollectionOverviewDataPoint {
  const dayStart = startOfDay(date)
  const dayEnd = endOfDay(date)

  const dayCustomers = customers.filter((c) => {
    const d = parseDate(c.loanDate || '')
    return d && d >= dayStart && d <= dayEnd
  })

  const amountGiven = dayCustomers.reduce((sum, c) => sum + (Number(c.loanAmount) || 0), 0)

  const dayPayments = paymentHistory.filter((p) => {
    const d = parseDate(p.paymentDate)
    return d && d >= dayStart && d <= dayEnd
  })

  const paymentCollected = dayPayments.reduce((sum, p) => sum + (p.paymentAmount || 0), 0)

  const amountReceived = paymentCollected
  const interestAmount = dayCustomers.reduce((sum, c) => sum + (Number(c.interestAmount) || 0), 0)
  const totalLoanAmount = dayCustomers.reduce((sum, c) => sum + (c.totalAmount || 0), 0)
  const balanceAmount = Math.max(0, totalLoanAmount - paymentCollected)
  const totalAmount = amountGiven + amountReceived

  const result = {
    day: formatDateShort(date),
    date: formatDateFull(date),
    amountGiven,
    amountReceived,
    paymentCollected,
    interestAmount,
    balanceAmount,
    totalLoanAmount,
    totalAmount,
  }

  debugLog(`aggregateForDate[${result.day}]`, {
    customersInDay: dayCustomers.length,
    paymentsInDay: dayPayments.length,
    ...result,
  })

  return result
}

function aggregateForMonth(
  year: number,
  month: number,
  customers: Customer[],
  paymentHistory: PaymentRecord[]
): CollectionOverviewDataPoint {
  const monthCustomers = customers.filter((c) => {
    const d = parseDate(c.loanDate || '')
    return d && d.getFullYear() === year && d.getMonth() === month
  })

  const monthPayments = paymentHistory.filter((p) => {
    const d = parseDate(p.paymentDate)
    return d && d.getFullYear() === year && d.getMonth() === month
  })

  const amountGiven = monthCustomers.reduce((sum, c) => sum + (Number(c.loanAmount) || 0), 0)
  const paymentCollected = monthPayments.reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
  const amountReceived = paymentCollected
  const interestAmount = monthCustomers.reduce((sum, c) => sum + (Number(c.interestAmount) || 0), 0)
  const totalLoanAmount = monthCustomers.reduce((sum, c) => sum + (c.totalAmount || 0), 0)
  const balanceAmount = Math.max(0, totalLoanAmount - amountReceived)
  const totalAmount = amountGiven + amountReceived

  return {
    day: MONTHS[month],
    date: `${MONTHS[month]} ${year}`,
    amountGiven,
    amountReceived,
    paymentCollected,
    interestAmount,
    balanceAmount,
    totalLoanAmount,
    totalAmount,
  }
}

export function getCollectionOverviewData(
  filter: string,
  customers: Customer[],
  paymentHistory: PaymentRecord[],
  customStart?: Date,
  customEnd?: Date
): CollectionOverviewDataPoint[] {
  const now = new Date()
  let result: CollectionOverviewDataPoint[]

  switch (filter) {
    case 'today':
      result = [aggregateForDate(now, customers, paymentHistory)]
      break

    case 'yesterday': {
      const yesterday = new Date(now)
      yesterday.setDate(now.getDate() - 1)
      result = [aggregateForDate(yesterday, customers, paymentHistory)]
      break
    }

    case 'week': {
      const monday = getMonday(now)
      result = []
      for (let i = 0; i < 7; i++) {
        const date = new Date(monday)
        date.setDate(monday.getDate() + i)
        if (date > endOfDay(now)) break
        result.push(aggregateForDate(date, customers, paymentHistory))
      }
      break
    }

    case 'lastWeek': {
      const thisMonday = getMonday(now)
      const lastMonday = new Date(thisMonday)
      lastMonday.setDate(thisMonday.getDate() - 7)
      result = []
      for (let i = 0; i < 7; i++) {
        const date = new Date(lastMonday)
        date.setDate(lastMonday.getDate() + i)
        result.push(aggregateForDate(date, customers, paymentHistory))
      }
      break
    }

    case 'month': {
      result = []
      for (let i = 1; i <= now.getDate(); i++) {
        const date = new Date(now.getFullYear(), now.getMonth(), i)
        result.push(aggregateForDate(date, customers, paymentHistory))
      }
      break
    }

    case 'lastMonth': {
      const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1)
      const daysInMonth = new Date(lastMonth.getFullYear(), lastMonth.getMonth() + 1, 0).getDate()
      result = []
      for (let i = 1; i <= daysInMonth; i++) {
        const date = new Date(lastMonth.getFullYear(), lastMonth.getMonth(), i)
        result.push(aggregateForDate(date, customers, paymentHistory))
      }
      break
    }

    case 'year': {
      result = []
      for (let i = 0; i <= now.getMonth(); i++) {
        result.push(aggregateForMonth(now.getFullYear(), i, customers, paymentHistory))
      }
      break
    }

    case 'custom': {
      if (!customStart || !customEnd) return []
      const start = startOfDay(customStart)
      const end = endOfDay(customEnd)
      result = []
      const current = new Date(start)
      while (current <= end) {
        result.push(aggregateForDate(new Date(current), customers, paymentHistory))
        current.setDate(current.getDate() + 1)
      }
      break
    }

    default:
      return []
  }

  debugLog(`getCollectionOverviewData[${filter}]`, {
    dataPoints: result.length,
    totals: result.reduce(
      (acc, d) => ({
        amountGiven: acc.amountGiven + d.amountGiven,
        paymentCollected: acc.paymentCollected + d.paymentCollected,
        interestAmount: acc.interestAmount + d.interestAmount,
        balanceAmount: acc.balanceAmount + d.balanceAmount,
      }),
      { amountGiven: 0, paymentCollected: 0, interestAmount: 0, balanceAmount: 0 }
    ),
  })

  return result
}

export function computeFinancialSummary(customers: Customer[], paymentHistory: PaymentRecord[]) {
  const now = new Date()

  const totalLoanGiven = customers.reduce((sum, c) => sum + (Number(c.loanAmount) || 0), 0)
  const totalAmountReceived = paymentHistory.reduce((sum, p) => sum + (p.paymentAmount || 0), customers.reduce((sum,c)=>sum+(c.offlinePaidAmount||0),0))
  const pendingCollection = customers.reduce(
    (sum, c) => sum + Math.max(0, (Number(c.totalAmount) || 0) - (Number(c.loanAmount) || 0)),
    0
  )
  const interestEarned = customers.reduce((sum, c) => sum + (Number(c.interestAmount) || 0), 0)

  const todayPayments = paymentHistory.filter((p) => {
    const d = parseDate(p.paymentDate)
    return d && sameDay(d, now)
  })
  const todayIncome = todayPayments.reduce((sum, p) => sum + (p.paymentAmount || 0), 0)

  const monthPayments = paymentHistory.filter((p) => {
    const d = parseDate(p.paymentDate)
    return d && sameMonth(d, now)
  })
  const monthlyIncome = monthPayments.reduce((sum, p) => sum + (p.paymentAmount || 0), 0)

  const yearPayments = paymentHistory.filter((p) => {
    const d = parseDate(p.paymentDate)
    return d && d.getFullYear() === now.getFullYear()
  })
  const yearlyIncome = yearPayments.reduce((sum, p) => sum + (p.paymentAmount || 0), 0)

  const avgLoan = customers.length > 0 ? totalLoanGiven / customers.length : 0

  const result = {
    totalLoanGiven,
    totalAmountReceived,
    pendingCollection,
    interestEarned,
    todayIncome,
    monthlyIncome,
    yearlyIncome,
    avgLoan: Math.round(avgLoan),
  }
  debugLog('FinancialSummary', result)
  return result
}

export function computeBusinessInsights(customers: Customer[], paymentHistory: PaymentRecord[]) {
  const now = new Date()
  const monday = getMonday(now)

  const dailyTotals: Record<number, { total: number; count: number }> = {}
  for (let i = 0; i < 7; i++) dailyTotals[i] = { total: 0, count: 0 }

  for (const p of paymentHistory) {
    const d = parseDate(p.paymentDate)
    if (!d) continue
    if (d < monday || d > endOfDay(now)) continue
    const dayIdx = (d.getDay() + 6) % 7
    dailyTotals[dayIdx].total += p.paymentAmount || 0
    dailyTotals[dayIdx].count += 1
  }

  let highestDayIdx = 0
  let lowestDayIdx = 0
  let highestVal = 0
  let lowestVal = Infinity
  for (let i = 0; i < 7; i++) {
    if (dailyTotals[i].total > highestVal) {
      highestVal = dailyTotals[i].total
      highestDayIdx = i
    }
    if (dailyTotals[i].total < lowestVal && dailyTotals[i].total > 0) {
      lowestVal = dailyTotals[i].total
      lowestDayIdx = i
    }
  }

  const areaCounts: Record<string, number> = {}
  for (const c of customers) {
    if (c.area) areaCounts[c.area] = (areaCounts[c.area] || 0) + 1
  }
  let mostActiveArea = 'N/A'
  let maxAreaCount = 0
  for (const [area, count] of Object.entries(areaCounts)) {
    if (count > maxAreaCount) {
      maxAreaCount = count
      mostActiveArea = area
    }
  }

  const last30Start = new Date(now)
  last30Start.setDate(now.getDate() - 30)
  const last30Payments = paymentHistory.filter((p) => {
    const d = parseDate(p.paymentDate)
    return d && d >= last30Start && d <= endOfDay(now)
  })
  const last30Total = last30Payments.reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
  const avgDailyCollection = last30Total / 30

  const monthlyGroups: Record<string, number> = {}
  for (const p of paymentHistory) {
    const d = parseDate(p.paymentDate)
    if (!d) continue
    const key = `${d.getFullYear()}-${d.getMonth()}`
    monthlyGroups[key] = (monthlyGroups[key] || 0) + (p.paymentAmount || 0)
  }
  let bestMonthKey = ''
  let bestMonthVal = 0
  for (const [key, val] of Object.entries(monthlyGroups)) {
    if (val > bestMonthVal) {
      bestMonthVal = val
      bestMonthKey = key
    }
  }
  let bestMonthLabel = 'N/A'
  if (bestMonthKey) {
    const [y, m] = bestMonthKey.split('-').map(Number)
    bestMonthLabel = `${MONTHS[m]} ${y}`
  }

  const totalDue = customers.reduce((sum, c) => sum + (Number(c.totalAmount) || 0), 0)
  const totalPaid = last30Payments.reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
  const successRate = totalDue > 0 ? Math.min(100, (totalPaid / totalDue) * 100) : 0

  return {
    highestDay: { value: highestVal > 0 ? `₹${highestVal.toLocaleString('en-IN')}` : '₹0', sub: DAYS[highestDayIdx] },
    lowestDay: { value: lowestVal < Infinity ? `₹${lowestVal.toLocaleString('en-IN')}` : '₹0', sub: DAYS[lowestDayIdx] },
    activeArea: { value: mostActiveArea, sub: `${maxAreaCount} customers` },
    avgDaily: { value: `₹${Math.round(avgDailyCollection).toLocaleString('en-IN')}`, sub: 'Last 30 days' },
    bestMonth: { value: bestMonthLabel, sub: bestMonthVal > 0 ? `₹${bestMonthVal.toLocaleString('en-IN')} collected` : 'No data' },
    successRate: { value: `${successRate.toFixed(1)}%`, sub: successRate > 0 ? 'Collection rate' : 'No data' },
  }
}

export type SparkType = 'customers' | 'active' | 'completed' | 'aborted' | 'loan' | 'received' | 'totalAmount' | 'interest' | 'balance' | 'today'

export function computeSparkData(
  customers: Customer[],
  paymentHistory: PaymentRecord[],
  type: SparkType
): number[] {
  const now = new Date()
  const result: number[] = []

  for (let i = 11; i >= 0; i--) {
    const monthDate = new Date(now.getFullYear(), now.getMonth() - i, 1)
    const nextMonthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 0)
    const monthEnd = endOfDay(nextMonthEnd)

    switch (type) {
      case 'customers':
        result.push(
          customers.filter((c) => {
            const d = parseDate(c.createdAt)
            return d && d >= monthDate && d <= nextMonthEnd
          }).length
        )
        break
      case 'active':
        result.push(
          customers.filter((c) => {
            const d = parseDate(c.createdAt)
            return d && d >= monthDate && d <= nextMonthEnd && c.status === 'Active'
          }).length
        )
        break
      case 'completed':
        result.push(
          customers.filter((c) => {
            const d = parseDate(c.createdAt)
            return d && d >= monthDate && d <= nextMonthEnd && c.status === 'Completed'
          }).length
        )
        break
      case 'aborted':
        result.push(
          customers.filter((c) => {
            const d = parseDate(c.createdAt)
            return d && d >= monthDate && d <= nextMonthEnd && c.status === 'Aborted'
          }).length
        )
        break
      case 'loan':
        result.push(
          customers
            .filter((c) => {
              const d = parseDate(c.loanDate || '')
              return d && d >= monthDate && d <= nextMonthEnd
            })
            .reduce((sum, c) => sum + (Number(c.loanAmount) || 0), 0)
        )
        break
      case 'received':
        result.push(
          paymentHistory
            .filter((p) => {
              const d = parseDate(p.paymentDate)
              return d && d >= monthDate && d <= nextMonthEnd
            })
            .reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
        )
        break
      case 'totalAmount':
        result.push(
          customers
            .filter((c) => {
              const d = parseDate(c.loanDate || '')
              return d && d >= monthDate && d <= nextMonthEnd
            })
            .reduce((sum, c) => sum + (c.totalAmount || 0), 0)
        )
        break
      case 'interest':
        result.push(
          customers
            .filter((c) => {
              const d = parseDate(c.loanDate || '')
              return d && d >= monthDate && d <= nextMonthEnd
            })
            .reduce((sum, c) => sum + (Number(c.interestAmount) || 0), 0)
        )
        break
      case 'balance': {
        const cumulativeTotal = customers
          .filter((c) => {
            const d = parseDate(c.loanDate || '')
            return d && d <= monthEnd
          })
          .reduce((sum, c) => sum + (c.totalAmount || 0), 0)
        const cumulativePaid = paymentHistory
          .filter((p) => {
            const d = parseDate(p.paymentDate)
            return d && d <= monthEnd
          })
          .reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
        result.push(Math.max(0, cumulativeTotal - cumulativePaid))
        break
      }
      case 'today':
        result.push(
          paymentHistory
            .filter((p) => {
              const d = parseDate(p.paymentDate)
              return d && sameDay(d, new Date(now.getFullYear(), now.getMonth() - i, now.getDate()))
            })
            .reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
        )
        break
    }
  }

  debugLog(`SparkData[${type}]`, { customers: customers.length, payments: paymentHistory.length, data: result })
  return result
}

export function computeChangePercent(
  customers: Customer[],
  paymentHistory: PaymentRecord[],
  type: SparkType
): number {
  const now = new Date()
  const currentMonthStart = new Date(now.getFullYear(), now.getMonth(), 1)
  const prevMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1)
  const prevMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0)
  const currentMonthEnd = endOfDay(new Date(now.getFullYear(), now.getMonth() + 1, 0))

  let current = 0
  let previous = 0

  switch (type) {
    case 'customers':
      current = customers.filter((c) => {
        const d = parseDate(c.createdAt)
        return d && d >= currentMonthStart
      }).length
      previous = customers.filter((c) => {
        const d = parseDate(c.createdAt)
        return d && d >= prevMonthStart && d <= prevMonthEnd
      }).length
      break
    case 'active':
      current = customers.filter((c) => {
        const d = parseDate(c.createdAt)
        return d && d >= currentMonthStart && c.status === 'Active'
      }).length
      previous = customers.filter((c) => {
        const d = parseDate(c.createdAt)
        return d && d >= prevMonthStart && d <= prevMonthEnd && c.status === 'Active'
      }).length
      break
    case 'completed':
      current = customers.filter((c) => {
        const d = parseDate(c.createdAt)
        return d && d >= currentMonthStart && c.status === 'Completed'
      }).length
      previous = customers.filter((c) => {
        const d = parseDate(c.createdAt)
        return d && d >= prevMonthStart && d <= prevMonthEnd && c.status === 'Completed'
      }).length
      break
    case 'aborted':
      current = customers.filter((c) => {
        const d = parseDate(c.createdAt)
        return d && d >= currentMonthStart && c.status === 'Aborted'
      }).length
      previous = customers.filter((c) => {
        const d = parseDate(c.createdAt)
        return d && d >= prevMonthStart && d <= prevMonthEnd && c.status === 'Aborted'
      }).length
      break
    case 'loan':
      current = customers
        .filter((c) => {
          const d = parseDate(c.loanDate || '')
          return d && d >= currentMonthStart
        })
        .reduce((sum, c) => sum + (Number(c.loanAmount) || 0), 0)
      previous = customers
        .filter((c) => {
          const d = parseDate(c.loanDate || '')
          return d && d >= prevMonthStart && d <= prevMonthEnd
        })
        .reduce((sum, c) => sum + (Number(c.loanAmount) || 0), 0)
      break
    case 'received':
      current = paymentHistory
        .filter((p) => {
          const d = parseDate(p.paymentDate)
          return d && d >= currentMonthStart
        })
        .reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
      previous = paymentHistory
        .filter((p) => {
          const d = parseDate(p.paymentDate)
          return d && d >= prevMonthStart && d <= prevMonthEnd
        })
        .reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
      break
    case 'totalAmount':
      current = customers
        .filter((c) => {
          const d = parseDate(c.loanDate || '')
          return d && d >= currentMonthStart
        })
        .reduce((sum, c) => sum + (c.totalAmount || 0), 0)
      previous = customers
        .filter((c) => {
          const d = parseDate(c.loanDate || '')
          return d && d >= prevMonthStart && d <= prevMonthEnd
        })
        .reduce((sum, c) => sum + (c.totalAmount || 0), 0)
      break
    case 'interest':
      current = customers
        .filter((c) => {
          const d = parseDate(c.loanDate || '')
          return d && d >= currentMonthStart
        })
        .reduce((sum, c) => sum + (Number(c.interestAmount) || 0), 0)
      previous = customers
        .filter((c) => {
          const d = parseDate(c.loanDate || '')
          return d && d >= prevMonthStart && d <= prevMonthEnd
        })
        .reduce((sum, c) => sum + (Number(c.interestAmount) || 0), 0)
      break
    case 'balance': {
      const curTotal = customers
        .filter((c) => { const d = parseDate(c.loanDate || ''); return d && d <= currentMonthEnd })
        .reduce((sum, c) => sum + (c.totalAmount || 0), 0)
      const curPaid = paymentHistory
        .filter((p) => { const d = parseDate(p.paymentDate); return d && d <= currentMonthEnd })
        .reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
      current = Math.max(0, curTotal - curPaid)
      const prevTotal = customers
        .filter((c) => { const d = parseDate(c.loanDate || ''); return d && d <= prevMonthEnd })
        .reduce((sum, c) => sum + (c.totalAmount || 0), 0)
      const prevPaid = paymentHistory
        .filter((p) => { const d = parseDate(p.paymentDate); return d && d <= prevMonthEnd })
        .reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
      previous = Math.max(0, prevTotal - prevPaid)
      break
    }
    case 'today': {
      const today = now.getDate()
      for (let day = 1; day <= today; day++) {
        const dayDate = new Date(now.getFullYear(), now.getMonth(), day)
        current += paymentHistory
          .filter((p) => {
            const d = parseDate(p.paymentDate)
            return d && sameDay(d, dayDate)
          })
          .reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
      }
      const prevMonthDayCount = new Date(now.getFullYear(), now.getMonth(), 0).getDate()
      const daysToCount = Math.min(today, prevMonthDayCount)
      for (let day = 1; day <= daysToCount; day++) {
        const dayDate = new Date(now.getFullYear(), now.getMonth() - 1, day)
        previous += paymentHistory
          .filter((p) => {
            const d = parseDate(p.paymentDate)
            return d && sameDay(d, dayDate)
          })
          .reduce((sum, p) => sum + (p.paymentAmount || 0), 0)
      }
      break
    }
  }

  if (previous === 0) return current > 0 ? 100 : 0
  return ((current - previous) / previous) * 100
}

export function computeKypMiniCards(
  customers: Customer[],
  paymentHistory: PaymentRecord[]
): KypMiniCardData[] {
  const totalLoanAmount = customers.reduce((sum, c) => sum + (Number(c.loanAmount) || 0), 0)
  const totalInterest = customers.reduce((sum, c) => sum + (Number(c.interestAmount) || 0), 0)
  const activeCount = customers.filter((c) => c.status === 'Active').length
  const completedCount = customers.filter((c) => c.status === 'Completed').length
  const abortedCount = customers.filter((c) => c.status === 'Aborted').length

  return [
    {
      id: 'amount-given',
      label: 'Amount Given',
      value: totalLoanAmount,
      change: computeChangePercent(customers, paymentHistory, 'loan'),
      icon: 'HandCoins',
      gradient: 'from-[#7F1D1D] to-[#9B1D1D]',
      sparkData: computeSparkData(customers, paymentHistory, 'loan'),
    },
    {
      id: 'interest-amount',
      label: 'Interest Amount',
      value: totalInterest,
      change: computeChangePercent(customers, paymentHistory, 'interest'),
      icon: 'Percent',
      gradient: 'from-[#9B1D1D] to-[#7F1D1D]',
      sparkData: computeSparkData(customers, paymentHistory, 'interest'),
    },
    {
      id: 'active-customers',
      label: 'Active Customers',
      value: activeCount,
      change: computeChangePercent(customers, paymentHistory, 'active'),
      icon: 'UserCheck',
      gradient: 'from-[#7F1D1D] to-[#9B1D1D]',
      sparkData: computeSparkData(customers, paymentHistory, 'active'),
    },
    {
      id: 'completed-customers',
      label: 'Completed Customers',
      value: completedCount,
      change: computeChangePercent(customers, paymentHistory, 'completed'),
      icon: 'BadgeCheck',
      gradient: 'from-[#D4AF37] to-[#B8943A]',
      sparkData: computeSparkData(customers, paymentHistory, 'completed'),
    },
    {
      id: 'aborted-customers',
      label: 'Aborted Customers',
      value: abortedCount,
      change: computeChangePercent(customers, paymentHistory, 'aborted'),
      icon: 'UserX',
      gradient: 'from-[#9B1D1D] to-[#7F1D1D]',
      sparkData: computeSparkData(customers, paymentHistory, 'aborted'),
    },
  ]
}
