import { NextResponse } from 'next/server'
import { z } from 'zod'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { buildXlsx, x, XS_HEADER, XS_TITLE } from '@/server/audit-excel'

export const runtime = 'nodejs'
const schema = z.object({
  title: z.string().max(200),
  headers: z.array(z.string().max(100)).min(1).max(40),
  rows: z.array(z.array(z.union([z.string().max(32767), z.number().finite(), z.null()])).max(40)).max(50000),
  metadata: z.array(z.string().max(1000)).max(10).default([]),
})

export async function POST(request: Request) {
  const auth = await requireAuthWithPermission('reports:read')
  if (auth.error) return auth.error
  const raw = await request.text()
  if (raw.length > 8 * 1024 * 1024) return NextResponse.json({ error: 'Report is too large. Narrow the filters and try again.' }, { status: 413 })
  let input: unknown
  try { input = JSON.parse(raw) } catch { return NextResponse.json({ error: 'Invalid report.' }, { status: 400 }) }
  const parsed = schema.safeParse(input)
  if (!parsed.success || parsed.data.rows.some(row => row.length !== parsed.data.headers.length)) {
    return NextResponse.json({ error: 'Invalid report data or report size limit exceeded.' }, { status: 400 })
  }
  const { title, headers, rows, metadata } = parsed.data
  const headerRow = metadata.length + 2
  const bytes = buildXlsx([{ name: 'Report', cols: headers.map(() => 22), freezeRows: headerRow, filterRow: headerRow,
    rows: [[x.ST(title, XS_TITLE)], ...metadata.map(line => [x.ST(line)]), headers.map(label => x.ST(label, XS_HEADER)),
      ...rows.map(row => row.map(value => typeof value === 'number' ? x.NM(value) : x.ST(value ?? '')))],
  }])
  return new NextResponse(new Uint8Array(bytes), { headers: {
    'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'Content-Disposition': 'attachment; filename="report.xlsx"',
    'Cache-Control': 'private, no-store',
  } })
}
