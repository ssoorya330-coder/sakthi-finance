'use client'

import { useEffect, useMemo, useState } from 'react'
import { ShieldAlert, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import AdminSectionShell, { AdminEmpty, AdminError, AdminLoading } from './AdminSectionShell'
import { adminMutate, useAdminApi } from './useAdminApi'
import { isDeveloperEmail } from '@/config/developer-access'
import { formatCurrency } from '@/features/dashboard/dashboard.styles'

interface AdminUserRow {
  customer_count?: number
  active_customer_count?: number
  loan_amount?: string
  paid_amount?: string
  balance_amount?: string
  user_id?: string | null
  id?: string | number | null
  email?: string | null
  full_name?: string | null
  role?: string | null
  role_name?: string | null
  is_active?: boolean | null
  provider?: string | null
  last_login_at?: string | null
}

const fmtDT = (iso: string | null | undefined) => {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: true,
    })
  } catch {
    return '—'
  }
}

const roleOf = (u: AdminUserRow) => (u.role_name || u.role || 'employee').toLowerCase()

export default function UsersContent() {
  const { data, state, retrying, retry } = useAdminApi<AdminUserRow[]>('/api/admin/users', (j) =>
    Array.isArray(j?.users) ? (j.users as AdminUserRow[]) : []
  )
  const users = useMemo(() => data || [], [data])
  const [actorRole, setActorRole] = useState<string>('admin')
  const [actionMsg, setActionMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const [busy, setBusy] = useState<string | null>(null)
  const [roleDialog, setRoleDialog] = useState<{ user: AdminUserRow; next: string } | null>(null)
  const [confirmDeact, setConfirmDeact] = useState<AdminUserRow | null>(null)

  useEffect(() => {
    fetch('/api/admin/access', { credentials: 'include' })
      .then((r) => r.json().catch(() => null))
      .then((j) => {
        if (j?.role) setActorRole(String(j.role))
      })
      .catch(() => {})
  }, [])

  const allowedTargets = (u: AdminUserRow): string[] => {
    // Mirrors server rules: owner may assign anything; others follow
    // canAssignRole (never owner). Self is never listed (handled below).
    if (actorRole === 'owner') return ['admin', 'owner']
    return []
  }

  const runAction = async (key: string, fn: () => Promise<{ ok: boolean; message: string }>) => {
    setBusy(key)
    setActionMsg(null)
    const r = await fn()
    setBusy(null)
    setActionMsg({ ok: r.ok, text: r.ok ? 'Done.' : r.message })
    if (r.ok) retry()
  }

  const saveRole = () =>
    runAction('role', () =>
      adminMutate(`/api/admin/users/${encodeURIComponent(roleDialog!.user.user_id || String(roleDialog!.user.id))}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: roleDialog!.next }),
      }).then((r) => {
        if (r.ok) setRoleDialog(null)
        return r
      })
    )

  return (
    <AdminSectionShell title="Users & Roles" subtitle="Manage users and assign permitted roles" icon="users">
      {actionMsg && (
        <div className={cn(
          'p-4 rounded-2xl border text-sm flex items-start gap-2',
          actionMsg.ok ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-amber-50 border-amber-200 text-amber-800'
        )}>
          <ShieldAlert className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <span className="flex-1">{actionMsg.text}</span>
          <button onClick={() => setActionMsg(null)} aria-label="Dismiss"><X className="w-4 h-4 opacity-60" /></button>
        </div>
      )}

      {state === 'loading' && <AdminLoading />}
      {state === 'unauthorized' && (
        <AdminError message="You are not authorized to access this page." onRetry={retry} retrying={retrying} />
      )}
      {state === 'failed' && (
        <AdminError message="Unable to connect to the database. Please try again." onRetry={retry} retrying={retrying} />
      )}
      {state === 'ready' &&
        (users.length === 0 ? (
          <AdminEmpty message="No users found" />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-bold text-slate-900">
                Users <span className="text-slate-400 font-semibold">({users.length})</span>
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm min-w-[880px]">
                <thead>
                  <tr className="bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)] text-left">
                    {['ID', 'Name', 'Email', 'Role', 'Actions'].map((h) => (
                      <th key={h} className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-[#F3DFA7] whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map((u, i) => {
                    const uid = u.user_id || String(u.id || `row-${i}`)
                    const email = u.email || '—'
                    const name = u.full_name || email.split('@')[0] || 'User'
                    const role = roleOf(u)
                    const active = u.is_active !== false
                    return (
                      <tr key={uid} className="hover:bg-slate-50 align-top">
                        <td className="px-4 py-2.5 text-xs font-mono text-slate-500 whitespace-nowrap">{uid.slice(0, 13)}…</td>
                        <td className="px-4 py-2.5 text-xs font-bold text-slate-900 whitespace-nowrap">{name}</td>
                        <td className="px-4 py-2.5 text-xs text-slate-600 whitespace-nowrap">{email}</td>
                        <td className="px-4 py-2.5">
                          <span className="inline-flex items-center px-2 py-0.5 rounded-lg text-[11px] font-bold border bg-slate-100 text-slate-700 border-slate-200 capitalize whitespace-nowrap">
                            {isDeveloperEmail(u.email) ? 'Developer' : role}
                          </span>
                        </td>
                        <td className="px-4 py-2.5">
                          <div className="flex flex-wrap gap-1.5">
                            <select
                              aria-label={`Change role for ${email}`}
                              defaultValue=""
                              disabled={busy !== null || isDeveloperEmail(u.email)}
                              onChange={(e) => {
                                const next = e.target.value
                                e.target.value = ''
                                if (next) setRoleDialog({ user: u, next })
                              }}
                              className="px-2 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-600 bg-white hover:bg-slate-50 disabled:opacity-50"
                            >
                              <option value="">Set role…</option>
                              {allowedTargets(u)
                                .filter((r) => r !== role)
                                .map((r) => (
                                  <option key={r} value={r} className="capitalize">{r}</option>
                                ))}
                            </select>
                            {active ? (
                              <button
                                disabled={busy !== null}
                                onClick={() => setConfirmDeact(u)}
                                className="px-2 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                              >
                                Deactivate
                              </button>
                            ) : (
                              <button
                                disabled={busy !== null}
                                onClick={() =>
                                  runAction(`act-${uid}`, () =>
                                    adminMutate(`/api/admin/users/${encodeURIComponent(uid)}`, {
                                      method: 'PUT',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify({ is_active: true, reason: 'reactivated' }),
                                    })
                                  )
                                }
                                className="px-2 py-1.5 rounded-lg text-[11px] font-semibold bg-[var(--primary)] text-white hover:bg-[#912222] disabled:opacity-50"
                              >
                                {busy === `act-${uid}` ? 'Saving…' : 'Activate'}
                              </button>
                            )}
                            <button
                              disabled={busy !== null}
                              onClick={() =>
                                runAction(`out-${uid}`, () =>
                                  adminMutate(`/api/admin/devices?userId=${encodeURIComponent(uid)}`, {
                                    method: 'DELETE',
                                  })
                                )
                              }
                              className="px-2 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                              title="Force logout all sessions"
                            >
                              Force logout
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ))}

      {/* Role-change confirmation */}
      {roleDialog && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setRoleDialog(null)}>
          <div onClick={(e) => e.stopPropagation()} className="w-full max-w-[440px] bg-white rounded-[22px] border border-slate-100 shadow-2xl p-6">
            <h3 className="text-base font-bold text-slate-900">Change user role?</h3>
            <div className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between gap-4"><span className="text-slate-500">User</span><span className="font-semibold text-slate-900 text-right break-all">{roleDialog.user.email || roleDialog.user.user_id}</span></div>
              <div className="flex justify-between gap-4"><span className="text-slate-500">Current Role</span><span className="font-semibold text-slate-900 capitalize">{roleOf(roleDialog.user)}</span></div>
              <div className="flex justify-between gap-4"><span className="text-slate-500">New Role</span><span className="font-semibold text-[var(--primary)] capitalize">{roleDialog.next}</span></div>
              {roleDialog.next === 'owner' && (
                <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-xl p-2.5">
                  You are granting full Owner privileges. This is a protected Owner-only operation.
                </p>
              )}
            </div>
            <div className="mt-5 flex gap-2 justify-end">
              <button onClick={() => setRoleDialog(null)} className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-medium hover:bg-slate-50">Cancel</button>
              <button
                onClick={saveRole}
                disabled={busy === 'role'}
                className="px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222] disabled:opacity-50"
              >
                {busy === 'role' ? 'Saving…' : 'Save Changes'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Deactivate confirmation */}
      {confirmDeact && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setConfirmDeact(null)}>
          <div onClick={(e) => e.stopPropagation()} className="w-full max-w-[440px] bg-white rounded-[22px] border border-slate-100 shadow-2xl p-6">
            <h3 className="text-base font-bold text-slate-900">Deactivate this account?</h3>
            <p className="text-sm text-slate-500 mt-2">
              <b className="text-slate-800">{confirmDeact.email || confirmDeact.user_id}</b> will no longer be able to
              access Sakthi Finance.
            </p>
            <div className="mt-5 flex gap-2 justify-end">
              <button onClick={() => setConfirmDeact(null)} className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-medium hover:bg-slate-50">Cancel</button>
              <button
                onClick={() => {
                  const u = confirmDeact
                  const uid = u.user_id || String(u.id || '')
                  setConfirmDeact(null)
                  runAction(`act-${uid}`, () =>
                    adminMutate(`/api/admin/users/${encodeURIComponent(uid)}`, {
                      method: 'PUT',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ is_active: false, reason: 'deactivated' }),
                    })
                  )
                }}
                disabled={busy !== null}
                className="px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222] disabled:opacity-50"
              >
                Deactivate
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminSectionShell>
  )
}
