import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/api-utils';
import { dbQuery } from '@/server/database';
import { getPersonGroup } from '@/lib/customer-group';

export const dynamic = 'force-dynamic';

const num = (v: any) => Number(v) || 0;

/**
 * One kanaku's detail for the linked customer person.
 * The `code` is verified server-side against the authenticated session's
 * person group: codes outside the group get 404 without leaking anything.
 */
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ code: string }> }
) {
  const auth = await requireAuth();
  if (auth.error) return auth.error;
  if (auth.user.role !== 'customer' || !auth.user.customerId) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  try {
    const { code } = await params;
    const group = await getPersonGroup(auth.user.customerId);
    if (!group) {
      return NextResponse.json({ error: 'Customer account not found.' }, { status: 404 });
    }
    const rows = group.accounts.filter((a) => a.customer_code === code);
    if (rows.length === 0) {
      // Not this person's kanaku (or doesn't exist): reveal nothing.
      return NextResponse.json({ error: 'Kanaku not found.' }, { status: 404 });
    }

    const out = [];
    for (const row of rows) {
      const kanakuNo =
        group.accounts.find((a) => a.id === row.id)?.kanaku_no ??
        group.accounts.findIndex((a) => a.customer_code === row.customer_code) + 1;
      const [cust, loans, payments] = await Promise.all([
        dbQuery(
          `SELECT c.id, c.customer_code, c.full_name, c.phone_number, c.address,
                  rc.name AS city_name, ra.name AS area_name, rb.name AS business_name,
                  c.status, c.created_at
           FROM customers c
           LEFT JOIN ref_city rc ON rc.id = c.city_id
           LEFT JOIN ref_area ra ON ra.id = c.area_id
           LEFT JOIN ref_business rb ON rb.id = c.business_id
           WHERE c.id = $1 LIMIT 1`,
          [row.id]
        ),
        dbQuery(
          `SELECT loan_id, loan_date, due_date, loan_amount, interest_rate,
                  interest_amount, total_amount, installment, installment_amount,
                  balance_amount, received_amount, duration, loan_type, status,
                  disbursal_mode, completed_at
           FROM loans WHERE customer_id = $1 ORDER BY loan_date ASC NULLS LAST, created_at ASC`,
          [row.id]
        ),
        dbQuery(
          `SELECT payment_id, loan_id, amount, payment_date, payment_time,
                  COALESCE(payment_mode, payment_method, 'Cash') AS mode, remarks, created_at
           FROM payments WHERE customer_id = $1 OR loan_id IN (SELECT loan_id FROM loans WHERE customer_id = $1)
           ORDER BY payment_date ASC, created_at ASC`,
          [row.id]
        ),
      ]);
      const loanRows = Array.isArray(loans.rows) ? loans.rows : [];
      const payRows = Array.isArray(payments.rows) ? payments.rows : [];
      const payable = loanRows.reduce((s: number, l: any) => s + num(l.total_amount), 0);
      const paid = loanRows.reduce((s: number, l: any) => s + num(l.received_amount), 0);
      const outstanding = loanRows.reduce((s: number, l: any) => s + num(l.balance_amount), 0);
      // Running balance from stored totals (display only, oldest first).
      let running = payable;
      const history = [...payRows].reverse().map((p: any) => {
        running -= num(p.amount);
        return { ...p, balanceAfter: Math.max(Math.round(running * 100) / 100, 0) };
      });
      const completedAts = loanRows.map((l: any) => l.completed_at).filter(Boolean);
      out.push({
        id: row.id,
        customer_code: row.customer_code,
        kanaku_no: kanakuNo,
        customer: cust.rows[0] || null,
        loans: loanRows,
        payments: history,
        totals: {
          payable,
          paid,
          outstanding,
          completedDate: completedAts.length ? completedAts.sort().reverse()[0] : null,
          finalPayment: payRows.length
            ? payRows.slice().sort((a: any, b: any) => String(b.payment_date).localeCompare(String(a.payment_date)))[0]
            : null,
        },
        status:
          loanRows.length > 0 && loanRows.every((l: any) => l.status === 'Completed')
            ? 'Completed'
            : payable > 0 && outstanding <= 0 && loanRows.length > 0
              ? 'FULLY PAID'
              : 'Active',
      });
    }

    return NextResponse.json({ kanaku: rows[0].customer_code, rows: out });
  } catch (err: any) {
    console.error('[GET /api/customer/kanaku] Error:', err?.message || err);
    return NextResponse.json(
      { error: 'Unable to load this kanaku. Please try again.' },
      { status: 500 }
    );
  }
}

