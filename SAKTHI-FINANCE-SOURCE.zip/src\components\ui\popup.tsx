'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Z_INDEX } from '@/lib/z-index'
import { cn } from '@/lib/utils'

export type PopupPlacement = 'bottom-start' | 'bottom-end' | 'top-start' | 'top-end'

interface PopupProps {
  open: boolean
  onClose: () => void
  anchorRef: { current: HTMLElement | null }
  placement?: PopupPlacement
  matchWidth?: boolean
  minWidth?: number
  zIndex?: number
  offset?: number
  className?: string
  children: React.ReactNode
}

/**
 * Portal-based popup. Renders into `document.body` with `position: fixed` so it
 * escapes every stacking context (framer-motion transforms, overflow scroll
 * containers, sticky headers/cells) and always floats above the content.
 */
export default function Popup({
  open,
  onClose,
  anchorRef,
  placement = 'bottom-start',
  matchWidth = false,
  minWidth = 220,
  zIndex = Z_INDEX.dropdown,
  offset = 8,
  className,
  children,
}: PopupProps) {
  const [pos, setPos] = useState<{ top: number; left: number; width: number } | null>(null)
  const panelRef = useRef<HTMLDivElement>(null)

  const measure = useCallback(() => {
    const anchor = anchorRef.current
    if (!anchor) return
    const panel = panelRef.current
    const rect = anchor.getBoundingClientRect()
    const gap = offset
    const panelW = matchWidth ? rect.width : panel ? panel.offsetWidth : minWidth
    const panelH = panel ? panel.offsetHeight : 0
    const vw = window.innerWidth
    const vh = window.innerHeight

    let left = placement.endsWith('end') ? rect.right - panelW : rect.left
    left = Math.max(gap, Math.min(left, vw - panelW - gap))

    let top: number
    let flipped = false
    if (placement.startsWith('top')) {
      top = rect.top - panelH - gap
      if (top < gap) {
        top = rect.bottom + gap
        flipped = true
      }
    } else {
      top = rect.bottom + gap
      if (top + panelH > vh - gap) {
        top = rect.top - panelH - gap
        flipped = true
      }
    }
    if (flipped && top < gap) top = gap

    setPos({ top, left, width: panelW })
  }, [anchorRef, placement, matchWidth, minWidth, offset])

  useEffect(() => {
    if (!open) {
      setPos(null)
      return
    }
    measure()
    const raf = requestAnimationFrame(measure)
    let ticking = false
    const onScrollOrResize = () => {
      if (ticking) return
      ticking = true
      requestAnimationFrame(() => {
        measure()
        ticking = false
      })
    }
    window.addEventListener('resize', onScrollOrResize)
    document.addEventListener('scroll', onScrollOrResize, true)
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', onScrollOrResize)
      document.removeEventListener('scroll', onScrollOrResize, true)
    }
  }, [open, measure])

  useEffect(() => {
    if (!open) return
    const onPointerDown = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Node
      if (panelRef.current && panelRef.current.contains(target)) return
      if (anchorRef.current && anchorRef.current.contains(target)) return
      onClose()
    }
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        onClose()
      }
    }
    document.addEventListener('mousedown', onPointerDown)
    document.addEventListener('touchstart', onPointerDown)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('mousedown', onPointerDown)
      document.removeEventListener('touchstart', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [open, onClose, anchorRef])

  if (typeof document === 'undefined') return null

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          ref={panelRef}
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.96 }}
          transition={{ duration: 0.15, ease: [0.22, 1, 0.36, 1] }}
          className={cn('fixed left-0 top-0 will-change-transform', className)}
          style={{
            top: pos?.top ?? -9999,
            left: pos?.left ?? -9999,
            width: pos?.width ?? undefined,
            visibility: pos ? 'visible' : 'hidden',
            zIndex,
            transformOrigin: placement.startsWith('top') ? 'bottom center' : 'top center',
          }}
        >
          {children}
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  )
}
