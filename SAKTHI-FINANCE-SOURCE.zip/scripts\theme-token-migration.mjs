// Mechanical color-token migration only; never changes business logic.
import { readdir, readFile, writeFile } from 'node:fs/promises'
const map = { '#F7F9EC': 'var(--background)', '#F2F4E8': 'var(--surface-secondary)', '#7F1D1D': 'var(--primary)', '#9B1D1D': 'var(--primary-hover)', '#6B1818': 'var(--primary-hover)', '#FDF2F2': 'var(--primary-soft)', '#27253B': 'var(--text-primary)', '#D4AF37': 'var(--secondary)', '#FDF8E8': 'var(--surface-secondary)' }
let count = 0
async function walk(dir) {
  for (const item of await readdir(dir, { withFileTypes: true })) {
    const file = `${dir}/${item.name}`
    if (item.isDirectory()) await walk(file)
    else if (file.endsWith('.tsx')) {
      const original = await readFile(file, 'utf8')
      const updated = original.replace(/#(?:F7F9EC|F2F4E8|7F1D1D|9B1D1D|6B1818|FDF2F2|27253B|D4AF37|FDF8E8)\b/g, hex => map[hex])
      if (updated !== original) { await writeFile(file, updated); count++ }
    }
  }
}
for (const dir of ['src/components', 'src/features', 'src/app/dashboard']) await walk(dir)
console.log(`Migrated brand color tokens in ${count} UI files`)
