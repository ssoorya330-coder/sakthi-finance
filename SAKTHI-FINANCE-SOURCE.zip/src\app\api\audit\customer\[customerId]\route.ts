import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { AUDIT_CURRENT_CUSTOMER_ID } from '@/server/audit-query'
import { resolveCustomerId } from '@/server/customer-identity'

export const dynamic = 'force-dynamic'

/**
 * Chronological audit history for one customer (customer + linked loan and
 * payment events). Owner-scoped: only events on the caller's own customers.
 * Used by the Customer Details "Audit History" section.
 */
export async function GET(request: NextRequest, { params }: { params: Promise<{ customerId: string }> }) {
  const auth = await requireAuthWithPermission('customers:read')
  if (auth.error) return auth.error

  try {
    const customerId = await resolveCustomerId((await params).customerId)
    const { searchParams } = new URL(request.url)
    const dir = searchParams.get('dir') === 'asc' ? 'ASC' : 'DESC'
    const limit = Math.min(Math.max(parseInt(searchParams.get('limit') || '100', 10) || 100, 1), 500)

    // Owner scope: the customer must belong to the caller.
    const owned = await dbQuery('SELECT id, customer_code, full_name FROM customers WHERE id = $1 AND user_id = $2', [
      customerId,
      auth.user.userId,
    ])
    if (owned.rows.length === 0) {
      return NextResponse.json({ error: 'Customer not found' }, { status: 404 })
    }

    const rows = await dbQuery(
      `SELECT seq, audit_id, created_at, action, entity_type, entity_id, customer_id,
              loan_id, payment_id, performed_by, user_role, source, reason, result, changes
       FROM audit_events
       WHERE ${AUDIT_CURRENT_CUSTOMER_ID} = $1
         AND (user_id = $2 OR user_id IS NULL)
       ORDER BY created_at ${dir}, seq ${dir}
       LIMIT $3`,
      [customerId, auth.user.userId, limit]
    )
    return NextResponse.json({
      customer: owned.rows[0],
      events: rows.rows,
      total: rows.rows.length,
    })
  } catch (err: any) {
    return NextResponse.json({ error: 'Failed to load customer audit history' }, { status: 500 })
  }
}

