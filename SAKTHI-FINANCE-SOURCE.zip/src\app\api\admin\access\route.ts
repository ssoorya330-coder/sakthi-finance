import { NextResponse } from 'next/server';
import { requireOwner } from '@/lib/api-utils';
import { ROLE_PERMISSIONS } from '@/config/rbac';

export const dynamic = 'force-dynamic';

/**
 * Backend authorization for Admin Access.
 *
 * Owner-only: explicit rule role === 'owner'. Admin and Customer both get
 * 403. The role is read from the trusted server-side session/database
 * source (`getFullUserFromToken`) — never from the browser — so direct
 * URL/API access by non-owners is rejected.
 *
 * Also exposes the application's actual permission matrix (server config,
 * not database content) for the Permissions sub-section.
 */
export async function GET() {
  const auth = await requireOwner();
  if (auth.error) return auth.error;

  const roles = ['owner', 'admin', 'manager', 'employee', 'viewer', 'customer'] as const;
  const permissions: Record<string, string[]> = {};
  for (const r of roles) {
    const list = (ROLE_PERMISSIONS as Record<string, string[]>)[r];
    permissions[r] = Array.isArray(list) ? list : [];
  }

  return NextResponse.json({
    ok: true,
    role: auth.user.role,
    sections: [
      { id: 'users', href: '/dashboard/admin-access/users' },
      { id: 'accounts', href: '/dashboard/admin-access/accounts' },
      { id: 'login-activity', href: '/dashboard/admin-access/login-activity' },
      { id: 'devices', href: '/dashboard/admin-access/devices' },
      { id: 'data-access', href: '/dashboard/admin-access/data-access' },
      { id: 'security', href: '/dashboard/admin-access/security' },
      { id: 'permissions', href: '/dashboard/admin-access/permissions' },
      { id: 'security-settings', href: '/dashboard/admin-access/security-settings' },
      { id: 'system-activity', href: '/dashboard/admin-access/system-activity' },
      { id: 'system-health', href: '/dashboard/admin-access/system-health' },
    ],
    permissions,
  });
}
