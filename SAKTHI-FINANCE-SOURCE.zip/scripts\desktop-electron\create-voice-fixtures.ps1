$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$sfFixtures = Join-Path (Get-Location) 'test-reports/offline-voice-fixtures'
New-Item -ItemType Directory -Path $sfFixtures -Force | Out-Null
$sfCases = @{
    'name' = 'Soorya'
    'sakthivel' = 'Sakthivel'
    'full-name' = 'Ravi Kumar'
    'city' = 'Salem'
    'phone' = 'nine eight seven six five four three two one zero'
    'address' = 'number twelve Gandhi Road Chennai'
    'unseen-name' = 'Arjun'
    'unseen-city' = 'Coimbatore'
    'requested-name' = 'Arul Vettri'
    'requested-address' = 'RS Puram Coimbatore'
    'country-phone' = 'plus nine one nine eight seven six five four three two one zero'
    'double-phone' = 'double nine eight seven six five four three two one'
}
foreach ($sfCase in $sfCases.GetEnumerator()) {
    $sfSynth = New-Object System.Speech.Synthesis.SpeechSynthesizer
    try {
        $sfFormat = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo(16000, [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen, [System.Speech.AudioFormat.AudioChannel]::Mono)
        $sfSynth.SetOutputToWaveFile((Join-Path $sfFixtures ($sfCase.Key + '.wav')), $sfFormat)
        $sfPrompt = New-Object System.Speech.Synthesis.PromptBuilder
        $sfPrompt.AppendBreak([TimeSpan]::FromMilliseconds(400))
        $sfPrompt.AppendText($sfCase.Value)
        $sfPrompt.AppendBreak([TimeSpan]::FromMilliseconds(500))
        $sfSynth.Speak($sfPrompt)
    } finally { $sfSynth.Dispose() }
}
Write-Output 'Generated synthetic audio fixtures; no microphone was used.'
