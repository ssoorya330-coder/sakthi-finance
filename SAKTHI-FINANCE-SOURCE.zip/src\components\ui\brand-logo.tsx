export default function BrandLogo({ className = '' }: { className?: string }) {
  return <img src="/sakthi-brand.png" alt="Sakthi Finance" width={1254} height={1254} className={`object-contain ${className}`} />
}
