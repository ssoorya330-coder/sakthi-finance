export type SyncKind = 'customer' | 'loan' | 'payment'
export type SyncStatus = 'PENDING' | 'SYNCING' | 'SYNCED' | 'FAILED' | 'CONFLICT'
export type Row = Record<string, any>
export interface SyncOperation {
  id: string; deviceId: string; kind: SyncKind; method: 'POST' | 'PUT'; recordId: string
  customerId: string; data: Row; recordedAt: string; baseRevision: string | null
  status: SyncStatus; error?: string; serverRevision?: string; serverRecord?: Row
  createdBy?: string
  discarded?: boolean
  snapshotApplied?: boolean
}
export interface SyncSnapshot {
  userId: string; customers: Row[]; loans: Row[]; payments: Row[]
  revisions: Record<string, string>; capturedAt: string
  schemaVersion?: number; customerCount?: number; loanCount?: number
}
export interface SyncWorkspace {
  enabled: boolean; deviceId: string; snapshot: SyncSnapshot; queue: SyncOperation[]
  mappings: Record<string, string>; lastSync?: string
  history: Array<{ date: string; synced: number; duplicates: number; failed: number; conflicts: number; message: string }>
}
