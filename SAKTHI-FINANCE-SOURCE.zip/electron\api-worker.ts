import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { NextRequest, NextResponse } from 'next/server'
import { withDesktopSession } from '../src/config/supabase-auth'
import { validCall, matchRoute } from './policy'
import routeMap from './api-routes.generated'
import { tabletApi } from '../src/server/tablet-api'

/**
 * API worker — bundled TOGETHER with all route handlers (dist-electron/api/
 * routes.js) so that setDesktopSessionToken and the handlers share one module
 * instance. The main process resolves the session/refresh rotation and calls
 * callApi(token, call) here; no HTTP server is involved.
 */

export interface ApiCall {
  path: string
  method?: string
  body?: unknown
  query?: Record<string, string | number | boolean | undefined>
  form?: Array<{ name: string; value?: string; bytes?: number[]; filename?: string; type?: string }>
}

export interface ApiResult {
  status: number
  ok: boolean
  data: unknown
  binary?: { base64: string; mimeType: string; fileName?: string }
}

const map = routeMap as unknown as Record<string, Record<string, Function>>
const RESERVED = new Set(['auth', 'desktop'])

function buildRequest(call: ApiCall): NextRequest {
  const method = (call.method || 'GET').toUpperCase()
  const params = new URLSearchParams()
  for (const [key, value] of Object.entries(call.query ?? {})) {
    if (value !== undefined && value !== null) params.set(key, String(value))
  }
  const qs = params.toString()
  const url = `http://sakthi.desktop/api${call.path}${qs ? `?${qs}` : ''}`
  const headers: Record<string, string> = { 'content-type': 'application/json' }
  let body: BodyInit | undefined
  if (method !== 'GET' && call.body !== undefined) {
    body = typeof call.body === 'string' ? call.body : JSON.stringify(call.body)
  }
  if (call.form) {
    delete headers['content-type']
    const form = new FormData()
    for (const field of call.form) {
      if (field.bytes) form.append(field.name, new Blob([Uint8Array.from(field.bytes)], { type: field.type }), field.filename)
      else form.append(field.name, field.value || '')
    }
    body = form
  }
  return new NextRequest(new Request(url, { method, headers, body }))
}

async function unwrap(response: NextResponse | Response): Promise<ApiResult> {
  const status = response.status
  if ([204, 205, 304].includes(status)) return { status, ok: response.ok, data: null }
  const contentType = response.headers.get('content-type') || ''
  const disposition = response.headers.get('content-disposition') || ''
  const isJson = contentType.includes('application/json') || (!contentType && status !== 204)
  if (!isJson) {
    // Binary payloads (xlsx, zip, csv, pdf) travel as base64 with headers.
    const buffer = await response.arrayBuffer()
    return {
      status,
      ok: status >= 200 && status < 300,
      data: null,
      binary: {
        base64: Buffer.from(buffer).toString('base64'),
        mimeType: contentType || 'application/octet-stream',
        fileName: disposition.match(/filename="([^"]+)"/)?.[1],
      },
    }
  }
  let data: unknown = null
  try {
    data = await response.json()
  } catch {
    data = null
  }
  return { status, ok: status >= 200 && status < 300, data }
}

// Handler execution must be SERIAL: the session token is passed through a
// module-global (setDesktopSessionToken) shared with every route handler.
// Parallel calls would race — one call's finally clears the token while
// another handler is still reading it, producing spurious 401s that log the
// user out (the dashboard fires many requests simultaneously on mount).
let workerQueue: Promise<unknown> = Promise.resolve()

export async function callApi(token: string | null, call: ApiCall): Promise<ApiResult> {
  if (!token) return { status: 401, ok: false, data: { error: 'Not signed in' } }
  if (!validCall(call)) return { status: 400, ok: false, data: { error: 'Invalid desktop request' } }
  const route = '/' + call.path.replace(/^\/+/, '').replace(/\/+$/, '')
  const root = route.split('/')[1]
  if (RESERVED.has(root) || route === '/notifications/stream') {
    return { status: 403, ok: false, data: { error: 'Use dedicated desktop IPC for this operation.' } }
  }
  const match = matchRoute(Object.keys(map), route)
  const mod = match ? map[match.key] : null
  if (!mod) return { status: 404, ok: false, data: { error: `Unknown API route: ${route}` } }
  const method = (call.method || 'GET').toUpperCase()
  const handler = mod[method]
  if (typeof handler !== 'function') {
    return { status: 405, ok: false, data: { error: `Method ${method} not allowed` } }
  }
  const run = async (): Promise<ApiResult> => {
    try {
      const request = buildRequest(call)
      const response = await handler(request, { params: Promise.resolve(match!.params) })
      return await unwrap(response as Response)
    } catch (error) {
      return { status: 500, ok: false, data: { error: 'Operation failed. Check database/storage availability before retrying.' } }
    }
  }
  return withDesktopSession(token, run)
}

export { closePool } from '../src/server/database'

export async function callTablet(token: string | null, action: string, body: Record<string, unknown>) {
  if (!token) return {status:401,ok:false,data:{error:'Not signed in'}}
  return withDesktopSession(token, () => tabletApi(action,body))
}
