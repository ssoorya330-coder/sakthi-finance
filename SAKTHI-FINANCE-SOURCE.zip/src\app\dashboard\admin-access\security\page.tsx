'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import SecurityContent from '@/features/admin-access/SecurityContent'

export default function SecurityContentPage() {
  return (
    <ClientPageGate requireRole="owner">
      <SecurityContent />
    </ClientPageGate>
  )
}
