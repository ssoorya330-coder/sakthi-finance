import { readFile, writeFile, stat } from 'node:fs/promises'
import { createReadStream } from 'node:fs'
import { createHash, sign } from 'node:crypto'
import path from 'node:path'
const dir = path.resolve('release/electron')
const { version } = JSON.parse(await readFile('package.json', 'utf8'))
const filename = `SAKTHI FINANCE Setup ${version}.exe`
const file = path.join(dir, filename)
const digest = createHash('sha256'); for await (const chunk of createReadStream(file)) digest.update(chunk)
const payload = Buffer.from(JSON.stringify({ app: 'com.sakthifinance.desktop', version, filename, size: (await stat(file)).size, sha256: digest.digest('hex'), notes: 'App updates are available from About > Check for Updates. Includes automatic update checks from the configured public Tailscale Funnel server. Download and installation require your confirmation. Voice entry and saved finance data remain unchanged.' }))
const privateKey = await readFile('desktop-private/update-signing.pem', 'utf8')
await writeFile(path.join(dir, 'SakthiFinance-' + version + '.sfupdate.json'), JSON.stringify({ payload: payload.toString('base64'), signature: sign(null, payload, privateKey).toString('base64') }, null, 2))
console.log('Signed update metadata created for version ' + version + '. Private signing key was not copied.')
