'use client'

import { useState, useEffect, useMemo, useCallback, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  X,
  PencilLine,
  Save,
  User,
  Phone,
  Smartphone,
  MapPin,
  Building2,
  Home,
  IndianRupee,
  Percent,
  ListOrdered,
  Timer,
  CalendarDays,
  FileText,
  Hash,
  History,
  Download,
} from 'lucide-react'
import { addDays, addWeeks, addMonths, addYears, format, differenceInCalendarDays } from 'date-fns'
import { useCustomerStore } from '@/store/customer-store'
import { useToastStore } from '@/store/toast-store'
import { formatCurrency, formatDateDMY } from '@/features/dashboard/dashboard.styles'
import type { Customer } from '@/types/customer.types'
import { BUSINESS_OPTIONS } from '@/components/ui/business-select'

interface CustomerDetailDrawerProps {
  customer: Customer | null
  isOpen: boolean
  onClose: () => void
  onSaved?: () => void
  initialMode?: 'view' | 'edit'
}

const LOAN_TYPE_OPTIONS = ['Daily', 'Weekly', 'Monthly', 'Yearly'] as const

interface DetailForm {
  fullName: string
  mobileNumber: string
  alternateMobile: string
  address: string
  area: string
  city: string
  occupation: string
  monthlyIncome: string
  notes: string
  loanAmount: string
  interestRate: string
  loanType: string
  duration: string
  loanDate: string
}

function toForm(c: Customer): DetailForm {
  return {
    fullName: c.fullName || '',
    mobileNumber: c.mobileNumber || '',
    alternateMobile: c.alternateMobile || '',
    address: c.address || '',
    area: c.area || '',
    city: c.city || '',
    occupation: c.occupation || '',
    monthlyIncome: c.monthlyIncome || '',
    notes: c.loanNotes || '',
    loanAmount: c.loanAmount || '',
    interestRate: c.interestRate || '',
    loanType: c.loanType || 'Daily',
    duration: c.duration || '',
    loanDate: c.loanDate || '',
  }
}

function durationLabelFor(loanType: string): string {
  switch (loanType) {
    case 'Daily': return 'Number of Days'
    case 'Weekly': return 'Number of Weeks'
    case 'Monthly': return 'Number of Months'
    case 'Yearly': return 'Number of Years'
    default: return 'Duration'
  }
}

function ViewRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="min-w-0">
      <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">{label}</p>
      <p className="text-sm font-semibold text-slate-900 mt-0.5 break-words">{value || '—'}</p>
    </div>
  )
}

function formatPercent(value: string | number | null | undefined) {
  const number = Number(value)
  if (!Number.isFinite(number)) return '0%'
  return `${Number.isInteger(number) ? number : number.toString()}%`
}

function EditField({
  label,
  required,
  error,
  children,
}: {
  label: string
  required?: boolean
  error?: string
  children: React.ReactNode
}) {
  return (
    <div className="min-w-0">
      <label className="block text-xs font-medium text-[#1E1B14] mb-1 tracking-wide">
        {label}
        {required && <span className="text-[#BA7517] ml-0.5">*</span>}
      </label>
      {children}
      {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
    </div>
  )
}

const inputCls =
  'w-full h-10 px-3.5 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 placeholder:text-slate-400 outline-none transition-all focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/10'

export default function CustomerDetailDrawer({ customer, isOpen, onClose, onSaved, initialMode = 'view' }: CustomerDetailDrawerProps) {
  const liveCustomer = useCustomerStore((s) =>
    customer ? s.customers.find((c) => c.id === customer.id) || null : null,
  )
  const updateCustomer = useCustomerStore((s) => s.updateCustomer)
  const updateCustomerStatus = useCustomerStore((s) => s.updateCustomerStatus)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const getDisplayId = useCustomerStore((s) => s.getDisplayId)
  const addToast = useToastStore((s) => s.addToast)

  const activeCustomer = liveCustomer || customer
  const autoCompletedRef = useRef<string | null>(null)

  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState<DetailForm | null>(null)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)
  const [paymentMode, setPaymentMode] = useState<'Cash' | 'PhonePe'>('Cash')

  useEffect(() => {
    if (isOpen && customer) {
      setForm(toForm(liveCustomer || customer))
      setErrors({})
      setEditing(initialMode === 'edit')
      setSaving(false)
    }
    if (!isOpen) {
      setEditing(false)
      setErrors({})
      setSaving(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, customer?.id, initialMode])

  const set = useCallback((key: keyof DetailForm, value: string) => {
    setForm((f) => (f ? { ...f, [key]: value } : f))
    setErrors((e) => {
      if (!e[key]) return e
      const next = { ...e }
      delete next[key]
      return next
    })
  }, [])

  const computed = useMemo(() => {
    if (!form) return null
    const amount = Number(form.loanAmount) || 0
    const rate = Number(form.interestRate) || 0
    const dur = Number(form.duration) || 0
    const interestAmount = (amount * rate) / 100
    const totalAmount = amount + interestAmount
    const installmentAmount = dur > 0 ? totalAmount / dur : 0

    let dueDateISO = ''
    let dueDateDisplay = '—'
    let nextCollectionDisplay = '—'
    let remainingDays = 0
    if (form.loanDate && dur > 0 && form.loanType) {
      const start = new Date(`${form.loanDate}T00:00:00`)
      if (!isNaN(start.getTime())) {
        let due: Date
        if (form.loanType === 'Daily') due = addDays(start, dur)
        else if (form.loanType === 'Weekly') due = addWeeks(start, dur)
        else if (form.loanType === 'Monthly') due = addMonths(start, dur)
        else due = addYears(start, dur)
        dueDateISO = format(due, 'yyyy-MM-dd')
        dueDateDisplay = format(due, 'dd-MM-yyyy')
        let next: Date
        if (form.loanType === 'Daily') next = addDays(start, 1)
        else if (form.loanType === 'Weekly') next = addWeeks(start, 1)
        else if (form.loanType === 'Monthly') next = addMonths(start, 1)
        else next = addYears(start, 1)
        nextCollectionDisplay = format(next, 'dd-MM-yyyy')
        remainingDays = differenceInCalendarDays(due, new Date())
      }
    }
    return { interestAmount, totalAmount, installmentAmount, dueDateISO, dueDateDisplay, nextCollectionDisplay, remainingDays }
  }, [form])

  const validate = useCallback((f: DetailForm): Record<string, string> => {
    const e: Record<string, string> = {}
    if (!f.fullName.trim()) e.fullName = 'Full name is required'
    if (!/^\d{10}$/.test(f.mobileNumber.trim())) e.mobileNumber = 'Must be exactly 10 digits'
    if (f.alternateMobile.trim() && !/^\d{10}$/.test(f.alternateMobile.trim())) e.alternateMobile = 'Must be exactly 10 digits'
    if (!(Number(f.loanAmount) > 0)) e.loanAmount = 'Must be a positive number'
    if (f.interestRate.trim() === '' || isNaN(Number(f.interestRate)) || Number(f.interestRate) < 0) e.interestRate = 'Must be 0 or more'
    if (!f.loanType) e.loanType = 'Loan type is required'
    if (!(Number(f.duration) > 0)) e.duration = 'Must be positive'
    if (!f.loanDate) e.loanDate = 'Loan date is required'
    return e
  }, [])

  const handleSave = useCallback(async () => {
    if (!activeCustomer || !form || !computed || saving) return
    const errs = validate(form)
    if (Object.keys(errs).length > 0) {
      setErrors(errs)
      addToast('Please fix the highlighted fields.', 'error')
      return
    }
    setSaving(true)
    const result = await updateCustomer(activeCustomer.id, {
      fullName: form.fullName.trim(),
      mobileNumber: form.mobileNumber.trim(),
      alternateMobile: form.alternateMobile.trim(),
      address: form.address.trim(),
      area: form.area.trim(),
      city: form.city.trim(),
      occupation: form.occupation,
      monthlyIncome: form.monthlyIncome.trim(),
      loanNotes: form.notes.trim(),
      loanAmount: form.loanAmount.trim(),
      interestRate: form.interestRate.trim(),
      loanType: form.loanType as Customer['loanType'],
      duration: form.duration.trim(),
      loanDate: form.loanDate,
      dueDate: computed.dueDateISO || activeCustomer.dueDate,
      totalAmount: computed.totalAmount,
      interestAmount: String(computed.interestAmount),
      installmentAmount: computed.installmentAmount,
      remainingDays: computed.remainingDays,
    })
    setSaving(false)
    if (result.success) {
      addToast('Customer details updated.', 'success')
      setEditing(false)
      onSaved?.()
    } else {
      addToast(result.error || 'Failed to update customer.', 'error')
    }
  }, [activeCustomer, form, computed, saving, validate, updateCustomer, addToast, onSaved])

  const handleCancelEdit = useCallback(() => {
    if (activeCustomer) setForm(toForm(activeCustomer))
    setErrors({})
    setEditing(false)
  }, [activeCustomer])

  // Balance = totalAmount - totalPaid (from payment history). When it hits
  // zero the loan is fully repaid.
  const totalPaid = useMemo(() => {
    if (!activeCustomer) return 0
    return paymentHistory
      .filter((p) => p.customerId === activeCustomer.id)
      .reduce((sum, p) => sum + (Number(p.paymentAmount) || 0), 0)
  }, [paymentHistory, activeCustomer])

  const outstanding = useMemo(() => {
    if (!activeCustomer) return 0
    return Math.max(0, (Number(activeCustomer.totalAmount) || 0) - totalPaid)
  }, [activeCustomer, totalPaid])

  // PostgreSQL completes each Kanaku and customer in the payment transaction.

  useEffect(() => {
    if (!isOpen) autoCompletedRef.current = null
  }, [isOpen])

  if (!activeCustomer) return null

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[var(--z-modal)]"
            onClick={onClose}
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
            className="fixed top-0 right-0 h-full w-full max-w-[720px] bg-[var(--background)] z-[var(--z-modal)] shadow-2xl flex flex-col"
          >
            {/* Header */}
            <div className="bg-white border-b border-[rgba(212,175,55,0.15)] px-6 py-4 flex-shrink-0">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-4 min-w-0">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center text-white text-lg font-bold flex-shrink-0 shadow-lg shadow-[var(--primary)]/20">
                    {activeCustomer.fullName.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <h2 className="text-lg font-bold text-slate-900 truncate">{activeCustomer.fullName}</h2>
                    <div className="flex items-center gap-2 flex-wrap mt-1">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${activeCustomer.status === 'Completed' ? 'bg-[var(--primary-soft)] text-[var(--primary)]' : activeCustomer.status === 'Overdue' ? 'bg-red-50 text-red-700' : activeCustomer.status === 'Aborted' ? 'bg-red-50 text-[var(--primary)]' : 'bg-emerald-50 text-emerald-700'}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${activeCustomer.status === 'Completed' ? 'bg-[var(--primary)]' : activeCustomer.status === 'Overdue' ? 'bg-red-500' : activeCustomer.status === 'Aborted' ? 'bg-[var(--primary)]' : 'bg-emerald-500'}`} />
                        {activeCustomer.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-slate-500 flex-wrap mt-0.5">
                      <span className="flex items-center gap-1.5">
                        <Hash className="w-3.5 h-3.5" />
                        {getDisplayId(activeCustomer)}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5" />
                        {activeCustomer.mobileNumber}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 mt-1.5 text-sm">
                      <span className="text-slate-600">
                        Loan: <span className="font-semibold text-slate-900">{formatCurrency(Number(activeCustomer.loanAmount) || 0)}</span>
                      </span>
                      <span className="text-slate-600">
                        Balance: <span className="font-semibold text-slate-900">{formatCurrency(outstanding)}</span>
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  {!editing ? (
                    <button
                      onClick={() => setEditing(true)}
                      className="inline-flex items-center gap-2 h-9 px-4 rounded-xl text-sm font-semibold text-white transition-all active:scale-[0.97]"
                      style={{ background: 'linear-gradient(135deg, var(--primary), #912222)' }}
                    >
                      <PencilLine className="w-4 h-4" />
                      Edit
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={handleCancelEdit}
                        disabled={saving}
                        className="h-9 px-4 rounded-xl border text-sm font-medium transition-colors bg-white disabled:opacity-50"
                        style={{ borderColor: 'rgba(127,29,29,.2)', color: 'var(--text-primary)' }}
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleSave}
                        disabled={saving}
                        className="inline-flex items-center gap-2 h-9 px-4 rounded-xl text-sm font-semibold text-white transition-all active:scale-[0.97] disabled:opacity-50"
                        style={{ background: 'linear-gradient(135deg, var(--primary), #912222)' }}
                      >
                        {saving ? (
                          <svg className="animate-spin w-4 h-4" viewBox="0 0 16 16" fill="none">
                            <circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="2" opacity="0.25" />
                            <path d="M15 8A7 7 0 1 1 1 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                          </svg>
                        ) : (
                          <Save className="w-4 h-4" />
                        )}
                        {saving ? 'Saving...' : 'Save'}
                      </button>
                    </>
                  )}
                  <button
                    onClick={onClose}
                    className="w-9 h-9 rounded-xl border border-transparent flex items-center justify-center hover:bg-[var(--primary-soft)] hover:border-[var(--primary)]/20 transition-colors active:scale-95"
                  >
                    <X className="w-5 h-5 text-[var(--primary)]" />
                  </button>
                </div>
              </div>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto min-h-0 p-6 space-y-4">
              {!editing || !form ? (
                <>
                  {/* Personal Information (read-only) */}
                  <div className="bg-white rounded-[14px] border border-[rgba(212,175,55,0.2)] shadow-[0_1px_2px_rgba(0,0,0,0.04)] overflow-hidden">
                    <div className="px-4 py-3 border-b border-[rgba(212,175,55,0.12)] flex items-center gap-2">
                      <User className="w-4 h-4 text-[var(--primary)]" />
                      <h3 className="text-sm font-semibold text-slate-900">Personal Information</h3>
                    </div>
                    <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-4">
                      <ViewRow label="Full Name" value={activeCustomer.fullName} />
                      <ViewRow label="Mobile Number" value={activeCustomer.mobileNumber} />
                      <ViewRow label="Alternate Mobile" value={activeCustomer.alternateMobile} />
                      <ViewRow label="Address" value={activeCustomer.address} />
                      <ViewRow label="Area" value={activeCustomer.area} />
                      <ViewRow label="City" value={activeCustomer.city} />
                      <ViewRow label="Business" value={activeCustomer.occupation} />
                      <ViewRow label="Monthly Income" value={activeCustomer.monthlyIncome ? formatCurrency(Number(activeCustomer.monthlyIncome) || 0) : ''} />
                      <ViewRow label="Notes" value={activeCustomer.loanNotes} />
                    </div>
                  </div>

                  {/* Loan Details (read-only) */}
                  <div className="bg-white rounded-[14px] border border-[rgba(212,175,55,0.2)] shadow-[0_1px_2px_rgba(0,0,0,0.04)] overflow-hidden">
                    <div className="px-4 py-3 border-b border-[rgba(212,175,55,0.12)] flex items-center gap-2">
                      <IndianRupee className="w-4 h-4 text-[var(--primary)]" />
                      <h3 className="text-sm font-semibold text-slate-900">Loan Details</h3>
                    </div>
                    <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-4">
                      <ViewRow label="Loan Amount" value={formatCurrency(Number(activeCustomer.loanAmount) || 0)} />
                      <ViewRow label="Interest Rate" value={formatPercent(activeCustomer.interestRate)} />
                      <ViewRow label="Interest Amount" value={formatCurrency(Number(activeCustomer.interestAmount) || 0)} />
                      <ViewRow label="Total Amount" value={formatCurrency(activeCustomer.totalAmount || 0)} />
                      <ViewRow label="Total Paid" value={formatCurrency(totalPaid)} />
                      <ViewRow label="Balance Amount" value={formatCurrency(outstanding)} />
                      <div className="sm:col-span-2 lg:col-span-3 rounded-xl border border-[var(--secondary)]/50 bg-[#FFFBEA] p-3">
                        <p className="mb-2 text-[11px] font-bold uppercase tracking-wide text-[#7A6200]">Payment mode</p>
                        <div className="flex gap-2" role="group" aria-label="Payment mode">
                          {(['Cash', 'PhonePe'] as const).map((mode) => (
                            <button
                              key={mode}
                              type="button"
                              onClick={() => setPaymentMode(mode)}
                              aria-pressed={paymentMode === mode}
                              className={`flex-1 rounded-lg px-3 py-2.5 text-xs font-semibold transition-colors ${paymentMode === mode ? 'bg-[var(--primary)] text-white shadow-sm' : 'bg-white text-[var(--primary)] border border-[#E7D98C] hover:bg-[#FFFDF0]'}`}
                            >
                              {mode}
                            </button>
                          ))}
                        </div>
                      </div>
                      <ViewRow label="Status" value={activeCustomer.status} />
                      <ViewRow label="Per Installment" value={formatCurrency(Math.round(activeCustomer.installmentAmount || 0))} />
                      <ViewRow label="Loan Type" value={activeCustomer.loanType} />
                      <ViewRow label="Duration" value={activeCustomer.duration} />
                      <ViewRow label="Loan Date" value={activeCustomer.loanDate ? formatDateDMY(activeCustomer.loanDate) : ''} />
                      <ViewRow label="Due Date" value={activeCustomer.dueDate ? formatDateDMY(activeCustomer.dueDate) : ''} />
                    </div>
                  </div>

                  {/* Audit History (read-only, append-only) */}
                  {activeCustomer.id && <CustomerAuditHistory customerId={activeCustomer.id} customerCode={getDisplayId(activeCustomer)} />}
                </>
              ) : (
                <>
                  {/* Personal Information (editable) */}
                  <div className="bg-white rounded-[14px] border border-[rgba(212,175,55,0.2)] shadow-[0_1px_2px_rgba(0,0,0,0.04)] overflow-hidden">
                    <div className="px-4 py-3 border-b border-[rgba(212,175,55,0.12)] flex items-center gap-2">
                      <User className="w-4 h-4 text-[var(--primary)]" />
                      <h3 className="text-sm font-semibold text-slate-900">Personal Information</h3>
                    </div>
                    <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-x-3 gap-y-3">
                      <div className="sm:col-span-2">
                        <EditField label="Full Name" required error={errors.fullName}>
                          <div className="relative">
                            <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                            <input
                              type="text"
                              placeholder="Enter full name"
                              value={form.fullName}
                              onChange={(e) => set('fullName', e.target.value)}
                              className={`${inputCls} pl-10`}
                            />
                          </div>
                        </EditField>
                      </div>
                      <EditField label="Mobile Number" required error={errors.mobileNumber}>
                        <div className="relative">
                          <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                          <input
                            type="tel"
                            placeholder="10-digit number"
                            maxLength={10}
                            value={form.mobileNumber}
                            onChange={(e) => set('mobileNumber', e.target.value.replace(/\D/g, '').slice(0, 10))}
                            className={`${inputCls} pl-10`}
                          />
                        </div>
                      </EditField>
                      <EditField label="Alternate Mobile" error={errors.alternateMobile}>
                        <div className="relative">
                          <Smartphone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                          <input
                            type="tel"
                            placeholder="Alternate number"
                            maxLength={10}
                            value={form.alternateMobile}
                            onChange={(e) => set('alternateMobile', e.target.value.replace(/\D/g, '').slice(0, 10))}
                            className={`${inputCls} pl-10`}
                          />
                        </div>
                      </EditField>
                      <EditField label="Address">
                        <div className="relative">
                          <Home className="absolute left-3.5 top-3 w-4 h-4 text-slate-400 pointer-events-none" />
                          <textarea
                            placeholder="Enter full address"
                            rows={2}
                            value={form.address}
                            onChange={(e) => set('address', e.target.value)}
                            className="w-full px-3.5 py-2.5 pl-10 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 placeholder:text-slate-400 outline-none transition-all focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/10 resize-none"
                          />
                        </div>
                      </EditField>
                      <EditField label="Area">
                        <div className="relative">
                          <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                          <input
                            type="text"
                            placeholder="Area / Locality"
                            value={form.area}
                            onChange={(e) => set('area', e.target.value)}
                            className={`${inputCls} pl-10`}
                          />
                        </div>
                      </EditField>
                      <EditField label="City">
                        <div className="relative">
                          <Building2 className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                          <input
                            type="text"
                            placeholder="Enter city"
                            value={form.city}
                            onChange={(e) => set('city', e.target.value)}
                            className={`${inputCls} pl-10`}
                          />
                        </div>
                      </EditField>
                      <EditField label="Business">
                        <div className="relative">
                          <Building2 className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                          <select
                            value={BUSINESS_OPTIONS.includes(form.occupation) ? form.occupation : ''}
                            onChange={(e) => set('occupation', e.target.value)}
                            className={`${inputCls} pl-10 pr-10 appearance-none cursor-pointer ${form.occupation ? '' : 'text-slate-400'}`}
                          >
                            <option value="">Select Business</option>
                            {BUSINESS_OPTIONS.map((opt) => (
                              <option key={opt} value={opt}>{opt}</option>
                            ))}
                            {form.occupation && !BUSINESS_OPTIONS.includes(form.occupation) && (
                              <option value={form.occupation}>{form.occupation}</option>
                            )}
                          </select>
                          <svg className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
                          </svg>
                        </div>
                      </EditField>
                      <EditField label="Monthly Income">
                        <div className="relative">
                          <IndianRupee className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                          <input
                            type="number"
                            placeholder="0"
                            min="0"
                            value={form.monthlyIncome}
                            onChange={(e) => set('monthlyIncome', e.target.value)}
                            className={`${inputCls} pl-10`}
                          />
                        </div>
                      </EditField>
                      <div className="sm:col-span-2">
                        <EditField label="Notes">
                          <div className="relative">
                            <FileText className="absolute left-3.5 top-3 w-4 h-4 text-slate-400 pointer-events-none" />
                            <textarea
                              placeholder="Add notes..."
                              rows={2}
                              value={form.notes}
                              onChange={(e) => set('notes', e.target.value)}
                              className="w-full px-3.5 py-2.5 pl-10 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 placeholder:text-slate-400 outline-none transition-all focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/10 resize-none"
                            />
                          </div>
                        </EditField>
                      </div>
                    </div>
                  </div>

                  {/* Loan Details (editable) */}
                  <div className="bg-white rounded-[14px] border border-[rgba(212,175,55,0.2)] shadow-[0_1px_2px_rgba(0,0,0,0.04)] overflow-hidden">
                    <div className="px-4 py-3 border-b border-[rgba(212,175,55,0.12)] flex items-center gap-2">
                      <IndianRupee className="w-4 h-4 text-[var(--primary)]" />
                      <h3 className="text-sm font-semibold text-slate-900">Loan Details</h3>
                    </div>
                    <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-x-3 gap-y-3">
                      <EditField label="Loan Amount" required error={errors.loanAmount}>
                        <div className="relative">
                          <IndianRupee className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                          <input
                            type="number"
                            placeholder="0"
                            min="0"
                            value={form.loanAmount}
                            onChange={(e) => set('loanAmount', e.target.value)}
                            className={`${inputCls} pl-10`}
                          />
                        </div>
                      </EditField>
                      <EditField label="Interest Rate (%)" required error={errors.interestRate}>
                        <div className="relative">
                          <Percent className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                          <input
                            type="number"
                            placeholder="0"
                            min="0"
                            step="0.1"
                            value={form.interestRate}
                            onChange={(e) => set('interestRate', e.target.value)}
                            className={`${inputCls} pl-10`}
                          />
                        </div>
                      </EditField>
                      <EditField label="Loan Type" required error={errors.loanType}>
                        <div className="relative">
                          <ListOrdered className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                          <select
                            value={form.loanType}
                            onChange={(e) => set('loanType', e.target.value)}
                            className={`${inputCls} pl-10 pr-10 appearance-none cursor-pointer`}
                          >
                            {LOAN_TYPE_OPTIONS.map((opt) => (
                              <option key={opt} value={opt}>{opt}</option>
                            ))}
                          </select>
                          <svg className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
                          </svg>
                        </div>
                      </EditField>
                      <EditField label={durationLabelFor(form.loanType)} required error={errors.duration}>
                        <div className="relative">
                          <Timer className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                          <input
                            type="number"
                            placeholder="0"
                            min="1"
                            value={form.duration}
                            onChange={(e) => set('duration', e.target.value)}
                            className={`${inputCls} pl-10`}
                          />
                        </div>
                      </EditField>
                      <EditField label="Loan Date" required error={errors.loanDate}>
                        <div className="relative">
                          <CalendarDays className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                          <input
                            type="date"
                            value={form.loanDate}
                            onChange={(e) => set('loanDate', e.target.value)}
                            className={`${inputCls} pl-10 pr-3 cursor-pointer`}
                          />
                        </div>
                      </EditField>
                      <EditField label="Due Date (auto)">
                        <div className="relative">
                          <CalendarDays className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                          <input
                            type="text"
                            readOnly
                            value={computed?.dueDateDisplay || '—'}
                            className={`${inputCls} pl-10 bg-slate-50 text-slate-500 cursor-not-allowed`}
                          />
                        </div>
                      </EditField>
                    </div>
                    {computed && (
                      <div className="mx-4 mb-4 px-4 py-3 rounded-xl bg-[#FDF8E5] border border-[rgba(212,175,55,.3)] flex flex-wrap items-center gap-x-6 gap-y-1.5 text-sm">
                        <span className="text-slate-600">
                          Interest: <span className="font-bold text-slate-900">{formatCurrency(Math.round(computed.interestAmount))}</span>
                        </span>
                        <span className="text-slate-600">
                          Total: <span className="font-bold text-slate-900">{formatCurrency(Math.round(computed.totalAmount))}</span>
                        </span>
                        <span className="text-slate-600">
                          Per Installment: <span className="font-bold text-[var(--primary)]">{formatCurrency(Math.round(computed.installmentAmount))}</span>
                        </span>
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

interface HistoryEvent {
  seq: number
  audit_id: string
  created_at: string
  action: string
  entity_type: string
  performed_by: string | null
  result: string
  changes: Array<{ field: string; label: string; before: any; after: any }>
}

const fmtHistVal = (v: any): string => {
  if (v === null || v === undefined || v === '') return '—'
  if (typeof v === 'number') return v.toLocaleString('en-IN')
  if (typeof v === 'object') return JSON.stringify(v)
  return String(v)
}

function CustomerAuditHistory({ customerId, customerCode }: { customerId: string; customerCode: string }) {
  const [events, setEvents] = useState<HistoryEvent[]>([])
  const [loading, setLoading] = useState(true)
  const [order, setOrder] = useState<'desc' | 'asc'>('desc')

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    fetch(`/api/audit/customer/${encodeURIComponent(customerId)}?dir=${order}&limit=200`, { credentials: 'include' })
      .then((r) => (r.ok ? r.json() : { events: [] }))
      .then((d) => {
        if (!cancelled) setEvents(d.events || [])
      })
      .catch(() => {})
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [customerId, order])

  const exportReport = (format: 'csv' | 'json') => {
    const stamp = new Date().toISOString().slice(0, 10)
    if (format === 'json') {
      const blob = new Blob(
        [JSON.stringify({ report: 'Sakthi Finance — Customer Audit Report', generatedAt: new Date().toISOString(), customerId: customerCode, events }, null, 2)],
        { type: 'application/json' }
      )
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `sakthi-finance-customer-audit-${stamp}.json`
      document.body.appendChild(a)
      a.click()
      a.remove()
      setTimeout(() => URL.revokeObjectURL(url), 2000)
      return
    }
    const cell = (v: any) => `"${String(v ?? '').replace(/"/g, '""')}"`
    const lines = [
      'Sakthi Finance - Customer Audit Report',
      `Report Generated,${new Date().toISOString()}`,
      `Customer ID,${customerCode}`,
      '',
      'Date & Time,Audit ID,Action,Entity,Performed By,Result,Changes',
      ...events.map((e) =>
        [
          cell(new Date(e.created_at).toISOString()),
          cell(e.audit_id),
          cell(e.action),
          cell(e.entity_type),
          cell(e.performed_by),
          cell(e.result),
          cell((e.changes || []).map((c) => `${c.label || c.field}: ${JSON.stringify(c.before ?? null)} -> ${JSON.stringify(c.after ?? null)}`).join('; ')),
        ].join(',')
      ),
      '',
      `Total Records,${events.length}`,
    ]
    const blob = new Blob([lines.join('\r\n')], { type: 'text/csv; charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `sakthi-finance-customer-audit-${stamp}.csv`
    document.body.appendChild(a)
    a.click()
    a.remove()
    setTimeout(() => URL.revokeObjectURL(url), 2000)
  }

  return (
    <div className="bg-white rounded-[14px] border border-[rgba(212,175,55,0.2)] shadow-[0_1px_2px_rgba(0,0,0,0.04)] overflow-hidden">
      <div className="px-4 py-3 border-b border-[rgba(212,175,55,0.12)] flex items-center gap-2 flex-wrap">
        <History className="w-4 h-4 text-[var(--primary)]" />
        <h3 className="text-sm font-semibold text-slate-900">Audit History</h3>
        <div className="ml-auto flex items-center gap-1.5">
          <button
            onClick={() => setOrder(order === 'desc' ? 'asc' : 'desc')}
            className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-600 hover:bg-slate-50"
          >
            {order === 'desc' ? 'Newest first' : 'Oldest first'}
          </button>
          <button
            onClick={() => exportReport('csv')}
            className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-600 hover:bg-slate-50 inline-flex items-center gap-1"
          >
            <Download className="w-3 h-3" /> Export
          </button>
        </div>
      </div>
      <div className="p-4">
        {loading ? (
          <p className="text-xs text-slate-500">Loading audit history…</p>
        ) : events.length === 0 ? (
          <p className="text-xs text-slate-500">No audit events recorded for this customer yet. New changes will appear here automatically.</p>
        ) : (
          <ol className="relative border-l-2 border-[rgba(127,29,29,0.15)] ml-1.5 space-y-4">
            {events.map((e) => (
              <li key={e.seq} className="ml-4">
                <span className="absolute -left-[7px] mt-1 w-3 h-3 rounded-full bg-[var(--primary)] border-2 border-white shadow" />
                <p className="text-[13px] font-bold text-slate-900">{e.action.replace(/_/g, ' ')}</p>
                <p className="text-[11px] text-slate-500">
                  {new Date(e.created_at).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })}
                  {' · '}By <b>{e.performed_by || '—'}</b>
                  {e.result !== 'SUCCESS' && <span className="text-red-600 font-bold"> · {e.result}</span>}
                </p>
                {Array.isArray(e.changes) && e.changes.length > 0 && (
                  <div className="mt-1.5 rounded-lg bg-slate-50 border border-slate-100 px-2.5 py-1.5 space-y-0.5">
                    {e.changes.slice(0, 6).map((c, i) => (
                      <p key={i} className="text-[11px] text-slate-600">
                        <span className="font-semibold text-slate-800">{c.label || c.field}:</span>{' '}
                        {fmtHistVal(c.before)} → <b>{fmtHistVal(c.after)}</b>
                      </p>
                    ))}
                    {e.changes.length > 6 && (
                      <p className="text-[11px] text-slate-400">+{e.changes.length - 6} more fields</p>
                    )}
                  </div>
                )}
              </li>
            ))}
          </ol>
        )}
      </div>
    </div>
  )
}
