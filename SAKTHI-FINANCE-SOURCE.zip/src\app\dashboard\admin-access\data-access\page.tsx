'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import DataAccessContent from '@/features/admin-access/DataAccessContent'

export default function DataAccessContentPage() {
  return (
    <ClientPageGate requireRole="owner">
      <DataAccessContent />
    </ClientPageGate>
  )
}
