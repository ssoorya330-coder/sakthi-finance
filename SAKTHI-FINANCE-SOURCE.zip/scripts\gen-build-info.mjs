import { execSync } from 'child_process'
import { writeFileSync, existsSync, mkdirSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const root = join(__dirname, '..')
const outDir = join(root, 'src', 'lib')

let gitHash = 'development'
try {
  gitHash = execSync('git rev-parse --short HEAD', {
    encoding: 'utf8',
    cwd: root,
    stdio: ['ignore', 'pipe', 'ignore'],
  }).trim()
} catch {}

let buildTime = new Date().toISOString()

const info = { buildTime, gitHash }

if (!existsSync(outDir)) mkdirSync(outDir, { recursive: true })
writeFileSync(join(outDir, 'build-info.json'), JSON.stringify(info, null, 2))
console.log(`[build-info] ${JSON.stringify(info)}`)
