import type { NextConfig } from 'next';
import desktopConfig from './next.config.desktop';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  compress: true,
  poweredByHeader: false,
  // Permit the development server to serve HMR and client resources when
  // the app is opened from another device on the local network.
  allowedDevOrigins: process.env.SAKTHI_SERVER_URL ? [new URL(process.env.SAKTHI_SERVER_URL).hostname] : [],
  env: { NEXT_PUBLIC_SAKTHI_SERVER_URL: process.env.SAKTHI_SERVER_URL || '' },
  output: 'standalone',
  outputFileTracingExcludes: {
    '/*': ['./desktop-staging/**/*', './src-tauri/**/*', './__recovery*/**/*', './test-reports/**/*', './.backups/**/*', './.env*'],
  },
  serverExternalPackages: ['pg'],
  images: {
    unoptimized: true,
  },
  compiler: {
    removeConsole: process.env.NODE_ENV === 'production' ? { exclude: ['error', 'warn'] } : false,
  },
  experimental: {
    optimizePackageImports: [
      'lucide-react',
      'framer-motion',
      'recharts',
      'date-fns',
      '@radix-ui/react-checkbox',
      '@radix-ui/react-label',
      '@radix-ui/react-progress',
      '@radix-ui/react-separator',
      '@radix-ui/react-slot',
      '@radix-ui/react-tooltip',
    ],
  },
  async headers() {
    return [
      {
        source: '/wasm/:path*.wasm',
        headers: [
          { key: 'Content-Type', value: 'application/wasm' },
          { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
        ],
      },
      {
        source: '/api/:path*',
        headers: [
          { key: 'Access-Control-Allow-Origin', value: '*' },
          { key: 'Access-Control-Allow-Methods', value: 'GET, POST, PUT, DELETE, OPTIONS' },
          { key: 'Access-Control-Allow-Headers', value: 'Content-Type, Authorization, X-User-Id' },
        ],
      },
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-DNS-Prefetch-Control', value: 'on' },
        ],
      },
    ];
  },
};

export default process.env.SAKTHI_ELECTRON_BUILD === '1' ? desktopConfig : nextConfig;
