import { verify, createHash } from 'node:crypto'
import { readFile, stat, mkdir, mkdtemp, unlink } from 'node:fs/promises'
import { createReadStream, createWriteStream } from 'node:fs'
import { Transform } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import path from 'node:path'
import { spawn } from 'node:child_process'

const PUBLIC_KEY = '-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAp4DYLWitmlQWZmWISSSURXb9fC4y4fSRSxcDZ1jvsXs=\n-----END PUBLIC KEY-----'
export type UpdateRelease = { app: string; version: string; filename: string; size: number; sha256: string; notes: string }
export function newerVersion(next: string, current: string) {
  if (!/^\d{1,6}\.\d{1,6}\.\d{1,6}$/.test(next) || !/^\d{1,6}\.\d{1,6}\.\d{1,6}$/.test(current)) return false
  const a = next.split('.').map(Number), b = current.split('.').map(Number)
  for (let i=0;i<3;i++) if (a[i] !== b[i]) return a[i] > b[i]
  return false
}
export function validateRelease(envelope: unknown, key = PUBLIC_KEY): UpdateRelease {
  const value = envelope as { payload?: string; signature?: string }
  if (typeof value?.payload !== 'string' || value.payload.length > 16000 || typeof value.signature !== 'string' || value.signature.length > 200) throw Error('Invalid update manifest')
  const bytes = Buffer.from(value.payload, 'base64')
  if (!verify(null, bytes, key, Buffer.from(value.signature, 'base64'))) throw Error('Update signature is invalid')
  const release = JSON.parse(bytes.toString('utf8')) as UpdateRelease
  if (release.app !== 'com.sakthifinance.desktop' || !/^\d{1,6}\.\d{1,6}\.\d{1,6}$/.test(release.version) || !/^[a-f0-9]{64}$/.test(release.sha256) || !Number.isSafeInteger(release.size) || release.size < 1 || release.size > 1024*1024*1024 || typeof release.notes !== 'string' || release.notes.length > 4000 || typeof release.filename !== 'string' || !/^[A-Za-z0-9 _.-]+\.exe$/.test(release.filename) || release.filename.includes('..') || path.basename(release.filename) !== release.filename) throw Error('Invalid update details')
  return release
}
async function hash(file: string) { const digest = createHash('sha256'); for await (const chunk of createReadStream(file)) digest.update(chunk); return digest.digest('hex') }
export class DesktopUpdates {
  private release?: UpdateRelease
  private staged?: string
  private busy = false
  private pendingInstall = false
  private progress = 0
  private message = 'Choose an update file from your laptop or USB drive.'
  constructor(private directory: string, private version: string) {}
  status() { return { version: this.version, release: this.release, ready: Boolean(this.staged), busy: this.busy, progress: this.progress, message: this.message } }
  async select(manifest: string) {
    if (this.busy) return this.status()
    this.busy = true; this.progress = 0; this.release = undefined; this.staged = undefined
    let target: string | undefined
    try {
      if ((await stat(manifest)).size > 24000) throw Error('Manifest too large')
      const release = validateRelease(JSON.parse(await readFile(manifest, 'utf8')))
      if (!newerVersion(release.version, this.version)) { this.message = 'This update is the same version or older than your installed app.'; return this.status() }
      const source = path.join(path.dirname(manifest), release.filename)
      if ((await stat(source)).size !== release.size) throw Error('Installer size mismatch')
      const parent = path.join(this.directory, 'updates'); await mkdir(parent, { recursive: true })
      target = path.join(await mkdtemp(path.join(parent, 'verified-')), 'SakthiFinanceUpdate.exe')
      this.message = 'Copying and verifying update. Keep the USB connected…'
      let bytes = 0
      const guard = new Transform({ transform: (chunk, _encoding, callback) => {
        bytes += chunk.length
        this.progress = Math.min(99, Math.floor(bytes / release.size * 100))
        callback(bytes > release.size ? Error('Size mismatch') : null, chunk)
      } })
      await pipeline(createReadStream(source), guard, createWriteStream(target, { flags: 'wx' }))
      if (bytes !== release.size || await hash(target) !== release.sha256) throw Error('Checksum mismatch')
      this.release = release; this.staged = target; this.progress = 100; this.message = 'Update verified. Save your work, then click Install update. The USB is no longer needed.'
    } catch { if (target) await unlink(target).catch(() => {}); this.message = 'Update could not be verified. Keep the original installer and update file together, and try again. Nothing was installed.' }
    finally { this.busy = false }
    return this.status()
  }
  async prepareInstall() {
    if (this.busy || !this.staged || !this.release || await hash(this.staged) !== this.release.sha256) throw Error('Verified update required')
    this.pendingInstall = true
  }
  async launchAfterShutdown() {
    if (!this.pendingInstall || !this.staged || !this.release) return
    if (await hash(this.staged) !== this.release.sha256) throw Error('Update changed')
    const child = spawn(this.staged, [], { detached: true, stdio: 'ignore', windowsHide: true })
    await new Promise<void>((resolve, reject) => { child.once('spawn', resolve); child.once('error', reject) })
    child.unref()
  }
}
