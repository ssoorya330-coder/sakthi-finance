import { NextRequest, NextResponse } from 'next/server';
import { requireOwner } from '@/lib/api-utils';
import {
  getSessionTimeoutMinutes,
  getMaxSessionsPerUser,
  setAppSetting,
  SESSION_TIMEOUT_KEY,
  MAX_SESSIONS_KEY,
} from '@/server/app-settings';
import { actorFromAuthUser, requestMeta, recordAuditStandalone } from '@/server/audit';
import { rateLimit, rateLimitKey } from '@/lib/rate-limit';

export const dynamic = 'force-dynamic';

/**
 * Owner-controlled security settings backed by the existing `settings`
 * table. Both reading and writing require the Owner role explicitly
 * (Admin and Customer get 403).
 *
 * Enforced settings (never inert toggles):
 * - security.session_timeout_minutes (5–480): access-token + cookie expiry
 *   applied at sign-in and at every silent refresh.
 * - security.max_sessions_per_user (1–50): oldest sessions beyond the cap
 *   are revoked at sign-in; viewable/revocable under Device Management.
 */
export async function GET() {
  const auth = await requireOwner();
  if (auth.error) return auth.error;
  const [timeout, maxSessions] = await Promise.all([
    getSessionTimeoutMinutes(),
    getMaxSessionsPerUser(),
  ]);
  return NextResponse.json({
    sessionTimeoutMinutes: timeout,
    maxSessionsPerUser: maxSessions,
    canManage: auth.user.role === 'owner',
  });
}

export async function PUT(request: NextRequest) {
  const auth = await requireOwner();
  if (auth.error) return auth.error;

  if (!rateLimit(rateLimitKey(request, 'admin-security-settings'), 20, 60_000)) {
    return NextResponse.json({ error: 'Too many requests. Please slow down.' }, { status: 429 })
  }

  try {
    const body = await request.json().catch(() => ({}));
    const changes: Array<{ field: string; label: string; before: any; after: any }> = [];
    const result: Record<string, number> = {};

    if (body.sessionTimeoutMinutes !== undefined) {
      const n = Math.floor(Number(body.sessionTimeoutMinutes));
      if (!Number.isFinite(n) || n < 5 || n > 480) {
        return NextResponse.json(
          { error: 'Session timeout must be between 5 and 480 minutes.' },
          { status: 400 }
        );
      }
      const before = await getSessionTimeoutMinutes();
      await setAppSetting(SESSION_TIMEOUT_KEY, String(n));
      result.sessionTimeoutMinutes = n;
      if (before !== n) {
        changes.push({ field: SESSION_TIMEOUT_KEY, label: 'Session Timeout (minutes)', before, after: n });
      }
    }

    if (body.maxSessionsPerUser !== undefined) {
      const n = Math.floor(Number(body.maxSessionsPerUser));
      if (!Number.isFinite(n) || n < 1 || n > 50) {
        return NextResponse.json(
          { error: 'Max sessions per user must be between 1 and 50.' },
          { status: 400 }
        );
      }
      const before = await getMaxSessionsPerUser();
      await setAppSetting(MAX_SESSIONS_KEY, String(n));
      result.maxSessionsPerUser = n;
      if (before !== n) {
        changes.push({ field: MAX_SESSIONS_KEY, label: 'Max Sessions Per User', before, after: n });
      }
    }

    if (changes.length > 0) {
      const meta = requestMeta(request);
      await recordAuditStandalone({
        action: 'SETTINGS_UPDATED',
        entityType: 'settings',
        entityId: 'security',
        actor: actorFromAuthUser(auth.user),
        ipAddress: meta.ip,
        clientInfo: meta.client,
        result: 'SUCCESS',
        changes,
      });
    }

    const [timeout, maxSessions] = await Promise.all([
      getSessionTimeoutMinutes(),
      getMaxSessionsPerUser(),
    ]);
    return NextResponse.json({
      sessionTimeoutMinutes: timeout,
      maxSessionsPerUser: maxSessions,
    });
  } catch (err: any) {
    console.error('[PUT /api/admin/security-settings] Error:', err?.message || err);
    return NextResponse.json({ error: 'Failed to save security settings' }, { status: 500 });
  }
}
