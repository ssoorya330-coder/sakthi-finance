import fs from 'node:fs';
import crypto from 'node:crypto';
import dotenv from 'dotenv';
import pg from 'pg';

// Never print connection values or customer data. Default mode only uses temporary tables.
const inheritedKeys = new Set(Object.keys(process.env));
for (const file of ['.env', '.env.local']) {
  if (fs.existsSync(file)) {
    const config = dotenv.parse(fs.readFileSync(file));
    for (const [key, value] of Object.entries(config)) {
      if (!inheritedKeys.has(key)) process.env[key] = value;
    }
  }
}
const apply = process.argv.includes('--apply');
const client = new pg.Client(process.env.DATABASE_URL ? {
  connectionString: process.env.DATABASE_URL, connectionTimeoutMillis: 5000,
} : {
  host: process.env.DB_HOST || 'localhost', port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_NAME || 'sakthi_finance', user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD, connectionTimeoutMillis: 5000,
});
const tables = ['customers', 'loans', 'payments', 'daily_collection', 'audit_events', 'audit_logs', 'reports'];
const quote = (identifier) => '"' + identifier.replaceAll('"', '""') + '"';
const hash = (rows) => crypto.createHash('sha256').update(JSON.stringify(rows)).digest('hex');

try {
  await client.connect();
  await client.query("SET statement_timeout = '30s'");
  await client.query("SET lock_timeout = '3s'");
  const report = { mode: apply ? 'apply' : 'inspect', tables: [], note: 'Sample measurements exclude application indexes. Existing rows are not rewritten.' };
  for (const table of tables) {
    const identifier = `public.${quote(table)}`;
    const exists = await client.query('SELECT to_regclass($1) AS relation', [identifier]);
    if (!exists.rows[0].relation) continue;
    // One snapshot shared by every candidate, with no persistent copies or data in output.
    await client.query(`CREATE TEMP TABLE sf_storage_sample AS SELECT * FROM ${identifier} LIMIT 2000`);
    const sample = await client.query('SELECT row_to_json(s)::text AS value FROM sf_storage_sample s ORDER BY row_to_json(s)::text');
    const expected = hash(sample.rows);
    const candidates = [];
    for (const target of [2040, 1024, 512]) {
      await client.query(`CREATE TEMP TABLE sf_storage_candidate (LIKE sf_storage_sample) WITH (toast_tuple_target = ${target})`);
      // Decode/re-encode in PostgreSQL so every candidate starts from uncompressed logical values.
      await client.query(`INSERT INTO sf_storage_candidate SELECT (json_populate_record(NULL::sf_storage_candidate, row_to_json(s))).* FROM sf_storage_sample s`);
      const actual = await client.query('SELECT row_to_json(s)::text AS value FROM sf_storage_candidate s ORDER BY row_to_json(s)::text');
      if (hash(actual.rows) !== expected) throw new Error('Round-trip verification failed');
      const size = await client.query("SELECT pg_total_relation_size('sf_storage_candidate')::float8 AS bytes");
      candidates.push({ target, bytes: size.rows[0].bytes });
      await client.query('DROP TABLE sf_storage_candidate');
    }
    const baseline = candidates[0];
    const best = candidates.reduce((a, b) => b.bytes < a.bytes ? b : a);
    const worthwhile = sample.rows.length >= 100 && best.bytes <= baseline.bytes * 0.9;
    const item = { table, sampleRows: sample.rows.length, candidates, roundTripVerified: true, recommendedTarget: worthwhile ? best.target : null, applied: false };
    if (apply && worthwhile) {
      await client.query('BEGIN');
      try {
        // Metadata-only change. Financial values, audit hashes, indexes and queries are untouched.
        await client.query(`ALTER TABLE ${identifier} SET (toast_tuple_target = ${best.target})`);
        await client.query('COMMIT');
        item.applied = true;
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      }
    }
    report.tables.push(item);
    await client.query('DROP TABLE sf_storage_sample');
  }
  if (apply) {
    await client.query('BEGIN');
    try {
      const indexSizes = () => client.query("SELECT coalesce(sum(pg_relation_size(c.oid)),0)::float8 AS bytes FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname IN ('idx_ref_area_name','idx_ref_city_name','idx_ref_business_name','idx_refresh_tokens_hash')");
      const before = (await indexSizes()).rows[0].bytes;
      // Lock the four small tables while verifying complete logical contents.
      const checkedTables = ['ref_area', 'ref_city', 'ref_business', 'refresh_tokens'];
      const fingerprints = [];
      for (const table of checkedTables) {
        await client.query(`LOCK TABLE public.${quote(table)} IN SHARE MODE`);
        // Streaming aggregate in PostgreSQL; do not expose raw records or tokens.
        const digest = await client.query(`SELECT count(*)::text AS count, sum(('x' || substr(md5(row_to_json(t)::text),1,15))::bit(60)::bigint)::text AS checksum FROM public.${quote(table)} t`);
        fingerprints.push(digest.rows);
      }
      await client.query(fs.readFileSync(new URL('../migrations/003_redundant_storage_indexes.sql', import.meta.url), 'utf8'));
      for (const [i, table] of checkedTables.entries()) {
        const digest = await client.query(`SELECT count(*)::text AS count, sum(('x' || substr(md5(row_to_json(t)::text),1,15))::bit(60)::bigint)::text AS checksum FROM public.${quote(table)} t`);
        if (JSON.stringify(digest.rows) !== JSON.stringify(fingerprints[i])) throw new Error('Data verification failed');
      }
      report.redundantIndexBytesRemoved = before - (await indexSizes()).rows[0].bytes;
      report.indexMigrationDataVerified = true;
      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    }
  }
  console.log(JSON.stringify(report, null, 2));
} catch (error) {
  // Errors may contain data/connection details; expose only a safe code.
  console.error(`Storage optimization stopped; no records deleted. Code: ${error.code || 'verification_or_connection_failure'}`);
  process.exitCode = 1;
} finally {
  await client.end();
}
