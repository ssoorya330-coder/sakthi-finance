import * as mod_0 from '../src/app/api/aborted-customers/route.js';
import * as mod_1 from '../src/app/api/admin/access/route.js';
import * as mod_2 from '../src/app/api/admin/activity/route.js';
import * as mod_3 from '../src/app/api/admin/devices/route.js';
import * as mod_4 from '../src/app/api/admin/security/overview/route.js';
import * as mod_5 from '../src/app/api/admin/security-settings/route.js';
import * as mod_6 from '../src/app/api/admin/system-health/route.js';
import * as mod_7 from '../src/app/api/admin/users/route.js';
import * as mod_8 from '../src/app/api/admin/users/[id]/route.js';
import * as mod_9 from '../src/app/api/audit/archive/route.js';
import * as mod_10 from '../src/app/api/audit/cash/route.js';
import * as mod_11 from '../src/app/api/audit/cash/[kind]/[id]/route.js';
import * as mod_12 from '../src/app/api/audit/customer/[customerId]/route.js';
import * as mod_13 from '../src/app/api/audit/export/route.js';
import * as mod_14 from '../src/app/api/audit/financial/export/route.js';
import * as mod_15 from '../src/app/api/audit/financial/route.js';
import * as mod_16 from '../src/app/api/audit/reports-archive/route.js';
import * as mod_17 from '../src/app/api/audit/route.js';
import * as mod_18 from '../src/app/api/audit/summary/route.js';
import * as mod_19 from '../src/app/api/audit/verify/route.js';
import * as mod_20 from '../src/app/api/audit/[id]/route.js';
import * as mod_21 from '../src/app/api/audit-logs/route.js';
import * as mod_22 from '../src/app/api/auth/customer-email/route.js';
import * as mod_23 from '../src/app/api/auth/customer-phone-otp/route.js';
import * as mod_24 from '../src/app/api/auth/google/desktop/route.js';
import * as mod_25 from '../src/app/api/auth/google/route.js';
import * as mod_26 from '../src/app/api/auth/logout/route.js';
import * as mod_27 from '../src/app/api/auth/refresh/route.js';
import * as mod_28 from '../src/app/api/auth/supabase/callback/route.js';
import * as mod_29 from '../src/app/api/auth/supabase/session/route.js';
import * as mod_30 from '../src/app/api/completed-customers/route.js';
import * as mod_31 from '../src/app/api/customer/kanaku/[code]/route.js';
import * as mod_32 from '../src/app/api/customer/link/route.js';
import * as mod_33 from '../src/app/api/customer/me/route.js';
import * as mod_34 from '../src/app/api/customer/route.js';
import * as mod_35 from '../src/app/api/customer/[id]/route.js';
import * as mod_36 from '../src/app/api/customer/[id]/unabort/route.js';
import * as mod_37 from '../src/app/api/customers/route.js';
import * as mod_38 from '../src/app/api/customers/suggest/route.js';
import * as mod_39 from '../src/app/api/daily-collection/route.js';
import * as mod_40 from '../src/app/api/dashboard/deleted-count/route.js';
import * as mod_41 from '../src/app/api/dashboard/route.js';
import * as mod_42 from '../src/app/api/database/backups/route.js';
import * as mod_43 from '../src/app/api/database/export/route.js';
import * as mod_44 from '../src/app/api/database/import/route.js';
import * as mod_45 from '../src/app/api/database/logs/route.js';
import * as mod_46 from '../src/app/api/database/migration/apply-config/route.js';
import * as mod_47 from '../src/app/api/database/migration/complete/route.js';
import * as mod_48 from '../src/app/api/database/migration/copy/cancel/route.js';
import * as mod_49 from '../src/app/api/database/migration/copy/progress/route.js';
import * as mod_50 from '../src/app/api/database/migration/copy/start/route.js';
import * as mod_51 from '../src/app/api/database/migration/elevated/progress/route.js';
import * as mod_52 from '../src/app/api/database/migration/elevated/start/route.js';
import * as mod_53 from '../src/app/api/database/migration/prepare/route.js';
import * as mod_54 from '../src/app/api/database/migration/safety/route.js';
import * as mod_55 from '../src/app/api/database/migration/service/route.js';
import * as mod_56 from '../src/app/api/database/migration/status/route.js';
import * as mod_57 from '../src/app/api/database/migration/verify/route.js';
import * as mod_58 from '../src/app/api/database/migration/verify-backup/route.js';
import * as mod_59 from '../src/app/api/database/migration/verify-copy/route.js';
import * as mod_60 from '../src/app/api/database/restore/route.js';
import * as mod_61 from '../src/app/api/database/status/route.js';
import * as mod_62 from '../src/app/api/database/storage/route.js';
import * as mod_63 from '../src/app/api/database/system/route.js';
import * as mod_64 from '../src/app/api/database/tables/route.js';
import * as mod_65 from '../src/app/api/desktop/ready/route.js';
import * as mod_66 from '../src/app/api/device-sync/activity/route.js';
import * as mod_67 from '../src/app/api/device-sync/assets/route.js';
import * as mod_68 from '../src/app/api/device-sync/connection/route.js';
import * as mod_69 from '../src/app/api/device-sync/route.js';
import * as mod_70 from '../src/app/api/device-sync/snapshot/route.js';
import * as mod_71 from '../src/app/api/kanaku-trash/route.js';
import * as mod_72 from '../src/app/api/loan/route.js';
import * as mod_73 from '../src/app/api/loan/[id]/route.js';
import * as mod_74 from '../src/app/api/loans/route.js';
import * as mod_75 from '../src/app/api/notifications/route.js';
import * as mod_76 from '../src/app/api/notifications/stream/route.js';
import * as mod_77 from '../src/app/api/payment/route.js';
import * as mod_78 from '../src/app/api/payment/[id]/route.js';
import * as mod_79 from '../src/app/api/payments/route.js';
import * as mod_80 from '../src/app/api/reports/workbook/route.js';
import * as mod_81 from '../src/app/api/reports/[type]/route.js';
import * as mod_82 from '../src/app/api/search/route.js';
import * as mod_83 from '../src/app/api/settings/cash-threshold/route.js';
import * as mod_84 from '../src/app/api/storage/route.js';
import * as mod_85 from '../src/app/api/storage/validate/route.js';
import * as mod_86 from '../src/app/api/storage/[id]/route.js';
import * as mod_87 from '../src/app/api/system/drives/route.js';

export default {
  '/aborted-customers': mod_0,
  '/admin/access': mod_1,
  '/admin/activity': mod_2,
  '/admin/devices': mod_3,
  '/admin/security/overview': mod_4,
  '/admin/security-settings': mod_5,
  '/admin/system-health': mod_6,
  '/admin/users': mod_7,
  '/admin/users/[id]': mod_8,
  '/audit/archive': mod_9,
  '/audit/cash': mod_10,
  '/audit/cash/[kind]/[id]': mod_11,
  '/audit/customer/[customerId]': mod_12,
  '/audit/export': mod_13,
  '/audit/financial/export': mod_14,
  '/audit/financial': mod_15,
  '/audit/reports-archive': mod_16,
  '/audit': mod_17,
  '/audit/summary': mod_18,
  '/audit/verify': mod_19,
  '/audit/[id]': mod_20,
  '/audit-logs': mod_21,
  '/auth/customer-email': mod_22,
  '/auth/customer-phone-otp': mod_23,
  '/auth/google/desktop': mod_24,
  '/auth/google': mod_25,
  '/auth/logout': mod_26,
  '/auth/refresh': mod_27,
  '/auth/supabase/callback': mod_28,
  '/auth/supabase/session': mod_29,
  '/completed-customers': mod_30,
  '/customer/kanaku/[code]': mod_31,
  '/customer/link': mod_32,
  '/customer/me': mod_33,
  '/customer': mod_34,
  '/customer/[id]': mod_35,
  '/customer/[id]/unabort': mod_36,
  '/customers': mod_37,
  '/customers/suggest': mod_38,
  '/daily-collection': mod_39,
  '/dashboard/deleted-count': mod_40,
  '/dashboard': mod_41,
  '/database/backups': mod_42,
  '/database/export': mod_43,
  '/database/import': mod_44,
  '/database/logs': mod_45,
  '/database/migration/apply-config': mod_46,
  '/database/migration/complete': mod_47,
  '/database/migration/copy/cancel': mod_48,
  '/database/migration/copy/progress': mod_49,
  '/database/migration/copy/start': mod_50,
  '/database/migration/elevated/progress': mod_51,
  '/database/migration/elevated/start': mod_52,
  '/database/migration/prepare': mod_53,
  '/database/migration/safety': mod_54,
  '/database/migration/service': mod_55,
  '/database/migration/status': mod_56,
  '/database/migration/verify': mod_57,
  '/database/migration/verify-backup': mod_58,
  '/database/migration/verify-copy': mod_59,
  '/database/restore': mod_60,
  '/database/status': mod_61,
  '/database/storage': mod_62,
  '/database/system': mod_63,
  '/database/tables': mod_64,
  '/desktop/ready': mod_65,
  '/device-sync/activity': mod_66,
  '/device-sync/assets': mod_67,
  '/device-sync/connection': mod_68,
  '/device-sync': mod_69,
  '/device-sync/snapshot': mod_70,
  '/kanaku-trash': mod_71,
  '/loan': mod_72,
  '/loan/[id]': mod_73,
  '/loans': mod_74,
  '/notifications': mod_75,
  '/notifications/stream': mod_76,
  '/payment': mod_77,
  '/payment/[id]': mod_78,
  '/payments': mod_79,
  '/reports/workbook': mod_80,
  '/reports/[type]': mod_81,
  '/search': mod_82,
  '/settings/cash-threshold': mod_83,
  '/storage': mod_84,
  '/storage/validate': mod_85,
  '/storage/[id]': mod_86,
  '/system/drives': mod_87,
}
