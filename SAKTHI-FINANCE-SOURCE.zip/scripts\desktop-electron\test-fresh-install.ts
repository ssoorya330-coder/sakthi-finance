import path from 'node:path'
import { mkdir, readFile, writeFile, access } from 'node:fs/promises'
import assert from 'node:assert/strict'
import { Client } from 'pg'
import { provisionNewDatabase, startManagedDatabase, stopManagedDatabase } from '../../electron/managed-postgres'

async function main() {
  const root = path.resolve('test-reports', 'fresh-install-' + Date.now())
  const native = path.resolve('dist-electron/native')
  const settings = path.join(root, 'settings')
  await mkdir(root, { recursive: true })
  const checks: { test: string; status: string }[] = []
  const passed = (test: string) => checks.push({ test, status: 'PASS' })
  // No real finance credentials are used. dotenv must not read the project .env.
  process.chdir(root)
  let meta: Awaited<ReturnType<typeof provisionNewDatabase>> | null = null
  const options = { selectedFolder: root, settingsDirectory: settings, nativeDirectory: native,
    oauth: { clientId: 'qa-only.apps.googleusercontent.com', clientSecret: 'qa-only-not-real' },
    initialize: async (config: Record<string, string>) => {
      delete process.env.DATABASE_URL
      Object.assign(process.env, config)
      const db = await import('../../src/server/database')
      try { await db.ensureSchema() } finally { await db.closePool() }
    },
  }
  try {
    meta = await provisionNewDatabase(options)
    passed('Bundled PostgreSQL initializes a separate empty database with existing application schema')
    const config = JSON.parse(await readFile(path.join(settings, 'runtime.json'), 'utf8'))
    const connection = { host: config.DB_HOST, port: Number(config.DB_PORT), database: config.DB_NAME, user: config.DB_USER, password: config.DB_PASSWORD }
    const client = new Client(connection)
    await client.connect()
    try {
      assert.equal((await client.query('SHOW listen_addresses')).rows[0].listen_addresses, '127.0.0.1')
      assert.equal((await client.query('SHOW password_encryption')).rows[0].password_encryption, 'scram-sha-256')
      passed('Database listens on loopback only and uses SCRAM password encryption')
      for (const table of ['customers', 'loans', 'payments']) assert.equal(Number((await client.query(`SELECT COUNT(*) AS n FROM ${table}`)).rows[0].n), 0)
      passed('No existing customers, loans or payments copied into new database')
      await client.query('CREATE TABLE qa_persistence (id integer PRIMARY KEY, amount numeric(12,2))')
      await client.query('INSERT INTO qa_persistence VALUES (1,500.25)')
    } finally { await client.end() }
    assert.notEqual(config.JWT_ACCESS_SECRET, config.JWT_REFRESH_SECRET)
    assert.ok(config.DB_PASSWORD.length >= 32)
    passed('Per-installation random password and distinct session keys generated')
    await assert.rejects(provisionNewDatabase(options), /already has settings/)
    await assert.rejects(provisionNewDatabase({ ...options, settingsDirectory: path.join(root, 'other-settings') }), /already exists/)
    passed('Existing settings and storage folders cannot be overwritten by setup')
    await stopManagedDatabase(native, meta)
    await startManagedDatabase(settings, native, config)
    const restarted = new Client(connection)
    await restarted.connect()
    try { assert.equal((await restarted.query('SELECT amount FROM qa_persistence WHERE id=1')).rows[0].amount, '500.25') }
    finally { await restarted.end() }
    passed('Managed database restarts with identical identity and preserved records')
    const missingSettings = path.join(root, 'missing-drive-settings')
    await mkdir(missingSettings)
    const missingRoot = path.join(root, 'not-connected')
    await writeFile(path.join(missingSettings, 'managed-postgres.json'), JSON.stringify({ ...meta, dataRoot: missingRoot, dataDirectory: path.join(missingRoot, 'postgres-data') }))
    await assert.rejects(startManagedDatabase(missingSettings, native, config), /Storage offline/)
    await assert.rejects(access(missingRoot))
    passed('Missing configured storage fails closed without creating replacement data')
    const mismatchSettings = path.join(root, 'mismatch-settings')
    await mkdir(mismatchSettings)
    await writeFile(path.join(mismatchSettings, 'managed-postgres.json'), JSON.stringify({ ...meta, systemIdentifier: 'wrong-identity' }))
    await assert.rejects(startManagedDatabase(mismatchSettings, native, config), /identity mismatch/)
    passed('Wrong database identity is rejected')
  } catch (error) {
    checks.push({ test: 'Fresh installation integration', status: 'FAIL' })
    // No connection strings or generated secrets are printed.
    console.error(error instanceof Error ? error.name + ': ' + error.message.replace(/password[^\s]*/gi, '[redacted]') : 'Test failed')
    process.exitCode = 1
  } finally {
    await stopManagedDatabase(native, meta).catch(() => {})
    await writeFile(path.join(root, '..', 'FRESH_INSTALL_TEST.json'), JSON.stringify({ date: new Date().toISOString(), retainedTestFolder: root, checks }, null, 2))
    console.log(JSON.stringify(checks))
  }
}
void main()
