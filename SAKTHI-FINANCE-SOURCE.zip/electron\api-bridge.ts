/**
 * Main-process API bridge.
 *
 * Delegates to the worker bundle (dist-electron/api/routes.js) which contains
 * the route handlers AND the dispatcher in one module graph — so the per-call
 * session token set there is visible to the shared supabase-auth module.
 * This file only resolves the desktop session and forwards the call.
 */

export interface ApiCall {
  path: string
  method?: string
  body?: unknown
  query?: Record<string, string | number | boolean | undefined>
}

export interface ApiResult {
  status: number
  ok: boolean
  data: unknown
  binary?: { base64: string; mimeType: string; fileName?: string }
}

interface WorkerModule {
  callApi: (token: string | null, call: ApiCall) => Promise<ApiResult>
  callTablet: (token: string | null, action: string, body: Record<string, unknown>) => Promise<ApiResult>
}

export async function callTablet(sessionId: number | null, action: string, body: Record<string, unknown> = {}): Promise<ApiResult> {
  const {resolveSessionIdentity,currentAccessToken} = await import('./session')
  if(sessionId===null || !await resolveSessionIdentity(sessionId)) return {status:401,ok:false,data:{error:'Not signed in'}}
  return worker.callTablet(currentAccessToken(sessionId),action,body)
}

// The worker bundle is built separately and must not be merged into main.js.
// eslint-disable-next-line @typescript-eslint/no-var-requires
const worker: WorkerModule = require('./api/routes.js')

export async function callApi(sessionId: number | null, call: ApiCall): Promise<ApiResult> {
  if (sessionId === null) {
    return { status: 401, ok: false, data: { error: 'Not signed in' } }
  }
  const { resolveSessionIdentity, currentAccessToken } = await import('./session')
  const user = await resolveSessionIdentity(sessionId)
  if (!user) return { status: 401, ok: false, data: { error: 'Not signed in' } }
  const token = currentAccessToken(sessionId)
  return worker.callApi(token, call)
}
