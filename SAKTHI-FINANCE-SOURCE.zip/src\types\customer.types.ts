export interface Customer {
  id: string
  customerCode: string
  offlinePaidAmount?: number
  fullName: string
  mobileNumber: string
  alternateMobile: string
  address: string
  areaId: number | null
  areaName: string
  cityName: string
  businessName: string
  monthlyIncome: string
  status: 'Active' | 'Completed' | 'Overdue' | 'Aborted'
  createdAt: string
  updatedAt: string
  // Loan fields (populated from JOIN with loans table)
  loanId?: string
  loanCount?: number
  cycleNumber?: number
  kanakuNumber?: number
  kanakuSchedules?: Pick<Customer, 'loanDate' | 'dueDate' | 'loanType' | 'duration'>[]
  loanDate?: string
  dueDate?: string
  loanAmount?: string
  interestRate?: string
  interestAmount?: string
  totalAmount?: number
  installmentAmount?: number
  remainingDays?: number
  duration?: string
  loanType?: 'Daily' | 'Weekly' | 'Monthly' | 'Yearly'
  completedAt?: string
  abortedAt?: string
  abortReason?: string
  loanNotes?: string
  disbursalMode?: 'Cash' | 'Bank'
  // Legacy aliases for backward compatibility
  area?: string
  city?: string
  occupation?: string
}

export interface Loan {
  loanId: string
  customerId: string
  loanDate: string
  dueDate: string
  loanAmount: string
  interestRate: string
  interestAmount: string
  totalAmount: string
  installmentAmount: string
  remainingDays: number
  duration: string
  loanType: 'Daily' | 'Weekly' | 'Monthly' | 'Yearly'
  status: 'Active' | 'Completed' | 'Overdue' | 'Aborted'
  completedAt?: string
  abortedAt?: string
  abortReason?: string
  notes: string
  createdAt: string
  updatedAt: string
}

export interface PaymentRecord {
  id: string
  customerId: string
  paymentAmount: number
  paymentDate: string
  paymentTime: string
  paymentMethod: 'Cash' | 'PhonePe' | 'UPI' | 'Bank Transfer' | 'Cheque' | 'Other'
  remainingBalance: number
  remarks: string
  collectedBy: string
  createdAt: string
}
