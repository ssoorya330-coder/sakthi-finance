import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createGzip } from 'node:zlib';
import { NextRequest, NextResponse } from 'next/server';
import { requireAuthWithPermission } from '@/lib/api-utils';
import { ensureSchema, getPool } from '@/server/database';
import { buildAuditWhere, auditOrderBy, readFilters } from '@/server/audit-query';
import { auditArchiveJson } from '@/server/audit-archive';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('audit:read');
  if (auth.error) return auth.error;
  const filters = readFilters(request.nextUrl.searchParams);
  const params: unknown[] = [];
  const { clause } = buildAuditWhere(filters, params, 1);
  await ensureSchema();
  // Acquisition/startup stays inside the generator: cancellation releases the client.
  async function* records() {
    const client = await getPool().connect();
    try {
      await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
      await client.query("SET LOCAL statement_timeout = '60s'");
      await client.query(`DECLARE sf_audit_archive NO SCROLL CURSOR FOR
        SELECT row_to_json(a)::text AS record FROM
        (SELECT * FROM audit_events WHERE 1=1${clause} ${auditOrderBy(filters.sort, filters.dir)}) a`, params);
      for (;;) {
        const batch = await client.query('FETCH FORWARD 500 FROM sf_audit_archive');
        if (!batch.rows.length) break;
        for (const row of batch.rows) yield row.record as string;
      }
      await client.query('COMMIT');
    } finally {
      // Also runs on a disconnected download or query failure.
      try { await client.query('ROLLBACK'); } finally { client.release(); }
    }
  }
  const input = Readable.from(auditArchiveJson(records(), {
    generatedAt: new Date().toISOString(), generatedBy: auth.user.email, filters,
    scope: 'matching audit_events; every column; consistent database snapshot',
    integrityNote: 'Archive checksum preserves content. Use Audit Verify for the existing hash chain; filtered archives may omit chain links.',
  }));
  const gzip = createGzip({ level: 9 });
  // pipeline propagates cancellation/errors in both directions; an incomplete
  // transfer is an invalid gzip archive, never a successful truncated export.
  void pipeline(input, gzip).catch(() => {});
  return new NextResponse(Readable.toWeb(gzip) as ReadableStream<Uint8Array>, {
    headers: {
      'Content-Type': 'application/gzip',
      'Content-Disposition': `attachment; filename="sakthi-finance-audit-${new Date().toISOString().slice(0, 10)}.json.gz"`,
      'Cache-Control': 'private, no-store',
      'X-Content-Type-Options': 'nosniff',
    },
  });
}
