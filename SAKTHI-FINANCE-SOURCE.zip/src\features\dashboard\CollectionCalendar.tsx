'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { ChevronLeft, ChevronRight, CalendarDays } from 'lucide-react'
import { cn } from '@/lib/utils'
import WidgetCard from './WidgetCard'
import { useCustomerStore } from '@/store/customer-store'
import { formatINR } from '@/lib/dashboard-utils'

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const HIGH_THRESHOLD = 10000
const MEDIUM_THRESHOLD = 4000

type Level = 'high' | 'medium' | 'low' | 'none'

const LEVEL_META: Record<Level, { color: string; label: string }> = {
  high: { color: '#10B981', label: 'High Collection' },
  medium: { color: 'var(--secondary)', label: 'Medium Collection' },
  low: { color: 'var(--primary)', label: 'Low Collection' },
  none: { color: '#E2E8F0', label: 'No Collection' },
}

function levelFor(amount: number): Level {
  if (amount >= HIGH_THRESHOLD) return 'high'
  if (amount >= MEDIUM_THRESHOLD) return 'medium'
  if (amount > 0) return 'low'
  return 'none'
}

function localDayStr(y: number, m: number, d: number): string {
  return `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`
}

export default function CollectionCalendar() {
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)

  const now = new Date()
  const [viewDate, setViewDate] = useState(() => new Date(now.getFullYear(), now.getMonth(), 1))
  const [selectedDay, setSelectedDay] = useState(() => localDayStr(now.getFullYear(), now.getMonth(), now.getDate()))

  const todayStr = localDayStr(now.getFullYear(), now.getMonth(), now.getDate())

  const dailyTotals = useMemo(() => {
    const map: Record<string, number> = {}
    for (const p of paymentHistory) {
      const d = (p.paymentDate || '').slice(0, 10)
      if (d) map[d] = (map[d] || 0) + (p.paymentAmount || 0)
    }
    return map
  }, [paymentHistory])

  const cells = useMemo(() => {
    const y = viewDate.getFullYear()
    const m = viewDate.getMonth()
    const firstDay = new Date(y, m, 1).getDay()
    const daysInMonth = new Date(y, m + 1, 0).getDate()
    const arr: { day: number | null; key: string; amount: number }[] = []
    for (let i = 0; i < firstDay; i++) arr.push({ day: null, key: `pad-${i}`, amount: 0 })
    for (let d = 1; d <= daysInMonth; d++) {
      const key = localDayStr(y, m, d)
      arr.push({ day: d, key, amount: dailyTotals[key] || 0 })
    }
    while (arr.length < 42) arr.push({ day: null, key: `pad-${arr.length}`, amount: 0 })
    return arr
  }, [viewDate, dailyTotals])

  const monthLabel = viewDate.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })
  const selectedAmount = selectedDay ? dailyTotals[selectedDay] || 0 : 0

  const goPrev = () => setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1))
  const goNext = () => setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1))

  return (
    <WidgetCard
      icon={CalendarDays}
      title="Collection Calendar"
      subtitle="Daily collection status"
      action={
        <div className="flex items-center gap-1.5">
          <button
            onClick={goPrev}
            className="w-8 h-8 rounded-[10px] border border-slate-200 bg-white flex items-center justify-center text-slate-500 hover:text-[var(--primary)] hover:border-[var(--secondary)] hover:bg-[var(--surface-secondary)] transition-all duration-200 active:scale-95"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-sm font-semibold text-slate-800 min-w-[130px] text-center">{monthLabel}</span>
          <button
            onClick={goNext}
            className="w-8 h-8 rounded-[10px] border border-slate-200 bg-white flex items-center justify-center text-slate-500 hover:text-[var(--primary)] hover:border-[var(--secondary)] hover:bg-[var(--surface-secondary)] transition-all duration-200 active:scale-95"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      }
    >
      <div className="grid grid-cols-7 gap-1 mb-1.5">
        {WEEKDAYS.map((wd) => (
          <div key={wd} className="text-center text-[10px] font-semibold text-slate-400 uppercase tracking-wider py-1">
            {wd}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1">
        {cells.map((cell, i) => {
          if (cell.day === null) {
            return <div key={cell.key} className="h-9 sm:h-10 rounded-[10px]" />
          }
          const lvl = levelFor(cell.amount)
          const isSelected = cell.key === selectedDay
          const isToday = cell.key === todayStr
          return (
            <motion.button
              key={cell.key}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.25, delay: i * 0.008, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ scale: 1.05, zIndex: 5 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedDay(cell.key)}
              className={cn(
                'h-9 sm:h-10 rounded-[10px] flex flex-col items-center justify-center gap-1 transition-all duration-200 cursor-pointer',
                isSelected
                  ? 'bg-gradient-to-br from-[#E6C55A] to-[var(--secondary)] border-2 border-[var(--primary)] shadow-[0_4px_16px_rgba(212,175,55,0.45)]'
                  : 'bg-slate-50 hover:bg-white hover:shadow-[0_4px_14px_rgba(212,175,55,0.35)] border border-transparent hover:border-[var(--secondary)]'
              )}
            >
              <span
                className={cn(
                  'text-xs font-semibold leading-none',
                  isSelected ? 'text-[var(--primary)]' : isToday ? 'text-[var(--primary)]' : 'text-[var(--text-primary)]'
                )}
              >
                {cell.day}
              </span>
              <span
                className={cn('w-2 h-2 rounded-full', lvl === 'none' && 'bg-[#E2E8F0]')}
                style={lvl !== 'none' ? { backgroundColor: LEVEL_META[lvl].color, boxShadow: `0 0 6px ${LEVEL_META[lvl].color}66` } : undefined}
              />
            </motion.button>
          )
        })}
      </div>

      <div className="mt-2 pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-3">
          {(['high', 'medium', 'low'] as Level[]).map((lvl) => (
            <div key={lvl} className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: LEVEL_META[lvl].color }} />
              <span className="text-[11px] font-medium text-slate-500">{LEVEL_META[lvl].label}</span>
            </div>
          ))}
        </div>
        {selectedAmount > 0 && (
          <span className="text-xs font-semibold text-[var(--text-primary)]">
            Selected day: <span className="text-[var(--primary)]">{formatINR(Math.round(selectedAmount))}</span>
          </span>
        )}
      </div>
    </WidgetCard>
  )
}
