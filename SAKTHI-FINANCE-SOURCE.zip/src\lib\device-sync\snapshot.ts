import type { SyncSnapshot, SyncWorkspace } from './types'

export function validateSnapshot(snapshot: SyncSnapshot, user: string) {
  if(snapshot.userId!==user||!Array.isArray(snapshot.customers)||!Array.isArray(snapshot.loans)||!Array.isArray(snapshot.payments)||!snapshot.revisions||!Number.isFinite(Date.parse(snapshot.capturedAt)))throw new Error('Invalid offline snapshot. Previous data retained.')
  if(snapshot.schemaVersion!==2||snapshot.customerCount!==snapshot.customers.length||snapshot.loanCount!==snapshot.loans.length)throw new Error('Incomplete snapshot. Previous data retained.')
  const ids=new Set(snapshot.customers.map(c=>String(c.id)))
  if(ids.size!==snapshot.customers.length||new Set(snapshot.loans.map(l=>String(l.loan_id))).size!==snapshot.loans.length)throw new Error('Duplicate snapshot IDs.')
  for(const c of snapshot.customers)if(!c.id||!snapshot.revisions[String(c.id)])throw new Error('Snapshot revision missing.')
  for(const l of snapshot.loans)if(!ids.has(String(l.customer_id))||!l.loan_id||!Number.isFinite(Number(l.outstanding))||Number(l.outstanding)<0||!Number.isFinite(Number(l.paid_amount)))throw new Error('Invalid snapshot loan.')
}

/** Called within the same durable local transaction as replacement. */
export function activateSnapshot(w: SyncWorkspace, snapshot: SyncSnapshot) {
  validateSnapshot(snapshot,w.snapshot.userId)
  // A user can save new entries while the network snapshot is in flight. Keep
  // their original revisions: edits made elsewhere must still cause conflicts.
  w.snapshot=snapshot
  w.queue=w.queue.filter(op=>op.status!=='SYNCED')
  w.lastSync=snapshot.capturedAt
  w.history=w.history.slice(0,50)
}
