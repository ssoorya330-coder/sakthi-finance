'use client'
import { useEffect, useMemo, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useVoiceInput } from '@/hooks/use-voice-input'
import { parseVoiceCommand, suggestCustomerNames, type VoiceIntent } from '@/lib/voice-commands'
import { useCustomerStore } from '@/store/customer-store'

/** Voice prepares navigation/review only. It never calls a financial mutation. */
export default function VoiceCommandPanel() {
  const [open, setOpen] = useState(false)
  const [text, setText] = useState('')
  const [intent, setIntent] = useState<VoiceIntent>({ type: 'unknown' })
  const closeButton = useRef<HTMLButtonElement>(null)
  const router = useRouter()
  const customers = useCustomerStore(s=>s.customers)
  const suggestions=useMemo(()=>intent.type==='search' || intent.type==='payment'
    ? suggestCustomerNames(intent.name,customers.slice(0,1000).map(c=>c.fullName)) : [],[intent,customers])
  const voice = useVoiceInput(final => { setText(final); setIntent(parseVoiceCommand(final)) })
  useEffect(() => {
    const show = () => { setOpen(true); setText(''); setIntent({type:'unknown'}) }
    window.addEventListener('sakthi:voice-command', show)
    return () => window.removeEventListener('sakthi:voice-command', show)
  }, [])
  useEffect(() => { if (open) closeButton.current?.focus() }, [open])
  if (!open) return null
  function close() { voice.stop(); setOpen(false) }
  function proceed() {
    if (intent.type === 'unknown') return
    // Customer selection, Kanaku, amount entry, permissions and Save All remain
    // the existing workflow. A spoken amount is NEVER silently submitted.
    const path = intent.type === 'navigate' ? intent.path : `/dashboard/customers?q=${encodeURIComponent(intent.name)}`
    router.push(path); close()
  }
  return <div className="fixed inset-0 z-[var(--z-modal)] grid place-items-center bg-black/30 p-4" onKeyDown={e => {
    if (e.key === 'Escape') close()
    if (e.key === 'Tab') {
      const controls = [...e.currentTarget.querySelectorAll<HTMLElement>('button:not(:disabled),input')]
      const first=controls[0],last=controls[controls.length-1]
      if (e.shiftKey && document.activeElement===first) { e.preventDefault(); last?.focus() }
      else if (!e.shiftKey && document.activeElement===last) { e.preventDefault(); first?.focus() }
    }
  }}>
    <section role="dialog" aria-modal="true" aria-labelledby="voice-command-title" className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-xl">
      <div className="flex justify-between"><h2 id="voice-command-title" className="font-bold">Voice commands</h2><button ref={closeButton} onClick={close}>Close</button></div>
      <p className="my-3 text-sm text-slate-600">Say “Open dashboard”, “Search Ramesh” or “Receive five thousand from Ramesh”. Review before continuing.</p>
      <button onClick={voice.toggle} disabled={!voice.isSupported || voice.status === 'processing'} className="rounded-lg bg-[var(--primary)] px-4 py-2 text-white">{voice.status === 'idle' ? 'Start listening' : voice.status === 'processing' ? 'Processing…' : 'Stop listening'}</button>
      <p role="status" className="my-3 min-h-6 text-sm">{voice.error || voice.interimTranscript || voice.feedback}</p>
      <label className="block text-sm" htmlFor="voice-command-text">Review or correct what was heard</label>
      <input id="voice-command-text" className="my-2 w-full rounded-lg border p-3" value={text} onChange={e => { setText(e.target.value); setIntent(parseVoiceCommand(e.target.value)) }} />
      {intent.type === 'payment' && <p className="my-3 text-sm">Review: {intent.name} · ₹{intent.amount.toLocaleString('en-IN')}. Continue to select the correct customer and Kanaku, then enter this amount and use Save All. Nothing has been saved.</p>}
      {suggestions.length>0 && <div className="my-3"><p className="text-sm text-slate-600">Possible local matches — choose only if correct:</p><div className="mt-2 flex flex-wrap gap-2">{suggestions.map(name=><button key={name} type="button" className="rounded-lg border px-3 py-2 text-sm" onClick={()=>setIntent(previous=>previous.type==='payment'||previous.type==='search'?{...previous,name}:previous)}>{name}</button>)}</div></div>}
      {intent.type === 'unknown' && text && <p className="text-sm text-amber-800">Command unclear. Please correct it or try again.</p>}
      <button disabled={intent.type === 'unknown' || voice.status !== 'idle'} onClick={proceed} className="mt-3 rounded-lg bg-[var(--primary)] px-4 py-2 text-white disabled:opacity-40">{intent.type === 'payment' ? 'Review in existing payment screen' : 'Continue'}</button>
    </section>
  </div>
}
