import fs from 'fs'
import os from 'os'
import path from 'path'
import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { runPgRestore } from '@/server/storage'
import { actorFromAuthUser, requestMeta, recordAuditStandalone } from '@/server/audit'

export const dynamic = 'force-dynamic'

const MAX_UPLOAD_BYTES = 512 * 1024 * 1024

/**
 * Import a previously exported local backup (.dump custom format or .sql).
 * Restores it into LOCAL PostgreSQL. Overwrites current data — the UI must
 * confirm before calling. Nothing is uploaded anywhere.
 */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  let tmpFile: string | null = null
  try {
    const form = await request.formData()
    const file = form.get('file') as File | null
    const confirmed = form.get('confirmed') === 'true'
    if (!file) return NextResponse.json({ error: 'Backup file is required.' }, { status: 400 })
    if (!confirmed) {
      return NextResponse.json(
        { error: 'Import must be explicitly confirmed. This overwrites current data.' },
        { status: 400 }
      )
    }
    if (!/\.(dump|sql|backup)$/i.test(file.name)) {
      return NextResponse.json({ error: 'Invalid backup file. Use a .dump or .sql backup.' }, { status: 400 })
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      return NextResponse.json({ error: 'File is too large (max 512 MB).' }, { status: 400 })
    }
    tmpFile = path.join(os.tmpdir(), `sf-import-${Date.now()}-${Math.random().toString(36).slice(2, 8)}${path.extname(file.name) || '.dump'}`)
    const buf = Buffer.from(await file.arrayBuffer())
    fs.writeFileSync(tmpFile, buf)

    await runPgRestore(tmpFile)
    await dbQuery(
      "INSERT INTO audit_logs (action, entity_type, entity_id, details, user_id) VALUES ('import', 'database', $1, $2, $3)",
      ['upload', JSON.stringify({ filename: file.name, size: file.size }), auth.user.userId]
    ).catch(() => {})
    {
      const meta = requestMeta(request)
      await recordAuditStandalone({
        action: 'DATA_IMPORTED',
        entityType: 'database',
        entityId: 'sakthi_finance',
        actor: actorFromAuthUser(auth.user),
        ipAddress: meta.ip,
        clientInfo: meta.client,
        reason: 'Database imported from backup file (overwrites current data)',
        result: 'SUCCESS',
        changes: [
          { field: 'filename', label: 'Imported File', before: null, after: file.name },
          { field: 'size', label: 'Size (bytes)', before: null, after: file.size },
        ],
      })
    }
    return NextResponse.json({ success: true })
  } catch (err: any) {
    const message = err?.message || 'Import failed.'
    const status = /not found on this computer/i.test(message) ? 503 : 500
    return NextResponse.json({ error: message }, { status })
  } finally {
    if (tmpFile) {
      try {
        fs.unlinkSync(tmpFile)
      } catch {}
    }
  }
}
