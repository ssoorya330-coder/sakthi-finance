'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { HandCoins, ArrowRight, Users, Wallet, Hourglass } from 'lucide-react'
import WidgetCard from './WidgetCard'
import { useCustomerStore } from '@/store/customer-store'
import { formatINR } from '@/lib/dashboard-utils'
import { getTodayCollection } from './dashboard-data'

function useCountUp(target: number, duration = 900): number {
  const [value, setValue] = useState(target)
  const fromRef = useRef(target)

  useEffect(() => {
    const from = fromRef.current
    if (from === target) {
      setValue(target)
      return
    }
    let raf = 0
    const start = performance.now()
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration)
      const eased = 1 - Math.pow(1 - t, 3)
      const next = from + (target - from) * eased
      setValue(next)
      if (t < 1) {
        raf = requestAnimationFrame(tick)
      } else {
        fromRef.current = target
      }
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [target, duration])

  return value
}

export default function TodayCollection() {
  const customers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)

  const data = useMemo(() => {
    const today = new Date().toISOString().split('T')[0]
    const paidToday = paymentHistory.filter((p) => (p.paymentDate || '').startsWith(today))
    const collected = paidToday.reduce((s, p) => s + (p.paymentAmount || 0), 0)
    const paidTodayIds = new Set(paidToday.map((p) => p.customerId))

    const active = customers.filter((c) => c.status === 'Active' || c.status === 'Overdue')
    const expected = active.reduce((s, c) => s + (Number(c.installmentAmount) || 0), 0)

    const completionPct = expected > 0
      ? Math.min(100, (collected / expected) * 100)
      : collected > 0
        ? 100
        : 0

    const pending = Math.max(0, expected - collected)
    const paidActive = active.filter((c) => paidTodayIds.has(c.id)).length
    const remainingCustomers = Math.max(0, active.length - paidActive)

    return { collected, expected, pending, completionPct, remainingCustomers, activeCount: active.length }
  }, [customers, paymentHistory])

  const animatedCollected = useCountUp(data.collected)
  const animatedPending = useCountUp(data.pending)
  const animatedCompletion = useCountUp(data.completionPct)
  const animatedRemaining = useCountUp(data.remainingCustomers)

  const r = 54
  const c = 2 * Math.PI * r
  const pct = Math.min(100, Math.max(0, data.completionPct))

  return (
    <WidgetCard
      icon={HandCoins}
      title="Today's Collection"
      subtitle={`${data.activeCount} active loans · ${data.expected > 0 ? formatINR(Math.round(data.expected)) : '—'} expected`}
      action={
        <button className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-600 hover:text-[var(--primary)] hover:border-[var(--secondary)] hover:bg-[var(--surface-secondary)] transition-all duration-300 active:scale-95">
          View All
          <ArrowRight className="w-3 h-3" />
        </button>
      }
    >
      <div className="flex items-center gap-5">
        <div className="relative w-[136px] h-[136px] flex-shrink-0">
          <svg width="136" height="136" viewBox="0 0 136 136">
            <defs>
              <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="var(--secondary)" />
                <stop offset="55%" stopColor="var(--primary)" />
                <stop offset="100%" stopColor="var(--primary-hover)" />
              </linearGradient>
            </defs>
            <circle cx="68" cy="68" r={r} fill="none" stroke="#EEF0F3" strokeWidth="10" />
            <motion.circle
              cx="68"
              cy="68"
              r={r}
              fill="none"
              stroke="url(#ringGrad)"
              strokeWidth="10"
              strokeLinecap="round"
              strokeDasharray={c}
              initial={{ strokeDashoffset: c }}
              animate={{ strokeDashoffset: c - (c * pct) / 100 }}
              transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
              transform="rotate(-90 68 68)"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <motion.p
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 0.4 }}
              className="text-[26px] font-semibold text-[var(--text-primary)] tracking-tight leading-none"
            >
              {Math.round(animatedCompletion)}%
            </motion.p>
            <p className="text-[10px] font-medium text-slate-400 uppercase tracking-wider mt-1">Completion</p>
          </div>
        </div>

        <div className="flex-1 space-y-3.5">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
              <Wallet className="w-3.5 h-3.5 text-emerald-500" />
              Collected
            </div>
            <p className="text-xl font-semibold text-emerald-600 tracking-tight mt-0.5">
              {formatINR(Math.round(animatedCollected))}
            </p>
          </div>
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
              <Hourglass className="w-3.5 h-3.5 text-orange-500" />
              Pending
            </div>
            <p className="text-xl font-semibold text-orange-500 tracking-tight mt-0.5">
              {formatINR(Math.round(animatedPending))}
            </p>
          </div>
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
              <Users className="w-3.5 h-3.5 text-slate-600" />
              Remaining Customers
            </div>
            <p className="text-xl font-semibold text-[var(--text-primary)] tracking-tight mt-0.5">
              {Math.round(animatedRemaining)}
            </p>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-4 mt-5 pt-4 border-t border-slate-100">
        {[
          { color: '#10B981', label: 'Collected' },
          { color: '#F97316', label: 'Pending' },
          { color: 'var(--primary)', label: 'Active' },
        ].map((item) => (
          <div key={item.label} className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
            <span className="text-[11px] font-medium text-slate-500">{item.label}</span>
          </div>
        ))}
      </div>
    </WidgetCard>
  )
}
