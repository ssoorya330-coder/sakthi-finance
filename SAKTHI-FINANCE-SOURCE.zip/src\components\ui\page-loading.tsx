import { LoaderCircle } from 'lucide-react'

/** Lightweight fallback for navigation; the branded splash belongs to startup only. */
export default function PageLoading({ fullScreen = false }: { fullScreen?: boolean }) {
  return <div role="status" className={`flex items-center justify-center gap-2 bg-[var(--background)] text-sm text-[var(--primary)] ${fullScreen ? 'min-h-screen' : 'min-h-[40vh]'}`}>
    <LoaderCircle aria-hidden="true" size={20} className="motion-safe:animate-spin" />Loading…
  </div>
}
