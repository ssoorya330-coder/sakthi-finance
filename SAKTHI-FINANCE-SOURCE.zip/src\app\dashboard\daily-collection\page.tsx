'use client'

import { useState, useMemo, useCallback, Suspense, useRef, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts'
import {
  ArrowLeft,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Download,
  IndianRupee,
  Users,
  TrendingUp,
  TrendingDown,
  Search,
  Filter,
  Eye,
  Printer,
  CalendarCheck,
  Wallet,
  Clock,
  UserCheck,
  AlertTriangle,
  FileText,
} from 'lucide-react'
import { useCustomerStore } from '@/store/customer-store'
import { useSidebarStore } from '@/store/sidebar-store'
import { formatINR } from '@/lib/dashboard-utils'
import { formatCurrency, formatDateDMY } from '@/features/dashboard/dashboard.styles'
import Link from 'next/link'
import type { Customer, PaymentRecord } from '@/types/customer.types'

const WINE = 'var(--primary)'
const WINE_LIGHT = 'var(--primary-hover)'
const GOLD = 'var(--secondary)'
const AMBER = '#D97706'
const AMBER_LIGHT = '#F59E0B'
const BG_LIGHT = 'var(--background)'
const TEXT_DARK = 'var(--text-primary)'
const BORDER_WINE = 'rgba(127,29,29,.12)'

const STATUS_COLORS: Record<string, { bg: string; text: string }> = {
  'Fully Paid': { bg: 'bg-emerald-50', text: 'text-emerald-700' },
  Partial: { bg: 'bg-amber-50', text: 'text-amber-700' },
  'Not Paid': { bg: 'bg-red-50', text: 'text-red-700' },
}

function parseDate(dateStr: string): Date | null {
  if (!dateStr) return null
  const d = new Date(dateStr)
  return isNaN(d.getTime()) ? null : d
}

function sameDay(a: Date, b: Date): boolean {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  )
}

function toKey(d: Date): string {
  // Local calendar date (YYYY-MM-DD). Must pair with fromKey(), which parses
  // as local midnight — using toISOString() (UTC) here shifted dates in
  // UTC+X timezones and made the next-day arrow a silent no-op.
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

function fromKey(key: string): Date {
  return new Date(`${key}T00:00:00`)
}

function addDays(d: Date, n: number): Date {
  const r = new Date(d)
  r.setDate(r.getDate() + n)
  return r
}

function formatDisplayDate(key: string): string {
  const d = fromKey(key)
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
}

function formatDayShort(key: string): string {
  const d = fromKey(key)
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
}

function formatDayLabel(key: string): string {
  const d = fromKey(key)
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })
}

function getDateRangeKeys(center: Date, days: number): string[] {
  const keys: string[] = []
  const start = addDays(center, -(days - 1))
  for (let i = 0; i < days; i++) {
    keys.push(toKey(addDays(start, i)))
  }
  return keys
}

function getInstallmentsDueOnDate(c: Customer, date: Date): number {
  const loanDate = parseDate(c.loanDate || '')
  if (!loanDate) return 0
  if (date < loanDate) return 0
  const dueDate = parseDate(c.dueDate || '')
  if (dueDate && date > dueDate) return 0
  const installment = Number(c.installmentAmount) || 0
  if (installment <= 0) return 0
  const dur = Number(c.duration) || 0
  const loanType = c.loanType || 'Daily'
  const diffMs = date.getTime() - loanDate.getTime()
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))
  switch (loanType) {
    case 'Daily':
      return diffDays < dur ? installment : 0
    case 'Weekly':
      return diffDays % 7 === 0 && diffDays / 7 < dur ? installment : 0
    case 'Monthly': {
      const monthsElapsed =
        (date.getFullYear() - loanDate.getFullYear()) * 12 +
        (date.getMonth() - loanDate.getMonth())
      return monthsElapsed < dur ? installment : 0
    }
    case 'Yearly': {
      const yearsElapsed = date.getFullYear() - loanDate.getFullYear()
      return yearsElapsed < dur ? installment : 0
    }
    default:
      return diffDays < dur ? installment : 0
  }
}

interface DayData {
  dateKey: string
  amount: number
  paidCount: number
  totalCount: number
}

function computeDayData(
  dateKey: string,
  customers: Customer[],
  paymentHistory: PaymentRecord[]
): DayData {
  const date = fromKey(dateKey)
  const dayPayments = paymentHistory.filter((p) => {
    const d = parseDate(p.paymentDate)
    return d && sameDay(d, date)
  })
  const amount = dayPayments.reduce((s, p) => s + (Number(p.paymentAmount) || 0), 0)
  const paidIds = new Set(dayPayments.map((p) => p.customerId))
  const activeCustomers = customers.filter(
    (c) => c.status === 'Active' || c.status === 'Overdue'
  )
  const dueCount = activeCustomers.filter(
    (c) => getInstallmentsDueOnDate(c, date) > 0
  ).length
  const paidCount = activeCustomers.filter(
    (c) => paidIds.has(c.id) && getInstallmentsDueOnDate(c, date) > 0
  ).length

  return { dateKey, amount, paidCount, totalCount: dueCount }
}

function computeDatePayments(
  dateKey: string,
  customers: Customer[],
  paymentHistory: PaymentRecord[]
) {
  const date = fromKey(dateKey)
  const dayPayments = paymentHistory.filter((p) => {
    const d = parseDate(p.paymentDate)
    return d && sameDay(d, date)
  })
  return dayPayments
}

function computeDailyStatus(
  dateKey: string,
  customers: Customer[],
  paymentHistory: PaymentRecord[]
) {
  const date = fromKey(dateKey)
  const dayPayments = paymentHistory.filter((p) => {
    const d = parseDate(p.paymentDate)
    return d && sameDay(d, date)
  })

  const activeCustomers = customers.filter(
    (c) => c.status === 'Active' || c.status === 'Overdue'
  )

  const customersDue = activeCustomers.filter(
    (c) => getInstallmentsDueOnDate(c, date) > 0
  )

  const paidByCustomer = new Map<string, number>()
  for (const p of dayPayments) {
    if (!p.customerId) continue
    paidByCustomer.set(
      p.customerId,
      (paidByCustomer.get(p.customerId) ?? 0) + (Number(p.paymentAmount) || 0)
    )
  }

  let paid = 0
  let partial = 0
  let notPaid = 0
  let totalCollected = 0
  let totalRemaining = 0

  for (const c of customersDue) {
    const installment = Number(c.installmentAmount) || 0
    const paidToday = paidByCustomer.get(c.id) ?? 0
    totalCollected += paidToday

    if (paidToday <= 0) {
      notPaid++
      totalRemaining += installment
    } else if (paidToday >= installment) {
      paid++
    } else {
      partial++
      totalRemaining += installment - paidToday
    }
  }

  const completion =
    customersDue.length > 0
      ? Math.min(100, (paid / customersDue.length) * 100)
      : 0

  return {
    customersDue: customersDue.length,
    paid,
    partial,
    notPaid,
    totalCollected,
    totalRemaining,
    completion,
  }
}

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div
      className="rounded-xl shadow-xl px-4 py-3 min-w-[150px]"
      style={{
        background: '#FFFFFF',
        border: '1px solid rgba(127,29,29,.10)',
        boxShadow: '0 8px 24px rgba(127,29,29,.12), 0 2px 8px rgba(0,0,0,0.04)',
      }}
    >
      <p className="text-[11px] font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#94A3B8' }}>
        {label}
      </p>
      <p className="text-base font-bold tabular-nums" style={{ color: WINE }}>
        {formatINR(Number(payload[0].value) || 0)}
      </p>
    </div>
  )
}

function getMonthDays(year: number, month: number) {
  const firstDay = new Date(year, month, 1).getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const cells: (number | null)[] = []
  for (let i = 0; i < firstDay; i++) cells.push(null)
  for (let d = 1; d <= daysInMonth; d++) cells.push(d)
  return cells
}

function formatMonthYear(year: number, month: number) {
  return new Date(year, month, 1).toLocaleDateString('en-IN', {
    month: 'long',
    year: 'numeric',
  })
}

const WEEK_DAYS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']

function MiniCalendar({
  selectedDate,
  today,
  onSelect,
}: {
  selectedDate: string
  today: string
  onSelect: (key: string) => void
}) {
  const [viewMonth, setViewMonth] = useState(() => {
    const d = fromKey(selectedDate)
    return { year: d.getFullYear(), month: d.getMonth() }
  })

  const cells = useMemo(
    () => getMonthDays(viewMonth.year, viewMonth.month),
    [viewMonth.year, viewMonth.month]
  )

  const todayDate = fromKey(today)
  const selectedDateObj = fromKey(selectedDate)

  function prevMonth() {
    setViewMonth((v) => {
      if (v.month === 0) return { year: v.year - 1, month: 11 }
      return { year: v.year, month: v.month - 1 }
    })
  }

  function nextMonth() {
    setViewMonth((v) => {
      if (v.month === 11) return { year: v.year + 1, month: 0 }
      return { year: v.year, month: v.month + 1 }
    })
  }

  function handleSelectDay(day: number) {
    const d = new Date(viewMonth.year, viewMonth.month, day)
    if (d > todayDate) return
    onSelect(toKey(d))
  }

  return (
    <div className="select-none">
      <div className="flex items-center justify-between mb-3">
        <button
          onClick={prevMonth}
          className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-[rgba(127,29,29,.06)] transition-colors"
          style={{ color: TEXT_DARK }}
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <p className="text-sm font-semibold" style={{ color: TEXT_DARK }}>
          {formatMonthYear(viewMonth.year, viewMonth.month)}
        </p>
        <button
          onClick={nextMonth}
          className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-[rgba(127,29,29,.06)] transition-colors"
          style={{ color: TEXT_DARK }}
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-0.5 mb-1">
        {WEEK_DAYS.map((d) => (
          <div key={d} className="text-center text-[10px] font-semibold py-1" style={{ color: '#94A3B8' }}>
            {d}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-0.5">
        {cells.map((day, i) => {
          if (day === null) return <div key={`empty-${i}`} />
          const d = new Date(viewMonth.year, viewMonth.month, day)
          const key = toKey(d)
          const isSelected = key === selectedDate
          const isToday = key === today
          const isFuture = d > todayDate

          return (
            <button
              key={key}
              onClick={() => handleSelectDay(day)}
              disabled={isFuture}
              className="w-8 h-8 rounded-lg text-xs font-medium flex items-center justify-center transition-all disabled:opacity-25 disabled:cursor-not-allowed"
              style={{
                background: isSelected ? AMBER : isToday ? 'rgba(127,29,29,.08)' : 'transparent',
                color: isSelected ? '#FFFFFF' : isToday ? WINE : TEXT_DARK,
                fontWeight: isSelected || isToday ? 700 : 500,
                boxShadow: isSelected ? '0 2px 8px rgba(217,119,6,0.3)' : 'none',
              }}
            >
              {day}
            </button>
          )
        })}
      </div>
    </div>
  )
}

function DailyCollectionContent() {
  const { toggleSidebar } = useSidebarStore()
  const customers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const loading = useCustomerStore((s) => s.loading)
  const getDisplayId = useCustomerStore((s) => s.getDisplayId)

  const today = useMemo(() => toKey(new Date()), [])
  const [selectedDate, setSelectedDate] = useState(today)
  const [chartRange, setChartRange] = useState<7 | 30>(7)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('All')
  const [calendarOpen, setCalendarOpen] = useState(false)
  const [calendarMonth, setCalendarMonth] = useState(() => {
    const d = new Date()
    return { year: d.getFullYear(), month: d.getMonth() }
  })
  const calendarRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!calendarOpen) return
    function handleClickOutside(e: MouseEvent) {
      if (calendarRef.current && !calendarRef.current.contains(e.target as Node)) {
        setCalendarOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [calendarOpen])

  const chartData = useMemo(() => {
    const keys = getDateRangeKeys(fromKey(selectedDate), chartRange)
    return keys.map((k) => computeDayData(k, customers, paymentHistory))
  }, [selectedDate, chartRange, customers, paymentHistory])

  const selectedDayStatus = useMemo(
    () => computeDailyStatus(selectedDate, customers, paymentHistory),
    [selectedDate, customers, paymentHistory]
  )

  const selectedDayPayments = useMemo(
    () => computeDatePayments(selectedDate, customers, paymentHistory),
    [selectedDate, customers, paymentHistory]
  )

  const paymentByCustomer = useMemo(() => {
    const map = new Map<string, number>()
    for (const p of selectedDayPayments) {
      if (!p.customerId) continue
      map.set(
        p.customerId,
        (map.get(p.customerId) ?? 0) + (Number(p.paymentAmount) || 0)
      )
    }
    return map
  }, [selectedDayPayments])

  const previousDate = useMemo(() => toKey(addDays(fromKey(selectedDate), -1)), [selectedDate])
  const nextDate = useMemo(() => toKey(addDays(fromKey(selectedDate), 1)), [selectedDate])
  const isToday = selectedDate === today
  const isFuture = selectedDate > today

  const previousDayStatus = useMemo(
    () => computeDailyStatus(previousDate, customers, paymentHistory),
    [previousDate, customers, paymentHistory]
  )

  const collectionDiff = useMemo(() => {
    if (previousDayStatus.totalCollected === 0) {
      return selectedDayStatus.totalCollected > 0 ? 100 : 0
    }
    return (
      ((selectedDayStatus.totalCollected - previousDayStatus.totalCollected) /
        previousDayStatus.totalCollected) *
      100
    )
  }, [selectedDayStatus, previousDayStatus])

  const recentDays = useMemo(() => {
    const keys = getDateRangeKeys(fromKey(selectedDate), 7)
    return keys
      .map((k) => ({
        ...computeDayData(k, customers, paymentHistory),
        status: computeDailyStatus(k, customers, paymentHistory),
      }))
      .reverse()
  }, [selectedDate, customers, paymentHistory])

  const filteredPayments = useMemo(() => {
    const result: {
      payment: PaymentRecord
      customer: Customer | undefined
      customerPaid: number
      installment: number
      status: string
    }[] = []

    const activeCustomers = customers.filter(
      (c) => c.status === 'Active' || c.status === 'Overdue'
    )
    const date = fromKey(selectedDate)

    const allRelevantIds = new Set<string>()
    for (const c of activeCustomers) {
      if (getInstallmentsDueOnDate(c, date) > 0) allRelevantIds.add(c.id)
    }
    for (const p of selectedDayPayments) {
      if (p.customerId) allRelevantIds.add(p.customerId)
    }

    for (const c of customers) {
      if (!allRelevantIds.has(c.id)) continue
      const installment = getInstallmentsDueOnDate(c, date)
      if (installment <= 0) {
        const dayPay = paymentByCustomer.get(c.id) ?? 0
        if (dayPay <= 0) continue
        result.push({
          payment: selectedDayPayments.find((p) => p.customerId === c.id)!,
          customer: c,
          customerPaid: dayPay,
          installment,
          status: 'Fully Paid',
        })
        continue
      }
      const dayPay = paymentByCustomer.get(c.id) ?? 0
      let status = 'Not Paid'
      if (dayPay > 0 && dayPay >= installment) status = 'Fully Paid'
      else if (dayPay > 0) status = 'Partial'

      const firstPayment = selectedDayPayments.find((p) => p.customerId === c.id)
      result.push({
        payment: firstPayment!,
        customer: c,
        customerPaid: dayPay,
        installment,
        status,
      })
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase()
      return result.filter(
        (r) =>
          r.customer?.fullName?.toLowerCase().includes(q) ||
          r.customer?.mobileNumber?.includes(q) ||
          (r.customer && getDisplayId(r.customer).toLowerCase().includes(q))
      )
    }
    if (statusFilter !== 'All') {
      return result.filter((r) => r.status === statusFilter)
    }
    return result
  }, [
    selectedDate,
    customers,
    selectedDayPayments,
    paymentByCustomer,
    searchQuery,
    statusFilter,
    getDisplayId,
  ])

  const handlePrevDay = useCallback(() => {
    setSelectedDate((prev) => toKey(addDays(fromKey(prev), -1)))
  }, [])

  const handleNextDay = useCallback(() => {
    setSelectedDate((prev) => {
      const next = toKey(addDays(fromKey(prev), 1))
      return next > today ? prev : next
    })
  }, [today])

  const handleDownloadReport = useCallback(() => {
    const rows = [
      ['Customer Code', 'Customer Name', 'Mobile', 'Installment', 'Amount Paid', 'Status'],
    ]
    for (const r of filteredPayments) {
      const c = r.customer
      if (!c) continue
      rows.push([
        getDisplayId(c),
        c.fullName,
        c.mobileNumber,
        String(r.installment),
        String(r.customerPaid),
        r.status,
      ])
    }
    rows.push([])
    rows.push(['', '', '', 'Total Collected', String(selectedDayStatus.totalCollected), ''])
    rows.push(['', '', '', 'Remaining', String(selectedDayStatus.totalRemaining), ''])
    rows.push(['', '', '', 'Completion', `${selectedDayStatus.completion.toFixed(1)}%`, ''])

    const csv = rows.map((r) => r.map((v) => `"${v}"`).join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `collection-report-${selectedDate}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }, [filteredPayments, selectedDate, selectedDayStatus, getDisplayId])

  const handlePrint = useCallback(() => {
    window.print()
  }, [])

  if (loading && customers.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: BG_LIGHT }}>
        <div className="flex flex-col items-center gap-3">
          <svg className="animate-spin w-9 h-9" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="rgba(217,119,6,.20)" strokeWidth="3" />
            <path d="M22 12a10 10 0 0 0-10-10" stroke={AMBER} strokeWidth="3" strokeLinecap="round" />
          </svg>
          <p className="text-sm font-medium" style={{ color: TEXT_DARK, opacity: 0.55 }}>
            Loading collection data…
          </p>
        </div>
      </div>
    )
  }

  const maxChartAmount = Math.max(...chartData.map((d) => d.amount), 1)

  return (
    <div className="min-h-screen flex flex-col" style={{ background: BG_LIGHT }}>
      {/* ===== HEADER ===== */}
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="flex-shrink-0"
        style={{ borderBottom: `1px solid ${BORDER_WINE}` }}
      >
        <div className="px-6 py-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2.5 flex-shrink-0">
              <button
                onClick={toggleSidebar}
                className="w-9 h-9 rounded-xl flex items-center justify-center transition-all active:scale-95"
                style={{ background: '#FFFFFF', border: `1px solid ${BORDER_WINE}`, color: TEXT_DARK }}
              >
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                  <path d="M3 5h12" /><path d="M3 9h12" /><path d="M3 13h12" />
                </svg>
              </button>
              <Link
                href="/dashboard"
                className="w-9 h-9 rounded-xl flex items-center justify-center transition-all active:scale-95"
                style={{ background: '#FFFFFF', border: `1px solid ${BORDER_WINE}`, color: TEXT_DARK }}
              >
                <ArrowLeft className="w-4 h-4" />
              </Link>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20 flex-shrink-0">
                  <Wallet className="w-[16px] h-[16px] text-white" />
                </div>
                <div>
                  <h1 className="text-lg font-bold text-slate-900">Today&apos;s Collection</h1>
                  <p className="text-xs text-slate-500">Monitor daily collection status and amounts</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={handleDownloadReport}
                className="h-9 px-4 rounded-xl text-sm font-semibold flex items-center gap-2 transition-all active:scale-[0.97]"
                style={{ background: '#FFFFFF', border: `1px solid ${BORDER_WINE}`, color: TEXT_DARK }}
              >
                <Download className="w-4 h-4" />
                <span className="hidden sm:inline">Download Report</span>
              </button>
              <button
                onClick={handlePrint}
                className="h-9 px-4 rounded-xl text-sm font-semibold flex items-center gap-2 transition-all active:scale-[0.97]"
                style={{ background: '#FFFFFF', border: `1px solid ${BORDER_WINE}`, color: TEXT_DARK }}
              >
                <Printer className="w-4 h-4" />
                <span className="hidden sm:inline">Print</span>
              </button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ===== DATE NAVIGATION ===== */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, delay: 0.05 }}
        className="px-6 py-3"
      >
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={handlePrevDay}
            className="w-10 h-10 rounded-xl flex items-center justify-center transition-all active:scale-95 hover:bg-white"
            style={{ border: `1px solid ${BORDER_WINE}`, color: TEXT_DARK }}
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <div className="relative flex items-center gap-3" ref={calendarRef}>
            <button
              onClick={() => setCalendarOpen((o) => !o)}
              className="w-10 h-10 rounded-xl flex items-center justify-center shadow-md shadow-[var(--primary)]/15 flex-shrink-0 transition-all active:scale-95 hover:shadow-lg hover:shadow-[var(--primary)]/20"
              style={{
                background: calendarOpen
                  ? 'linear-gradient(135deg, #D97706, #F59E0B)'
                  : `linear-gradient(135deg, ${WINE}, ${WINE_LIGHT})`,
                boxShadow: calendarOpen
                  ? '0 4px 12px rgba(217,119,6,0.3)'
                  : '0 4px 12px rgba(127,29,29,0.15)',
              }}
            >
              <CalendarDays className="w-5 h-5 text-white" />
            </button>

            {calendarOpen && (
              <motion.div
                initial={{ opacity: 0, y: -8, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                className="absolute top-full left-1/2 -translate-x-1/2 mt-2 z-50 rounded-2xl p-4"
                style={{
                  background: '#FFFFFF',
                  border: '1px solid rgba(127,29,29,.08)',
                  boxShadow: '0 12px 40px rgba(127,29,29,.12), 0 4px 12px rgba(0,0,0,0.06)',
                  minWidth: '280px',
                }}
              >
                <MiniCalendar
                  selectedDate={selectedDate}
                  today={today}
                  onSelect={(key) => {
                    setSelectedDate(key)
                    setCalendarOpen(false)
                  }}
                />
              </motion.div>
            )}

            <div className="text-center min-w-[160px]">
              <p className="text-lg font-bold text-slate-900 tabular-nums">
                {formatDisplayDate(selectedDate)}
              </p>
              {selectedDate !== today && (
                <button
                  onClick={() => setSelectedDate(today)}
                  className="text-[11px] font-semibold text-[var(--primary)] hover:underline"
                >
                  Back to Today
                </button>
              )}
            </div>
          </div>

          <button
            onClick={handleNextDay}
            disabled={isToday || isFuture}
            className="w-10 h-10 rounded-xl flex items-center justify-center transition-all active:scale-95 hover:bg-white disabled:opacity-30 disabled:cursor-not-allowed"
            style={{ border: `1px solid ${BORDER_WINE}`, color: TEXT_DARK }}
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </motion.div>

      {/* ===== CONTENT ===== */}
      <div className="flex-1 px-6 pb-6 space-y-5">
        {/* KPI CARDS */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3"
        >
          <KpiCard
            icon={IndianRupee}
            iconColor="text-emerald-600"
            iconBg="bg-emerald-50"
            label="Total Collection"
            value={formatINR(selectedDayStatus.totalCollected)}
            subtitle={`${formatDayShort(selectedDate)}`}
          />
          <KpiCard
            icon={UserCheck}
            iconColor="text-[var(--primary)]"
            iconBg="bg-[var(--primary-soft)]"
            label="Customers Paid"
            value={String(selectedDayStatus.paid)}
            subtitle={`of ${selectedDayStatus.customersDue} due`}
          />
          <KpiCard
            icon={TrendingUp}
            iconColor="text-[var(--secondary)]"
            iconBg="bg-amber-50"
            label="Average Payment"
            value={
              selectedDayStatus.paid > 0
                ? formatINR(Math.round(selectedDayStatus.totalCollected / selectedDayStatus.paid))
                : '₹0'
            }
            subtitle={`across ${selectedDayStatus.paid} customer${selectedDayStatus.paid === 1 ? '' : 's'}`}
          />
          <KpiCard
            icon={collectionDiff >= 0 ? TrendingUp : TrendingDown}
            iconColor={collectionDiff >= 0 ? 'text-emerald-600' : 'text-red-600'}
            iconBg={collectionDiff >= 0 ? 'bg-emerald-50' : 'bg-red-50'}
            label="Today vs Yesterday"
            value={`${collectionDiff >= 0 ? '+' : ''}${collectionDiff.toFixed(1)}%`}
            subtitle={
              previousDayStatus.totalCollected > 0
                ? `Yesterday: ${formatINR(previousDayStatus.totalCollected)}`
                : 'No yesterday data'
            }
          />
        </motion.div>

        {/* COLLECTION BY DAY CHART */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.15 }}
          className="rounded-[20px] p-5 sm:p-6"
          style={{
            background: '#FDFBF5',
            border: '1px solid rgba(127,29,29,.06)',
            boxShadow: '0 1px 3px rgba(127,29,29,0.03), 0 4px 12px rgba(127,29,29,0.02)',
          }}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
            <div className="flex items-center gap-2.5">
              <div
                className="w-9 h-9 rounded-[11px] flex items-center justify-center flex-shrink-0"
                style={{
                  background: `linear-gradient(135deg, ${WINE}, ${WINE_LIGHT})`,
                  boxShadow: `0 4px 12px rgba(127,29,29,0.18)`,
                }}
              >
                <BarChart className="w-[16px] h-[16px] text-white" />
              </div>
              <div>
                <h3 className="text-base font-semibold" style={{ color: TEXT_DARK }}>
                  Collection by Day
                </h3>
                <p className="text-xs" style={{ color: '#94A3B8' }}>
                  {chartRange === 7 ? 'Last 7 days' : 'Last 30 days'} ·{' '}
                  {formatDayShort(chartData[0]?.dateKey || today)} –{' '}
                  {formatDayShort(chartData[chartData.length - 1]?.dateKey || today)}
                </p>
              </div>
            </div>
            <div
              className="flex items-center gap-1.5 p-1 rounded-xl"
              style={{ background: 'rgba(127,29,29,.04)', border: '1px solid rgba(127,29,29,.06)' }}
            >
              <button
                onClick={() => setChartRange(7)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                style={{
                  background: chartRange === 7 ? WINE : 'transparent',
                  color: chartRange === 7 ? '#FFFFFF' : '#94A3B8',
                  boxShadow: chartRange === 7 ? '0 2px 6px rgba(127,29,29,0.2)' : 'none',
                }}
              >
                7 Days
              </button>
              <button
                onClick={() => setChartRange(30)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                style={{
                  background: chartRange === 30 ? WINE : 'transparent',
                  color: chartRange === 30 ? '#FFFFFF' : '#94A3B8',
                  boxShadow: chartRange === 30 ? '0 2px 6px rgba(127,29,29,0.2)' : 'none',
                }}
              >
                30 Days
              </button>
            </div>
          </div>

          {chartData.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
                style={{ background: 'rgba(127,29,29,.04)' }}
              >
                <BarChart className="w-8 h-8" style={{ color: '#CBD5E1' }} />
              </div>
              <p className="text-sm font-medium" style={{ color: '#94A3B8' }}>
                No collection data available
              </p>
            </div>
          ) : (
            <div className="h-[300px] sm:h-[340px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartData}
                  margin={{ top: 8, right: 4, left: 0, bottom: 0 }}
                  barCategoryGap={chartRange === 30 ? '18%' : '28%'}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(127,29,29,.05)"
                    vertical={false}
                  />
                  <XAxis
                    dataKey="dateKey"
                    tickFormatter={chartRange === 30 ? formatDayShort : formatDayLabel}
                    tick={{ fontSize: 11, fill: '#94A3B8', fontWeight: 500 }}
                    axisLine={false}
                    tickLine={false}
                    interval={chartRange === 30 ? Math.max(0, Math.floor(chartData.length / 7) - 1) : 0}
                    minTickGap={8}
                  />
                  <YAxis
                    tick={{ fontSize: 11, fill: '#94A3B8', fontWeight: 500 }}
                    axisLine={false}
                    tickLine={false}
                    width={55}
                    tickFormatter={(v: number) =>
                      v >= 1e5 ? `${(v / 1e5).toFixed(1)}L` : v >= 1e3 ? `${(v / 1e3).toFixed(0)}k` : `${v}`
                    }
                  />
                  <Bar
                    dataKey="amount"
                    radius={[5, 5, 0, 0]}
                    animationDuration={400}
                    animationEasing="ease-out"
                  >
                    {chartData.map((entry) => {
                      const isSelected = entry.dateKey === selectedDate
                      const isTodayBar = entry.dateKey === today
                      let fill = '#E8DDD0'
                      if (isSelected) fill = AMBER
                      else if (isTodayBar) fill = WINE
                      return (
                        <Cell
                          key={entry.dateKey}
                          fill={fill}
                          style={{
                            cursor: 'pointer',
                            filter: isSelected ? 'drop-shadow(0 2px 6px rgba(217,119,6,0.3))' : 'none',
                            transition: 'fill 0.2s ease, filter 0.2s ease',
                          }}
                          onMouseEnter={(e: any) => {
                            if (!isSelected && !isTodayBar) e.target.style.fill = WINE_LIGHT
                          }}
                          onMouseLeave={(e: any) => {
                            if (!isSelected && !isTodayBar) e.target.style.fill = '#E8DDD0'
                          }}
                          onClick={() => setSelectedDate(entry.dateKey)}
                        />
                      )
                    })}
                  </Bar>
                  <Tooltip
                    content={<CustomTooltip />}
                    cursor={{ fill: 'rgba(127,29,29,.04)' }}
                    wrapperStyle={{ zIndex: 9999, outline: 'none' }}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Legend */}
          <div className="flex items-center justify-center gap-5 mt-4 pt-3" style={{ borderTop: '1px solid rgba(127,29,29,.05)' }}>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: WINE }} />
              <span className="text-[11px] font-medium" style={{ color: '#94A3B8' }}>Today</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: AMBER }} />
              <span className="text-[11px] font-medium" style={{ color: '#94A3B8' }}>Selected</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: '#E8DDD0' }} />
              <span className="text-[11px] font-medium" style={{ color: '#94A3B8' }}>Other days</span>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* DAILY COLLECTION STATUS + PAYMENT LIST */}
          <div className="lg:col-span-2 space-y-5">
            {/* DAILY COLLECTION STATUS */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.2 }}
              className="bg-white rounded-[20px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] p-5 sm:p-6"
            >
              <div className="flex items-center gap-2.5 mb-5">
                <div className="w-9 h-9 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20 flex-shrink-0">
                  <CalendarCheck className="w-[16px] h-[16px] text-white" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-slate-900">Daily Collection Status</h3>
                  <p className="text-xs text-slate-400">{formatDisplayDate(selectedDate)}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
                <StatusBox
                  label="Customers Due"
                  value={String(selectedDayStatus.customersDue)}
                  color="text-slate-900"
                  bg="bg-slate-50"
                />
                <StatusBox
                  label="Paid"
                  value={String(selectedDayStatus.paid)}
                  color="text-emerald-700"
                  bg="bg-emerald-50"
                />
                <StatusBox
                  label="Partial"
                  value={String(selectedDayStatus.partial)}
                  color="text-amber-700"
                  bg="bg-amber-50"
                />
                <StatusBox
                  label="Not Paid"
                  value={String(selectedDayStatus.notPaid)}
                  color="text-red-700"
                  bg="bg-red-50"
                />
              </div>

              <div className="border-t border-slate-100 pt-4 grid grid-cols-3 gap-3">
                <div>
                  <p className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Collected</p>
                  <p className="text-lg font-bold text-emerald-600 mt-0.5">
                    {formatINR(selectedDayStatus.totalCollected)}
                  </p>
                </div>
                <div>
                  <p className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Remaining</p>
                  <p className="text-lg font-bold text-red-600 mt-0.5">
                    {formatINR(selectedDayStatus.totalRemaining)}
                  </p>
                </div>
                <div>
                  <p className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Completion</p>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex-1 h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] transition-all duration-500"
                        style={{ width: `${selectedDayStatus.completion}%` }}
                      />
                    </div>
                    <span className="text-sm font-bold text-slate-900 tabular-nums">
                      {selectedDayStatus.completion.toFixed(0)}%
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* PAYMENT LIST */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.25 }}
              className="bg-white rounded-[20px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] overflow-hidden"
            >
              <div className="px-5 sm:px-6 pt-5 sm:pt-6 pb-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20 flex-shrink-0">
                      <FileText className="w-[16px] h-[16px] text-white" />
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-slate-900">Payment List</h3>
                      <p className="text-xs text-slate-400">
                        {filteredPayments.length} record{filteredPayments.length !== 1 ? 's' : ''}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="relative flex-1 min-w-[160px]">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                      <input
                        type="text"
                        placeholder="Search customer..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full h-9 pl-9 pr-3 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 placeholder:text-slate-400 outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/10 transition-all"
                      />
                    </div>
                    <select
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      className="h-9 px-3 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/10 transition-all appearance-none cursor-pointer"
                    >
                      <option value="All">All Status</option>
                      <option value="Fully Paid">Fully Paid</option>
                      <option value="Partial">Partial</option>
                      <option value="Not Paid">Not Paid</option>
                    </select>
                  </div>
                </div>
              </div>

              {filteredPayments.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
                  <div className="w-16 h-16 rounded-2xl bg-slate-50 flex items-center justify-center mb-4">
                    <Wallet className="w-8 h-8 text-slate-300" />
                  </div>
                  <p className="text-sm font-semibold text-slate-900 mb-1">No payments found</p>
                  <p className="text-xs text-slate-500">
                    {searchQuery || statusFilter !== 'All'
                      ? 'Try adjusting your filters.'
                      : `No collection activity on ${formatDayShort(selectedDate)}.`}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[600px]">
                    <thead>
                      <tr className="border-b border-slate-100">
                        <th className="text-left text-[10px] font-bold uppercase tracking-wider px-5 sm:px-6 py-2.5 text-slate-500">
                          S.No
                        </th>
                        <th className="text-left text-[10px] font-bold uppercase tracking-wider px-4 py-2.5 text-slate-500">
                          Customer Code
                        </th>
                        <th className="text-left text-[10px] font-bold uppercase tracking-wider px-4 py-2.5 text-slate-500">
                          Customer Name
                        </th>
                        <th className="text-right text-[10px] font-bold uppercase tracking-wider px-4 py-2.5 text-slate-500">
                          Amount Received
                        </th>
                        <th className="text-left text-[10px] font-bold uppercase tracking-wider px-4 py-2.5 text-slate-500">
                          Time
                        </th>
                        <th className="text-center text-[10px] font-bold uppercase tracking-wider px-4 py-2.5 text-slate-500">
                          Status
                        </th>
                        <th className="text-center text-[10px] font-bold uppercase tracking-wider px-5 sm:px-6 py-2.5 text-slate-500">
                          Action
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredPayments.map((row, idx) => {
                        const c = row.customer
                        if (!c) return null
                        const sc = STATUS_COLORS[row.status] || STATUS_COLORS['Not Paid']
                        return (
                          <tr
                            key={c.id}
                            className={`border-b border-slate-50 last:border-0 hover:bg-[rgba(212,175,55,0.04)] transition-colors ${
                              idx % 2 === 0 ? 'bg-white' : 'bg-[#FCFBF4]'
                            }`}
                          >
                            <td className="px-5 sm:px-6 py-3 text-sm text-slate-600 font-medium">
                              {idx + 1}
                            </td>
                            <td className="px-4 py-3 text-sm font-semibold text-slate-900">
                              {getDisplayId(c)}
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-2.5">
                                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0">
                                  {c.fullName.charAt(0)}
                                </div>
                                <span className="text-sm font-medium text-slate-900 truncate">
                                  {c.fullName}
                                </span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-sm font-semibold text-emerald-700 text-right tabular-nums">
                              {formatINR(row.customerPaid)}
                            </td>
                            <td className="px-4 py-3 text-sm text-slate-500">
                              {row.payment?.paymentTime || '—'}
                            </td>
                            <td className="px-4 py-3 text-center">
                              <span
                                className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-semibold ${sc.bg} ${sc.text}`}
                              >
                                {row.status}
                              </span>
                            </td>
                            <td className="px-5 sm:px-6 py-3 text-center">
                              <Link
                                href={`/dashboard/customers`}
                                className="w-8 h-8 rounded-lg border border-transparent inline-flex items-center justify-center hover:bg-[var(--primary-soft)] hover:border-[var(--primary)]/20 transition-colors"
                                title="View Customer"
                              >
                                <Eye className="w-4 h-4 text-[var(--primary)]" />
                              </Link>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </motion.div>
          </div>

          {/* RIGHT SIDEBAR */}
          <div className="space-y-5">
            {/* SELECTED DATE SUMMARY */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.2 }}
              className="bg-white rounded-[20px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] p-5"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-md flex-shrink-0">
                  <CalendarDays className="w-4 h-4 text-white" />
                </div>
                <h3 className="text-sm font-semibold text-slate-900">Selected Date Summary</h3>
              </div>

              <div className="space-y-3">
                <SummaryRow label="Date" value={formatDisplayDate(selectedDate)} />
                <SummaryRow
                  label="Total Collection"
                  value={formatINR(selectedDayStatus.totalCollected)}
                  highlight
                />
                <SummaryRow
                  label="Customers Paid"
                  value={`${selectedDayStatus.paid} / ${selectedDayStatus.customersDue}`}
                />
                <SummaryRow
                  label="Remaining"
                  value={formatINR(selectedDayStatus.totalRemaining)}
                  danger
                />
                <SummaryRow
                  label="Completion"
                  value={`${selectedDayStatus.completion.toFixed(1)}%`}
                />
              </div>
            </motion.div>

            {/* RECENT COLLECTION DAYS */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.25 }}
              className="bg-white rounded-[20px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] p-5"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[var(--secondary)] to-[#B8943A] flex items-center justify-center shadow-md flex-shrink-0">
                  <Clock className="w-4 h-4 text-white" />
                </div>
                <h3 className="text-sm font-semibold text-slate-900">Recent Collection Days</h3>
              </div>

              <div className="space-y-2">
                {recentDays.map((day) => (
                  <button
                    key={day.dateKey}
                    onClick={() => setSelectedDate(day.dateKey)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left transition-all hover:bg-[rgba(212,175,55,0.06)] ${
                      day.dateKey === selectedDate
                        ? 'bg-[#FDF8E5] border border-[rgba(212,175,55,0.3)]'
                        : 'border border-transparent'
                    }`}
                  >
                    <div>
                      <p className="text-sm font-semibold text-slate-900">
                        {formatDayShort(day.dateKey)}
                      </p>
                      <p className="text-[11px] text-slate-400">
                        {day.status.paid} paid · {day.status.customersDue} due
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-[var(--primary)] tabular-nums">
                        {formatINR(day.amount)}
                      </p>
                      <p
                        className={`text-[11px] font-semibold ${
                          day.status.completion >= 80
                            ? 'text-emerald-600'
                            : day.status.completion >= 40
                              ? 'text-amber-600'
                              : 'text-red-600'
                        }`}
                      >
                        {day.status.completion.toFixed(0)}%
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </motion.div>

            {/* QUICK ACTIONS */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.3 }}
              className="bg-white rounded-[20px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] p-5"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-md flex-shrink-0">
                  <IndianRupee className="w-4 h-4 text-white" />
                </div>
                <h3 className="text-sm font-semibold text-slate-900">Quick Actions</h3>
              </div>

              <div className="space-y-2">
                <Link
                  href="/dashboard/customers"
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-[rgba(127,29,29,.06)] border border-transparent hover:border-[rgba(127,29,29,.1)]"
                  style={{ color: TEXT_DARK }}
                >
                  <Users className="w-4 h-4" />
                  View Customers
                </Link>
                <button
                  onClick={handleDownloadReport}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-[rgba(127,29,29,.06)] border border-transparent hover:border-[rgba(127,29,29,.1)]"
                  style={{ color: TEXT_DARK }}
                >
                  <Download className="w-4 h-4" />
                  Generate Report
                </button>
                <button
                  onClick={handlePrint}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-[rgba(127,29,29,.06)] border border-transparent hover:border-[rgba(127,29,29,.1)]"
                  style={{ color: TEXT_DARK }}
                >
                  <Printer className="w-4 h-4" />
                  Print Report
                </button>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  )
}

function KpiCard({
  icon: Icon,
  iconColor,
  iconBg,
  label,
  value,
  subtitle,
}: {
  icon: React.ComponentType<{ className?: string }>
  iconColor: string
  iconBg: string
  label: string
  value: string
  subtitle: string
}) {
  return (
    <div className="bg-white rounded-[18px] border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] p-4 hover:shadow-[0_4px_16px_rgba(0,0,0,0.06)] transition-all duration-300 hover:-translate-y-0.5">
      <div className="flex items-start gap-3">
        <div className={`w-10 h-10 rounded-xl ${iconBg} flex items-center justify-center flex-shrink-0`}>
          <Icon className={`w-5 h-5 ${iconColor}`} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">{label}</p>
          <p className="text-xl font-bold text-slate-900 mt-0.5 tracking-tight">{value}</p>
          <p className="text-[11px] text-slate-400 mt-0.5 truncate">{subtitle}</p>
        </div>
      </div>
    </div>
  )
}

function StatusBox({
  label,
  value,
  color,
  bg,
}: {
  label: string
  value: string
  color: string
  bg: string
}) {
  return (
    <div className={`${bg} rounded-xl p-3 text-center`}>
      <p className={`text-2xl font-bold ${color} tabular-nums`}>{value}</p>
      <p className="text-[11px] font-medium text-slate-500 mt-0.5">{label}</p>
    </div>
  )
}

function SummaryRow({
  label,
  value,
  highlight,
  danger,
}: {
  label: string
  value: string
  highlight?: boolean
  danger?: boolean
}) {
  return (
    <div className="flex items-center justify-between">
      <p className="text-xs text-slate-500">{label}</p>
      <p
        className={`text-sm font-semibold tabular-nums ${
          highlight ? 'text-[var(--primary)]' : danger ? 'text-red-600' : 'text-slate-900'
        }`}
      >
        {value}
      </p>
    </div>
  )
}

export default function DailyCollectionPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center" style={{ background: BG_LIGHT }}>
          <svg className="animate-spin w-9 h-9" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="rgba(212,175,55,.25)" strokeWidth="3" />
            <path d="M22 12a10 10 0 0 0-10-10" stroke={GOLD} strokeWidth="3" strokeLinecap="round" />
          </svg>
        </div>
      }
    >
      <DailyCollectionContent />
    </Suspense>
  )
}
