'use client'

import { useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useQueryClient } from '@tanstack/react-query'
import { RefreshCw } from 'lucide-react'
import { useCustomerStore } from '@/store/customer-store'
import { useToastStore } from '@/store/toast-store'

export default function ApplicationRefresh() {
  const [refreshing, setRefreshing] = useState(false)
  const busy = useRef(false)
  const router = useRouter()
  const queries = useQueryClient()
  const refresh = async () => {
    if (busy.current) return
    busy.current = true
    setRefreshing(true)
    try {
      const success = await useCustomerStore.getState().refresh()
      await queries.invalidateQueries({}, { throwOnError: true })
      router.refresh()
      if (!success) throw new Error('Some data could not refresh. Please try again.')
      useToastStore.getState().addToast('Application refreshed. Your unfinished entries are kept.', 'success')
    } catch {
      useToastStore.getState().addToast('Could not refresh all data. Your work is still here. Please try again.', 'error')
    } finally {
      busy.current = false
      setRefreshing(false)
    }
  }
  return <button type="button" onClick={refresh} disabled={refreshing} aria-label="Refresh application" title="Refresh application data and keep your current work" className="fixed bottom-5 right-5 z-40 inline-flex items-center gap-2 rounded-full border border-[var(--secondary)]/40 bg-[#FFFEF9] px-4 py-3 text-sm font-semibold text-[var(--primary)] shadow-lg hover:bg-[#F6E7AF] disabled:opacity-60">
    <RefreshCw aria-hidden="true" size={17} className={refreshing ? 'motion-safe:animate-spin' : ''} />{refreshing ? 'Refreshing…' : 'Refresh app'}
  </button>
}
