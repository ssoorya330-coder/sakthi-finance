'use client'

import { motion } from 'framer-motion'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts'
import { formatNumber } from './dashboard.styles'

const statusData: { name: string; value: number; color: string }[] = []

const total = statusData.reduce((sum, entry) => sum + entry.value, 0)

const CustomTooltip = ({
  active,
  payload,
}: {
  active?: boolean
  payload?: Array<{ payload: { name: string; value: number; color: string } }>
}) => {
  if (!active || !payload) return null
  const data = payload[0].payload
  return (
    <div className="bg-white rounded-xl border border-slate-100 shadow-lg px-3 py-2">
      <p className="text-xs font-semibold text-slate-900">{data.name}</p>
      <p className="text-xs text-slate-500">{formatNumber(data.value)} customers</p>
    </div>
  )
}

export default function StatusChart() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="relative bg-white/70 backdrop-blur-xl rounded-[22px] border border-white/20 p-6 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] overflow-hidden"
    >
      <div className="absolute inset-0 sf-pattern-dots opacity-40 pointer-events-none" />
      <div className="mb-6 relative">
        <h3 className="text-lg font-bold text-slate-900">Customer Status</h3>
        <p className="text-sm text-slate-500 mt-0.5">Distribution by status</p>
      </div>

      <div className="flex items-center gap-6">
        <div className="relative w-[180px] h-[180px] flex-shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={80}
                paddingAngle={4}
                dataKey="value"
                strokeWidth={0}
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <p className="text-2xl font-bold text-slate-900">{formatNumber(total)}</p>
            <p className="text-xs text-slate-500">Total</p>
          </div>
        </div>

        <div className="flex-1 space-y-4">
          {statusData.map((entry) => (
            <div key={entry.name} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: entry.color }}
                />
                <span className="text-sm font-medium text-slate-700">{entry.name}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm font-bold text-slate-900">
                  {formatNumber(entry.value)}
                </span>
                <span className="text-xs text-slate-400 w-12 text-right">
                  {((entry.value / total) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  )
}
