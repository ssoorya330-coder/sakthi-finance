import fs from 'fs'
import path from 'path'
import { NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import {
  getPgServiceInfo,
  getDataDirectory,
  getDataDirSizeBytes,
  getServerVersion,
  getDatabaseSizeBytes,
  getDiskUsageForPath,
  listLocalDrives,
  findPgBin,
  verifyBackupArchive,
} from '@/server/storage'

export const dynamic = 'force-dynamic'

export interface SafetyCheck {
  key: string
  label: string
  ok: boolean
  detail: string
}

/**
 * STEP 1 — Real, backend-verified safety checklist. Every check is measured
 * live; nothing is assumed. A green check appears only when the backend
 * actually verified the condition.
 */
export async function GET() {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  const checks: SafetyCheck[] = []
  const push = (key: string, label: string, ok: boolean, detail: string) => {
    checks.push({ key, label, ok, detail })
  }

  try {
    const [service, dataDir, version, dbSize, pgBin] = await Promise.all([
      getPgServiceInfo(),
      getDataDirectory(),
      getServerVersion(),
      getDatabaseSizeBytes(),
      (async () => findPgBin())(),
    ]);

    // 1 — Backup storage: Active + purpose Database Backups + accessible + writable.
    let backupStorage: { id: string; name: string; path: string } | null = null
    let storageFreeBytes: number | null = null
    try {
      const loc = await dbQuery(
        `SELECT id, name, path FROM storage_locations
         WHERE status = 'Active' AND purpose = 'Database Backups'
         ORDER BY created_at ASC LIMIT 1`
      )
      if (loc.rows.length === 0) {
        push('backup-storage', 'Backup storage available', false, 'No Active storage with purpose “Database Backups” is configured.')
      } else {
        const row = loc.rows[0]
        backupStorage = { id: row.id, name: row.name, path: row.path }
        try {
          const st = fs.statSync(row.path)
          if (!st.isDirectory()) {
            push('backup-storage', 'Backup storage available', false, `${row.path} exists but is not a folder.`)
          } else {
            // Real writability probe (temp file, immediately removed).
            const probe = path.join(row.path, '.sf-write-test')
            try {
              fs.writeFileSync(probe, 'ok')
              fs.unlinkSync(probe)
            } catch {
              push('backup-storage', 'Backup storage available', false, `${row.path} is not writable. Check permissions.`)
              backupStorage = null
            }
            if (backupStorage) {
              const usage = getDiskUsageForPath(row.path)
              storageFreeBytes = usage?.freeBytes ?? null
              push(
                'backup-storage',
                'Backup storage available',
                true,
                `${row.name} — ${row.path}`
              )
            }
          }
        } catch {
          push('backup-storage', 'Backup storage available', false, `${row.path} does not exist or cannot be accessed. Reconnect the drive.`)
          backupStorage = null
        }
      }
    } catch (e: any) {
      push('backup-storage', 'Backup storage available', false, `Storage lookup failed: ${e.message}`)
    }

    // 2 — Verified backup: Successful record + file present + readable archive.
    let verifiedBackup: { id: string; filename: string; createdAt: string; entries: number; message: string } | null = null
    try {
      const rec = await dbQuery(
        `SELECT b.id, b.filename, b.path, b.size_bytes, b.created_at, b.storage_location_id
         FROM backup_records b
         WHERE b.status = 'Successful'
         ORDER BY b.created_at DESC LIMIT 5`
      )
      let found = false
      for (const row of rec.rows) {
        try {
          if (!fs.existsSync(row.path)) continue
          if ((Number(row.size_bytes) || 0) <= 0) continue
        } catch {
          continue
        }
        const v = await verifyBackupArchive(row.path)
        if (v.ok) {
          verifiedBackup = { id: row.id, filename: row.filename, createdAt: row.created_at, entries: v.entries, message: v.message }
          push('verified-backup', 'Verified backup available', true, `${row.filename} — ${v.message}`)
          found = true
          break
        }
      }
      if (!found) {
        push(
          'verified-backup',
          'Verified backup available',
          false,
          rec.rows.length === 0
            ? 'No successful backup exists yet. Create one below before continuing.'
            : 'Existing backups could not be verified (file missing or unreadable). Create a fresh backup below.'
        )
      }
    } catch (e: any) {
      push('verified-backup', 'Verified backup available', false, `Backup lookup failed: ${e.message}`)
    }

    // 3 — Installation detected (service present).
    if (service.name) {
      push('pg-install', 'PostgreSQL installation detected', true, `Windows service “${service.name}”${service.displayName ? ` (${service.displayName})` : ''}.`)
    } else {
      push('pg-install', 'PostgreSQL installation detected', false, 'No PostgreSQL Windows service was detected on this computer.')
    }

    // 4 — Version verified (destination uses these same local binaries, so
    // major versions cannot mix in this workflow).
    if (version) {
      push('pg-version', 'PostgreSQL version verified', true, `${version.split(' ').slice(0, 2).join(' ')} — the move reuses these same binaries; major versions cannot mix.`)
    } else {
      push('pg-version', 'PostgreSQL version verified', false, 'PostgreSQL version could not be detected.')
    }

    // 5 — Data directory detected + readable.
    if (dataDir) {
      try {
        fs.accessSync(dataDir, fs.constants.R_OK)
        fs.readFileSync(path.join(dataDir, 'PG_VERSION'), 'utf8')
        push('data-dir', 'Current data directory detected', true, dataDir)
      } catch {
        push('data-dir', 'Current data directory detected', false, `${dataDir} is not readable by the backend. Check permissions.`)
      }
    } else {
      push('data-dir', 'Current data directory detected', false, 'Data directory could not be detected.')
    }

    // 6 — Service must be RUNNING during Step 1 (stops only at Step 5).
    if (!service.name) {
      push('service-running', 'PostgreSQL service running', false, 'No PostgreSQL service detected.')
    } else if (service.state === 'running') {
      push('service-running', 'PostgreSQL service running', true, `“${service.name}” is running. It stays running until Step 5.`)
    } else {
      push('service-running', 'PostgreSQL service running', false, `Service state is “${service.state}”. Start PostgreSQL before migrating.`)
    }

    // 7 — Backup tools present.
    if (pgBin) {
      push('pg-tools', 'Backup tools available', true, `pg_dump/pg_restore found (${pgBin}).`)
    } else {
      push('pg-tools', 'Backup tools available', false, 'pg_dump/pg_restore were not found on this computer.')
    }

    // 8 — Permissions: data dir readable (measured above) + storage writable.
    const dirOk = checks.find((c) => c.key === 'data-dir')?.ok === true
    const storeOk = checks.find((c) => c.key === 'backup-storage')?.ok === true
    push(
      'permissions',
      'Required permissions available',
      dirOk && storeOk,
      dirOk && storeOk
        ? 'Backend can read the data directory and write to the backup storage.'
        : 'Backend lacks read access to the data directory and/or write access to the backup storage.'
    )

    // 9 — Disk space: backup drive must hold a fresh backup (db size + 20%).
    if (dbSize === null || dbSize <= 0) {
      push('disk-space', 'Sufficient disk space available', false, 'Database size could not be measured.')
    } else if (storageFreeBytes === null) {
      push('disk-space', 'Sufficient disk space available', false, 'Backup drive free space is unknown.')
    } else {
      const required = Math.ceil(dbSize * 1.2)
      push(
        'disk-space',
        'Sufficient disk space available',
        storageFreeBytes >= required,
        storageFreeBytes >= required
          ? `${storageFreeBytes.toLocaleString()} bytes free; backup needs ~${required.toLocaleString()} bytes.`
          : `Only ${storageFreeBytes.toLocaleString()} bytes free; backup needs ~${required.toLocaleString()} bytes.`
      )
    }

    // 10 — A migration target disk exists (any local drive holding data dir + margin).
    try {
      const [drives, srcSize] = await Promise.all([listLocalDrives(), getDataDirSizeBytes()])
      const need = srcSize !== null ? Math.ceil(srcSize * 1.1) : null
      const candidate = need !== null ? drives.find((d) => d.freeBytes >= need) : null
      if (candidate && need !== null) {
        push('target-disk', 'Destination disk available', true, `${candidate.root} has ${candidate.freeBytes.toLocaleString()} bytes free (needs ~${need.toLocaleString()} bytes).`)
      } else {
        push('target-disk', 'Destination disk available', false, 'No local disk currently has enough free space for the data directory copy.')
      }
    } catch (e: any) {
      push('target-disk', 'Destination disk available', false, `Drive detection failed: ${e.message}`)
    }

    // 11 — Original preserved: guarantee by design (never auto-deleted).
    push('original-preserved', 'Original directory will be preserved', true, 'This wizard never deletes the original data directory; removal is manual-only after verification.')

    return NextResponse.json({ checks, backupStorage, verifiedBackup })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Safety check failed', details: err.message },
      { status: 500 }
    )
  }
}
