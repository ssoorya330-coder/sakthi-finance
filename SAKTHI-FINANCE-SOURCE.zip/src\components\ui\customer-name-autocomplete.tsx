'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { User } from 'lucide-react'
import { IconInput } from '@/components/ui/icon-input'
import { useAuthStore } from '@/store/auth-store'
import { deviceMode } from '@/lib/device-sync/browser'
import { apiClient } from '@/services/api-client'

export interface SuggestCustomer {
  customer_code: string
  full_name: string
  phone_number: string | null
  alternate_phone: string | null
  address: string | null
  area: string | null
  city: string | null
  business: string | null
  status: string | null
}

interface CustomerNameAutocompleteProps {
  value: string
  onChange: (value: string) => void
  /** Called when the user picks a recommendation. Must only fill the form — never submit. */
  onPick: (customer: SuggestCustomer) => void
  error?: string
  placeholder?: string
  name?: string
}

const MIN_CHARS = 2
const DEBOUNCE_MS = 300
const MAX_SUGGESTIONS = 6

// Status badge colors follow the app's existing Active/Completed/Aborted
// conventions (dashboard KPIs).
function statusBadgeClass(status: string | null): string {
  switch ((status || '').toLowerCase()) {
    case 'completed':
      return 'bg-indigo-50 text-indigo-700'
    case 'aborted':
      return 'bg-red-50 text-red-700'
    case 'overdue':
      return 'bg-amber-50 text-amber-700'
    default:
      return 'bg-emerald-50 text-emerald-700'
  }
}

function statusLabel(status: string | null): string {
  const s = (status || '').trim()
  return s || 'Active'
}

/**
 * Full Name input with autocomplete recommendations from saved customers.
 * Searches the existing `/api/customers/suggest` endpoint (server-side,
 * case-insensitive partial match) with debounce + request cancellation, so
 * the customer database is never bulk-loaded into the browser.
 */
export default function CustomerNameAutocomplete({
  value,
  onChange,
  onPick,
  error,
  placeholder = 'Enter full name',
  name = 'fullName',
}: CustomerNameAutocompleteProps) {
  const [results, setResults] = useState<SuggestCustomer[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [highlightIndex, setHighlightIndex] = useState(-1)
  const containerRef = useRef<HTMLDivElement>(null)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const abortRef = useRef<AbortController | null>(null)
  const requestIdRef = useRef(0)
  // Set when a recommendation is picked so the resulting value change
  // doesn't immediately reopen the dropdown.
  const suppressRef = useRef(false)

  // Close on click/tap outside (touchstart covers Android/iOS taps).
  useEffect(() => {
    function handleOutside(e: Event) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false)
        setHighlightIndex(-1)
      }
    }
    document.addEventListener('mousedown', handleOutside)
    document.addEventListener('touchstart', handleOutside)
    return () => {
      document.removeEventListener('mousedown', handleOutside)
      document.removeEventListener('touchstart', handleOutside)
    }
  }, [])

  // Cleanup pending timers/requests on unmount.
  useEffect(() => {
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current)
      abortRef.current?.abort()
    }
  }, [])

  // Debounced search on the controlled value.
  useEffect(() => {
    if (suppressRef.current) {
      suppressRef.current = false
      return
    }
    const q = (value || '').trim()
    if (q.length < MIN_CHARS) {
      if (debounceRef.current) clearTimeout(debounceRef.current)
      abortRef.current?.abort()
      setResults([])
      setIsOpen(false)
      setHighlightIndex(-1)
      setLoading(false)
      return
    }
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      abortRef.current?.abort()
      const controller = new AbortController()
      abortRef.current = controller
      const id = ++requestIdRef.current
      setLoading(true)
      const user=useAuthStore.getState().userId
      const lookup=user&&deviceMode(user)
        ? apiClient.fetchCustomers({search:q,limit:MAX_SUGGESTIONS}).then(result=>({customers:result.data.map(c=>({...c,area:c.area_name,city:c.city_name,business:c.business_name}))}))
        : fetch(`/api/customers/suggest?q=${encodeURIComponent(q)}`, {
        credentials: 'include',
        signal: controller.signal,
      })
        .then((res) => (res.ok ? res.json() : { customers: [] }))
      lookup
        .then((data) => {
          if (requestIdRef.current !== id) return
          setResults((data.customers || []).slice(0, MAX_SUGGESTIONS))
          setHighlightIndex(-1)
          setIsOpen(true)
        })
        .catch((err) => {
          if (err?.name !== 'AbortError') {
            console.error('[CustomerNameAutocomplete] Search failed:', err)
          }
        })
        .finally(() => {
          if (requestIdRef.current === id) setLoading(false)
        })
    }, DEBOUNCE_MS)
  }, [value])

  const pick = useCallback(
    (customer: SuggestCustomer) => {
      suppressRef.current = true
      abortRef.current?.abort()
      if (debounceRef.current) clearTimeout(debounceRef.current)
      setResults([])
      setIsOpen(false)
      setHighlightIndex(-1)
      setLoading(false)
      onPick(customer)
    },
    [onPick]
  )

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false)
        setHighlightIndex(-1)
        return
      }
      if (!isOpen || results.length === 0) return
      if (e.key === 'ArrowDown') {
        e.preventDefault()
        setHighlightIndex((prev) => (prev < results.length - 1 ? prev + 1 : 0))
      } else if (e.key === 'ArrowUp') {
        e.preventDefault()
        setHighlightIndex((prev) => (prev > 0 ? prev - 1 : results.length - 1))
      } else if (e.key === 'Enter') {
        e.preventDefault()
        if (highlightIndex >= 0) {
          pick(results[highlightIndex])
        } else {
          setIsOpen(false)
        }
      }
    },
    [isOpen, results, highlightIndex, pick]
  )

  // Keep the highlighted item visible while navigating.
  useEffect(() => {
    if (highlightIndex >= 0 && dropdownRef.current) {
      dropdownRef.current
        .querySelectorAll('[data-suggest-item]')
        [highlightIndex]?.scrollIntoView({ block: 'nearest' })
    }
  }, [highlightIndex])

  return (
    <div ref={containerRef} className="relative">
      <IconInput
        icon={<User className="w-5 h-5 text-slate-400" />}
        type="text"
        name={name}
        autoComplete="off"
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        onFocus={() => {
          if (results.length > 0 && (value || '').trim().length >= MIN_CHARS) {
            setIsOpen(true)
          }
        }}
        error={error}
        rightAction={
          loading ? (
            <div className="w-4 h-4 mr-2 border-2 border-[var(--secondary)]/30 border-t-[var(--secondary)] rounded-full animate-spin" />
          ) : undefined
        }
      />

      {isOpen && results.length > 0 && (
        <div
          ref={dropdownRef}
          role="listbox"
          aria-label="Existing customer recommendations"
          className="absolute z-50 left-0 right-0 mt-1.5 bg-white rounded-xl shadow-[0_12px_32px_rgba(0,0,0,0.14)] border border-[#E8E5E0] overflow-hidden"
          style={{ maxHeight: '290px', overflowY: 'auto' }}
        >
          {results.map((customer, idx) => {
            const location = [customer.address, customer.area, customer.city]
              .filter(Boolean)
              .join(', ')
            return (
              <button
                key={customer.customer_code}
                type="button"
                role="option"
                aria-selected={idx === highlightIndex}
                data-suggest-item
                onClick={() => pick(customer)}
                onMouseEnter={() => setHighlightIndex(idx)}
                className={`w-full text-left px-3 py-2 border-b border-[#E8E5E0]/50 last:border-0 transition-colors ${
                  idx === highlightIndex ? 'bg-[var(--background)]' : 'hover:bg-[var(--background)]/60'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <p className="font-semibold text-[13px] text-[var(--text-primary)] truncate">
                    {customer.full_name}
                  </p>
                  <span
                    className={`text-[10px] font-semibold uppercase tracking-wide px-1.5 py-px rounded-full flex-shrink-0 ${statusBadgeClass(customer.status)}`}
                  >
                    {statusLabel(customer.status)}
                  </span>
                  <span className="text-[10px] font-mono text-[#9A9AA2] bg-[var(--background)] px-1.5 py-px rounded flex-shrink-0">
                    {customer.customer_code}
                  </span>
                </div>
                {(customer.phone_number || customer.alternate_phone) && (
                  <p className="text-xs text-[#6A6A72] mt-0.5 truncate">
                    {customer.phone_number ? `Mobile: ${customer.phone_number}` : null}
                    {customer.phone_number && customer.alternate_phone ? ' • ' : null}
                    {customer.alternate_phone ? `Alternate: ${customer.alternate_phone}` : null}
                  </p>
                )}
                {location && (
                  <p className="text-xs text-[#9A9AA2] truncate">
                    {customer.address ? `Address: ${customer.address}` : null}
                    {customer.address && (customer.area || customer.city) ? ' • ' : null}
                    {[customer.area ? `Area: ${customer.area}` : null, customer.city ? `City: ${customer.city}` : null]
                      .filter(Boolean)
                      .join(' • ')}
                  </p>
                )}
                {customer.business && (
                  <p className="text-xs text-[#9A9AA2] truncate">Business: {customer.business}</p>
                )}
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}
