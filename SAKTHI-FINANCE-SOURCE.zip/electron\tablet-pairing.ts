import { randomBytes, randomInt, randomUUID, createHash, timingSafeEqual } from 'node:crypto'

export type TabletEnvironment = 'development' | 'production'
export interface PairingScope { ownerId: string; googleSubject: string; laptopId: string; databaseId: string; environment: TabletEnvironment }
export interface TabletGrant extends PairingScope { deviceId: string; deviceName: string; tokenHash: string; approvedAt: number }
export interface GrantStore {
  // Must durably commit before resolving; failure must leave no partial grant.
  save(grant: TabletGrant): Promise<void>
  find(tokenHash: string): Promise<TabletGrant | null>
  revoke(scope: PairingScope, deviceId: string): Promise<void>
}
export class PairingError extends Error {
  constructor(readonly status: number, message: string) { super(message) }
}
const hash = (value: string) => createHash('sha256').update(value).digest('hex')
const sameScope = (a: PairingScope, b: PairingScope) =>
  a.ownerId === b.ownerId && a.googleSubject === b.googleSubject && a.laptopId === b.laptopId && a.databaseId === b.databaseId && a.environment === b.environment
const deviceIdPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
interface Challenge { scope: PairingScope; codeHash: string; expiresAt: number; attempts: number; claimed: boolean }
interface Pending { scope: PairingScope; deviceId: string; deviceName: string; expiresAt: number; tokenHash: string; phase: 'pending' | 'saving' | 'approved' | 'rejected' }

/** Transport-independent pairing policy. Scope must come from the authenticated
 * laptop session, and googleSubject from server-side Google token verification.
 * This module does not accept email strings as proof of identity. */
export class TabletPairing {
  private challenge?: Challenge
  private pending = new Map<string, Pending>()
  constructor(private store: GrantStore, private now: () => number = Date.now) {}
  private sweep() {
    for (const [id, value] of this.pending) if (value.expiresAt <= this.now() && value.phase !== 'saving') this.pending.delete(id)
  }
  generate(scope: PairingScope) {
    this.sweep()
    if (!scope.ownerId || !scope.googleSubject || !scope.laptopId || !scope.databaseId || !['development','production'].includes(scope.environment)) throw new PairingError(403,'Authenticated laptop identity required')
    if (this.pending.size >= 20) throw new PairingError(429,'Too many pairing requests; wait for expiry')
    const code = String(randomInt(0, 1000000)).padStart(6, '0')
    const expiresAt = this.now() + 5 * 60_000
    this.challenge = { scope: {...scope}, codeHash: hash(code), expiresAt, attempts: 0, claimed: false }
    return { code, expiresAt }
  }
  request(input: { code: string; deviceId: string; deviceName: string; verifiedGoogleSubject: string }) {
    this.sweep()
    const challenge = this.challenge
    if (!challenge || challenge.expiresAt <= this.now() || challenge.claimed) throw new PairingError(403,'Pairing code unavailable or expired')
    if (++challenge.attempts > 5) throw new PairingError(429,'Pairing attempt limit reached; generate a new code on the laptop')
    if (!/^\d{6}$/.test(input.code) || !timingSafeEqual(Buffer.from(hash(input.code),'hex'),Buffer.from(challenge.codeHash,'hex')) || input.verifiedGoogleSubject !== challenge.scope.googleSubject) throw new PairingError(403,'Pairing identity or code does not match')
    if (!deviceIdPattern.test(input.deviceId) || typeof input.deviceName !== 'string' || !input.deviceName.trim() || input.deviceName.length > 80 || /[\x00-\x1f\x7f]/.test(input.deviceName)) throw new PairingError(400,'Invalid device identity')
    if (this.pending.size >= 20) throw new PairingError(429,'Too many pairing requests')
    challenge.claimed = true // Consume before any asynchronous approval/storage.
    const requestId = randomUUID()
    // The tablet retains this secret over its pinned TLS channel. Only its hash
    // is stored on the laptop; it authorizes nothing until approval commits.
    const token = randomBytes(32).toString('base64url')
    this.pending.set(requestId, { scope: {...challenge.scope}, deviceId: input.deviceId,
      deviceName: input.deviceName.trim(), expiresAt: challenge.expiresAt, tokenHash: hash(token), phase: 'pending' })
    return { requestId, token, expiresAt: challenge.expiresAt }
  }
  list(scope: PairingScope) {
    this.sweep()
    return [...this.pending].filter(([,p])=>sameScope(p.scope,scope)&&p.phase==='pending').map(([requestId,p])=>({requestId,deviceId:p.deviceId,deviceName:p.deviceName,expiresAt:p.expiresAt}))
  }
  async decide(scope: PairingScope, requestId: string, approve: boolean) {
    this.sweep()
    const pending = this.pending.get(requestId)
    if (!pending || pending.phase !== 'pending' || !sameScope(scope,pending.scope) || pending.expiresAt <= this.now()) throw new PairingError(409,'Pairing request is unavailable')
    if (!approve) { pending.phase = 'rejected'; return }
    pending.phase = 'saving'
    try {
      await this.store.save({...pending.scope,deviceId:pending.deviceId,deviceName:pending.deviceName,tokenHash:pending.tokenHash,approvedAt:this.now()})
      pending.phase = 'approved'
    } catch { pending.phase = 'pending'; throw new PairingError(503,'Approval could not be saved; no device access granted') }
  }
  async authenticate(token: string, scope: PairingScope) {
    if (!/^[A-Za-z0-9_-]{43}$/.test(token)) throw new PairingError(401,'Invalid device credential')
    const grant = await this.store.find(hash(token))
    if (!grant || !sameScope(scope,grant)) throw new PairingError(403,'Device is not authorized for this laptop, database and account')
    return grant
  }
  async revoke(scope: PairingScope, deviceId: string) { await this.store.revoke(scope,deviceId) }
}
