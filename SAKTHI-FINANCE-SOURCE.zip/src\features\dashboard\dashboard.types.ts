export interface KpiCardData {
  id: string
  title: string
  value: number
  change: number
  changeLabel: string
  icon: string
  iconColor: string
  iconBg: string
  sparkData: number[]
  onClick?: () => void
}

export interface CollectionDataPoint {
  day: string
  amount: number
  count: number
}

export interface LoanAnalyticsPoint {
  month: string
  disbursed: number
  collected: number
  pending: number
}

export interface CollectionPerformancePoint {
  day: string
  target: number
  actual: number
}

export interface CustomerGrowthPoint {
  month: string
  newCustomers: number
  totalCustomers: number
}

export interface LoanStatusData {
  name: string
  value: number
  color: string
}

export interface PaymentDistributionData {
  name: string
  value: number
  color: string
}

export interface FinancialSummaryCard {
  id: string
  label: string
  value: number
  icon: string
  color: string
}

export interface BusinessInsight {
  id: string
  label: string
  value: string
  icon: string
  color: string
}

export interface DateRange {
  start: Date
  end: Date
  label: string
}

export interface KypMiniCardData {
  id: string
  label: string
  value: number
  change: number
  icon: string
  gradient: string
  sparkData: number[]
}
