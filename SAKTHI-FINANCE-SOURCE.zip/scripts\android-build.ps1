param([string[]]$Tasks = @('assembleDebug','testDebugUnitTest'))
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$env:JAVA_HOME = (Get-ChildItem "$projectRoot\android-toolchain\jdk" -Directory | Select-Object -First 1).FullName
$env:ANDROID_HOME = "$projectRoot\android-toolchain\sdk"
$env:GRADLE_USER_HOME = "$projectRoot\android-toolchain\gradle-cache"
& "$projectRoot\android-toolchain\gradle-8.11.1\bin\gradle.bat" -p "$projectRoot\android" --console=plain @Tasks
if ($LASTEXITCODE -ne 0) { throw "Android build failed ($LASTEXITCODE)" }
