using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
using System.Web.Script.Serialization;

// Bounded mono PCM capture. Audio travels through a private pipe, never a file.
class AudioCapture {
    [StructLayout(LayoutKind.Sequential, Pack = 2)]
    struct Format { public ushort tag, channels; public uint rate, bytesPerSecond; public ushort align, bits, extra; }
    [StructLayout(LayoutKind.Sequential)]
    struct Header { public IntPtr data; public uint length, recorded; public UIntPtr user; public uint flags, loops; public IntPtr next; public UIntPtr reserved; }
    [DllImport("winmm.dll")] static extern uint waveInOpen(out IntPtr handle, uint device, ref Format format, IntPtr callback, IntPtr instance, uint flags);
    [DllImport("winmm.dll")] static extern uint waveInPrepareHeader(IntPtr handle, IntPtr header, uint size);
    [DllImport("winmm.dll")] static extern uint waveInUnprepareHeader(IntPtr handle, IntPtr header, uint size);
    [DllImport("winmm.dll")] static extern uint waveInAddBuffer(IntPtr handle, IntPtr header, uint size);
    [DllImport("winmm.dll")] static extern uint waveInStart(IntPtr handle);
    [DllImport("winmm.dll")] static extern uint waveInReset(IntPtr handle);
    [DllImport("winmm.dll")] static extern uint waveInClose(IntPtr handle);
    static volatile bool stop, cancel;
    static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = 2000000 };
    static void Emit(object value) { Console.WriteLine(Json.Serialize(value)); Console.Out.Flush(); }
    static void Check(uint result) { if (result != 0) throw new InvalidOperationException("audio-capture"); }
    static byte[] Wave(byte[] pcm) {
        using (var stream = new MemoryStream()) using (var writer = new BinaryWriter(stream)) {
            writer.Write(Encoding.ASCII.GetBytes("RIFF")); writer.Write(36 + pcm.Length);
            writer.Write(Encoding.ASCII.GetBytes("WAVEfmt ")); writer.Write(16);
            writer.Write((ushort)1); writer.Write((ushort)1); writer.Write(16000); writer.Write(32000);
            writer.Write((ushort)2); writer.Write((ushort)16);
            writer.Write(Encoding.ASCII.GetBytes("data")); writer.Write(pcm.Length); writer.Write(pcm);
            return stream.ToArray();
        }
    }
    static int Main(string[] args) {
        Console.OutputEncoding = new UTF8Encoding(false);
        if (args.Length == 1 && args[0] == "--self-test") {
            var wav = Wave(new byte[32000]);
            Emit(new { type = "self-test", waveLength = wav.Length, headerSize = Marshal.SizeOf(typeof(Header)), formatSize = Marshal.SizeOf(typeof(Format)), rate = BitConverter.ToInt32(wav, 24) });
            return 0;
        }
        if (args.Length != 0) return 2;
        IntPtr handle = IntPtr.Zero;
        var headers = new IntPtr[4]; var buffers = new IntPtr[4]; var prepared = new bool[4];
        uint size = (uint)Marshal.SizeOf(typeof(Header));
        try {
            var format = new Format { tag = 1, channels = 1, rate = 16000, bytesPerSecond = 32000, align = 2, bits = 16 };
            Check(waveInOpen(out handle, UInt32.MaxValue, ref format, IntPtr.Zero, IntPtr.Zero, 0));
            for (int i = 0; i < 4; i++) {
                buffers[i] = Marshal.AllocHGlobal(3200); headers[i] = Marshal.AllocHGlobal((int)size);
                Marshal.StructureToPtr(new Header { data = buffers[i], length = 3200 }, headers[i], false);
                Check(waveInPrepareHeader(handle, headers[i], size)); prepared[i] = true;
                Check(waveInAddBuffer(handle, headers[i], size));
            }
            var input = new Thread(() => { try { cancel = Console.ReadLine() != "stop"; } catch { cancel = true; } stop = true; });
            input.IsBackground = true; input.Start();
            Check(waveInStart(handle)); Emit(new { type = "ready" });
            using (var pcm = new MemoryStream()) {
                var clock = System.Diagnostics.Stopwatch.StartNew();
                long lastSound = 0, lastPreview = 0; int soundSamples = 0; bool detected = false;
                double noiseFloor = 0.0015;
                const double minimumThreshold = 0.0025, adaptiveMultiplier = 1.8;
                const int endSilenceMs = 1400, previewIntervalMs = 600;
                var bytes = new byte[3200]; int next = 0;
                while (!stop && clock.ElapsedMilliseconds < 30000) {
                    var header = (Header)Marshal.PtrToStructure(headers[next], typeof(Header));
                    if ((header.flags & 1) == 0) { Thread.Sleep(10); continue; }
                    int count = (int)Math.Min(header.recorded, 3200);
                    Marshal.Copy(header.data, bytes, 0, count); pcm.Write(bytes, 0, count);
                    double energy = 0;
                    for (int n = 0; n + 1 < count; n += 2) { double sample = BitConverter.ToInt16(bytes, n) / 32768.0; energy += sample * sample; }
                    double rms = count > 1 ? Math.Sqrt(energy / (count / 2)) : 0;
                    // Track quieter frames only so speech does not raise its own gate.
                    // All captured PCM is retained, including calibration/pre-roll and pauses.
                    if (rms < noiseFloor * 1.8) noiseFloor = noiseFloor * 0.92 + rms * 0.08;
                    double threshold = Math.Max(minimumThreshold, noiseFloor * adaptiveMultiplier);
                    if (count > 0 && rms > threshold) {
                        soundSamples += count / 2; lastSound = clock.ElapsedMilliseconds;
                        if (!detected && soundSamples >= 3200) { detected = true; Emit(new { type = "sound" }); }
                    } else if (!detected) soundSamples = 0;
                    // Keep 600 ms before sustained speech, rather than many seconds
                    // of leading silence. Calibration never discards a word onset.
                    if (!detected && pcm.Length > 19200) {
                        var leading = pcm.ToArray();
                        pcm.SetLength(0); pcm.Write(leading, leading.Length - 19200, 19200);
                        Array.Clear(leading, 0, leading.Length);
                    }
                    Check(waveInAddBuffer(handle, headers[next], size)); next = (next + 1) % 4;
                    if (detected && clock.ElapsedMilliseconds - lastPreview >= previewIntervalMs) {
                        lastPreview = clock.ElapsedMilliseconds;
                        var snapshot = Wave(pcm.ToArray());
                        Emit(new { type = "preview-audio", data = Convert.ToBase64String(snapshot) });
                        Array.Clear(snapshot, 0, snapshot.Length);
                    }
                    if (detected && clock.ElapsedMilliseconds - lastSound > endSilenceMs) break;
                    if (!detected && clock.ElapsedMilliseconds > 12000) break;
                }
                // Reset returns the final partial buffer too (important on manual stop).
                Check(waveInReset(handle));
                for (int i = 0; i < 4; i++) {
                    var header = (Header)Marshal.PtrToStructure(headers[(next + i) % 4], typeof(Header));
                    int count = (int)Math.Min(header.recorded, 3200);
                    if ((header.flags & 1) != 0 && count > 0) { Marshal.Copy(header.data, bytes, 0, count); pcm.Write(bytes, 0, count); }
                }
                if (!cancel) {
                    if (!detected) Emit(new { type = "error", error = "no-speech" });
                    else Emit(new { type = "audio", data = Convert.ToBase64String(Wave(pcm.ToArray())) });
                }
                Array.Clear(bytes, 0, bytes.Length);
            }
            return 0;
        } catch { if (!cancel) Emit(new { type = "error", error = "audio-capture" }); return 1; }
        finally {
            if (handle != IntPtr.Zero) waveInReset(handle);
            for (int i = 0; i < 4; i++) {
                if (prepared[i]) waveInUnprepareHeader(handle, headers[i], size);
                if (headers[i] != IntPtr.Zero) Marshal.FreeHGlobal(headers[i]);
                if (buffers[i] != IntPtr.Zero) Marshal.FreeHGlobal(buffers[i]);
            }
            if (handle != IntPtr.Zero) waveInClose(handle);
        }
    }
}
