'use client'

import { useEffect } from 'react'
import { useAuthStore } from '@/store/auth-store'
import { setTokenProvider, setAccessTokenProvider } from '@/api/client'
import { setAuthProvider as setNewApiClientProvider } from '@/services/api-client'
import { readAccessTokenFromCookie, clearClientAuthStorage } from '@/lib/auth/client-auth'
import { createSessionSync } from '@/lib/auth/session-sync'
import { clearAllOfflineCustomerCaches } from '@/store/customer-store'

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const userId = useAuthStore((s) => s.userId)

  useEffect(() => {
    const tokenProvider = async () => readAccessTokenFromCookie()
    const userIdProvider = () => useAuthStore.getState().userId || null
    setAccessTokenProvider(tokenProvider)
    setTokenProvider(tokenProvider, userIdProvider)
    setNewApiClientProvider(tokenProvider, userIdProvider)

    let disposed = false
    const sync = createSessionSync({
      getState: () => useAuthStore.getState(),
      fetch: (input, init) => fetch(input, init),
      apply: (user) => useAuthStore.getState().setUser({
        userId: user.id, email: user.email, name: user.name, role: user.role,
      }),
      roleChanged: (role) => {
        // Reload also discards server component, query and in-memory data caches.
        clearAllOfflineCustomerCaches()
        window.location.replace(role === 'customer' ? '/dashboard/my-account' : '/dashboard')
      },
      dataFormat: (format) => {
        // Each open tab reloads once after the customer PK migration, clearing
        // in-memory UUID records as well as older offline snapshots.
        const previous = sessionStorage.getItem('sf-customer-id-format')
        sessionStorage.setItem('sf-customer-id-format', format)
        if (format === 'bigint' && previous !== format) {
          clearAllOfflineCustomerCaches()
          window.location.reload()
        }
      },
      signedOut: () => {
        clearClientAuthStorage()
        useAuthStore.getState().logout()
        window.location.replace('/login')
      },
    })
    void sync.check().finally(() => {
      if (!disposed) useAuthStore.getState().setLoading(false)
    })
    const check = () => {
      if (document.visibilityState === 'visible' && useAuthStore.getState().isAuthenticated) void sync.check()
    }
    const onStorage = (event: StorageEvent) => {
      if (event.key === 'sf-auth') check()
    }
    // Database-backed checks work across browsers/devices and server instances.
    const timer = window.setInterval(check, 3000)
    window.addEventListener('focus', check)
    window.addEventListener('online', check)
    window.addEventListener('storage', onStorage)
    document.addEventListener('visibilitychange', check)
    return () => {
      disposed = true
      sync.dispose()
      window.clearInterval(timer)
      window.removeEventListener('focus', check)
      window.removeEventListener('online', check)
      window.removeEventListener('storage', onStorage)
      document.removeEventListener('visibilitychange', check)
    }
  }, [userId])

  return <>{children}</>
}
