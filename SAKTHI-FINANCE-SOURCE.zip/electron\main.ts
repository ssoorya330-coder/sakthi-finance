import { app, BrowserWindow, dialog, shell, protocol, net } from 'electron'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { existsSync, readFileSync, statSync } from 'node:fs'
import { trustedRenderer, rendererFile } from './policy'
import { logEvent } from './logging'
import { firstRunSetup } from './first-run'
import { startManagedDatabase, stopManagedDatabase, type ManagedDatabase } from './managed-postgres'
import { validateRuntimeConfig, databaseProbeConfig } from '../scripts/desktop/runtime-config.mjs'

/**
 * Sakthi Finance — Electron main process.
 *
 * Production loads the bundled static export from application files
 * (loadFile). No HTTP server is started: data flows renderer → preload →
 * IPC → in-process API bridge (existing handlers) → PostgreSQL.
 *
 * Development mode (SAKTHI_ELECTRON_DEV=1) may load the Next dev server for
 * hot reload — production never does.
 *
 * IMPORTANT: auth modules read signing keys at require time, so the private
 * runtime configuration is loaded before they are imported (lazy require).
 */

const isDev = !app.isPackaged && process.env.SAKTHI_ELECTRON_DEV === '1'

// Static-export assets are emitted with absolute /_next/... URLs, which do
// not resolve over file:// . A custom app:// scheme serves the bundled
// out-desktop-build directory as an http-like origin (absolute paths,
// correct MIME types) while keeping webSecurity enabled.
const RENDERER_ROOT = path.join(__dirname, '../out-desktop-build')
const MIME_TYPES: Record<string, string> = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.mjs': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.map': 'application/json',
  '.txt': 'text/plain',
  '.webmanifest': 'application/manifest+json',
}

protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } },
])

function resolveRendererFile(urlPath: string): string | null {
  try {
    const candidate = rendererFile(RENDERER_ROOT, urlPath)
    if (!candidate) return null
    // Directories must NOT match existsSync — net.fetch on a directory 404s.
    const stat = existsSync(candidate) ? statSync(candidate) : null
    if (stat?.isFile()) return candidate
    // Clean-URL fallbacks: /dashboard -> dashboard.html, then /dashboard/index.html
    const flat = `${candidate}.html`
    if (existsSync(flat)) return flat
    const nested = path.join(candidate, 'index.html')
    if (existsSync(nested)) return nested
    return null
  } catch {
    return null
  }
}

function createAppProtocolHandler(): (request: Request) => Response | Promise<Response> {
  return (request) => {
    if (!trustedRenderer(request.url) || request.method !== 'GET') return new Response('Forbidden', { status: 403 })
    const { pathname } = new URL(request.url)
    const file = resolveRendererFile(pathname === '/' ? '/index.html' : pathname)
    if (!file) {
      return new Response('Not found', { status: 404 })
    }
    const mime = MIME_TYPES[path.extname(file).toLowerCase()] ?? 'application/octet-stream'
    return net.fetch(pathToFileURL(file).toString(), { bypassCustomProtocolHandlers: true })
      .then((response) => new Response(response.body, { status: response.status, headers: {
        'content-type': mime, 'x-content-type-options': 'nosniff',
        'content-security-policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; font-src 'self' data:; connect-src 'self' https:; worker-src 'self' blob:; object-src 'none'; base-uri 'none'; frame-src 'none'",
      } }))
      .catch(() => new Response('Not found', { status: 404 }))
  }
}

let mainWindow: BrowserWindow | null = null
let managedDatabase: ManagedDatabase | null = null
let startupComplete = false

function resolveIconPath(): string | undefined {
  const candidates = [
    path.join(__dirname, 'icon.ico'),
    path.join(__dirname, 'icon.png'),
    path.join(__dirname, '../renderer/icon.png'),
    path.join(process.resourcesPath ?? '', 'icon.png'),
  ]
  return candidates.find((candidate) => existsSync(candidate))
}

/**
 * Private runtime settings (database credentials, OAuth client, signing
 * keys). Kept at the same location the desktop setup already uses; never
 * shipped inside the application.
 */
function loadDesktopConfig(): void {
  const candidates = [process.env.SAKTHI_DESKTOP_CONFIG ||
    path.join(app.getPath('appData'), 'com.sakthifinance.desktop', 'runtime.json')]
  for (const file of candidates) {
    try {
      const config = validateRuntimeConfig(JSON.parse(readFileSync(file, 'utf8'))) as Record<string, string>
      for (const key of ['DATABASE_URL', 'DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']) delete process.env[key]
      for (const [key, value] of Object.entries(config)) {
        if (typeof value === 'string' && value) process.env[key] = value
      }
      return
    } catch {
      // Try the next candidate; a missing file is reported by validation below.
    }
  }
  throw new Error('Private desktop configuration required')
}

function validateDesktopConfig(): void {
  const hasDatabase = Boolean(
    process.env.DATABASE_URL ||
      ['DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD'].every((key) => process.env[key]?.trim())
  )
  const hasKeys = Boolean(
    process.env.JWT_ACCESS_SECRET && process.env.JWT_ACCESS_SECRET.length >= 32 &&
    process.env.JWT_REFRESH_SECRET && process.env.JWT_REFRESH_SECRET.length >= 32
  )
  if (!hasDatabase || !hasKeys) {
    dialog.showErrorBox(
      'Sakthi Finance — setup required',
      'Private desktop settings are missing or invalid. Complete the desktop setup, then start Sakthi Finance again.'
    )
    app.exit(1)
  }
}

function createMainWindow(): void {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 600,
    title: 'Sakthi Finance',
    show: false,
    autoHideMenuBar: true,
    icon: resolveIconPath(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      spellcheck: false,
    },
  })

  const window = mainWindow
  window.once('ready-to-show', () => {
    if (window.isDestroyed()) return
    window.maximize()
    window.show()
  })

  if (isDev) {
    void mainWindow.loadURL('http://localhost:3000')
  } else {
    void mainWindow.loadURL('app://sakthi.local/index.html')
  }

  // Open external links in the user's browser, never in the app window.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    // Existing print/report windows write their own HTML into a blank page.
    if (url === 'about:blank') return { action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true, preload: undefined } } }
    return { action: 'deny' }
  })

  // app:// pages must stay inside the window; only https links go external.
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!trustedRenderer(url, isDev)) {
      event.preventDefault()
    }
  })

  mainWindow.on('closed', () => {
    const { stopDesktopVoice } = require('./ipc') as typeof import('./ipc')
    stopDesktopVoice()
    mainWindow = null
  })
  mainWindow.webContents.on('render-process-gone', () => { logEvent('renderer_failure'); dialog.showErrorBox('Sakthi Finance', 'The application window stopped. Restart the app; saved PostgreSQL data is unchanged.') })
  mainWindow.webContents.session.setPermissionRequestHandler((contents, permission, callback) => {
    if (contents !== mainWindow?.webContents || !trustedRenderer(contents.getURL(), isDev) || permission !== 'media') return callback(false)
    void dialog.showMessageBox(mainWindow!, { type: 'question', buttons: ['Allow microphone', 'Cancel'], defaultId: 1, cancelId: 1, message: 'Allow microphone access for voice entry?' }).then(result => callback(result.response === 0))
  })
}

const gotLock = app.requestSingleInstanceLock()
if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore()
      mainWindow.focus()
    }
  })

  app.whenReady().then(async () => {
    logEvent('startup')
    process.env.SAKTHI_APP_ROOT = app.getAppPath()
    process.env.SAKTHI_HELPER_ROOT = app.isPackaged
      ? path.join(process.resourcesPath, 'native') : path.join(__dirname, 'native')
    process.env.SAKTHI_NODE_EXE = path.join(process.env.SAKTHI_HELPER_ROOT, 'node.exe')
    process.chdir(app.getPath('userData'))
    if (!process.env.SAKTHI_ELECTRON_DEV) (process.env as Record<string, string | undefined>).NODE_ENV = 'production'

    // Persist only fixed event codes. Existing library logs may contain PII.
    if (!isDev) {
      try {
        console.log = () => {}
        console.error = () => { logEvent('unexpected_failure') }
        console.warn = () => {}
        process.on('uncaughtException', () => { logEvent('unexpected_failure'); app.exit(1) })
        process.on('unhandledRejection', () => logEvent('unexpected_failure'))
      } catch { /* logging is best-effort */ }
    }

    const settingsFile = process.env.SAKTHI_DESKTOP_CONFIG || path.join(app.getPath('appData'), 'com.sakthifinance.desktop', 'runtime.json')
    const settingsDirectory = path.dirname(settingsFile)
    if (!existsSync(settingsFile)) {
      if (process.env.SAKTHI_DESKTOP_CONFIG) throw Error('Explicit desktop configuration missing')
      if (!await firstRunSetup(settingsDirectory, process.env.SAKTHI_HELPER_ROOT!)) { app.quit(); return }
    }
    loadDesktopConfig()
    validateDesktopConfig()
    for (;;) {
      try { managedDatabase = await startManagedDatabase(settingsDirectory, process.env.SAKTHI_HELPER_ROOT!, process.env); break }
      catch {
        const result = await dialog.showMessageBox({ type: 'error', message: 'Configured storage is unavailable', detail: 'Connect the original selected drive. Sakthi Finance will not create a new database or replace your data. If the drive is connected, the saved storage settings need inspection.', buttons: ['Retry', 'Exit'], cancelId: 1 })
        if (result.response === 1) { await stopManagedDatabase(process.env.SAKTHI_HELPER_ROOT!, managedDatabase).catch(() => {}); app.quit(); return }
      }
    }
    // Existing backup/export functions locate the bundled PostgreSQL tools.
    process.env.PATH = path.join(process.env.SAKTHI_HELPER_ROOT!, 'postgres', 'bin') + path.delimiter + (process.env.PATH || '')

    // Read-only preflight: never initialize a replacement if storage is absent.
    const { Client } = require('pg') as typeof import('pg')
    for (;;) {
      const probe = new Client(databaseProbeConfig(process.env))
      try {
        await probe.connect()
        const result = await probe.query("SELECT to_regclass('public.customers') IS NOT NULL AND to_regclass('public.loans') IS NOT NULL AND to_regclass('public.payments') IS NOT NULL AS ready")
        if (!result.rows[0]?.ready) throw Error('Existing database required')
        break
      } catch {
        logEvent('database_failure')
        const result = await dialog.showMessageBox({ type: 'error', message: 'Storage offline', detail: 'Connect the configured storage and start PostgreSQL. Your database will not be replaced.', buttons: ['Retry', 'Exit'], cancelId: 1, defaultId: 0 })
        if (result.response === 1) { await stopManagedDatabase(process.env.SAKTHI_HELPER_ROOT!, managedDatabase).catch(() => {}); app.quit(); return }
      } finally { await probe.end().catch(() => {}) }
    }

    if (!isDev) {
      protocol.handle('app', createAppProtocolHandler())
    }

    // Lazy require: session/API modules read signing keys at load time.
    const { registerIpcHandlers, restoreStartupSession } = require('./ipc') as
      typeof import('./ipc')
    const { closePool } = require('../src/server/database') as
      typeof import('../src/server/database')

    registerIpcHandlers(() => mainWindow)
    await restoreStartupSession().catch(() => undefined)
    createMainWindow()
    const { startOnlineUpdates } = require('./ipc') as typeof import('./ipc')
    startOnlineUpdates()
    startupComplete = true
    logEvent('ready')

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createMainWindow()
    })

    let quitting = false
    app.on('before-quit', async (event) => {
      if (quitting) return
      quitting = true
      event.preventDefault()
      const { stopOnlineUpdateChecks } = require('./ipc') as typeof import('./ipc')
      stopOnlineUpdateChecks()
      let shutdownSucceeded = false
      try {
        const { cancelPendingSignIn, stopDesktopVoice, stopTabletService } = require('./ipc') as typeof import('./ipc')
        cancelPendingSignIn()
        stopDesktopVoice()
        await stopTabletService()
        await closePool()
        const worker = require('./api/routes.js') as { closePool: () => Promise<void> }
        await worker.closePool()
        await stopManagedDatabase(process.env.SAKTHI_HELPER_ROOT!, managedDatabase)
        shutdownSucceeded = true
      } catch {
        logEvent('database_failure')
        dialog.showErrorBox('Application closed safely without updating', 'Storage could not finish shutting down. No update was started. Reopen Sakthi Finance and check the configured storage before trying again.')
      } finally {
        if (!shutdownSucceeded) { process.exit(1); return }
        const { launchPendingUpdate } = require('./ipc') as typeof import('./ipc')
        await launchPendingUpdate()?.catch(() => dialog.showErrorBox('Update not installed', 'The installer could not start. Reopen Sakthi Finance and try again.'))
        logEvent('shutdown')
        const { launchPendingOnlineUpdate } = require('./ipc') as typeof import('./ipc')
        try {
          if (launchPendingOnlineUpdate()) {
            // electron-updater schedules app.quit after spawning NSIS. Pools and
            // managed PostgreSQL are already closed; let that normal quit finish.
            setTimeout(() => app.exit(0), 15000).unref()
            return
          }
        } catch { dialog.showErrorBox('Update not installed', 'The downloaded installer could not start. Reopen Sakthi Finance and try again.') }
        process.exit(0)
      }
    })
  }).catch(async () => { await stopManagedDatabase(process.env.SAKTHI_HELPER_ROOT!, managedDatabase).catch(() => {}); logEvent('setup_failure'); dialog.showErrorBox('Sakthi Finance', 'Desktop startup failed. Check private settings and configured storage, then restart.'); app.exit(1) })
}

app.on('window-all-closed', () => {
  if (startupComplete && process.platform !== 'darwin') app.quit()
})
