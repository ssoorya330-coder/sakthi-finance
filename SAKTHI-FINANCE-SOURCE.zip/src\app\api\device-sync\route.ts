import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbTransaction } from '@/server/database'
import { customerRevision, digest, ensureDeviceSyncSchema } from '@/server/device-sync'
import { syncTransaction } from '@/server/sync-context'
import { recordAuditEvent, actorFromAuthUser } from '@/server/audit'
import { POST as addCustomer } from '@/app/api/customer/route'
import { PUT as editCustomer } from '@/app/api/customer/[id]/route'
import { POST as addLoan } from '@/app/api/loan/route'
import { PUT as editLoan } from '@/app/api/loan/[id]/route'
import { POST as addPayment } from '@/app/api/payment/route'
import { PUT as editPayment } from '@/app/api/payment/[id]/route'
import type { SyncOperation } from '@/lib/device-sync/types'

const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('customers:create')
  if (auth.error) return auth.error
  if (request.headers.get('X-Sync-Owner') !== auth.user.userId) {
    return NextResponse.json({ error: 'Account changed. Sign in to the account that owns these offline records.' }, { status: 403 })
  }
  try {
    const op = await request.json() as SyncOperation
    if (!uuid.test(op.id) || !uuid.test(op.deviceId) || !['customer','loan','payment'].includes(op.kind)
      || !['POST','PUT'].includes(op.method) || !op.data || typeof op.data !== 'object'
      || !Number.isFinite(Date.parse(op.recordedAt)) || JSON.stringify(op).length > 100000) {
      return NextResponse.json({ error: 'Invalid synchronization record.' }, { status: 400 })
    }
    await ensureDeviceSyncSchema()
    const owner = auth.user.userId
    const fingerprint = digest({ kind: op.kind, method: op.method, data: op.data, recordId: op.recordId, customerId: op.customerId, recordedAt: op.recordedAt, deviceId: op.deviceId })
    const result = await dbTransaction(async client => syncTransaction.run({ client }, async () => {
      await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [`device-sync:${owner}`])
      const receipt = await client.query('SELECT fingerprint,response FROM device_sync_receipts WHERE owner_id=$1 AND operation_id=$2', [owner,op.id])
      if (receipt.rows.length) {
        if (receipt.rows[0].fingerprint !== fingerprint) throw Object.assign(new Error('This operation ID was already used for different data.'), { status: 409 })
        return { ...receipt.rows[0].response, duplicate: true }
      }
      const resolve = async (id: string) => {
        if (!id) return id
        const r = await client.query(`SELECT response->'mappings'->>$2 AS id FROM device_sync_receipts WHERE owner_id=$1 AND (response->'mappings') ? $2 LIMIT 1`, [owner,String(id)])
        return r.rows[0]?.id || String(id)
      }
      let customerId = await resolve(op.customerId)
      const recordId = await resolve(op.recordId)
      if (op.method === 'PUT' && op.kind !== 'customer') {
        const table = op.kind === 'loan' ? 'loans' : 'payments'
        const key = op.kind === 'loan' ? 'loan_id' : 'payment_id'
        const owned = await client.query(`SELECT customer_id::text FROM ${table} WHERE ${key}::text=$1 AND user_id=$2`, [recordId,owner])
        if (owned.rows[0]?.customer_id !== customerId) throw Object.assign(new Error('Record does not belong to this customer.'), { status: 404 })
      }
      if (op.method === 'PUT' && op.kind === 'customer' && recordId !== customerId) throw Object.assign(new Error('Customer identity mismatch.'), { status: 400 })
      if (!(op.kind === 'customer' && op.method === 'POST')) {
        // Lock both parent and children so online writes cannot slip between
        // revision comparison and the existing handler's mutation.
        const c = await client.query('SELECT id FROM customers WHERE id::text=$1 AND user_id=$2 FOR UPDATE', [customerId,owner])
        if (!c.rows.length) throw Object.assign(new Error('Customer is missing or belongs to another account.'), { status: 409 })
        await client.query('SELECT loan_id FROM loans WHERE customer_id::text=$1 AND user_id=$2 ORDER BY loan_id FOR UPDATE', [customerId,owner])
        await client.query('SELECT payment_id FROM payments WHERE customer_id::text=$1 AND user_id=$2 ORDER BY payment_id FOR UPDATE', [customerId,owner])
        const current = await customerRevision(client,owner,customerId)
        if (!current || op.baseRevision !== current.revision) throw Object.assign(new Error('This customer or their financial records changed on the laptop. Review both versions before continuing.'), { status: 409, current })
      }
      const data = { ...op.data }
      delete data.__localLoanId
      if (op.kind !== 'customer' || 'customer_id' in data) data.customer_id = customerId
      if (data.loan_id) data.loan_id = await resolve(String(data.loan_id))
      const req = new NextRequest(new URL(`/api/${op.kind}/${recordId}`, request.url), {
        method: op.method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data),
      })
      const response = op.method === 'POST'
        ? await ({ customer: addCustomer, loan: addLoan, payment: addPayment }[op.kind])(req)
        : await ({ customer: editCustomer, loan: editLoan, payment: editPayment }[op.kind])(req, { params: Promise.resolve({ id: recordId }) })
      const body = await response.json()
      if (!response.ok) throw Object.assign(new Error(body.error || 'Record could not be saved.'), { status: response.status })
      if(op.kind==='payment'&&op.method==='POST') {
        // Only the newly inserted record is timestamped; never rewrite old data.
        await client.query('UPDATE payments SET created_at=$1 WHERE payment_id=$2 AND user_id=$3',[op.recordedAt,body.payment_id,owner])
      }
      const mappings: Record<string,string> = {}
      if (op.method === 'POST') {
        const id = String(op.kind === 'customer' ? body.id : op.kind === 'loan' ? body.loan_id : body.payment_id)
        mappings[op.recordId] = id
        if (op.kind === 'customer') {
          customerId = id
          if (op.data.__localLoanId) mappings[op.data.__localLoanId] = String(body.loan_id)
        }
      }
      const current = await customerRevision(client,owner,customerId)
      const confirmation = { operationId: op.id, status: 'SYNCED', mappings, customerId, revision: current?.revision, duplicate: false }
      await recordAuditEvent(client, { action: 'DEVICE_RECORD_SYNCED', entityType: op.kind, customerId,
        actor: actorFromAuthUser(auth.user), result: 'SUCCESS',
        after: { operation_id: op.id, device_id: op.deviceId, recorded_at: op.recordedAt, method: op.method },
        reason: 'Offline record merged; original payment date and time retained.' })
      await client.query(`INSERT INTO device_sync_receipts(owner_id,operation_id,device_id,fingerprint,response,recorded_at) VALUES($1,$2,$3,$4,$5,$6)`, [owner,op.id,op.deviceId,fingerprint,JSON.stringify(confirmation),op.recordedAt])
      return confirmation
    }))
    return NextResponse.json(result)
  } catch (error: any) {
    const status = [400,401,403,404,409].includes(error.status) ? error.status : 503
    return NextResponse.json({ error: status === 503 ? 'Sync interrupted. Keep your local records and retry when the laptop database is available.' : error.message,
      revision: error.current?.revision, record: error.current?.record }, { status })
  }
}
