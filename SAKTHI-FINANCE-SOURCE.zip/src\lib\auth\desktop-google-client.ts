declare global {
  interface Window {
    __TAURI__?: { core: { invoke: <T>(command: string, args?: Record<string, unknown>) => Promise<T> } }
  }
}

export function isTauriApp() { return typeof window !== 'undefined' && Boolean(window.__TAURI__?.core) }

/** @legacy Tauri flow — retained until Tauri removal completes. */
export const isDesktopApp = isTauriApp

export async function desktopGoogleSignIn(signal: AbortSignal): Promise<string> {
  const invoke = window.__TAURI__?.core.invoke
  if (!invoke) throw new Error('Please open Sakthi Finance in the desktop application.')
  const request = async (action: string, ticket?: string, requestSignal?: AbortSignal) => {
    const response = await fetch('/api/auth/google/desktop', { method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, ticket }),
      signal: requestSignal ?? AbortSignal.timeout(10_000) })
    const data = await response.json()
    if (!response.ok) throw new Error(data.error || 'Desktop Google sign-in failed.')
    return data
  }
  let ticket: string | undefined
  try {
    const started = await request('start')
    ticket = started.ticket
    signal.throwIfAborted()
    try {
      await invoke('open_google_sign_in', { url: started.url })
    } catch (error) {
      // Tauri rejects commands with strings, not necessarily Error instances.
      // Map known failures without displaying raw URLs or authorization values.
      const reason = typeof error === 'string' ? error : error instanceof Error ? error.message : ''
      if (/not allowed|denied|permission/i.test(reason)) {
        throw new Error('Desktop sign-in permission was blocked. Restart the updated desktop app and try again.')
      }
      if (reason === 'Only Google sign-in from the local login page is allowed' || reason === 'Invalid sign-in window') {
        throw new Error('Open the desktop login page and try Google sign-in again.')
      }
      throw new Error('Unable to open your default browser. Check the Windows default browser setting and try again.')
    }
    const deadline = Date.now() + 300_000
    while (Date.now() < deadline) {
      signal.throwIfAborted()
      const result = await request('poll', ticket, AbortSignal.any([signal, AbortSignal.timeout(10_000)]))
      if (result.status === 'complete') return result.credential
      if (result.status === 'failed') throw new Error(result.error)
      if (result.status === 'expired') break
      await new Promise<void>(resolve => setTimeout(resolve, 1000))
    }
    throw new Error('Sign-in timed out. Please try again.')
  } finally {
    if (ticket) await request('cancel', ticket).catch(() => {})
  }
}
