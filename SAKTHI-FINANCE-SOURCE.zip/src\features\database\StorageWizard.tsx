'use client'

import { useCallback, useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, HardDrive, Check, Loader2, FolderOpen, AlertCircle, ChevronRight, ChevronLeft } from 'lucide-react'
import { cn } from '@/lib/utils'

export interface DriveInfo {
  root: string
  label: string
  totalBytes: number
  freeBytes: number
  usedBytes: number
}

export function formatBytes(bytes: number | null | undefined): string {
  if (bytes === null || bytes === undefined || !Number.isFinite(bytes)) return 'Unavailable'
  if (bytes < 0) return 'Unavailable'
  if (bytes === 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let v = bytes
  let u = 0
  while (v >= 1024 && u < units.length - 1) {
    v /= 1024
    u++
  }
  return `${v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2)} ${units[u]}`
}

const PURPOSES = ['Database Backups', 'Application Backups', 'Documents', 'General Storage']
const ALLOCATIONS = ['10 GB', '25 GB', '50 GB', '100 GB', 'Use Available Space']

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, { credentials: 'include', ...init })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error((data as any).error || `Request failed (${res.status})`)
  return data as T
}

export default function StorageWizard({
  open,
  onClose,
  onConfigured,
}: {
  open: boolean
  onClose: () => void
  onConfigured: () => void
}) {
  const [step, setStep] = useState(1)
  const [drives, setDrives] = useState<DriveInfo[]>([])
  const [drivesLoading, setDrivesLoading] = useState(false)
  const [drivesError, setDrivesError] = useState<string | null>(null)
  const [driveRoot, setDriveRoot] = useState<string | null>(null)
  const [name, setName] = useState('Sakthi Backup Storage')
  const [storagePath, setStoragePath] = useState('')
  const [purpose, setPurpose] = useState(PURPOSES[0])
  const [allocation, setAllocation] = useState(ALLOCATIONS[4])
  const [validating, setValidating] = useState(false)
  const [validation, setValidation] = useState<{ ok: boolean; error?: string; normalizedPath?: string } | null>(null)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showBrowse, setShowBrowse] = useState(false)

  const selectedDrive = drives.find((d) => d.root === driveRoot) || null

  const loadDrives = useCallback(async () => {
    setDrivesLoading(true)
    setDrivesError(null)
    try {
      const data = await api<{ drives: DriveInfo[] }>('/api/system/drives')
      setDrives(data.drives || [])
      if (data.drives?.length === 1) {
        setDriveRoot(data.drives[0].root)
        setStoragePath((p) => p || `${data.drives[0].root}Sakthi Finance\\Storage`)
      }
    } catch (e: any) {
      setDrivesError(e.message || 'Could not detect local drives.')
    } finally {
      setDrivesLoading(false)
    }
  }, [])

  useEffect(() => {
    if (open) {
      setStep(1)
      setError(null)
      setValidation(null)
      setShowBrowse(false)
      loadDrives()
    }
  }, [open, loadDrives])

  useEffect(() => {
    if (driveRoot && !storagePath) setStoragePath(`${driveRoot}Sakthi Finance\\Storage`)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [driveRoot])

  const runValidation = useCallback(async () => {
    if (!storagePath.trim()) {
      setValidation({ ok: false, error: 'Storage path is required.' })
      return false
    }
    setValidating(true)
    setValidation(null)
    try {
      const data = await api<{ ok: boolean; error?: string; normalizedPath?: string }>('/api/storage/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: storagePath }),
      })
      setValidation(data)
      return data.ok
    } catch (e: any) {
      setValidation({ ok: false, error: e.message })
      return false
    } finally {
      setValidating(false)
    }
  }, [storagePath])

  const handleConfigure = useCallback(async () => {
    setSaving(true)
    setError(null)
    try {
      await api('/api/storage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, path: validation?.normalizedPath || storagePath, purpose, allocation }),
      })
      onConfigured()
      onClose()
    } catch (e: any) {
      setError(e.message || 'Failed to configure storage.')
    } finally {
      setSaving(false)
    }
  }, [name, storagePath, purpose, allocation, validation, onConfigured, onClose])

  if (!open) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, y: 24, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 24, scale: 0.98 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-[560px] max-h-[90vh] overflow-y-auto bg-white rounded-[22px] border border-slate-100 shadow-2xl"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 sticky top-0 bg-white rounded-t-[22px]">
            <div>
              <h3 className="text-base font-bold text-slate-900">Add Local Storage</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Step {step} of 3 — {step === 1 ? 'Select Storage' : step === 2 ? 'Configure' : 'Confirm'}
              </p>
            </div>
            <button onClick={onClose} className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex gap-1.5 px-6 pt-4">
            {[1, 2, 3].map((s) => (
              <div key={s} className={cn('h-1.5 flex-1 rounded-full', s <= step ? 'bg-[var(--primary)]' : 'bg-slate-200')} />
            ))}
          </div>

          <div className="p-6">
            {step === 1 && (
              <div className="space-y-3">
                <p className="text-sm text-slate-600">Select a local drive detected on this computer.</p>
                {drivesLoading && (
                  <div className="flex items-center gap-2 text-sm text-slate-500 py-6 justify-center">
                    <Loader2 className="w-4 h-4 animate-spin" /> Detecting local drives…
                  </div>
                )}
                {drivesError && (
                  <div className="flex items-start gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-700">
                    <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" /> {drivesError}
                  </div>
                )}
                {!drivesLoading && !drivesError && drives.length === 0 && (
                  <p className="text-sm text-slate-500 py-6 text-center">No local drives detected. Unavailable.</p>
                )}
                {drives.map((d) => (
                  <button
                    key={d.root}
                    onClick={() => {
                      setDriveRoot(d.root)
                      setStoragePath(`${d.root}Sakthi Finance\\Storage`)
                      setValidation(null)
                    }}
                    className={cn(
                      'w-full text-left px-4 py-3.5 rounded-2xl border transition-colors flex items-center gap-3',
                      driveRoot === d.root
                        ? 'border-[var(--primary)] bg-[var(--primary-soft)]'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    )}
                  >
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
                      <HardDrive className="w-5 h-5 text-slate-600" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-slate-900 truncate">
                        {d.root} {d.label}
                      </p>
                      <p className="text-xs text-slate-500">Available: {formatBytes(d.freeBytes)}</p>
                    </div>
                    {driveRoot === d.root && (
                      <span className="w-6 h-6 rounded-full bg-[var(--primary)] flex items-center justify-center flex-shrink-0">
                        <Check className="w-3.5 h-3.5 text-white" />
                      </span>
                    )}
                  </button>
                ))}
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Storage Name</label>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Sakthi Backup Storage"
                    className="mt-1.5 w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-[var(--primary)]/30 focus:border-[var(--primary)] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Storage Path</label>
                  <div className="mt-1.5 flex gap-2">
                    <input
                      value={storagePath}
                      onChange={(e) => {
                        setStoragePath(e.target.value)
                        setValidation(null)
                      }}
                      placeholder="D:\Sakthi Finance\Storage"
                      className="flex-1 min-w-0 px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-mono focus:ring-2 focus:ring-[var(--primary)]/30 focus:border-[var(--primary)] focus:outline-none"
                    />
                    <button
                      onClick={() => setShowBrowse((v) => !v)}
                      className="px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-medium text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5 flex-shrink-0"
                    >
                      <FolderOpen className="w-4 h-4" /> Browse
                    </button>
                  </div>
                  {showBrowse && (
                    <div className="mt-2 p-2 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                      {drives.map((d) => (
                        <button
                          key={d.root}
                          onClick={() => {
                            setDriveRoot(d.root)
                            setStoragePath(`${d.root}Sakthi Finance\\Storage`)
                            setValidation(null)
                            setShowBrowse(false)
                          }}
                          className="w-full text-left px-3 py-2 rounded-lg text-sm hover:bg-white flex items-center justify-between"
                        >
                          <span className="font-medium text-slate-700">
                            {d.root} {d.label}
                          </span>
                          <span className="text-xs text-slate-500">{formatBytes(d.freeBytes)} free</span>
                        </button>
                      ))}
                    </div>
                  )}
                  <button
                    onClick={runValidation}
                    disabled={validating}
                    className="mt-2 text-xs font-semibold text-[var(--primary)] hover:underline disabled:opacity-50"
                  >
                    {validating ? 'Validating…' : 'Validate path'}
                  </button>
                  {validation && (
                    <div
                      className={cn(
                        'mt-2 p-3 rounded-xl border text-xs',
                        validation.ok ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-red-50 border-red-200 text-red-700'
                      )}
                    >
                      {validation.ok
                        ? `Path is valid${validation.normalizedPath ? `: ${validation.normalizedPath}` : ''}.`
                        : validation.error}
                    </div>
                  )}
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Storage Purpose</label>
                  <select
                    value={purpose}
                    onChange={(e) => setPurpose(e.target.value)}
                    className="mt-1.5 w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-[var(--primary)]/30 focus:border-[var(--primary)] focus:outline-none"
                  >
                    {PURPOSES.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Maximum Storage Allocation</label>
                  <select
                    value={allocation}
                    onChange={(e) => setAllocation(e.target.value)}
                    className="mt-1.5 w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-[var(--primary)]/30 focus:border-[var(--primary)] focus:outline-none"
                  >
                    {ALLOCATIONS.map((a) => (
                      <option key={a} value={a}>
                        {a}
                      </option>
                    ))}
                  </select>
                  {selectedDrive && allocation !== 'Use Available Space' && (
                    <p className="mt-1 text-xs text-slate-500">Drive free space: {formatBytes(selectedDrive.freeBytes)}</p>
                  )}
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-2 text-sm">
                {[
                  ['Storage Name', name],
                  ['Location', validation?.normalizedPath || storagePath],
                  ['Available', selectedDrive ? formatBytes(selectedDrive.freeBytes) : 'Unavailable'],
                  ['Allocated', allocation],
                  ['Purpose', purpose],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-4 py-2 border-b border-slate-100 last:border-0">
                    <span className="text-slate-500">{k}</span>
                    <span className="font-semibold text-slate-900 text-right break-all">{v}</span>
                  </div>
                ))}
                {error && (
                  <div className="flex items-start gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-700">
                    <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" /> {error}
                  </div>
                )}
              </div>
            )}

            <div className="flex gap-2 mt-6">
              {step > 1 ? (
                <button
                  onClick={() => {
                    setStep(step - 1)
                    setError(null)
                  }}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5"
                >
                  <ChevronLeft className="w-4 h-4" /> Back
                </button>
              ) : (
                <button
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
              )}
              <div className="flex-1" />
              {step === 1 && (
                <button
                  onClick={() => setStep(2)}
                  disabled={!driveRoot}
                  className="px-5 py-2.5 rounded-xl bg-[var(--primary)] text-white text-sm font-medium hover:bg-[#912222] disabled:opacity-40 inline-flex items-center gap-1.5"
                >
                  Continue <ChevronRight className="w-4 h-4" />
                </button>
              )}
              {step === 2 && (
                <button
                  onClick={async () => {
                    const ok = await runValidation()
                    if (ok && name.trim()) setStep(3)
                    else if (!name.trim()) setValidation({ ok: false, error: 'Storage name is required.' })
                  }}
                  disabled={validating || !name.trim() || !storagePath.trim()}
                  className="px-5 py-2.5 rounded-xl bg-[var(--primary)] text-white text-sm font-medium hover:bg-[#912222] disabled:opacity-40 inline-flex items-center gap-1.5"
                >
                  {validating ? <Loader2 className="w-4 h-4 animate-spin" /> : null} Continue{' '}
                  <ChevronRight className="w-4 h-4" />
                </button>
              )}
              {step === 3 && (
                <button
                  onClick={handleConfigure}
                  disabled={saving}
                  className="px-5 py-2.5 rounded-xl bg-[var(--primary)] text-white text-sm font-medium hover:bg-[#912222] disabled:opacity-50 inline-flex items-center gap-2"
                >
                  {saving && <Loader2 className="w-4 h-4 animate-spin" />} Configure Storage
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
