'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import AccountMonitorContent from '@/features/admin-access/AccountMonitorContent'

export default function AccountMonitorContentPage() {
  return (
    <ClientPageGate requireRole="owner">
      <AccountMonitorContent />
    </ClientPageGate>
  )
}
