import { NextResponse } from 'next/server'
import { readdir } from 'node:fs/promises'
import path from 'node:path'
import { requireAuthWithPermission } from '@/lib/api-utils'

export async function GET() {
  const auth=await requireAuthWithPermission('customers:create')
  if(auth.error)return auth.error
  const root=process.env.SAKTHI_APP_ROOT
    ? path.join(process.env.SAKTHI_APP_ROOT,'out-desktop-build','_next','static')
    : path.join(process.cwd(),'.next',process.env.NODE_ENV==='development'?'dev/static':'static')
  const assets:string[]=[]
  const walk=async(dir:string)=>{
    for(const entry of await readdir(dir,{withFileTypes:true})){
      const file=path.join(dir,entry.name)
      if(entry.isDirectory())await walk(file)
      else if(/\.(?:js|css|woff2?)$/.test(entry.name))assets.push('/_next/static/'+path.relative(root,file).split(path.sep).join('/'))
    }
  }
  try{await walk(root);return NextResponse.json({assets},{headers:{'Cache-Control':'no-store'}})}
  catch{return NextResponse.json({error:'Application assets are not ready. Retry after the build finishes.'},{status:503})}
}
