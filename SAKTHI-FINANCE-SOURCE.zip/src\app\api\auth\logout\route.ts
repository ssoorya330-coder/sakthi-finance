import { NextRequest, NextResponse } from 'next/server';
import {
  REFRESH_COOKIE_NAME,
  ACCESS_COOKIE_NAME,
  revokeRefreshToken,
  cookieOptions,
} from '@/lib/auth/tokens';
import { isSupabaseConfigured, getSupabaseServerClient } from '@/lib/supabase/server';
import { recordAuditStandalone } from '@/server/audit';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  // Audit: logout (best-effort identity — never blocks sign-out).
  try {
    const { getFullUserFromToken } = await import('@/config/supabase-auth');
    const u = await getFullUserFromToken().catch(() => null);
    if (u) {
      recordAuditStandalone({
        action: 'LOGOUT',
        entityType: 'auth',
        entityId: (u as any).userId || null,
        actor: {
          userId: (u as any).userId || null,
          name: (u as any).name || (u as any).email || null,
          role: (u as any).role || null,
        },
        ipAddress:
          request.headers.get('x-forwarded-for')?.split(',')[0].trim() ||
          request.headers.get('x-real-ip') ||
          null,
        clientInfo: request.headers.get('user-agent')?.slice(0, 300) || null,
        result: 'SUCCESS',
      });
    }
  } catch {}
  try {
    const refreshToken = request.cookies.get(REFRESH_COOKIE_NAME)?.value;
    if (refreshToken) {
      try {
        await revokeRefreshToken(refreshToken);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Unknown error';
        console.warn('[Auth/Logout] Failed to revoke refresh token:', message);
        // Continue with cookie clearing even if DB fails
      }
    }

    const response = NextResponse.json({ success: true });
    response.cookies.set(REFRESH_COOKIE_NAME, '', cookieOptions(0, true));
    response.cookies.set(ACCESS_COOKIE_NAME, '', cookieOptions(0, true));

    // Also sign out the Supabase Auth session when configured, so the
    // Supabase cookies (sb-*) are cleared server-side as well.
    if (isSupabaseConfigured()) {
      try {
        const supabase = await getSupabaseServerClient();
        await supabase.auth.signOut();
      } catch (err) {
        console.warn('[Auth/Logout] Supabase signOut failed:', err);
      }
      try {
        request.cookies.getAll().forEach((c) => {
          if (c.name.startsWith('sb-')) {
            response.cookies.set(c.name, '', { path: '/', maxAge: 0 });
          }
        });
      } catch {}
    }

    return response;
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    console.error('[Auth/Logout] Error:', message);
    return NextResponse.json(
      { error: 'Logout failed', details: message, code: 'logout_error' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  return POST(request);
}
