import DatabasePage from '@/features/database/DatabasePage'

export default function DatabasePageRoute() {
  return <DatabasePage />
}
