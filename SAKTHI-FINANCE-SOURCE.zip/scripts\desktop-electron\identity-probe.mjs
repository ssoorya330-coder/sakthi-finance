import 'dotenv/config'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

process.env.JWT_ACCESS_SECRET ??= 's'.repeat(48)
process.env.JWT_REFRESH_SECRET ??= 'r'.repeat(48)

const root = process.cwd()
const { signAccessToken } = await import(pathToFileURL(path.join(root, 'src/lib/auth/tokens.ts')).href)
const { dbQuery } = await import(pathToFileURL(path.join(root, 'src/server/database.ts')).href)

// Look at the actual users table to understand the identity keys.
const users = await dbQuery(
  'SELECT user_id, email, role, COALESCE(supabase_user_id, \'<null>\') AS sup, is_active FROM users LIMIT 5'
)
console.log('users sample:', users.rows.map((u) => ({ id: String(u.user_id).slice(0, 8), role: u.role, hasSup: u.sup !== '<null>' })))

const token = signAccessToken({
  sub: users.rows[0]?.user_id ? String(users.rows[0].user_id) : 'smoke-user',
  email: users.rows[0]?.email || 'smoke@test',
  name: users.rows[0]?.email || 'Smoke',
  role: 'owner',
  provider: 'google',
})

const decoded = await import(pathToFileURL(path.join(root, 'src/lib/auth/tokens.ts')).href)
  .then((m) => m.verifyAccessToken(token))
console.log('decoded provider:', decoded?.provider)
process.exit(0)
