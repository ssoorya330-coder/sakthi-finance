import type { Pool } from 'pg'

// Additive, transactional migration. Existing IDs, receipts and audit rows stay intact.
export const kanakuMigration = `
SELECT pg_advisory_xact_lock(721904221);
CREATE TABLE IF NOT EXISTS kanaku_trash (
 loan_id UUID PRIMARY KEY, customer_id TEXT NOT NULL, user_id TEXT NOT NULL,
 kanaku_group_key TEXT NOT NULL, cycle_number INTEGER NOT NULL, kanaku_number INTEGER NOT NULL,
 deleted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), purge_after TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '30 days'),
 purged_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS sakthi_migrations (name TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
ALTER TABLE loans ADD COLUMN IF NOT EXISTS cycle_number INTEGER;
ALTER TABLE loans ADD COLUMN IF NOT EXISTS kanaku_number INTEGER;
ALTER TABLE loans ADD COLUMN IF NOT EXISTS request_key TEXT;
ALTER TABLE loans ADD COLUMN IF NOT EXISTS kanaku_group_key TEXT;
ALTER TABLE loans ADD COLUMN IF NOT EXISTS legacy_paid_amount NUMERIC(12,2) NOT NULL DEFAULT 0;
DO $$ BEGIN
IF NOT EXISTS (SELECT 1 FROM sakthi_migrations WHERE name = 'kanaku-cycles-v1') THEN
  LOCK TABLE loans, payments IN SHARE ROW EXCLUSIVE MODE;
  WITH numbered AS (
    SELECT loan_id, row_number() OVER (PARTITION BY customer_id ORDER BY created_at, loan_id) AS n FROM loans
  ) UPDATE loans l SET cycle_number = 1, kanaku_number = n.n FROM numbered n WHERE n.loan_id = l.loan_id;
  UPDATE loans l SET legacy_paid_amount = GREATEST(0, COALESCE(l.received_amount, 0) -
    COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.loan_id = l.loan_id AND p.customer_id = l.customer_id AND p.user_id IS NOT DISTINCT FROM l.user_id), 0));
  INSERT INTO sakthi_migrations(name) VALUES ('kanaku-cycles-v1');
END IF; END $$;
ALTER TABLE loans ALTER COLUMN cycle_number SET NOT NULL;
ALTER TABLE loans ALTER COLUMN kanaku_number SET NOT NULL;
CREATE OR REPLACE FUNCTION sakthi_customer_kanaku_key(customer_key TEXT) RETURNS TEXT LANGUAGE sql STABLE AS $$
 SELECT CASE WHEN trim(COALESCE(c.full_name,'')) = '' OR length(regexp_replace(COALESCE(c.phone_number,''),'[^0-9]','','g')) < 10
 OR c.city_id IS NULL OR c.business_id IS NULL OR c.user_id IS NULL
 THEN 'customer:' || c.id::text ELSE 'person:' || md5(json_build_array(c.user_id,
 lower(regexp_replace(trim(c.full_name),'\\s+',' ','g')),
 CASE WHEN regexp_replace(c.phone_number,'[^0-9]','','g') ~ '^91[0-9]{10}$' THEN right(regexp_replace(c.phone_number,'[^0-9]','','g'),10) ELSE regexp_replace(c.phone_number,'[^0-9]','','g') END,
 c.city_id, c.business_id)::text) END FROM customers c WHERE c.id::text = customer_key
$$;
DO $$ BEGIN
IF NOT EXISTS (SELECT 1 FROM sakthi_migrations WHERE name = 'kanaku-person-groups-v2') THEN
 LOCK TABLE loans, customers IN SHARE ROW EXCLUSIVE MODE;
 DROP TRIGGER IF EXISTS kanaku_protect ON loans;
 DROP INDEX IF EXISTS loans_customer_cycle_kanaku;
 CREATE TABLE IF NOT EXISTS kanaku_number_history (
   loan_id UUID PRIMARY KEY, previous_cycle INTEGER NOT NULL, previous_kanaku INTEGER NOT NULL,
   new_cycle INTEGER NOT NULL, new_kanaku INTEGER NOT NULL, changed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
 );
 UPDATE loans SET kanaku_group_key = sakthi_customer_kanaku_key(customer_id::text);
 WITH numbers AS (
   SELECT loan_id, cycle_number, kanaku_number, row_number() OVER (PARTITION BY kanaku_group_key, cycle_number ORDER BY created_at, loan_id)::integer AS next_number FROM loans
 ) INSERT INTO kanaku_number_history(loan_id,previous_cycle,previous_kanaku,new_cycle,new_kanaku)
 SELECT loan_id,cycle_number,kanaku_number,cycle_number,next_number FROM numbers;
 UPDATE loans l SET kanaku_number = h.new_kanaku FROM kanaku_number_history h WHERE l.loan_id=h.loan_id;
 INSERT INTO sakthi_migrations(name) VALUES ('kanaku-person-groups-v2');
END IF; END $$;
CREATE UNIQUE INDEX IF NOT EXISTS loans_group_cycle_kanaku ON loans(kanaku_group_key, cycle_number, kanaku_number);
CREATE UNIQUE INDEX IF NOT EXISTS loans_customer_cycle_kanaku ON loans(customer_id, cycle_number, kanaku_number);
CREATE UNIQUE INDEX IF NOT EXISTS loans_customer_request_key ON loans(customer_id, request_key) WHERE request_key IS NOT NULL;
-- Rebuild only these derived views inside the transaction when columns expand.
-- No stored loans, payments or audit records are removed.
DROP VIEW IF EXISTS kanaku_cycles;
DROP VIEW IF EXISTS kanaku_loan_balances;
CREATE VIEW kanaku_loan_balances AS
 SELECT l.*, COALESCE(p.paid, 0) + l.legacy_paid_amount AS paid_amount,
 GREATEST(0, COALESCE(l.total_amount, 0) - COALESCE(p.paid, 0) - l.legacy_paid_amount) AS outstanding
 FROM loans l LEFT JOIN LATERAL (
   SELECT SUM(amount) AS paid FROM payments WHERE loan_id = l.loan_id AND customer_id = l.customer_id AND user_id IS NOT DISTINCT FROM l.user_id
 ) p ON true WHERE NOT EXISTS (SELECT 1 FROM kanaku_trash t WHERE t.loan_id=l.loan_id);
CREATE VIEW kanaku_cycles AS
 SELECT members.customer_id, grouped.* FROM (
 SELECT kanaku_group_key, user_id, cycle_number,
 CASE WHEN bool_and(status = 'Completed' AND outstanding = 0) THEN 'Completed' ELSE 'Active' END AS status,
 COUNT(*) AS kanaku_count, SUM(loan_amount) AS total_borrowed, SUM(paid_amount) AS total_repaid, SUM(outstanding) AS outstanding
 FROM kanaku_loan_balances GROUP BY kanaku_group_key, user_id, cycle_number
 ) grouped JOIN (SELECT DISTINCT customer_id, kanaku_group_key FROM loans) members USING (kanaku_group_key);

CREATE OR REPLACE FUNCTION sakthi_assign_kanaku() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE current_cycle INTEGER; cycle_done BOOLEAN;
BEGIN
 PERFORM 1 FROM customers WHERE id = NEW.customer_id AND user_id IS NOT DISTINCT FROM NEW.user_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Customer does not belong to this finance owner'; END IF;
 SELECT kanaku_group_key INTO NEW.kanaku_group_key FROM loans WHERE customer_id = NEW.customer_id ORDER BY created_at LIMIT 1;
 NEW.kanaku_group_key := COALESCE(NEW.kanaku_group_key, sakthi_customer_kanaku_key(NEW.customer_id::text));
 PERFORM pg_advisory_xact_lock(hashtextextended(NEW.kanaku_group_key, 0));
 IF EXISTS (SELECT 1 FROM kanaku_trash WHERE loan_id=NEW.loan_id) THEN RAISE EXCEPTION 'This Kanaku was deleted; refresh before syncing'; END IF;
 SELECT MAX(cycle_number) INTO current_cycle FROM (
 SELECT cycle_number FROM loans WHERE kanaku_group_key = NEW.kanaku_group_key
 UNION ALL SELECT cycle_number FROM kanaku_trash WHERE kanaku_group_key = NEW.kanaku_group_key) reserved;
 IF current_cycle IS NULL THEN NEW.cycle_number := 1; NEW.kanaku_number := 1;
 ELSE
   SELECT bool_and(status = 'Completed' AND outstanding = 0) INTO cycle_done FROM kanaku_loan_balances WHERE kanaku_group_key = NEW.kanaku_group_key AND cycle_number = current_cycle;
   IF EXISTS (SELECT 1 FROM kanaku_trash WHERE kanaku_group_key=NEW.kanaku_group_key AND cycle_number=current_cycle AND purged_at IS NULL) THEN cycle_done := false; END IF;
   IF cycle_done THEN NEW.cycle_number := current_cycle + 1; NEW.kanaku_number := 1;
   ELSE
     NEW.cycle_number := current_cycle;
     SELECT COALESCE(MAX(kanaku_number), 0) + 1 INTO NEW.kanaku_number FROM (
       SELECT kanaku_number FROM loans WHERE kanaku_group_key = NEW.kanaku_group_key AND cycle_number = current_cycle
       UNION ALL SELECT kanaku_number FROM kanaku_trash WHERE kanaku_group_key = NEW.kanaku_group_key AND cycle_number = current_cycle) reserved;
   END IF;
 END IF;
 NEW.legacy_paid_amount := 0;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION sakthi_protect_kanaku() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE paid NUMERIC;
BEGIN
 IF TG_OP = 'DELETE' THEN
   IF current_setting('sakthi.purge_loan',true)=OLD.loan_id::text AND EXISTS (
     SELECT 1 FROM kanaku_trash WHERE loan_id=OLD.loan_id AND customer_id=OLD.customer_id::text
     AND user_id=OLD.user_id::text AND purge_after<=NOW() AND purged_at IS NULL) THEN RETURN OLD; END IF;
   RAISE EXCEPTION 'Kanaku history cannot be deleted; retain the loan and its statement';
 END IF;
 IF EXISTS (SELECT 1 FROM kanaku_trash WHERE loan_id=OLD.loan_id) THEN RAISE EXCEPTION 'Restore this Kanaku before editing it'; END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(OLD.kanaku_group_key, 0));
 IF NEW.loan_id IS DISTINCT FROM OLD.loan_id OR NEW.customer_id IS DISTINCT FROM OLD.customer_id OR NEW.user_id IS DISTINCT FROM OLD.user_id
 OR NEW.kanaku_group_key IS DISTINCT FROM OLD.kanaku_group_key OR NEW.cycle_number <> OLD.cycle_number OR NEW.kanaku_number <> OLD.kanaku_number OR NEW.legacy_paid_amount <> OLD.legacy_paid_amount THEN
   RAISE EXCEPTION 'Kanaku identity and historical opening payments cannot be changed';
 END IF;
 IF OLD.cycle_number < (SELECT MAX(cycle_number) FROM loans WHERE kanaku_group_key = OLD.kanaku_group_key) THEN
   RAISE EXCEPTION 'Previous cycle is read-only; its loan history is preserved';
 END IF;
 IF NEW.status = 'Completed' AND EXISTS (SELECT 1 FROM kanaku_loan_balances WHERE loan_id = OLD.loan_id AND paid_amount < NEW.total_amount) THEN
   RAISE EXCEPTION 'A Kanaku with outstanding balance cannot be completed';
 END IF;
 SELECT paid_amount INTO paid FROM kanaku_loan_balances WHERE loan_id = OLD.loan_id;
 NEW.received_amount := paid;
 NEW.balance_amount := GREATEST(0, COALESCE(NEW.total_amount, 0) - paid);
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION sakthi_guard_payment() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE selected_loan UUID; available NUMERIC; current_cycle INTEGER;
BEGIN
 IF TG_OP = 'DELETE' THEN
   IF current_setting('sakthi.purge_loan',true)=OLD.loan_id::text AND EXISTS (
     SELECT 1 FROM kanaku_trash WHERE loan_id=OLD.loan_id AND customer_id=OLD.customer_id::text
     AND user_id=OLD.user_id::text AND purge_after<=NOW() AND purged_at IS NULL) THEN RETURN OLD; END IF;
   RAISE EXCEPTION 'Payment history cannot be deleted';
 END IF;
 IF TG_OP = 'UPDATE' AND (NEW.loan_id IS DISTINCT FROM OLD.loan_id OR NEW.customer_id IS DISTINCT FROM OLD.customer_id OR NEW.user_id IS DISTINCT FROM OLD.user_id) THEN
   RAISE EXCEPTION 'Payment ownership and Kanaku cannot be changed';
 END IF;
 PERFORM 1 FROM customers WHERE id = NEW.customer_id AND user_id IS NOT DISTINCT FROM NEW.user_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Customer not found'; END IF;
 IF NEW.loan_id IS NULL THEN
   RAISE EXCEPTION 'A payment must specify its Kanaku';
 END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended((SELECT kanaku_group_key FROM loans WHERE loan_id = NEW.loan_id), 0));
 SELECT MAX(cycle_number) INTO current_cycle FROM loans WHERE customer_id = NEW.customer_id;
 SELECT outstanding INTO available FROM kanaku_loan_balances WHERE loan_id = NEW.loan_id AND customer_id = NEW.customer_id
   AND user_id IS NOT DISTINCT FROM NEW.user_id AND cycle_number = current_cycle;
 IF available IS NULL THEN RAISE EXCEPTION 'Choose a Kanaku in the current cycle'; END IF;
 IF TG_OP = 'UPDATE' THEN available := available + OLD.amount; END IF;
 IF NEW.amount IS NULL OR NEW.amount <= 0 OR NEW.amount > available THEN RAISE EXCEPTION 'Received amount exceeds the Kanaku balance or is invalid'; END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION sakthi_sync_kanaku_payment() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE paid NUMERIC; remaining NUMERIC;
BEGIN
 SELECT paid_amount, outstanding INTO paid, remaining FROM kanaku_loan_balances WHERE loan_id = NEW.loan_id;
 UPDATE loans SET received_amount = paid, balance_amount = remaining,
 status = CASE WHEN remaining = 0 THEN 'Completed' WHEN status = 'Completed' THEN 'Active' ELSE status END,
 completed_at = CASE WHEN remaining = 0 THEN COALESCE(completed_at, NOW()) ELSE NULL END, updated_at = NOW() WHERE loan_id = NEW.loan_id;
 UPDATE customers SET status = CASE WHEN status = 'Aborted' THEN status
 WHEN EXISTS (SELECT 1 FROM kanaku_loan_balances WHERE customer_id = NEW.customer_id AND user_id IS NOT DISTINCT FROM NEW.user_id AND (outstanding > 0 OR status = 'Aborted')) THEN 'Active' ELSE 'Completed' END,
 updated_at = NOW() WHERE id = NEW.customer_id AND user_id IS NOT DISTINCT FROM NEW.user_id;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION sakthi_activate_customer() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN UPDATE customers SET status = 'Active', updated_at = NOW() WHERE id = NEW.customer_id; RETURN NEW; END $$;
DROP TRIGGER IF EXISTS kanaku_assign ON loans;
CREATE TRIGGER kanaku_assign BEFORE INSERT ON loans FOR EACH ROW EXECUTE FUNCTION sakthi_assign_kanaku();
DROP TRIGGER IF EXISTS kanaku_protect ON loans;
CREATE TRIGGER kanaku_protect BEFORE UPDATE OR DELETE ON loans FOR EACH ROW EXECUTE FUNCTION sakthi_protect_kanaku();
DROP TRIGGER IF EXISTS kanaku_activate ON loans;
CREATE TRIGGER kanaku_activate AFTER INSERT ON loans FOR EACH ROW EXECUTE FUNCTION sakthi_activate_customer();
DROP TRIGGER IF EXISTS kanaku_payment_guard ON payments;
CREATE TRIGGER kanaku_payment_guard BEFORE INSERT OR UPDATE OR DELETE ON payments FOR EACH ROW EXECUTE FUNCTION sakthi_guard_payment();
DROP TRIGGER IF EXISTS kanaku_payment_sync ON payments;
CREATE TRIGGER kanaku_payment_sync AFTER INSERT OR UPDATE ON payments FOR EACH ROW EXECUTE FUNCTION sakthi_sync_kanaku_payment();
`

export async function migrateKanaku(pool: Pool) {
  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    await client.query(kanakuMigration)
    await client.query('COMMIT')
  } catch (error) {
    await client.query('ROLLBACK')
    throw error
  } finally { client.release() }
}
