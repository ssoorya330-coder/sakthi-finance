import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'
import { getDataDirectory } from '@/server/storage'
import { actorFromAuthUser, recordAuditStandalone, requestMeta } from '@/server/audit'

export const dynamic = 'force-dynamic'

/**
 * Record a completed data-directory migration as an audit event — only
 * after verifying PostgreSQL is actually running on the NEW directory and
 * the database answers. Called once by the wizard on success.
 */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const destination = (body.destination || '').trim()
    const source = (body.source || '').trim() || null
    if (!destination) return NextResponse.json({ error: 'Destination is required.' }, { status: 400 })

    // Verify live state first: connected + serving from the new directory.
    let liveDir: string | null = null
    try {
      liveDir = await getDataDirectory()
    } catch {}
    const norm = (p: string | null) => (p || '').replace(/\//g, '\\').toLowerCase().replace(/\\$/, '')
    if (!liveDir || norm(liveDir) !== norm(destination)) {
      return NextResponse.json(
        { ok: false, error: 'PostgreSQL is not running on the new data directory yet. Migration not recorded.' },
        { status: 200 }
      )
    }
    let version: string | null = null
    try {
      const v = await dbQuery<{ version: string }>('SELECT version() AS version')
      version = v.rows[0]?.version || null
    } catch {
      return NextResponse.json(
        { ok: false, error: 'Database is not accepting connections. Migration not recorded.' },
        { status: 200 }
      )
    }

    const meta = requestMeta(request)
    await recordAuditStandalone({
      action: 'DATA_DIRECTORY_MIGRATED',
      entityType: 'database',
      entityId: 'sakthi_finance',
      actor: actorFromAuthUser(auth.user),
      ipAddress: meta.ip,
      clientInfo: meta.client,
      source: 'migration-wizard',
      reason: 'Data directory migrated to another disk',
      result: 'SUCCESS',
      changes: [
        { field: 'data_directory', label: 'Data Directory', before: source, after: liveDir },
        { field: 'version', label: 'PostgreSQL Version', before: null, after: (version || '').split(' ').slice(0, 2).join(' ') },
      ],
      after: { data_directory: liveDir },
    })
    return NextResponse.json({ ok: true })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: 'Migration completion could not be recorded', details: err.message }, { status: 500 })
  }
}
