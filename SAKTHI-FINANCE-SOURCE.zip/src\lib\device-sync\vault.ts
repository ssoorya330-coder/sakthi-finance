export interface SealedImage { version: 2; iv: Uint8Array; ciphertext: ArrayBuffer; compressed: boolean }
export async function sealImage(bytes: Uint8Array, key: CryptoKey, user: string): Promise<SealedImage> {
  const compressed = typeof CompressionStream !== 'undefined'
  const source = new Blob([bytes as BlobPart]).stream()
  const payload = await new Response(compressed ? source.pipeThrough(new CompressionStream('gzip')) : source).arrayBuffer()
  const iv = crypto.getRandomValues(new Uint8Array(12))
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(user) }, key, payload)
  return { version: 2, iv, ciphertext, compressed }
}
export async function unsealImage(image: SealedImage, key: CryptoKey, user: string): Promise<Uint8Array> {
  const bytes = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: image.iv as BufferSource, additionalData: new TextEncoder().encode(user) }, key, image.ciphertext)
  if (!image.compressed) return new Uint8Array(bytes)
  return new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer())
}
