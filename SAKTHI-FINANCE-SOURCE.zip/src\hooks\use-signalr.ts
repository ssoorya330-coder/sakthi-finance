'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { signalRService, ConnectionStatus } from '@/services/signalr-client';

type SignalREventHandler = (...args: unknown[]) => void;

interface UseSignalROptions {
  autoConnect?: boolean;
}

interface UseSignalRReturn {
  connection: ConnectionStatus;
  isConnected: boolean;
  on: (event: string, handler: SignalREventHandler, hub?: 'notification' | 'dashboard') => void;
  off: (event: string, hub?: 'notification' | 'dashboard') => void;
  invoke: (method: string, ...args: unknown[]) => Promise<unknown>;
  invokeDashboard: (method: string, ...args: unknown[]) => Promise<unknown>;
}

export function useSignalR(options: UseSignalROptions = {}): UseSignalRReturn {
  const { autoConnect = true } = options;
  const [status, setStatus] = useState<ConnectionStatus>(signalRService.getStatus());
  const connectedRef = useRef(signalRService.isConnected());

  useEffect(() => {
    if (!autoConnect) return;

    signalRService.connect();
    const unsub = signalRService.onStatusChange((newStatus) => {
      setStatus(newStatus);
      connectedRef.current = newStatus === 'connected';
    });

    return () => {
      unsub();
      signalRService.disconnect();
    };
  }, [autoConnect]);

  const on = useCallback(
    (event: string, handler: SignalREventHandler, hub: 'notification' | 'dashboard' = 'notification') => {
      signalRService.on(event, handler, hub);
    },
    []
  );

  const off = useCallback(
    (event: string, hub: 'notification' | 'dashboard' = 'notification') => {
      signalRService.off(event, hub);
    },
    []
  );

  const invoke = useCallback(
    (method: string, ...args: unknown[]) => signalRService.invoke(method, ...args),
    []
  );

  const invokeDashboard = useCallback(
    (method: string, ...args: unknown[]) => signalRService.invokeDashboard(method, ...args),
    []
  );

  return {
    connection: status,
    isConnected: status === 'connected',
    on,
    off,
    invoke,
    invokeDashboard,
  };
}
