'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import AccountsContent from '@/features/admin-access/AccountsContent'

export default function AccountsContentPage() {
  return (
    <ClientPageGate requireRole="owner">
      <AccountsContent />
    </ClientPageGate>
  )
}
