'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import {
  Banknote, Download, Printer, Search, ChevronLeft, ChevronRight,
  X, Loader2, FileSpreadsheet, Settings2,
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface CashTxn {
  date: string | null
  txnId: string
  kind: 'disbursal' | 'payment'
  type: string
  customerId: string
  customerCode: string
  customerName: string
  loanId: string | null
  paymentId: string | null
  mode: string
  amount: number
  principal: number
  interest: number
  outstanding: number
  cumulative: number
  flagged: boolean
  complianceStatus: string
  reason: string | null
}

interface CashSummary {
  threshold: number
  disbursals: number
  disbursed: number
  payments: number
  received: number
  flagged: number
  customersFlagged: number
}

interface CashData {
  years: Array<{ startYear: number; label: string }>
  fy: { startYear: number; label: string }
  threshold: number
  summary: CashSummary
  transactions: CashTxn[]
  total: number
  page: number
  totalPages: number
}

interface CashDetail {
  kind: 'disbursal' | 'payment'
  customer: { name: string; code: string; business: string | null; phone: string | null; address: string | null }
  loan: { id: string; date: string | null; principal: number; rate: number; duration: number; total: number; mode: string | null } | null
  payment: { id: string; date: string | null; amount: number; mode: string; prevOutstanding: number; newOutstanding: number } | null
  compliance: {
    threshold: number; cashAmount: number; fyCashBefore: number | null; fyCashAfter: number | null;
    outstandingBefore: number | null; flagged: boolean; reason: string | null; checkedAt: string
  }
  audit: { audit_id: string; action: string; created_at: string; performed_by: string | null; user_role: string | null; source: string | null; result: string } | null
}

const inr = (v: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(Number(v) || 0)

const fmtDate = (iso: string | null) => {
  if (!iso) return '—'
  try {
    return new Date(iso.length <= 10 ? `${iso}T00:00:00` : iso).toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
    })
  } catch {
    return iso
  }
}

const fmtDT = (iso: string) => {
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true,
    })
  } catch {
    return iso
  }
}

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, { credentials: 'include', ...init })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error((data as any).error || `Request failed (${res.status})`)
  return data as T
}

export default function CashAudit({ fyYear, onFyYearChange }: { fyYear?: number | null; onFyYearChange?: (y: number) => void }) {
  const [data, setData] = useState<CashData | null>(null)
  const [innerFy, setInnerFy] = useState<number | null>(null)
  const fy = fyYear ?? innerFy
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(true)
  const [exporting, setExporting] = useState<string | null>(null)
  const loadedFy = useRef<number | null>(null)

  const [customerCode, setCustomerCode] = useState('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [type, setType] = useState('')
  const [flagged, setFlagged] = useState<'all' | 'flagged' | 'notflagged'>('all')
  const [mode, setMode] = useState('')

  const [detail, setDetail] = useState<CashDetail | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [editThreshold, setEditThreshold] = useState(false)
  const [thresholdInput, setThresholdInput] = useState('')
  const [savingThreshold, setSavingThreshold] = useState(false)
  const [thresholdMsg, setThresholdMsg] = useState<string | null>(null)
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const queryString = useCallback((extra?: Record<string, string>) => {
    const p = new URLSearchParams()
    if (fy) p.set('fy', String(fy))
    if (customerCode) p.set('customerCode', customerCode)
    if (dateFrom) p.set('dateFrom', dateFrom)
    if (dateTo) p.set('dateTo', dateTo)
    if (type) p.set('type', type)
    if (flagged !== 'all') p.set('flagged', flagged)
    if (mode) p.set('mode', mode)
    p.set('limit', '25')
    if (extra) for (const [k, v] of Object.entries(extra)) p.set(k, v)
    return p.toString()
  }, [fy, customerCode, dateFrom, dateTo, type, flagged, mode])

  const load = useCallback(async (fyArg: number | null, pageNum: number, qs?: string) => {
    setLoading(true)
    try {
      const p = new URLSearchParams(qs || queryString({ page: String(pageNum) }))
      if (fyArg && !p.get('fy')) p.set('fy', String(fyArg))
      const d = await api<CashData>(`/api/audit/cash?${p.toString()}`)
      setData(d)
      setInnerFy(d.fy.startYear)
      loadedFy.current = d.fy.startYear
      setPage(d.page)
    } catch {
      setData(null)
    } finally {
      setLoading(false)
    }
  }, [queryString])

  useEffect(() => {
    load(null, 1)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (fyYear != null && fyYear !== loadedFy.current) {
      loadedFy.current = fyYear
      setInnerFy(fyYear)
      setPage(1)
      load(fyYear, 1)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fyYear])

  const changeFy = (y: number) => {
    loadedFy.current = y
    setInnerFy(y)
    if (onFyYearChange) onFyYearChange(y)
    setPage(1)
    load(y, 1)
  }

  const goPage = (n: number) => {
    setPage(n)
    load(fy, n)
  }

  const applyFilters = () => {
    setPage(1)
    load(fy, 1)
  }

  const clearFilters = () => {
    setCustomerCode(''); setDateFrom(''); setDateTo('')
    setType(''); setFlagged('all'); setMode('')
    setPage(1)
    setTimeout(() => load(fy, 1), 0)
  }

  const onCodeChange = (v: string) => {
    setCustomerCode(v)
    if (searchTimer.current) clearTimeout(searchTimer.current)
    searchTimer.current = setTimeout(() => {
      setPage(1)
      load(fy, 1)
    }, 500)
  }

  const openDetail = async (row: CashTxn) => {
    setDetail(null)
    setDetailLoading(true)
    try {
      const d = await api<{ detail: CashDetail }>(`/api/audit/cash/${row.kind}/${encodeURIComponent(row.txnId)}`)
      setDetail(d.detail)
    } catch {
      setDetail(null)
    } finally {
      setDetailLoading(false)
    }
  }

  const exportFile = async (format: 'xlsx' | 'csv') => {
    setExporting(format)
    try {
      const p = new URLSearchParams()
      if (fy) p.set('fy', String(fy))
      p.set('format', format)
      if (format === 'csv') p.set('section', 'cash')
      const res = await fetch(`/api/audit/financial/export?${p.toString()}`, { credentials: 'include' })
      if (!res.ok) throw new Error('Export failed')
      const blob = await res.blob()
      const stamp = new Date().toISOString().slice(0, 10)
      const a = document.createElement('a')
      a.href = URL.createObjectURL(blob)
      a.download = format === 'xlsx'
        ? `sakthi-finance-financial-audit-FY${data?.fy.label || ''}-${stamp}.xlsx`
        : `sakthi-finance-cash-transactions-FY${data?.fy.label || ''}-${stamp}.csv`
      document.body.appendChild(a)
      a.click()
      a.remove()
      setTimeout(() => URL.revokeObjectURL(a.href), 2000)
    } catch {}
    finally {
      setExporting(null)
    }
  }

  const exportPdf = async () => {
    if (!data) return
    setExporting('pdf')
    try {
      const { downloadCashAuditPdf } = await import('@/lib/audit-pdf')
      await downloadCashAuditPdf(data)
    } catch {}
    finally {
      setExporting(null)
    }
  }

  const saveThreshold = async () => {
    const n = Number(thresholdInput)
    if (!Number.isFinite(n) || n <= 0) {
      setThresholdMsg('Enter a positive amount.')
      return
    }
    setSavingThreshold(true)
    setThresholdMsg(null)
    try {
      const r = await api<{ threshold: number }>('/api/settings/cash-threshold', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ threshold: n }),
      })
      setThresholdMsg(`Threshold updated to ${inr(r.threshold)}. Applies to new transactions (history is never rewritten).`)
      setEditThreshold(false)
      load(fy, page)
    } catch (e: any) {
      setThresholdMsg(e.message || 'Could not update threshold.')
    } finally {
      setSavingThreshold(false)
    }
  }

  const inputCls = 'px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-[var(--primary)]/30 focus:outline-none bg-white min-w-0'
  const s = data?.summary

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="hidden print:block px-6 pt-6 text-center">
        <p className="text-xl font-extrabold text-slate-900">SAKTHI FINANCE</p>
        <p className="text-sm font-bold text-slate-700 mt-1">CASH TRANSACTION COMPLIANCE REPORT</p>
        <p className="text-xs text-slate-500 mt-1">Financial Year: {data?.fy.label || ''}</p>
      </div>

      <div className="px-4 py-3 border-b border-slate-100 flex flex-wrap items-center gap-2">
        <Banknote className="w-4 h-4 text-[var(--primary)]" />
        <p className="text-sm font-bold text-slate-900">Cash Transactions</p>
        <span className="text-[11px] text-slate-400 font-medium">FY {data?.fy.label || '…'}</span>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          {data && data.years.length > 0 && (
            <select
              value={fy ?? data.fy.startYear}
              onChange={(e) => changeFy(Number(e.target.value))}
              className="px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:ring-2 focus:ring-[var(--primary)]/30 focus:outline-none bg-white"
              title="Financial Year"
            >
              {data.years.map((y) => (
                <option key={y.startYear} value={y.startYear}>FY {y.label}</option>
              ))}
            </select>
          )}
          <button
            onClick={() => exportFile('xlsx')}
            disabled={exporting !== null || !data}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-[var(--primary)] text-white hover:bg-[#912222] disabled:opacity-50"
          >
            {exporting === 'xlsx' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
            {exporting === 'xlsx' ? 'Exporting…' : 'Export Excel'}
          </button>
          <button
            onClick={exportPdf}
            disabled={exporting !== null || !data}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50"
          >
            {exporting === 'pdf' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
            {exporting === 'pdf' ? 'Preparing…' : 'Download PDF'}
          </button>
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
          >
            <Printer className="w-3.5 h-3.5" /> Print
          </button>
          <button
            onClick={() => exportFile('csv')}
            disabled={exporting !== null || !data}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" /> {exporting === 'csv' ? 'Exporting…' : 'Export CSV'}
          </button>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {loading && !data ? (
          <p className="text-sm text-slate-500 py-6 text-center">Loading cash transactions…</p>
        ) : !data || !s ? (
          <p className="text-sm text-slate-500 py-6 text-center">Cash compliance data is unavailable.</p>
        ) : (
          <>
            {/* Summary */}
            <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-2.5">
              {([
                ['Cash Disbursals', String(s.disbursals)], ['Cash Disbursed', inr(s.disbursed)],
                ['Cash Payments', String(s.payments)], ['Cash Received', inr(s.received)],
                ['Flagged Transactions', String(s.flagged)], ['Customers Flagged', String(s.customersFlagged)],
              ] as Array<[string, string]>).map(([label, value]) => (
                <div key={label} className="rounded-xl border border-slate-200 bg-slate-50/60 px-3.5 py-2.5">
                  <p className="text-base font-extrabold text-slate-900 tabular-nums leading-tight">{value}</p>
                  <p className="text-[11px] font-semibold text-slate-500 mt-0.5">{label}</p>
                </div>
              ))}
            </div>

            {/* Threshold */}
            <div className="flex flex-wrap items-center gap-2 rounded-xl bg-slate-50 border border-slate-200 px-3.5 py-2.5">
              <Settings2 className="w-4 h-4 text-[var(--primary)]" />
              <p className="text-xs text-slate-600">
                Cash review threshold: <b className="text-slate-900 tabular-nums">{inr(s.threshold)}</b>
                <span className="text-slate-400"> · Flags mark transactions for Compliance Review — never a finding of illegality, and never taxable-income classification.</span>
              </p>
              <div className="ml-auto flex items-center gap-2">
                {editThreshold ? (
                  <>
                    <input
                      value={thresholdInput}
                      onChange={(e) => setThresholdInput(e.target.value)}
                      placeholder="20000"
                      inputMode="numeric"
                      className={cn(inputCls, 'w-32 py-1.5')}
                    />
                    <button onClick={saveThreshold} disabled={savingThreshold} className="px-3 py-1.5 rounded-lg bg-[var(--primary)] text-white text-xs font-semibold disabled:opacity-50">
                      {savingThreshold ? 'Saving…' : 'Save'}
                    </button>
                    <button onClick={() => { setEditThreshold(false); setThresholdMsg(null) }} className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium hover:bg-white">Cancel</button>
                  </>
                ) : (
                  <button
                    onClick={() => { setThresholdInput(String(s.threshold)); setEditThreshold(true); setThresholdMsg(null) }}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-white bg-white"
                  >
                    Change
                  </button>
                )}
              </div>
              {thresholdMsg && <p className="w-full text-[11px] text-slate-500">{thresholdMsg}</p>}
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-2">
              <div className="relative min-w-[180px] flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input value={customerCode} onChange={(e) => onCodeChange(e.target.value)} placeholder="Customer / Customer ID" className={cn(inputCls, 'w-full pl-9')} />
              </div>
              <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className={inputCls} title="From date" />
              <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className={inputCls} title="To date" />
              <select value={type} onChange={(e) => { setType(e.target.value); setPage(1); setTimeout(() => load(fy, 1), 0) }} className={inputCls}>
                <option value="">All types</option>
                <option value="disbursal">Loan Disbursal</option>
                <option value="payment">Installment Payment</option>
              </select>
              <select value={mode} onChange={(e) => { setMode(e.target.value); setPage(1); setTimeout(() => load(fy, 1), 0) }} className={inputCls}>
                <option value="">All modes</option>
                <option value="Cash">Cash</option>
                <option value="Bank">Bank</option>
                <option value="UPI">UPI</option>
                <option value="Cheque">Cheque</option>
              </select>
              <div className="inline-flex rounded-xl border border-slate-300 overflow-hidden text-xs font-semibold">
                {(['all', 'flagged', 'notflagged'] as const).map((v) => (
                  <button
                    key={v}
                    onClick={() => { setFlagged(v); setPage(1); setTimeout(() => load(fy, 1), 0) }}
                    className={cn('px-3 py-2', flagged === v ? 'bg-[var(--primary)] text-white' : 'bg-white text-slate-600 hover:bg-slate-50')}
                  >
                    {v === 'all' ? 'All' : v === 'flagged' ? 'Flagged' : 'Not Flagged'}
                  </button>
                ))}
              </div>
              <button onClick={() => { setPage(1); load(fy, 1) }} className="px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222]">Apply</button>
              <button onClick={clearFilters} className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-medium hover:bg-slate-50">Clear</button>
            </div>

            {/* Table */}
            <div className="rounded-xl border border-slate-200 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-xs min-w-[1500px]">
                  <thead>
                    <tr className="bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)] text-left">
                      {['Date & Time', 'Transaction ID', 'Type', 'Customer ID', 'Customer Name', 'Loan ID', 'Payment ID', 'Mode', 'Amount', 'Principal', 'Interest', 'Outstanding', 'Cumulative', 'Compliance', 'Flag'].map((h) => (
                        <th key={h} className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-[#F3DFA7] whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {data.transactions.length === 0 ? (
                      <tr><td colSpan={15} className="px-3 py-6 text-center text-slate-500">No cash transactions found.</td></tr>
                    ) : data.transactions.map((r) => (
                      <tr key={`${r.kind}-${r.txnId}`} onClick={() => openDetail(r)} className="hover:bg-slate-50 cursor-pointer">
                        <td className="px-3 py-2 whitespace-nowrap tabular-nums">{r.date || '—'}</td>
                        <td className="px-3 py-2 font-mono text-[11px] whitespace-nowrap">{r.txnId.slice(0, 8)}…</td>
                        <td className="px-3 py-2 whitespace-nowrap">{r.type}</td>
                        <td className="px-3 py-2 font-mono whitespace-nowrap">{r.customerCode}</td>
                        <td className="px-3 py-2 whitespace-nowrap">{r.customerName}</td>
                        <td className="px-3 py-2 font-mono text-[11px] whitespace-nowrap">{r.loanId ? `${r.loanId.slice(0, 8)}…` : '—'}</td>
                        <td className="px-3 py-2 font-mono text-[11px] whitespace-nowrap">{r.paymentId ? `${r.paymentId.slice(0, 8)}…` : '—'}</td>
                        <td className="px-3 py-2 whitespace-nowrap">{r.mode}</td>
                        <td className="px-3 py-2 tabular-nums">{inr(r.amount)}</td>
                        <td className="px-3 py-2 tabular-nums">{inr(r.principal)}</td>
                        <td className="px-3 py-2 tabular-nums">{inr(r.interest)}</td>
                        <td className="px-3 py-2 tabular-nums">{inr(r.outstanding)}</td>
                        <td className="px-3 py-2 tabular-nums font-semibold" title="Cumulative Cash Transactions">{inr(r.cumulative)}</td>
                        <td className="px-3 py-2 whitespace-nowrap text-slate-600">{r.complianceStatus || '—'}</td>
                        <td className="px-3 py-2 whitespace-nowrap">
                          {r.flagged
                            ? <span className="inline-flex px-2 py-0.5 rounded-lg text-[10px] font-bold border whitespace-nowrap bg-amber-50 text-amber-700 border-amber-200">⚠ Flagged</span>
                            : <span className="text-slate-400">—</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="px-3 py-2.5 border-t border-slate-100 flex items-center justify-between">
                <p className="text-[11px] text-slate-500">Page {data.page} of {data.totalPages} · {data.total.toLocaleString('en-IN')} transactions</p>
                <div className="flex gap-2">
                  <button disabled={data.page <= 1 || loading} onClick={() => goPage(data.page - 1)} className="w-7 h-7 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50 disabled:opacity-40">
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                  <button disabled={data.page >= data.totalPages || loading} onClick={() => goPage(data.page + 1)} className="w-7 h-7 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50 disabled:opacity-40">
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Detail modal */}
      {(detail || detailLoading) && (
        <DetailModal
          detail={detail}
          loading={detailLoading}
          onClose={() => { setDetail(null); setDetailLoading(false) }}
        />
      )}
    </div>
  )
}

function DetailModal({ detail, loading, onClose }: { detail: CashDetail | null; loading: boolean; onClose: () => void }) {
  const row = (k: string, v: string) => (
    <div key={k} className="flex justify-between gap-4 py-1 border-b border-slate-50 last:border-0">
      <span className="text-xs text-slate-500">{k}</span>
      <span className="text-xs font-semibold text-slate-900 text-right break-all">{v}</span>
    </div>
  )
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="w-full max-w-[640px] max-h-[90vh] overflow-y-auto bg-white rounded-[22px] border border-slate-100 shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 sticky top-0 bg-white rounded-t-[22px]">
          <div>
            <h3 className="text-base font-bold text-slate-900">Cash Transaction</h3>
            <p className="text-xs text-slate-500 mt-0.5">{detail ? `${detail.kind === 'disbursal' ? 'Loan Disbursal' : 'Installment Payment'} · ${detail.customer.name}` : 'Loading…'}</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          {loading || !detail ? (
            <p className="text-sm text-slate-500">Loading details…</p>
          ) : (
            <>
              <div>
                <p className="text-sm font-bold text-slate-900 mb-2">Customer Details</p>
                <div className="rounded-2xl border border-slate-200 p-4">
                  {row('Customer Name', detail.customer.name || '—')}
                  {row('Customer ID', detail.customer.code || '—')}
                  {row('Business', detail.customer.business || '—')}
                  {row('Phone', detail.customer.phone || '—')}
                </div>
              </div>
              {detail.loan && (
                <div>
                  <p className="text-sm font-bold text-slate-900 mb-2">Loan Details</p>
                  <div className="rounded-2xl border border-slate-200 p-4">
                    {row('Loan ID', detail.loan.id)}
                    {row('Loan Date', detail.loan.date || '—')}
                    {row('Principal', inr(detail.loan.principal))}
                    {row('Interest Rate', `${detail.loan.rate}%`)}
                    {row('Duration', String(detail.loan.duration ?? '—'))}
                    {row('Total Payable', inr(detail.loan.total))}
                    {row('Disbursal Mode', detail.loan.mode || 'Unknown (not recorded)')}
                  </div>
                </div>
              )}
              {detail.payment && (
                <div>
                  <p className="text-sm font-bold text-slate-900 mb-2">Payment Details</p>
                  <div className="rounded-2xl border border-slate-200 p-4">
                    {row('Payment ID', detail.payment.id)}
                    {row('Payment Date', detail.payment.date || '—')}
                    {row('Payment Amount', inr(detail.payment.amount))}
                    {row('Payment Mode', detail.payment.mode)}
                    {(() => {
                      // Principal-first split, consistent with ledger allocation.
                      const paidBefore = detail.loan
                        ? Math.max(detail.loan.total - detail.payment.prevOutstanding, 0)
                        : detail.payment.amount;
                      const principalBefore = detail.loan
                        ? Math.min(paidBefore, detail.loan.principal)
                        : 0;
                      const principalPart = detail.loan
                        ? Math.min(detail.payment.amount, Math.max(detail.loan.principal - principalBefore, 0))
                        : detail.payment.amount;
                      return (
                        <>
                          {row('Principal Portion', inr(principalPart))}
                          {row('Interest Portion', inr(Math.max(detail.payment.amount - principalPart, 0)))}
                        </>
                      );
                    })()}
                    {row('Previous Outstanding', inr(detail.payment.prevOutstanding))}
                    {row('New Outstanding', inr(detail.payment.newOutstanding))}
                  </div>
                </div>
              )}
              <div>
                <p className="text-sm font-bold text-slate-900 mb-2">Compliance Details</p>
                <div className="rounded-2xl border border-slate-200 p-4">
                  {row('Threshold', inr(detail.compliance.threshold))}
                  {row('Cash Amount', inr(detail.compliance.cashAmount))}
                  {detail.compliance.fyCashBefore !== null && row('FY Cash Before', inr(detail.compliance.fyCashBefore))}
                  {detail.compliance.fyCashAfter !== null && row('FY Cash After', inr(detail.compliance.fyCashAfter))}
                  {detail.compliance.outstandingBefore !== null && row('Outstanding Before', inr(detail.compliance.outstandingBefore))}
                  {row('Flagged', detail.compliance.flagged ? 'Yes' : 'No')}
                  {row('Reason', detail.compliance.reason || '—')}
                </div>
              </div>
              <div>
                <p className="text-sm font-bold text-slate-900 mb-2">Audit Details</p>
                <div className="rounded-2xl border border-slate-200 p-4">
                  {detail.audit ? (
                    <>
                      {row('Audit ID', detail.audit.audit_id)}
                      {row('Action', detail.audit.action)}
                      {row('Performed By', detail.audit.performed_by || '—')}
                      {row('Date/Time', fmtDT(detail.audit.created_at))}
                      {row('Source', detail.audit.source || '—')}
                      {row('Result', detail.audit.result)}
                    </>
                  ) : (
                    <p className="text-xs text-slate-500">No linked audit event found for this transaction.</p>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
