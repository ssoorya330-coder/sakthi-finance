'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ChevronDown,
  LogOut,
  Menu,
  Bell,
  CalendarDays,
  Loader2,
  Settings,
  User,
} from 'lucide-react'
import { useAuthStore } from '@/store/auth-store'
import { useSidebarStore } from '@/store/sidebar-store'
import { useAuthActions } from '@/hooks/use-auth'
import Link from 'next/link'
import { useNotifications } from '@/hooks/use-notifications'


export default function DashboardHeader() {
  const { data: notifications } = useNotifications()
  const userName = useAuthStore((s) => s.userName)
  const userEmail = useAuthStore((s) => s.userEmail)
  const { toggleSidebar, isOpen } = useSidebarStore()
  const { handleLogout, isLoggingOut } = useAuthActions()
  const [showProfile, setShowProfile] = useState(false)
  const [today, setToday] = useState('')
  const profileRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setToday(new Date().toLocaleDateString('en-IN', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }))
  }, [])

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setShowProfile(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <motion.header
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className="sticky top-0 z-30 bg-white/75 backdrop-blur-xl border-b border-slate-100/40 shadow-[0_1px_2px_rgba(0,0,0,0.02)]"
    >
      <div className="flex items-center justify-between h-16 px-6">
        {/* Left */}
        <div className="flex items-center gap-4">
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: '0 4px 12px rgba(127,29,29,0.15)' }}
            whileTap={{ scale: 0.95 }}
            onClick={toggleSidebar}
            className="w-10 h-10 rounded-[12px] bg-white border border-slate-200/60 flex items-center justify-center hover:bg-slate-50 hover:border-slate-300/60 transition-all flex-shrink-0 shadow-sm"
          >
            <Menu className="w-[16px] h-[16px] text-slate-600" />
          </motion.button>
          <div className="hidden sm:block">
            <div className="flex items-center gap-2.5">
              <h1 className="text-lg font-bold text-slate-900 tracking-tight">Dashboard</h1>
            </div>
            <p className="text-sm text-slate-500 mt-0.5">
              Welcome back, <span className="font-semibold text-slate-700">{userName || 'User'}</span>
            </p>
          </div>
        </div>

        {/* Right */}
        <div className="flex items-center gap-2.5">
          {/* Date */}
          <motion.div
            whileHover={{ scale: 1.02, borderColor: 'rgba(212,169,74,0.2)' }}
            className="hidden md:flex items-center gap-2 bg-slate-50/80 border border-slate-200/60 rounded-[12px] px-3 py-1.5 transition-colors"
          >
            <CalendarDays className="w-4 h-4 text-[var(--primary)] flex-shrink-0" />
            <span className="text-xs font-medium text-slate-600 whitespace-nowrap">{today}</span>
          </motion.div>

          {/* Notifications */}
          <Link
            href="/dashboard/notifications"
            aria-label={notifications ? `Notifications, ${notifications.unread} unread` : 'Open notifications'}
            className="relative w-10 h-10 rounded-[12px] bg-white border border-slate-200/60 flex items-center justify-center hover:bg-slate-50 hover:border-slate-300/60 transition-all shadow-sm"
          >
            <Bell className="w-[16px] h-[16px] text-slate-600" />
            {!!notifications?.unread && <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 500, damping: 15 }}
              className="absolute -top-0.5 -right-0.5 w-[16px] h-[16px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] rounded-full text-[9px] font-bold text-white flex items-center justify-center shadow-lg shadow-[var(--primary)]/20"
            >
              {notifications.unread > 99 ? '99+' : notifications.unread}
            </motion.span>}
          </Link>

          {/* Profile */}
          <div className="relative" ref={profileRef}>
            <motion.button
              whileHover={{ scale: 1.02, borderColor: 'rgba(212,169,74,0.2)' }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setShowProfile(!showProfile)}
              className="flex items-center gap-3 pl-2 pr-3 py-1.5 rounded-[12px] bg-white border border-slate-200/60 hover:bg-slate-50 hover:border-slate-300/60 transition-all shadow-sm"
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="relative w-9 h-9 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center text-white font-semibold text-sm shadow-lg shadow-[var(--primary)]/10"
              >
                {(userName || 'A').charAt(0).toUpperCase()}
                <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 border-2 border-white rounded-full" />
              </motion.div>
              <div className="hidden md:block text-left">
                <p className="text-sm font-semibold text-slate-900 leading-tight">{userName || 'User'}</p>
                <p className="text-xs text-slate-500 truncate max-w-[160px]">{userEmail || 'Signed in'}</p>
              </div>
              <motion.div
                animate={{ rotate: showProfile ? 180 : 0 }}
                transition={{ duration: 0.2 }}
              >
                <ChevronDown className="w-4 h-4 text-slate-400 hidden md:block" />
              </motion.div>
            </motion.button>

            <AnimatePresence>
              {showProfile && (
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.96 }}
                  transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
                  className="absolute right-0 top-12 w-56 bg-white/90 backdrop-blur-xl rounded-2xl border border-slate-200/50 shadow-xl z-[var(--z-dropdown)] overflow-hidden"
                >
                  <div className="p-2">
                    <div className="px-3 py-2.5 border-b border-slate-100/50 mb-1">
                      <p className="text-sm font-semibold text-slate-900">{userName || 'User'}</p>
                      <p className="text-xs text-slate-500 truncate">{userEmail || 'Signed in'}</p>
                    </div>
                    <button className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm text-slate-600 hover:bg-[var(--primary-soft)] hover:text-[var(--primary)] transition-colors">
                      <User className="w-4 h-4" />
                      Profile Settings
                    </button>
                    <button className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm text-slate-600 hover:bg-[var(--primary-soft)] hover:text-[var(--primary)] transition-colors">
                      <Settings className="w-4 h-4" />
                      Account Settings
                    </button>
                    <button
                      onClick={handleLogout}
                      disabled={isLoggingOut}
                      className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm text-red-600 hover:bg-red-50 transition-colors disabled:opacity-50 mt-1"
                    >
                      {isLoggingOut ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <LogOut className="w-4 h-4" />
                      )}
                      {isLoggingOut ? 'Signing out...' : 'Sign Out'}
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </motion.header>
  )
}
