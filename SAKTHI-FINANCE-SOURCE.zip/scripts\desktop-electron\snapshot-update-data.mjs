// Read-only verification: output hashes/counts, never customer values or credentials.
import {readFile,writeFile} from 'node:fs/promises'
import path from 'node:path'
import {createHash} from 'node:crypto'
import pg from 'pg'
import {databaseProbeConfig} from '../desktop/runtime-config.mjs'
const label=process.argv[2]
if(!['before','after'].includes(label))throw Error('Use before or after')
const release=process.argv[3] || ''
if(release && !/^\d+\.\d+\.\d+$/.test(release))throw Error('Invalid release label')
const prefix=`test-reports/update-data${release?'-'+release:''}`
const raw=await readFile(path.join(process.env.APPDATA,'com.sakthifinance.desktop/runtime.json'))
const config=databaseProbeConfig(JSON.parse(raw))
const primary=new pg.Client(config)
const snapshot={configHash:createHash('sha256').update(raw).digest('hex'),databases:{}}
try {
  await primary.connect()
  const current=(await primary.query('SELECT current_database() AS name')).rows[0].name
  const names=(await primary.query("SELECT datname FROM pg_database WHERE datname = $1 OR datname ~ '^sf_account_[a-f0-9]{32}$' ORDER BY datname",[current])).rows.map(row=>row.datname)
  for(const name of names){
    const options={...config,database:name}
    if(options.connectionString){const url=new URL(options.connectionString);url.pathname='/'+name;options.connectionString=url.toString()}
    const client=new pg.Client(options)
    try{
      await client.connect();await client.query('BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
      const tables={}
      for(const table of ['customers','loans','payments']){
        const exists=(await client.query('SELECT to_regclass($1) AS name',['public.'+table])).rows[0].name
        if(!exists)continue
        const rows=(await client.query(`SELECT row_to_json(t)::text AS value FROM public.${table} t ORDER BY row_to_json(t)::text`)).rows
        const digest=createHash('sha256');for(const row of rows)digest.update(row.value+'\n')
        tables[table]={count:rows.length,sha256:digest.digest('hex')}
      }
      await client.query('COMMIT');snapshot.databases[name]=tables
    }finally{await client.end()}
  }
}finally{await primary.end()}
await writeFile(`${prefix}-${label}.json`,JSON.stringify(snapshot,null,2))
if(label==='after'){
  const before=JSON.parse(await readFile(`${prefix}-before.json`,'utf8'))
  if(JSON.stringify(before)!==JSON.stringify(snapshot))throw Error('Data snapshot changed; inspect before claiming preservation')
  console.log('PASS: configuration and all customer/loan/payment rows match the pre-update hashes.')
}else console.log(`Read-only pre-update snapshot saved for ${Object.keys(snapshot.databases).length} databases.`)
