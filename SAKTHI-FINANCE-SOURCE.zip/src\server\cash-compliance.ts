import { dbQuery } from './database';
import { recordAuditEvent, type AuditQueryable, type AuditActor } from './audit';

/**
 * Cash-transaction compliance service (review assistance, NOT legal advice).
 *
 * Flags cash activity that reaches the configured review threshold so an
 * auditor can review it under applicable tax rules. Flags NEVER block a
 * save — the business operation always completes normally.
 *
 * Threshold source: `settings.cash_limit_threshold` (admin-configurable).
 * DEFAULT_CASH_THRESHOLD is only the fallback when no setting exists.
 */

export const CASH_THRESHOLD_KEY = 'cash_limit_threshold';
export const DEFAULT_CASH_THRESHOLD = 20000;

export const DISBURSAL_MODES = ['Cash', 'Bank'] as const;
export const PAYMENT_MODES = ['Cash', 'Bank', 'UPI', 'PhonePe', 'Cheque'] as const;

const isCashMode = (mode: any): boolean =>
  typeof mode === 'string' && mode.trim().toUpperCase() === 'CASH';

/** Effective payment mode: explicit column, else legacy method, else Cash. */
export function effectivePaymentMode(row: { payment_mode?: any; payment_method?: any }): string {
  const explicit = typeof row.payment_mode === 'string' && row.payment_mode.trim() ? row.payment_mode.trim() : null;
  if (explicit) return explicit;
  const legacy = typeof row.payment_method === 'string' && row.payment_method.trim() ? row.payment_method.trim() : null;
  return legacy || 'Cash';
}

export const isCashPayment = (row: { payment_mode?: any; payment_method?: any }): boolean =>
  isCashMode(effectivePaymentMode(row));

/** Effective disbursal mode. NULL/unknown is reported as-is — never invented. */
export function effectiveDisbursalMode(row: { disbursal_mode?: any }): string | null {
  const v = typeof row.disbursal_mode === 'string' && row.disbursal_mode.trim() ? row.disbursal_mode.trim() : null;
  return v;
}

export const isCashDisbursal = (row: { disbursal_mode?: any }): boolean =>
  isCashMode(effectiveDisbursalMode(row));

/** Configured threshold (admin setting) with safe fallback. Never hardcoded in rules. */
export async function getCashThreshold(q?: AuditQueryable): Promise<number> {
  try {
    const run = q ? q.query.bind(q) : (t: string, p?: any[]) => dbQuery(t, p).then((r) => ({ rows: r.rows }));
    const r = await run(`SELECT value FROM settings WHERE key = $1 LIMIT 1`, [CASH_THRESHOLD_KEY]);
    const n = Number(r.rows[0]?.value);
    if (Number.isFinite(n) && n > 0) return n;
  } catch {}
  return DEFAULT_CASH_THRESHOLD;
}

export async function setCashThreshold(value: number): Promise<number> {
  if (!Number.isFinite(value) || value <= 0) {
    throw new Error('Threshold must be a positive number.');
  }
  if (value > 100000000) {
    throw new Error('Threshold is unreasonably large.');
  }
  await dbQuery(
    `INSERT INTO settings (key, value, category, updated_at)
     VALUES ($1, $2, 'compliance', NOW())
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`,
    [CASH_THRESHOLD_KEY, String(Math.floor(value))]
  );
  return Math.floor(value);
}

export const inrShort = (v: number): string =>
  `₹${(Number(v) || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;

export interface DisbursalCheck {
  flagged: boolean;
  threshold: number;
  mode: string | null;
  principal: number;
  reason: string | null;
}

export function checkDisbursalCompliance(
  loan: { disbursal_mode?: any; loan_amount?: any },
  threshold: number
): DisbursalCheck {
  const mode = effectiveDisbursalMode(loan);
  const principal = Number(loan.loan_amount) || 0;
  if (isCashMode(mode) && principal >= threshold) {
    return {
      flagged: true,
      threshold,
      mode,
      principal,
      reason:
        `Cash disbursal of ${inrShort(principal)} has reached/exceeded the configured ` +
        `${inrShort(threshold)} compliance threshold. Review under applicable tax rules. ` +
        `This is a compliance review flag, not a finding of illegality.`,
    };
  }
  return { flagged: false, threshold, mode, principal, reason: null };
}

export interface RepaymentCheck {
  flagged: boolean;
  threshold: number;
  mode: string;
  cashAmount: number;
  fyCashBefore: number;
  fyCashAfter: number;
  outstandingBefore: number;
  reason: string | null;
  details: string | null;
}

/**
 * History-based repayment check. Flags a cash payment when the single
 * payment reaches the threshold, or when it carries the customer's
 * financial-year cumulative cash across the threshold. Deterministic,
 * computed from PostgreSQL payment history.
 */
export async function checkRepaymentCompliance(
  q: AuditQueryable,
  opts: {
    userId: string;
    customerId: string;
    amount: number;
    mode: string;
    fyFrom: string;
    fyTo: string;
    /** Exclude this row from the "before" total (corrections/updates). */
    excludePaymentId?: string | null;
  },
  threshold: number
): Promise<RepaymentCheck> {
  const base = {
    threshold,
    mode: opts.mode,
    cashAmount: opts.amount,
    fyCashBefore: 0,
    fyCashAfter: opts.amount,
    outstandingBefore: 0,
  };
  if (!isCashMode(opts.mode)) {
    return { ...base, flagged: false, reason: null, details: null };
  }
  const paidRes = await q.query(
    `SELECT COALESCE(SUM(p.amount), 0) AS fy_cash
     FROM payments p
     WHERE p.user_id = $1 AND p.customer_id = $2
       AND p.payment_date >= $3 AND p.payment_date < $4
       AND ($5::text IS NULL OR p.payment_id::text <> $5::text)
       AND UPPER(COALESCE(NULLIF(p.payment_mode, ''), p.payment_method, 'Cash')) = 'CASH'`,
    [opts.userId, opts.customerId, opts.fyFrom, opts.fyTo, opts.excludePaymentId || null]
  );
  const fyCashBefore = Number(paidRes.rows[0]?.fy_cash) || 0;
  const outRes = await q.query(
    `SELECT COALESCE(SUM(l.total_amount - COALESCE(rec.paid, 0)), 0) AS outstanding
     FROM loans l
     LEFT JOIN (SELECT loan_id, SUM(amount) AS paid FROM payments WHERE user_id = $1 GROUP BY loan_id) rec
       ON rec.loan_id = l.loan_id
     WHERE l.user_id = $1 AND l.customer_id = $2`,
    [opts.userId, opts.customerId]
  );
  const outstandingBefore = Math.max(Number(outRes.rows[0]?.outstanding) || 0, 0);
  const fyCashAfter = fyCashBefore + opts.amount;
  const crossed = fyCashBefore < threshold && fyCashAfter >= threshold;
  const single = opts.amount >= threshold;
  if (single || crossed) {
    const why = single
      ? `Single cash payment of ${inrShort(opts.amount)} reaches/exceeds the configured ${inrShort(threshold)} threshold.`
      : `Customer FY cumulative cash (${inrShort(fyCashBefore)} + ${inrShort(opts.amount)} = ${inrShort(fyCashAfter)}) reaches the configured ${inrShort(threshold)} threshold.`;
    return {
      ...base,
      fyCashBefore,
      fyCashAfter,
      outstandingBefore,
      flagged: true,
      reason:
        `Cash repayment ${why} Outstanding before this payment was ${inrShort(outstandingBefore)}. ` +
        `Review under applicable tax rules. This is a compliance review flag, not a finding of illegality.`,
      details:
        `FY cash before=${fyCashBefore}, this payment=${opts.amount}, FY cash after=${fyCashAfter}, ` +
        `outstanding before=${outstandingBefore}, threshold=${threshold}.`,
    };
  }
  return {
    ...base,
    fyCashBefore,
    fyCashAfter,
    outstandingBefore,
    flagged: false,
    reason: null,
    details: null,
  };
}

export interface FlagEventInput {
  action: 'CASH_DISBURSAL_FLAGGED' | 'CASH_PAYMENT_FLAGGED';
  entityType: 'loan' | 'payment';
  entityId: string;
  customerId: string;
  loanId: string | null;
  paymentId: string | null;
  actor: AuditActor;
  ip: string | null;
  client: string | null;
  threshold: number;
  amount: number;
  reason: string;
  after?: Record<string, any> | null;
}

/** Flag audit event through the existing tamper-evident infrastructure. */
export async function recordCashFlagEvent(q: AuditQueryable, input: FlagEventInput): Promise<any> {
  return recordAuditEvent(q, {
    action: input.action,
    entityType: input.entityType,
    entityId: input.entityId,
    customerId: input.customerId,
    loanId: input.loanId,
    paymentId: input.paymentId,
    actor: input.actor,
    ipAddress: input.ip,
    clientInfo: input.client,
    source: 'cash-compliance',
    reason: input.reason,
    result: 'SUCCESS',
    changes: [
      { field: 'threshold', label: 'Review Threshold', before: null, after: input.threshold },
      { field: 'amount', label: 'Cash Amount', before: null, after: input.amount },
      { field: 'is_flagged', label: 'Flagged', before: false, after: true },
    ],
    after: input.after || null,
  });
}
