'use client'

import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Users,
  UserCheck,
  CheckCircle,
  IndianRupee,
  Banknote,
  TrendingUp,
  Scale,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react'
import { formatCurrency, formatNumber } from './dashboard.styles'

const iconMap: Record<string, React.FC<React.SVGProps<SVGSVGElement>>> = {
  Users,
  UserCheck,
  CheckCircle,
  IndianRupee,
  Banknote,
  TrendingUp,
  Scale,
  Wallet,
}

function useAnimatedCounter(target: number, duration = 1200) {
  const safeTarget = Number(target) || 0
  const [count, setCount] = useState(0)
  const frameRef = useRef<number>(0)

  useEffect(() => {
    const start = performance.now()
    const animate = (now: number) => {
      const elapsed = now - start
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setCount(Math.round(eased * safeTarget))
      if (progress < 1) {
        frameRef.current = requestAnimationFrame(animate)
      }
    }
    frameRef.current = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(frameRef.current)
  }, [safeTarget, duration])

  return count
}

interface StatCardProps {
  data: {
    id: string
    title: string
    value: number
    description: string
    icon: string
    color: string
    bgColor: string
    change?: number
    changeType?: 'up' | 'down'
  }
  index: number
}

export default function StatCard({ data, index }: StatCardProps) {
  const Icon = iconMap[data.icon] || Users
  const animatedValue = useAnimatedCounter(data.value)
  const isCurrency = ['Total Amount', 'Amount Given', 'Interest Amount', 'Balance Amount', "Today's Collection"].includes(data.title)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.5,
        delay: index * 0.06,
        ease: [0.16, 1, 0.3, 1],
      }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      className="bg-white rounded-[18px] border border-slate-100 p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_4px_16px_rgba(0,0,0,0.06),0_8px_24px_rgba(0,0,0,0.04)] transition-shadow duration-300 cursor-default"
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className="w-11 h-11 rounded-2xl flex items-center justify-center"
          style={{ backgroundColor: `${data.color}12` }}
        >
          <Icon className="w-5 h-5" color={data.color} />
        </div>
        {data.change !== undefined && (
          <div
            className={`flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-lg ${
              data.changeType === 'up'
                ? 'text-emerald-700 bg-emerald-50'
                : 'text-red-700 bg-red-50'
            }`}
          >
            {data.changeType === 'up' ? (
              <ArrowUpRight className="w-3 h-3" />
            ) : (
              <ArrowDownRight className="w-3 h-3" />
            )}
            {data.change}%
          </div>
        )}
      </div>
      <p className="text-sm font-medium text-slate-500 mb-1">{data.title}</p>
      <p className="text-2xl font-bold text-slate-900 tracking-tight">
        {isCurrency ? formatCurrency(animatedValue) : formatNumber(animatedValue)}
      </p>
      <p className="text-xs text-slate-400 mt-1.5">{data.description}</p>
    </motion.div>
  )
}
