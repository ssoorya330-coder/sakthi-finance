'use client'

import { useEffect, useMemo, useState } from 'react'
import { Search, Users, Wallet, BadgeCheck, Ban, RefreshCw, ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import TopBar from '@/components/dashboard/TopBar'
import { useCustomerStore } from '@/store/customer-store'
import { buildCustomerEntries, type EntryKind } from '@/lib/customer-entries'
import { formatCustomerCode } from '@/utils/customer-id'
import { formatCurrency, formatDateDMY } from '@/features/dashboard/dashboard.styles'
import { DateInput } from '@/components/ui/date-input'
import { paymentDateInIndia } from '@/lib/payment-history'

const badge = { Added: 'bg-blue-50 text-blue-700', Paid: 'bg-emerald-50 text-emerald-700', Completed: 'bg-violet-50 text-violet-700', Aborted: 'bg-red-50 text-red-700' }
const kinds: EntryKind[] = ['Added', 'Paid', 'Completed', 'Aborted']
const icons = { Added: Users, Paid: Wallet, Completed: BadgeCheck, Aborted: Ban }

export default function CustomerEntriesPage() {
  const customers = useCustomerStore(s => s.customers)
  const payments = useCustomerStore(s => s.paymentHistory)
  const loading = useCustomerStore(s => s.loading)
  const refresh = useCustomerStore(s => s.refresh)
  const initialized = useCustomerStore(s => s.initialized)
  useEffect(() => {
    if (!initialized) return
    const reload = () => {
      if (!useCustomerStore.getState().loading) void refresh()
    }
    reload()
    window.addEventListener('focus', reload)
    return () => window.removeEventListener('focus', reload)
  }, [initialized, refresh])
  const [search, setSearch] = useState('')
  const [date, setDate] = useState(() => paymentDateInIndia())
  const [kind, setKind] = useState<EntryKind | 'All'>('All')
  const [page, setPage] = useState(1)
  const entries = useMemo(() => buildCustomerEntries(customers, payments), [customers, payments])
  const matching = useMemo(() => entries.filter(entry => {
    const q = search.trim().toLowerCase()
    return (!date || entry.date === date) && (!q || [entry.customer.fullName, formatCustomerCode(entry.customer.customerCode), entry.customer.mobileNumber].some(value => value.toLowerCase().includes(q)))
  }), [entries, search, date])
  const filtered = matching.filter(entry => kind === 'All' || entry.kind === kind)
  const pages = Math.max(1, Math.ceil(filtered.length / 25))
  const currentPage = Math.min(page, pages)

  return (
    <div className="min-h-screen bg-[var(--background)] px-4 py-6 sm:px-8">
      <Link href="/dashboard/customers" className="mb-4 inline-flex items-center gap-2 rounded-xl border border-[var(--primary)]/20 bg-white px-4 py-2.5 text-sm font-semibold text-[var(--primary)] shadow-sm transition-colors hover:bg-rose-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--primary)]/50 focus-visible:ring-offset-2">
        <ArrowLeft className="h-4 w-4" aria-hidden="true" />
        Back to Customer Details
      </Link>
      <TopBar title="Entries Customer" subtitle={date ? `Entries for ${formatDateDMY(date)} · Select another date using the calendar` : 'All dates · Customer additions, saved payments, and account status'} />
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {kinds.map(value => {
          const Icon = icons[value]
          const records = matching.filter(entry => entry.kind === value)
          return <button key={value} type="button" aria-pressed={kind === value} onClick={() => { setKind(kind === value ? 'All' : value); setPage(1) }} className={`rounded-2xl border bg-white p-4 text-left shadow-sm ${kind === value ? 'border-[var(--primary)] ring-1 ring-[var(--primary)]' : 'border-slate-100'}`}>
            <span className={`inline-flex items-center gap-2 rounded-lg px-2 py-1 text-xs font-semibold ${badge[value]}`}><Icon className="h-4 w-4" />{value === 'Paid' ? 'Payments received' : value === 'Added' ? 'Customers added' : value}</span>
            <p className="mt-3 text-2xl font-bold text-slate-900">{records.length}</p>
            {value === 'Paid' && <p className="mt-1 text-xs text-slate-500">{formatCurrency(records.reduce((sum, entry) => sum + (entry.amount || 0), 0))} received</p>}
          </button>
        })}
      </div>
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="flex flex-wrap items-center gap-3 border-b border-slate-100 p-4">
          <label className="relative min-w-48 flex-1"><span className="sr-only">Search customer name, ID or phone</span><Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" /><input value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} placeholder="Search name, ID or phone" className="h-10 w-full rounded-xl border border-slate-200 pl-9 pr-3 text-sm" /></label>
          <div className="relative shrink-0 rounded-[20px] bg-gradient-to-br from-[#EAC5A0] via-[#F6DFD8] to-[#C98F9B] p-px shadow-[0_5px_18px_rgba(127,29,29,0.09)]">
            <div className="rounded-[19px] bg-gradient-to-br from-[#FFFCF5] via-white to-[#FFF0F1] px-2 py-1.5">
              <div className="mb-1 flex items-center justify-between gap-3 px-1">
                <span className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#87545D]">Entry calendar</span>
                <span className="h-1.5 w-1.5 rounded-full bg-[#C79543]" aria-hidden="true" />
              </div>
              <DateInput compact showIcon aria-label="Select entry date" value={date} onChange={e => { setDate(e.target.value); setPage(1) }} className="h-9 min-w-[165px] whitespace-nowrap rounded-xl border border-[#EDDAD4] bg-white/80 pl-12 pr-3 text-xs font-semibold shadow-sm hover:border-[#C58B94] hover:bg-rose-50 [&>span:first-child>span]:bg-gradient-to-br [&>span:first-child>span]:from-[#A33B45] [&>span:first-child>span]:to-[var(--primary)] [&>span:first-child>span]:shadow-sm [&_svg]:text-[#FFE4B5]" />
            </div>
          </div>
          <button type="button" onClick={() => { setDate(paymentDateInIndia()); setPage(1) }} className="rounded-xl bg-rose-50 px-3 py-2 text-sm font-medium text-[var(--primary)]">Today</button>
          <button type="button" onClick={() => { setDate(''); setKind('All'); setSearch(''); setPage(1) }} className="rounded-xl bg-slate-100 px-3 py-2 text-sm">All entries</button>
          <button type="button" disabled={loading} onClick={() => void refresh()} aria-label="Refresh entries" className="rounded-xl border border-slate-200 p-2.5 disabled:opacity-50"><RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} /></button>
          <Link href="/dashboard/add-customer" className="rounded-xl bg-[var(--primary)] px-3 py-2 text-sm font-semibold text-white">Add Customer</Link>
        </div>
        <p className="px-4 py-2 text-xs text-slate-500">Latest actions first · Ordered by recorded time</p>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[780px] text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase text-slate-500"><tr>{['Entry date', 'Customer ID', 'Customer name', 'Entry', 'Amount received', 'Current status', 'Details'].map(label => <th key={label} className="px-4 py-3 font-semibold">{label}</th>)}</tr></thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.slice((currentPage - 1) * 25, currentPage * 25).map(entry => <tr key={entry.id} className="hover:bg-rose-50/40">
                <td className="whitespace-nowrap px-4 py-3">{entry.date ? formatDateDMY(entry.date) : 'Date not recorded'}{entry.recordedAt && Number.isFinite(Date.parse(entry.recordedAt)) && <span className="mt-1 block text-xs text-slate-500">Recorded {new Date(entry.recordedAt).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>}</td>
                <td className="px-4 py-3 font-semibold text-[var(--primary)]">{formatCustomerCode(entry.customer.customerCode)}</td>
                <td className="px-4 py-3 font-medium">{entry.customer.fullName}</td>
                <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${badge[entry.kind]}`}>{entry.kind}</span></td>
                <td className="whitespace-nowrap px-4 py-3">{entry.amount === null ? '—' : formatCurrency(entry.amount)}</td>
                <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${entry.customer.status === 'Completed' ? badge.Completed : entry.customer.status === 'Aborted' ? badge.Aborted : 'bg-slate-100 text-slate-600'}`}>{entry.customer.status}</span></td>
                <td className="max-w-xs break-words px-4 py-3 text-slate-500">{entry.detail}</td>
              </tr>)}
              {!filtered.length && <tr><td colSpan={7} className="px-4 py-12 text-center text-slate-500">{loading ? 'Loading customer entries…' : 'No customer entries match these filters.'}</td></tr>}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between border-t border-slate-100 px-4 py-3 text-xs text-slate-500"><span>{filtered.length} entries · Page {currentPage} of {pages}</span><div className="flex gap-2"><button disabled={currentPage <= 1} onClick={() => setPage(currentPage - 1)} className="rounded-lg border px-3 py-2 disabled:opacity-40">Previous</button><button disabled={currentPage >= pages} onClick={() => setPage(currentPage + 1)} className="rounded-lg border px-3 py-2 disabled:opacity-40">Next</button></div></div>
      </div>
    </div>
  )
}
