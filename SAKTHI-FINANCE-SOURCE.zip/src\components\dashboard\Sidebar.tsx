'use client'

import { useState, useRef, useCallback, memo } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Building2,
  UserPlus,
  Users,
  BadgeCheck,
  UserX,
  Trash2,
  Settings,
  LogOut,
  Loader2,
  Info,
  ShieldCheck,
  KeyRound,
  UserRound,
  Database,
} from 'lucide-react'
import { useAuthStore } from '@/store/auth-store'
import { useSidebarStore } from '@/store/sidebar-store'
import { useAuthActions } from '@/hooks/use-auth'
import BrandLogo from '@/components/ui/brand-logo'
import { isDeveloperEmail } from '@/config/developer-access'

interface NavItem {
  label: string
  href?: string
  icon: React.FC<{ className?: string }>
  minRole?: 'owner' | 'admin' | 'manager' | 'employee' | 'viewer'
  viewerReadOnly?: boolean
  /**
   * Owner-only item (ADMIN section). Enforced with the explicit rule
   * role === 'owner' — never via hierarchy tricks that could admit Admin.
   */
  ownerOnly?: boolean
  /**
   * Customer self-service item. Shown ONLY to customer-role logins;
   * hidden from every staff role.
   */
  customerOnly?: boolean
}

const allNavItems: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', icon: Building2 },
  { label: 'My Account', href: '/dashboard/my-account', icon: UserRound, customerOnly: true },
  { label: 'Add Customer', href: '/dashboard/add-customer', icon: UserPlus, minRole: 'employee', viewerReadOnly: true },
  { label: 'Customer Details', href: '/dashboard/customers', icon: Users, minRole: 'viewer' },
  { label: 'Completed Customers', href: '/dashboard/completed-customers', icon: BadgeCheck, minRole: 'viewer' },
  { label: 'Aborted Customers', href: '/dashboard/aborted-customers', icon: UserX, minRole: 'viewer' },
  { label: 'Deleted Customers', href: '/dashboard/recently-deleted', icon: Trash2, minRole: 'admin' },
  { label: 'Audit', href: '/dashboard/audit', icon: ShieldCheck, minRole: 'admin' },
  { label: 'Database', href: '/database', icon: Database, minRole: 'admin' },
  { label: 'About', href: '/about', icon: Info },
  { label: 'Settings', href: '/dashboard/settings', icon: Settings },
]

// Admin section — rendered as a separate block at the bottom of the sidebar,
// after a visual divider. Owner-only: hidden entirely for every other role.
const adminNavItems: NavItem[] = [
  { label: 'Admin Access', href: '/dashboard/admin-access', icon: KeyRound, ownerOnly: true },
]

const ROLE_HIERARCHY: Record<string, number> = {
  customer: 0,
  viewer: 0,
  employee: 1,
  // legacy alias
  collector: 1,
  manager: 2,
  admin: 3,
  owner: 4,
}

function normalizeSidebarRole(role: string): string {
  if (role === 'collector') return 'employee';
  return role;
}

function canAccess(minRole: string | undefined, userRole: string): boolean {
  if (!minRole) return true
  const user = normalizeSidebarRole(userRole)
  const min = normalizeSidebarRole(minRole)
  // Viewer (0) is the lowest: viewer minRole means everyone incl. viewer.
  // Employee minRole means employee and above, but NOT viewer.
  return (ROLE_HIERARCHY[user] ?? 0) >= (ROLE_HIERARCHY[min] ?? 0)
}

const NOISE_TEXTURE =
  "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")"

const WAVE_PATTERN =
  "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='460' height='900' viewBox='0 0 460 900'%3E%3Cpath d='M0 140 C 115 70, 230 210, 345 140 S 460 140, 460 140' fill='none' stroke='rgba(255,215,120,0.12)' stroke-width='1'/%3E%3C/svg%3E\")"

const DOTS_PATTERN =
  "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24'%3E%3Ccircle cx='2' cy='2' r='1' fill='rgba(255,215,120,0.35)'/%3E%3C/svg%3E\")"

const Shimmer = memo(function Shimmer() {
  return (
    <span
      className="absolute -top-[20%] -bottom-[20%] w-[70px] pointer-events-none z-20"
      style={{
        background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.35), transparent)',
        transform: 'rotate(25deg) translateZ(0)',
        animation: 'sf-shimmer-slide 2.8s ease-in-out infinite',
        animationDelay: '1.2s',
        willChange: 'transform',
      }}
    />
  )
})

const RippleEffect = memo(function RippleEffect({ x, y }: { x: number; y: number }) {
  return (
    <motion.span
      initial={{ scale: 0, opacity: 0.5 }}
      animate={{ scale: 4, opacity: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="absolute rounded-[14px] bg-white/15 pointer-events-none"
      style={{ left: x - 7, top: y - 7, width: 14, height: 14, willChange: 'transform, opacity' }}
    />
  )
})

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.03, delayChildren: 0.04 },
  },
}
const itemVariants = {
  hidden: { opacity: 0, y: 6 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.22, ease: [0.22, 1, 0.36, 1] as any } },
}

const NavButton = memo(function NavButton({
  item,
  isActive,
  onClick,
  ripples,
}: {
  item: NavItem
  isActive: boolean
  onClick: (item: NavItem, e: React.MouseEvent<HTMLButtonElement>) => void
  ripples: { id: number; x: number; y: number }[]
}) {
  const Icon = item.icon
  return (
    <motion.button
      variants={itemVariants}
      onClick={(e) => onClick(item, e)}
      className={`relative w-full flex items-center h-[44px] rounded-[14px] pl-[20px] pr-[14px] gap-[12px] text-[15px] font-medium overflow-hidden will-change-transform ${
        isActive
          ? 'bg-[#FFD88E] text-[#472714] ring-1 ring-[rgba(255,255,255,0.35)] shadow-[inset_0_0_12px_rgba(255,255,255,0.30),0_10px_28px_rgba(255,210,120,0.35)]'
          : 'text-white/80 hover:bg-[rgba(255,255,255,0.08)]'
      }`}
      style={{ transform: 'translateZ(0)', contain: 'layout paint' }}
    >
      {ripples.length > 0 && ripples.map((r) => <RippleEffect key={r.id} x={r.x} y={r.y} />)}
      {isActive && <Shimmer />}
      <span className="relative z-10 flex items-center justify-center w-5 h-5 flex-shrink-0">
        <Icon className={`w-5 h-5 ${isActive ? 'text-[var(--primary)]' : 'text-[#D9B03F]'}`} />
      </span>
      <span className={`whitespace-nowrap overflow-hidden relative z-10 ${isActive ? 'text-[#472714] font-medium' : 'text-white/80 font-medium'}`}>{item.label}</span>
    </motion.button>
  )
})

function SidebarComponent() {
  const pathname = usePathname()
  const router = useRouter()
  const userName = useAuthStore((s) => s.userName)
  const role = useAuthStore((s) => s.role)
  const userEmail = useAuthStore((s) => s.userEmail)
  const { isOpen, closeSidebar } = useSidebarStore()
  const { handleLogout, isLoggingOut } = useAuthActions()
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([])
  const rippleIdRef = useRef(0)

  const filterByRole = (item: NavItem) => {
    // Owner-only items use the explicit rule role === 'owner'.
    if (item.ownerOnly) return role === 'owner'
    // Customer logins get a minimal isolated menu: only their own account
    // page plus the harmless About/Settings pages. Everything else —
    // including staff lists and audit — stays hidden.
    if (role === 'customer') {
      return Boolean(item.customerOnly) || item.href === '/about' || item.href === '/dashboard/settings'
    }
    // Customer-only items are never shown to staff roles.
    if (item.customerOnly) return false
    // Viewer is read-only: hide create-action entry (API also enforces 403).
    if (role === 'viewer' && (item as NavItem).viewerReadOnly) return false
    return canAccess(item.minRole, role || 'employee')
  }

  const visibleNavItems = allNavItems.filter(filterByRole)
  // Entire ADMIN section (label, divider, and items) is hidden unless the
  // user can see at least one admin item — never merely disabled.
  const visibleAdminItems = adminNavItems.filter(filterByRole)

  const handleNavClick = useCallback(
    (item: NavItem, e: React.MouseEvent<HTMLButtonElement>) => {
      if (!item.href) return
      const rect = e.currentTarget.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top
      const id = rippleIdRef.current++
      setRipples((prev) => [...prev, { id, x, y }])
      setTimeout(() => setRipples((prev) => prev.filter((r) => r.id !== id)), 500)
      router.push(item.href!)
      closeSidebar()
    },
    [router, closeSidebar]
  )

  const isActivePath = useCallback(
    (href?: string) => {
      if (!href) return false
      return href === '/dashboard' ? pathname === '/dashboard' : pathname.startsWith(href)
    },
    [pathname]
  )

  const onLogout = useCallback(() => {
    closeSidebar()
    handleLogout()
  }, [closeSidebar, handleLogout])

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/25 z-40"
            style={{ backdropFilter: 'blur(4px)', WebkitBackdropFilter: 'blur(4px)' }}
            onClick={closeSidebar}
          />
        )}
      </AnimatePresence>

      <motion.aside
        initial={false}
        animate={{ x: isOpen ? 0 : -260 }}
        transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] as any }}
        className="fixed left-0 top-0 h-full w-[220px] lg:w-[235px] z-[var(--z-sidebar)] flex flex-col overflow-hidden"
        style={{
          background: 'var(--sidebar-background)',
          borderTopRightRadius: '28px',
          borderBottomRightRadius: '28px',
          borderRight: '1px solid rgba(255,255,255,0.08)',
          boxShadow: '0 25px 60px rgba(80,0,0,0.35)',
          transform: 'translateZ(0)',
          contain: 'layout paint',
          willChange: 'transform',
        }}
      >
        <div
          className="absolute inset-0 opacity-[0.04] pointer-events-none"
          style={{
            backgroundImage: WAVE_PATTERN,
            backgroundSize: '920px 100%',
            backgroundRepeat: 'repeat-x',
            transform: 'translateZ(0)',
          }}
        />
        <div
          className="absolute inset-0 opacity-[0.03] pointer-events-none"
          style={{
            backgroundImage: DOTS_PATTERN,
            backgroundSize: '24px 24px',
          }}
        />
        <div
          className="absolute -top-24 -right-20 w-80 h-80 rounded-full blur-[60px] pointer-events-none"
          style={{ background: 'radial-gradient(circle, rgba(255,210,120,0.10), transparent 70%)', transform: 'translateZ(0)' }}
        />
        <div className="absolute inset-0 pointer-events-none opacity-[0.03] mix-blend-overlay" style={{ backgroundImage: NOISE_TEXTURE }} />

        <div className="relative flex flex-col items-center pt-6 pb-6 px-6 flex-shrink-0" style={{ contain: 'layout paint' }}>
          <div
            className="relative w-28 h-28 flex items-center justify-center rounded-[20px] bg-[#FFFAED] shadow-[0_10px_25px_rgba(212,175,55,0.2)] overflow-hidden"
          >
            <BrandLogo className="w-full h-full p-1" />
            <Shimmer />
          </div>
          <div className="text-center mt-5 whitespace-nowrap">
            <h1 className="text-sm font-bold tracking-tight" style={{ color: '#FFD87A' }}>
              SAKTHI FINANCE
            </h1>
            <p className="text-[9px] font-medium tracking-wide mt-0.5" style={{ color: 'rgba(255,255,255,0.72)' }}>
              Finance Management System
            </p>
          </div>
        </div>

        <nav className="relative flex-1 px-3 py-2 overflow-y-auto overflow-x-hidden sidebar-scroll" style={{ contain: 'layout paint', contentVisibility: 'auto' as any }}>
          <div className="flex items-center gap-2 px-3 mb-4 whitespace-nowrap">
            <span className="text-[9px] font-semibold uppercase tracking-[0.15em] text-white/45">MAIN MENU</span>
            <div className="flex-1 h-px bg-white/10" />
          </div>
          <motion.div initial="hidden" animate="visible" variants={containerVariants} className="space-y-[7px]">
            {visibleNavItems.map((item) => (
              <NavButton key={item.label} item={item} isActive={isActivePath(item.href)} onClick={handleNavClick} ripples={[]} />
            ))}
          </motion.div>

          {/* ADMIN — separate section at the bottom of the sidebar, after a
              visual divider. Owner-only: the whole block (divider, label,
              and items) is hidden from Admin and Customer users. */}
          {visibleAdminItems.length > 0 && (
            <motion.div initial="hidden" animate="visible" variants={containerVariants} className="mt-4">
              <div className="h-px bg-white/10 mx-3 mb-4" />
              <div className="flex items-center gap-2 px-3 mb-4 whitespace-nowrap">
                <span className="text-[9px] font-semibold uppercase tracking-[0.15em] text-white/45">ADMIN</span>
                <div className="flex-1 h-px bg-white/10" />
              </div>
              <div className="space-y-[7px]">
                {visibleAdminItems.map((item) => (
                  <NavButton key={item.label} item={item} isActive={isActivePath(item.href)} onClick={handleNavClick} ripples={[]} />
                ))}
              </div>
            </motion.div>
          )}
        </nav>

        <div className="relative px-4 pb-5 pt-2 flex-shrink-0" style={{ contain: 'layout paint' }}>
          <div
            className="relative flex items-center justify-between rounded-[18px] px-4 py-3 overflow-hidden"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)', transform: 'translateZ(0)' }}
          >
            <Shimmer />
            <div className="flex items-center gap-3 min-w-0">
              <div
                className="relative w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0 shadow-md"
                style={{ background: 'linear-gradient(135deg, #D63E3E, #F36A6A)', transform: 'translateZ(0)' }}
              >
                {(userName || 's').charAt(0).toUpperCase()}
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white/30 rounded-full" />
              </div>
              <div className="min-w-0 overflow-hidden whitespace-nowrap">
                <p className="text-sm font-semibold text-white/90 truncate">{userName || 'User'}</p>
                <p className="text-[10px] font-medium text-white/55">Signed in</p>
              </div>
            </div>
            <button
              onClick={onLogout}
              disabled={isLoggingOut}
              className="w-7 h-7 rounded-full flex items-center justify-center text-white/50 hover:bg-white/10 hover:text-white/90 transition-colors disabled:opacity-50 flex-shrink-0"
            >
              {isLoggingOut ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <LogOut className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      </motion.aside>
    </>
  )
}

export default memo(SidebarComponent)
