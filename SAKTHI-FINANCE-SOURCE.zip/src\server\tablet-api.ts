import { NextRequest } from 'next/server'
import { randomUUID } from 'node:crypto'
import { requireAuthWithPermission } from '../lib/api-utils'
import { dbQuery, dbTransaction } from './database'
import { customerRevision, ensureDeviceSyncSchema } from './device-sync'
import { POST as syncRecord } from '../app/api/device-sync/route'

/** Internal desktop worker entry, never an unauthenticated HTTP route. */
export async function tabletApi(action: string, body: Record<string, unknown>) {
  const auth = await requireAuthWithPermission('customers:create')
  if (auth.error) return { status: auth.error.status, ok: false, data: { error: 'Sign in on the laptop first.' } }
  const owner = auth.user.userId
  await ensureDeviceSyncSchema()
  // Persist identity in the actual configured database. No fallback database.
  await dbQuery('CREATE TABLE IF NOT EXISTS tablet_database_identity (singleton BOOLEAN PRIMARY KEY DEFAULT TRUE CHECK(singleton), id UUID NOT NULL UNIQUE)')
  await dbQuery('INSERT INTO tablet_database_identity(singleton,id) VALUES(TRUE,$1) ON CONFLICT(singleton) DO NOTHING', [randomUUID()])
  const identity = await dbQuery('SELECT id::text FROM tablet_database_identity WHERE singleton=TRUE')
  const databaseId = identity.rows[0]?.id as string
  if (!databaseId) throw Error('Database identity unavailable')
  if (action === 'identity') {
    const account = await dbQuery('SELECT google_id FROM users WHERE user_id=$1 AND is_active=TRUE', [owner])
    if (!account.rows[0]?.google_id) return {status:403,ok:false,data:{error:'Google sign-in is required on the laptop.'}}
    return {status:200,ok:true,data:{ownerId:owner,googleSubject:account.rows[0].google_id,databaseId}}
  }
  if (body.ownerId !== owner || body.databaseId !== databaseId) return {status:403,ok:false,data:{error:'Account or database changed. Reconnect to the correct laptop.'}}
  if (action === 'sync') {
    const operation = body.operation as Record<string, unknown> | undefined
    if (!operation || operation.deviceId !== body.deviceId) return {status:400,ok:false,data:{error:'Invalid device operation.'}}
    const response = await syncRecord(new NextRequest('http://sakthi.desktop/api/device-sync', {
      method:'POST', headers:{'Content-Type':'application/json','X-Sync-Owner':owner},body:JSON.stringify(operation),
    }))
    return {status:response.status,ok:response.ok,data:await response.json()}
  }
  if (action !== 'summaries') return {status:404,ok:false,data:{error:'Unknown tablet operation.'}}
  const cursor = body.cursor === undefined ? '' : body.cursor
  if (typeof cursor !== 'string' || cursor.length > 100) return {status:400,ok:false,data:{error:'Invalid page cursor.'}}
  const data = await dbTransaction(async tx => {
    await tx.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ')
    const rows = await tx.query(`SELECT id::text,full_name,phone_number FROM customers
      WHERE user_id=$1 AND id::text > $2 ORDER BY id::text LIMIT 26`, [owner,cursor])
    const page = rows.rows.slice(0,25)
    const customers = []
    for (const row of page) {
      const revision = await customerRevision(tx,owner,row.id)
      const loans = await tx.query(`SELECT loan_id::text AS id, cycle_number,kanaku_number,
        total_amount::text,paid_amount::text,status FROM kanaku_loan_balances
        WHERE user_id=$1 AND customer_id::text=$2 ORDER BY loan_id LIMIT 201`,[owner,row.id])
      if(loans.rows.length>200) throw Error('Customer exceeds supported cache page size')
      customers.push({id:row.id,name:row.full_name,phone:row.phone_number||'',revision:revision!.revision,loans:loans.rows})
    }
    return {ownerId:owner,databaseId,customers,nextCursor:rows.rows.length>25?page[page.length-1].id:null}
  })
  return {status:200,ok:true,data}
}
