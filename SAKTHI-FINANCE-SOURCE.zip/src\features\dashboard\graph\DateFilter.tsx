'use client'

import { memo } from 'react'
import { motion } from 'framer-motion'
import { CalendarRange } from 'lucide-react'
import type { RangeKey } from './graph.types'

const OPTIONS: { key: RangeKey; label: string }[] = [
  { key: 'today', label: 'Today' },
  { key: 'yesterday', label: 'Yesterday' },
  { key: 'last7', label: 'Last 7 Days' },
  { key: 'last30', label: 'Last 30 Days' },
  { key: 'last3m', label: 'Last 3 Months' },
  { key: 'last6m', label: 'Last 6 Months' },
  { key: 'last1y', label: 'Last 1 Year' },
  { key: 'custom', label: 'Custom' },
]

interface DateFilterProps {
  activeKey: RangeKey
  customLabel: string | null
  onSelect: (key: RangeKey) => void
}

function DateFilterBase({ activeKey, customLabel, onSelect }: DateFilterProps) {
  return (
    <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Date range filter">
      {OPTIONS.map((opt) => {
        const isActive = activeKey === opt.key
        return (
          <motion.button
            key={opt.key}
            type="button"
            onClick={() => onSelect(opt.key)}
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.95 }}
            transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
            aria-pressed={isActive}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-[10px] text-xs font-semibold border transition-all duration-300 ${
              isActive
                ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                : 'bg-white text-slate-500 border-slate-200 hover:border-slate-300 hover:text-slate-700'
            }`}
          >
            {opt.key === 'custom' && <CalendarRange className="w-3.5 h-3.5" />}
            {opt.key === 'custom' && customLabel ? customLabel : opt.label}
          </motion.button>
        )
      })}
    </div>
  )
}

export default memo(DateFilterBase)
