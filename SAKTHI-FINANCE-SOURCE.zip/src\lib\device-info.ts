/**
 * Best-effort User-Agent parsing + IP classification for the Admin Access
 * device/session views. Dependency-free regex parsing — approximate only,
 * never claimed as precise identification.
 */

export interface ParsedDevice {
  device: string
  browser: string
  os: string
}

export function parseUserAgent(ua: string | null | undefined): ParsedDevice {
  const s = ua || ''
  let os = 'Unknown'
  let browser = 'Unknown'
  let device = 'Desktop'

  if (/Android/i.test(s)) {
    os = 'Android'
    device = 'Mobile'
  } else if (/iPhone|iPad|iPod/i.test(s)) {
    os = /iPad/i.test(s) ? 'iPadOS' : 'iOS'
    device = /iPad/i.test(s) ? 'Tablet' : 'Mobile'
  } else if (/Windows NT 10/i.test(s)) {
    os = 'Windows 10/11'
  } else if (/Windows NT/i.test(s)) {
    os = 'Windows'
  } else if (/Mac OS X/i.test(s)) {
    os = 'macOS'
  } else if (/Linux/i.test(s)) {
    os = 'Linux'
  } else if (/CrOS/i.test(s)) {
    os = 'ChromeOS'
  }

  const edge = s.match(/Edg(?:e|A|iOS)?\/(\d+)/i)
  const chrome = s.match(/(?:Chrome|CriOS)\/(\d+)/i)
  const firefox = s.match(/(?:Firefox|FxiOS)\/(\d+)/i)
  const safari = s.match(/Version\/(\d+).*Safari/i)
  if (edge) browser = `Edge ${edge[1]}`
  else if (/OPR\/(\d+)/i.test(s)) browser = `Opera ${s.match(/OPR\/(\d+)/i)?.[1] || ''}`.trim()
  else if (chrome && !/Edg/i.test(s)) browser = `Chrome ${chrome[1]}`
  else if (firefox) browser = `Firefox ${firefox[1]}`
  else if (safari) browser = `Safari ${safari[1]}`

  if (/Mobile|Android|iPhone|iPod/i.test(s)) device = 'Mobile'
  else if (/iPad|Tablet/i.test(s)) device = 'Tablet'

  return { device, browser, os }
}

/**
 * Honest IP classification. Private/loopback ranges are labelled as local;
 * anything else is "Unknown" — never a fabricated city.
 */
export function classifyIpLocation(ip: string | null | undefined): string {
  if (!ip) return 'Unknown'
  const v = ip.trim()
  if (v === '::1' || v === '127.0.0.1' || v === 'localhost') return 'Localhost'
  if (/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|fd|fe80)/i.test(v)) return 'Local network'
  return 'Unknown'
}
