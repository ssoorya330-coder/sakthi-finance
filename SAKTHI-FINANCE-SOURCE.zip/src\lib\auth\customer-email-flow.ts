import { z } from 'zod';
import { normalizePhone } from '@/lib/phone';

export const customerEmailInput = z.object({
  action: z.enum(['send', 'verify']),
  phone: z.string().max(30).transform(normalizePhone).refine(Boolean, 'Enter a valid mobile number.'),
  email: z.string().trim().email().max(254).transform((value) => value.toLowerCase()),
  code: z.string().trim().regex(/^\d{6,10}$/, 'Enter the code from your email.').optional(),
}).refine((value) => value.action !== 'verify' || Boolean(value.code), {
  message: 'Enter the code from your email.', path: ['code'],
});

export interface CustomerEmailUser {
  user_id: string;
  email: string;
  full_name: string;
  customer_id: string;
}

interface Dependencies {
  findCustomer: (email: string, phone: string) => Promise<CustomerEmailUser | null>;
  sendCode: (email: string) => Promise<boolean>;
  verifyCode: (email: string, code: string) => Promise<string | null>;
}

/** Email ownership is proved by the provider; phone only identifies the registered account. */
export async function customerEmailFlow(input: z.infer<typeof customerEmailInput>, deps: Dependencies) {
  const user = await deps.findCustomer(input.email, input.phone!);
  if (input.action === 'send') {
    // Same response for unknown, unlinked, disabled and staff accounts.
    if (user && !(await deps.sendCode(user.email.trim().toLowerCase()))) {
      return { status: 503, error: 'Unable to send the email right now. Please try again later.' };
    }
    return { status: 200, message: 'If these details match a registered customer account, a code will arrive by email. Check your spam folder too.' };
  }
  const invalid = { status: 401, error: 'Unable to verify. Check your details and code, or request a new code.' };
  if (!user || !input.code) return invalid;
  const verifiedEmail = await deps.verifyCode(user.email.trim().toLowerCase(), input.code);
  if (verifiedEmail?.trim().toLowerCase() !== input.email) return invalid;
  // Re-check access after verification in case an owner changed the account meanwhile.
  const current = await deps.findCustomer(input.email, input.phone!);
  if (!current || current.user_id !== user.user_id || current.customer_id !== user.customer_id) return invalid;
  return { status: 200, user: current };
}
