'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import {
  FileSpreadsheet, Download, Printer, ChevronLeft, ChevronRight,
  CheckCircle2, AlertTriangle, Loader2, Landmark, ChevronDown,
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface Overall {
  totalCustomers: number
  activeCustomers: number
  completedCustomers: number
  totalLoans: number
  activeLoans: number
  completedLoans: number
  totalGiven: number
  totalInterest: number
  totalReceivable: number
  totalReceived: number
  principalRecovered: number
  interestReceived: number
  outstandingPrincipal: number
  outstandingInterest: number
  outstanding: number
}

interface CustomerRow {
  customerId: string
  customerCode: string
  customerName: string
  business: string | null
  loans: number
  given: number
  interest: number
  receivable: number
  received: number
  principal: number
  interestReceived: number
  outPrincipal: number
  outInterest: number
  outstanding: number
  activeLoans: number
  completedLoans: number
  cashDisbursed: number
  cashPayments: number
  flaggedCount: number
}

interface LoanRow {
  loanId: string
  customerId: string
  customerCode: string
  customerName: string
  loanDate: string | null
  principal: number
  interestRate: number
  interest: number
  receivable: number
  frequency: string | null
  installment: number
  received: number
  principalRecovered: number
  interestReceived: number
  outPrincipal: number
  outInterest: number
  outstanding: number
  status: string
  disbursalMode: string | null
}

interface LedgerRow {
  date: string | null
  txnId: string
  customerCode: string
  customerName: string
  loanId: string | null
  paymentId: string | null
  type: string
  amount: number
  principal: number
  interest: number
  prevOutstanding: number
  balance: number
  mode: string
  performedBy: string | null
  result: string
  notes: string | null
  reference: string | null
}

interface Recon {
  ok: boolean
  checks: Array<{
    name: string
    levels: { overall: number; customer: number; loans: number; ledger: number | null }
    ok: boolean
    difference: number
  }>
}

interface DataQualityCheck {
  key: string
  label: string
  severity: 'warning' | 'critical'
  count: number
  amount: number
  status: 'OK' | 'REVIEW'
  detail: string
}

interface FinData {
  years: Array<{ startYear: number; label: string }>
  fy: { startYear: number; label: string; period: string }
  generatedAt: string
  generatedBy: string
  overall: Overall
  customers: CustomerRow[]
  loans: LoanRow[]
  ledger: LedgerRow[]
  ledgerTotal: number
  ledgerPage: number
  ledgerPages: number
  reconciliation: Recon
  dataQuality: DataQualityCheck[]
  allocationRule: string
}

const inr = (v: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(Number(v) || 0)

const inr2 = (v: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(Number(v) || 0)

const num = (v: number) => (Number(v) || 0).toLocaleString('en-IN')

const fmtDate = (iso: string | null) => {
  if (!iso) return '—'
  try {
    return new Date(iso.length <= 10 ? `${iso}T00:00:00` : iso).toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
    })
  } catch {
    return iso
  }
}

const fmtDT = (iso: string) => {
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true,
    })
  } catch {
    return iso
  }
}

async function api<T>(url: string): Promise<T> {
  const res = await fetch(url, { credentials: 'include' })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error((data as any).error || `Request failed (${res.status})`)
  return data as T
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 2000)
}

export default function FinancialAudit({ fyYear, onFyYearChange }: { fyYear?: number | null; onFyYearChange?: (y: number) => void }) {
  const [data, setData] = useState<FinData | null>(null)
  const [innerFy, setInnerFy] = useState<number | null>(null)
  const fy = fyYear ?? innerFy
  const [ledgerPage, setLedgerPage] = useState(1)
  const [loading, setLoading] = useState(true)
  const [exporting, setExporting] = useState<string | null>(null)
  const loadedFy = useRef<number | null>(null)
  // Collapsible detail sections (customer/loan/ledger lists grow over time).
  const [showCustomers, setShowCustomers] = useState(false)
  const [showLoans, setShowLoans] = useState(false)
  const [showLedger, setShowLedger] = useState(false)

  const load = useCallback(async (fyYearArg: number | null, page: number) => {
    setLoading(true)
    try {
      const p = new URLSearchParams()
      if (fyYearArg) p.set('fy', String(fyYearArg))
      p.set('ledgerPage', String(page))
      p.set('ledgerLimit', '25')
      const d = await api<FinData>(`/api/audit/financial?${p.toString()}`)
      setData(d)
      setInnerFy(d.fy.startYear)
      loadedFy.current = d.fy.startYear
      setLedgerPage(d.ledgerPage)
    } catch {
      setData(null)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load(null, 1)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Shared FY (controlled by the Audit page when provided).
  useEffect(() => {
    if (fyYear != null && fyYear !== loadedFy.current) {
      loadedFy.current = fyYear
      setInnerFy(fyYear)
      setLedgerPage(1)
      load(fyYear, 1)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fyYear])

  const changeFy = (y: number) => {
    loadedFy.current = y
    setInnerFy(y)
    if (onFyYearChange) onFyYearChange(y)
    setLedgerPage(1)
    load(y, 1)
  }

  const goLedger = (page: number) => {
    setLedgerPage(page)
    load(fy, page)
  }

  const exportFile = async (format: 'xlsx' | 'csv', section?: string) => {
    const key = section ? `${format}:${section}` : format
    setExporting(key)
    try {
      const p = new URLSearchParams()
      if (fy) p.set('fy', String(fy))
      p.set('format', format)
      if (section) p.set('section', section)
      const res = await fetch(`/api/audit/financial/export?${p.toString()}`, { credentials: 'include' })
      if (!res.ok) throw new Error('Export failed')
      const blob = await res.blob()
      const stamp = new Date().toISOString().slice(0, 10)
      const safeFy = `FY${data?.fy.startYear || ''}`
      const name = format === 'xlsx'
        ? `sakthi-finance-financial-audit-${safeFy}-${stamp}.xlsx`
        : `sakthi-finance-${section || 'ledger'}-${safeFy}-${stamp}.csv`
      downloadBlob(blob, name)
    } catch {}
    finally {
      setExporting(null)
    }
  }

  const exportPdf = async () => {
    if (!data) return
    setExporting('pdf')
    try {
      const { downloadFinancialAuditPdf } = await import('@/lib/audit-pdf')
      await downloadFinancialAuditPdf(data)
    } catch {}
    finally {
      setExporting(null)
    }
  }

  const o = data?.overall
  const countMetrics: Array<[string, string]> = o
    ? [
        ['Total Customers', num(o.totalCustomers)],
        ['Active Customers', num(o.activeCustomers)],
        ['Completed Customers', num(o.completedCustomers)],
        ['Total Loans', num(o.totalLoans)],
        ['Active Loans', num(o.activeLoans)],
        ['Completed Loans', num(o.completedLoans)],
      ]
    : []
  const finMetrics: Array<[string, string]> = o
    ? [
        ['Total Amount Given', inr2(o.totalGiven)],
        ['Total Interest Amount', inr2(o.totalInterest)],
        ['Total Receivable', inr2(o.totalReceivable)],
        ['Total Amount Received', inr2(o.totalReceived)],
        ['Principal Recovered', inr2(o.principalRecovered)],
        ['Interest Received', inr2(o.interestReceived)],
        ['Outstanding Principal', inr2(o.outstandingPrincipal)],
        ['Outstanding Interest', inr2(o.outstandingInterest)],
        ['Total Outstanding Amount', inr2(o.outstanding)],
      ]
    : []

  const busy = (key: string) => exporting === key

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      {/* Print-only report title */}
      <div className="hidden print:block px-6 pt-6 text-center">
        <p className="text-xl font-extrabold text-slate-900">SAKTHI FINANCE</p>
        <p className="text-sm font-bold text-slate-700 mt-1">OVERALL FINANCIAL AUDIT REPORT</p>
        <p className="text-xs text-slate-500 mt-1">Financial Year: FY {data?.fy.label || ''} · Period: {data?.fy.period || ''}</p>
        {data && <p className="text-[11px] text-slate-400 mt-0.5">Generated On: {fmtDT(data.generatedAt)} · Generated By: {data.generatedBy}</p>}
      </div>

      <div className="px-4 py-3 border-b border-slate-100 flex flex-wrap items-center gap-2">
        <p className="text-sm font-bold text-slate-900">Financial Audit</p>
        <span className="text-[11px] text-slate-400 font-medium">FY {data?.fy.label || '…'}</span>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          {data && data.years.length > 0 && (
            <select
              value={fy ?? data.fy.startYear}
              onChange={(e) => changeFy(Number(e.target.value))}
              className="px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:ring-2 focus:ring-[var(--primary)]/30 focus:outline-none bg-white"
              title="Financial Year"
            >
              {data.years.map((y) => (
                <option key={y.startYear} value={y.startYear}>FY {y.label}</option>
              ))}
            </select>
          )}
          <button
            onClick={() => exportFile('xlsx')}
            disabled={exporting !== null || !data}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-[var(--primary)] text-white hover:bg-[#912222] disabled:opacity-50"
          >
            {busy('xlsx') ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
            {busy('xlsx') ? 'Exporting…' : 'Export Excel'}
          </button>
          <button
            onClick={exportPdf}
            disabled={exporting !== null || !data}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50"
          >
            {busy('pdf') ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
            {busy('pdf') ? 'Preparing…' : 'Download PDF'}
          </button>
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
          >
            <Printer className="w-3.5 h-3.5" /> Print
          </button>
          <button
            onClick={() => exportFile('csv', 'ledger')}
            disabled={exporting !== null || !data}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50"
          >
            Export CSV
          </button>
        </div>
      </div>

      <div className="p-4 space-y-5">
        {loading && !data ? (
          <p className="text-sm text-slate-500 py-6 text-center">Loading financial audit…</p>
        ) : !data || !o ? (
          <p className="text-sm text-slate-500 py-6 text-center">Financial audit is unavailable.</p>
        ) : (
          <>
            <div className="text-xs text-slate-500">
              Financial Year: <b className="text-slate-800">FY {data.fy.label}</b>
              {' · '}Period: <b className="text-slate-800">{data.fy.period}</b>
              {' · '}Generated On: <b className="text-slate-800">{fmtDT(data.generatedAt)}</b>
              {' · '}Generated By: <b className="text-slate-800">{data.generatedBy}</b>
            </div>

            {/* Overall Summary */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <p className="text-[13px] font-bold text-slate-900">Overall Summary</p>
                <button onClick={() => exportFile('csv', 'summary')} disabled={exporting !== null} className="ml-auto text-[11px] font-semibold text-[var(--primary)] hover:underline disabled:opacity-50">
                  {busy('csv:summary') ? 'Exporting…' : 'Export CSV'}
                </button>
              </div>
              <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Customer &amp; Loan Summary</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-2.5">
                {countMetrics.map(([label, value]) => (
                  <div key={label} className="rounded-xl border border-slate-200 bg-slate-50/60 px-3.5 py-2.5">
                    <p className="text-base font-extrabold text-slate-900 tabular-nums leading-tight">{value}</p>
                    <p className="text-[11px] font-semibold text-slate-500 mt-0.5">{label}</p>
                  </div>
                ))}
              </div>
              <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mt-4 mb-1.5">Financial Summary</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {finMetrics.map(([label, value]) => (
                  <div key={label} className="rounded-xl border border-slate-200 bg-slate-50/60 px-3.5 py-2.5">
                    <p className="text-base font-extrabold text-slate-900 tabular-nums leading-tight">{value}</p>
                    <p className="text-[11px] font-semibold text-slate-500 mt-0.5">{label}</p>
                  </div>
                ))}
              </div>
              <p className="text-[11px] text-slate-400 mt-2">{data.allocationRule}</p>
            </div>

            {/* Reconciliation (separate section) */}
            <div>
              <p className="text-[13px] font-bold text-slate-900 mb-2">Reconciliation</p>
              <div className={cn(
                'flex items-start gap-2 p-3 rounded-xl border text-[13px] mb-2',
                data.reconciliation.ok
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-red-50 border-red-200 text-red-700'
              )}>
                <span>
                  <b>{data.reconciliation.ok ? '✓ Audit reconciliation verified. ' : '✗ Audit reconciliation failed. '}</b>
                  Summary vs Ledger across every metric below.
                </span>
              </div>
              <div className="rounded-xl border border-slate-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs min-w-[640px]">
                    <thead>
                      <tr className="bg-slate-50 text-left">
                        {['Metric', 'Summary', 'Ledger', 'Difference', 'Status'].map((h) => (
                          <th key={h} className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-500 whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {data.reconciliation.checks.map((c) => (
                        <tr key={c.name}>
                          <td className="px-3 py-2 font-semibold whitespace-nowrap">{c.name}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(c.levels.overall)}</td>
                          <td className="px-3 py-2 tabular-nums">{c.levels.ledger === null ? '—' : inr(c.levels.ledger)}</td>
                          <td className="px-3 py-2 tabular-nums">{c.levels.ledger === null ? '—' : inr(c.difference)}</td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            {c.ok
                              ? <span className="inline-flex px-2 py-0.5 rounded-lg text-[10px] font-bold border bg-emerald-50 text-emerald-700 border-emerald-200">OK</span>
                              : <span className="inline-flex px-2 py-0.5 rounded-lg text-[10px] font-bold border bg-red-50 text-red-700 border-red-200">MISMATCH</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div>
              <p className="text-[13px] font-bold text-slate-900 mb-2">Data Completeness Checks</p>
              <p className="text-[11px] text-slate-500 mb-2">Resolve every review item before sharing this report with an auditor.</p>
              <div className="rounded-xl border border-slate-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs min-w-[700px]">
                    <thead><tr className="bg-slate-50 text-left">
                      {['Check', 'Records', 'Amount', 'Status', 'What to do'].map((h) => <th key={h} className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">{h}</th>)}
                    </tr></thead>
                    <tbody className="divide-y divide-slate-100">
                      {data.dataQuality.map((c) => (
                        <tr key={c.key}>
                          <td className="px-3 py-2 font-semibold">{c.label}</td>
                          <td className="px-3 py-2 tabular-nums">{num(c.count)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr2(c.amount)}</td>
                          <td className="px-3 py-2">{c.status === 'OK' ? <span className="text-emerald-700 font-bold">OK</span> : <span className={cn('font-bold', c.severity === 'critical' ? 'text-red-700' : 'text-amber-700')}>REVIEW</span>}</td>
                          <td className="px-3 py-2 text-slate-500">{c.detail}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Customer Summary (collapsible — grows with customer count) */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <button onClick={() => setShowCustomers(!showCustomers)} className="flex items-center gap-1.5 text-[13px] font-bold text-slate-900 hover:text-[var(--primary)]">
                  <ChevronDown className={cn('w-4 h-4 transition-transform', !showCustomers && '-rotate-90')} />
                  Customer Summary <span className="text-slate-400 font-semibold">({data.customers.length})</span>
                </button>
                <button onClick={() => exportFile('csv', 'customers')} disabled={exporting !== null} className="ml-auto text-[11px] font-semibold text-[var(--primary)] hover:underline disabled:opacity-50">
                  {busy('csv:customers') ? 'Exporting…' : 'Export CSV'}
                </button>
              </div>
              {showCustomers && (
              <div className="rounded-xl border border-slate-200 overflow-hidden">
                <div className="overflow-x-auto max-h-[320px] overflow-y-auto">
                  <table className="w-full text-xs min-w-[1180px]">
                    <thead className="sticky top-0">
                      <tr className="bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)] text-left">
                        {['Customer ID', 'Customer Name', 'Loans', 'Given', 'Interest', 'Receivable', 'Received', 'Prin. Rec.', 'Int. Rec.', 'Out. Prin.', 'Out. Int.', 'Outstanding', 'Cash Out', 'Cash In', 'Flagged'].map((h) => (
                          <th key={h} className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-[#F3DFA7] whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {data.customers.length === 0 ? (
                        <tr><td colSpan={15} className="px-3 py-6 text-center text-slate-500">No customers in this financial year.</td></tr>
                      ) : data.customers.map((c) => (
                        <tr key={c.customerId} className="hover:bg-slate-50">
                          <td className="px-3 py-2 font-mono font-semibold whitespace-nowrap">{c.customerCode}</td>
                          <td className="px-3 py-2 font-semibold whitespace-nowrap">{c.customerName}</td>
                          <td className="px-3 py-2 tabular-nums">{c.loans}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(c.given)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(c.interest)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(c.receivable)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(c.received)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(c.principal)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(c.interestReceived)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(c.outPrincipal)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(c.outInterest)}</td>
                          <td className="px-3 py-2 tabular-nums font-bold">{inr(c.outstanding)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(c.cashDisbursed)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(c.cashPayments)}</td>
                          <td className="px-3 py-2 tabular-nums">
                            {c.flaggedCount > 0
                              ? <span className="inline-flex px-2 py-0.5 rounded-lg text-[10px] font-bold border whitespace-nowrap bg-amber-50 text-amber-700 border-amber-200">⚠ {c.flaggedCount}</span>
                              : <span className="text-slate-400">0</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              )}
            </div>

            {/* Loan Details (collapsible — grows with loan count) */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <button onClick={() => setShowLoans(!showLoans)} className="flex items-center gap-1.5 text-[13px] font-bold text-slate-900 hover:text-[var(--primary)]">
                  <ChevronDown className={cn('w-4 h-4 transition-transform', !showLoans && '-rotate-90')} />
                  Loan Details <span className="text-slate-400 font-semibold">({data.loans.length})</span>
                </button>
                <button onClick={() => exportFile('csv', 'loans')} disabled={exporting !== null} className="ml-auto text-[11px] font-semibold text-[var(--primary)] hover:underline disabled:opacity-50">
                  {busy('csv:loans') ? 'Exporting…' : 'Export CSV'}
                </button>
              </div>
              {showLoans && (
              <div className="rounded-xl border border-slate-200 overflow-hidden">
                <div className="overflow-x-auto max-h-[320px] overflow-y-auto">
                  <table className="w-full text-xs min-w-[1500px]">
                    <thead className="sticky top-0">
                      <tr className="bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)] text-left">
                        {['Loan ID', 'Customer ID', 'Customer Name', 'Loan Date', 'Principal', 'Int. Rate', 'Interest', 'Receivable', 'Frequency', 'Installment', 'Received', 'Prin. Rec.', 'Int. Rec.', 'Out. Prin.', 'Out. Int.', 'Outstanding', 'Status'].map((h) => (
                          <th key={h} className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-[#F3DFA7] whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {data.loans.length === 0 ? (
                        <tr><td colSpan={17} className="px-3 py-6 text-center text-slate-500">No loans in this financial year.</td></tr>
                      ) : data.loans.map((l) => (
                        <tr key={l.loanId} className="hover:bg-slate-50">
                          <td className="px-3 py-2 font-mono text-[11px] whitespace-nowrap">{l.loanId.slice(0, 8)}…</td>
                          <td className="px-3 py-2 font-mono whitespace-nowrap">{l.customerCode}</td>
                          <td className="px-3 py-2 whitespace-nowrap">{l.customerName}</td>
                          <td className="px-3 py-2 whitespace-nowrap tabular-nums">{fmtDate(l.loanDate)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(l.principal)}</td>
                          <td className="px-3 py-2 tabular-nums">{Number(l.interestRate)}%</td>
                          <td className="px-3 py-2 tabular-nums">{inr(l.interest)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(l.receivable)}</td>
                          <td className="px-3 py-2 whitespace-nowrap">{l.frequency || '—'}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(l.installment)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(l.received)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(l.principalRecovered)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(l.interestReceived)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(l.outPrincipal)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(l.outInterest)}</td>
                          <td className="px-3 py-2 tabular-nums font-bold">{inr(l.outstanding)}</td>
                          <td className="px-3 py-2 whitespace-nowrap">{l.status}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              )}
            </div>

            {/* Transaction Ledger (collapsible — grows with transaction count) */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <button onClick={() => setShowLedger(!showLedger)} className="flex items-center gap-1.5 text-[13px] font-bold text-slate-900 hover:text-[var(--primary)]">
                  <ChevronDown className={cn('w-4 h-4 transition-transform', !showLedger && '-rotate-90')} />
                  Transaction Ledger <span className="text-slate-400 font-semibold">({data.ledgerTotal.toLocaleString('en-IN')})</span>
                </button>
                <button onClick={() => exportFile('csv', 'ledger')} disabled={exporting !== null} className="ml-auto text-[11px] font-semibold text-[var(--primary)] hover:underline disabled:opacity-50">
                  {busy('csv:ledger') ? 'Exporting…' : 'Export CSV'}
                </button>
              </div>
              {showLedger && (
              <div className="rounded-xl border border-slate-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs min-w-[1380px]">
                    <thead>
                      <tr className="bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)] text-left">
                        {['Date', 'Transaction ID', 'Type', 'Customer ID', 'Customer Name', 'Loan ID', 'Payment ID', 'Mode', 'Total Amount', 'Principal', 'Interest', 'Prev. Outstanding', 'New Outstanding', 'Performed By', 'Result', 'Notes'].map((h) => (
                          <th key={h} className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-[#F3DFA7] whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {data.ledger.length === 0 ? (
                        <tr><td colSpan={16} className="px-3 py-6 text-center text-slate-500">No transactions in this financial year.</td></tr>
                      ) : data.ledger.map((r, i) => (
                        <tr key={`${r.txnId}-${i}`} className="hover:bg-slate-50">
                          <td className="px-3 py-2 whitespace-nowrap tabular-nums">{fmtDate(r.date)}</td>
                          <td className="px-3 py-2 font-mono text-[11px] whitespace-nowrap">{r.txnId.slice(0, 8)}…</td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className={cn(
                              'inline-flex px-2 py-0.5 rounded-lg text-[10px] font-bold border whitespace-nowrap',
                              r.type === 'Loan Disbursal' && 'bg-slate-100 text-slate-700 border-slate-200',
                              r.type === 'Payment' && 'bg-emerald-50 text-emerald-700 border-emerald-200',
                              r.type === 'Loan Completed' && 'bg-[var(--primary-soft)] text-[var(--primary)] border-[#E8CFCF]'
                            )}>{r.type}</span>
                          </td>
                          <td className="px-3 py-2 font-mono whitespace-nowrap">{r.customerCode}</td>
                          <td className="px-3 py-2 whitespace-nowrap">{r.customerName}</td>
                          <td className="px-3 py-2 font-mono text-[11px] whitespace-nowrap">{r.loanId ? `${r.loanId.slice(0, 8)}…` : '—'}</td>
                          <td className="px-3 py-2 font-mono text-[11px] whitespace-nowrap">{r.paymentId ? `${r.paymentId.slice(0, 8)}…` : '—'}</td>
                          <td className="px-3 py-2 whitespace-nowrap">{r.mode || '—'}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(r.amount)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(r.principal)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(r.interest)}</td>
                          <td className="px-3 py-2 tabular-nums">{inr(r.prevOutstanding)}</td>
                          <td className="px-3 py-2 tabular-nums font-bold">{inr(r.balance)}</td>
                          <td className="px-3 py-2 whitespace-nowrap">{r.performedBy || '—'}</td>
                          <td className="px-3 py-2 whitespace-nowrap">{r.result || '—'}</td>
                          <td className="px-3 py-2 text-slate-500 whitespace-nowrap max-w-[220px] truncate" title={r.notes || ''}>{r.notes || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="px-3 py-2.5 border-t border-slate-100 flex items-center justify-between">
                  <p className="text-[11px] text-slate-500">Page {data.ledgerPage} of {data.ledgerPages}</p>
                  <div className="flex gap-2">
                    <button disabled={data.ledgerPage <= 1 || loading} onClick={() => goLedger(data.ledgerPage - 1)} className="w-7 h-7 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50 disabled:opacity-40">
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                    <button disabled={data.ledgerPage >= data.ledgerPages || loading} onClick={() => goLedger(data.ledgerPage + 1)} className="w-7 h-7 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50 disabled:opacity-40">
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
