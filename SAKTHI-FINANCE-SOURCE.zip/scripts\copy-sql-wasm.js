const fs = require('fs');
const path = require('path');

const src = path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', 'sql-wasm.wasm');
const destDir = path.join(__dirname, '..', 'public', 'wasm');
const dest = path.join(destDir, 'sql-wasm.wasm');

if (!fs.existsSync(destDir)) {
  fs.mkdirSync(destDir, { recursive: true });
}

try {
  fs.copyFileSync(src, dest);
  const stats = fs.statSync(dest);
  console.log(`[postinstall] sql-wasm.wasm copied to public/wasm/ (${stats.size} bytes)`);
} catch (err) {
  console.error(`[postinstall] Failed to copy sql-wasm.wasm:`, err.message);
}
