import { spawn } from 'node:child_process'
import path from 'node:path'
import { availableParallelism } from 'node:os'

export function cleanTranscript(text: string, phrases: unknown = []): string {
  const cleaned = text.replace(/\[(?:music|silence|noise|inaudible|blank_audio)\]|\((?:music|silence|noise|inaudible)\)/gi, '').replace(/[\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim().replace(/[.!?]+$/u, '').trim()
  if (!cleaned || /^(?:thank you(?: for watching)?|thanks for watching|subscribe|you)$/i.test(cleaned)) return ''
  // Exact spelling matches only: never guess a different customer's identity.
  const hints = Array.isArray(phrases) ? phrases.filter((p): p is string => typeof p === 'string' && p.length <= 100) : []
  return hints.find(p => p.toLocaleLowerCase() === cleaned.toLocaleLowerCase()) ?? cleaned
}

/** Capture helper emits this exact PCM format. Reject malformed/silent input before inference. */
export function validSpeechWave(wav: Buffer): boolean {
  if (wav.length < 3244 || wav.length > 1000000 || wav.toString('ascii', 0, 4) !== 'RIFF' || wav.toString('ascii', 8, 16) !== 'WAVEfmt ' || wav.readUInt32LE(16) !== 16 || wav.readUInt16LE(20) !== 1 || wav.readUInt16LE(22) !== 1 || wav.readUInt32LE(24) !== 16000 || wav.readUInt16LE(34) !== 16 || wav.toString('ascii', 36, 40) !== 'data' || wav.readUInt32LE(40) !== wav.length - 44 || (wav.length - 44) % 2) return false
  let voiced = 0
  for (let start = 44; start < wav.length; start += 3200) {
    const end = Math.min(wav.length, start + 3200)
    let energy = 0
    for (let n = start; n < end; n += 2) energy += (wav.readInt16LE(n) / 32768) ** 2
    if (Math.sqrt(energy / ((end - start) / 2)) > 0.0025) voiced += end - start
  }
  return voiced >= 3200
}

/** No network, no temporary recording/transcript files, no shell, no customer names in argv. */
export async function transcribeWave(root: string, wav: Buffer, lang: string, signal: AbortSignal, phrases?: unknown, preview = false): Promise<string> {
  if (signal.aborted) throw Error('aborted')
  if (!validSpeechWave(wav)) throw Error('no-speech')
  const language = lang.split('-')[0]
  if (!['en', 'ta', 'hi'].includes(language)) throw Error('language-not-supported')
  return new Promise((resolve, reject) => {
    const child = spawn(path.join(root, 'voice', 'whisper-cli.exe'), [
      '-m', path.join(root, 'voice', 'ggml-small-q5_1.bin'), '-f', '-',
      // With stdin, the CLI otherwise disables its result callback. This basename
      // enables stdout results; NO output-file-format flags are set, so no file is written.
      '-of', 'sakthi-memory',
      '-l', language, '-t', String(Math.max(1, Math.min(6, availableParallelism() - 1))),
      '-ng', '-np', '-nt', '-sns', '-nf', '-bs', preview ? '1' : '5',
      // Match encoder work to this utterance (50 frames/second), including
      // one second of padding. Short fields need not encode 30 seconds.
      '-ac', String(Math.min(1500, Math.max(preview ? 256 : 768, Math.ceil((wav.length - 44) / 640) + 50))),
      // Fixed regional vocabulary, not private customer data or an instruction to fill a field.
      '--prompt', 'Indian English names and addresses: Soorya, Ravi Kumar, Salem, Chennai, Gandhi Road. Customer, loan, kanaku, receive payment, amount, interest, principal, duration, daily, weekly, monthly, completed, active, aborted, outstanding, collection, history, dashboard, reports, audit, database, settings, hundred, thousand, lakh, crore.',
    ], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'], cwd: path.join(root, 'voice') })
    let output = '', error: string | null = null
    const abort = () => { error = 'aborted'; child.kill() }
    signal.addEventListener('abort', abort, { once: true })
    const timeout = setTimeout(() => { error = 'timeout'; child.kill() }, 120000)
    child.stdout.setEncoding('utf8')
    child.stdout.on('data', (chunk: string) => { output += chunk; if (output.length > 16000) { error = 'recognition-failed'; child.kill() } })
    // Native diagnostic output can contain words. Do not log it.
    child.stderr.resume()
    child.stdin.on('error', () => {})
    child.on('error', () => { error = 'helper-unavailable' })
    child.on('close', code => {
      clearTimeout(timeout); signal.removeEventListener('abort', abort)
      if (error || code !== 0) reject(Error(error || 'recognition-failed'))
      else { const text = cleanTranscript(output, phrases); output = ''; if (text) resolve(text); else reject(Error('no-speech')) }
    })
    if (signal.aborted) abort()
    else child.stdin.end(wav)
  })
}
