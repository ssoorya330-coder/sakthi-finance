'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useSidebarStore } from '@/store/sidebar-store'
import { useCustomerStore } from '@/store/customer-store'
import { useAuthStore } from '@/store/auth-store'
import { usePathname, useRouter } from 'next/navigation'
import Sidebar from '@/components/dashboard/Sidebar'
import ToastContainer from '@/components/ui/toast-container'
import LiveNotifications from '@/components/shared/live-notifications'
import PageLoading from '@/components/ui/page-loading'
import ApplicationRefresh from '@/components/ui/application-refresh'
import DesktopUpdatesPanel from '@/components/ui/desktop-updates'
import DeviceModeBanner from './DeviceModeBanner'

const SIDEBAR_WIDTH_DESKTOP = 235
const SIDEBAR_WIDTH_TABLET = 220

export default function AppShell({ children }: { children: React.ReactNode }) {
  const { isOpen, closeSidebar } = useSidebarStore()
  const pathname = usePathname()
  const router = useRouter()
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)
  const isLoading = useAuthStore((s) => s.isLoading)
  const hasHydrated = useAuthStore((s) => s._hasHydrated)
  const [view, setView] = useState<'mobile' | 'tablet' | 'desktop'>(() =>
    typeof window === 'undefined'
      ? 'desktop'
      : window.innerWidth >= 1024
        ? 'desktop'
        : window.innerWidth >= 768
          ? 'tablet'
          : 'mobile'
  )

  useEffect(() => {
    const check = () => {
      if (window.innerWidth >= 1024) setView('desktop')
      else if (window.innerWidth >= 768) setView('tablet')
      else setView('mobile')
    }
    check()
    window.addEventListener('resize', check)
    return () => window.removeEventListener('resize', check)
  }, [])

  // Client-side route guard (proxy.ts enforces this server-side too).
  // Unauthenticated users are sent to /login; a valid session (restored via
  // silent refresh in AuthProvider) keeps the user logged in across refreshes.
  useEffect(() => {
    if (!hasHydrated || isLoading) return
    if (!isAuthenticated) {
      router.replace('/login')
    }
  }, [hasHydrated, isLoading, isAuthenticated, router])

  // Direct dashboard — init data immediately without auth
  useEffect(() => {
    if (!isAuthenticated) return
    if (!useCustomerStore.getState().initialized) {
      useCustomerStore.getState().init()
    }
  }, [isAuthenticated])

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeSidebar()
    }
    document.addEventListener('keydown', handleEsc)
    return () => document.removeEventListener('keydown', handleEsc)
  }, [closeSidebar])

  const offset = isOpen && view !== 'mobile' ? (view === 'desktop' ? SIDEBAR_WIDTH_DESKTOP : SIDEBAR_WIDTH_TABLET) : 0

  if (!hasHydrated || isLoading || !isAuthenticated) return <PageLoading fullScreen />

  return (
    <div className="min-h-screen bg-gradient-to-br from-[var(--background)] via-[var(--surface-secondary)] to-[#F0F2E4] relative" style={{ fontSize: '14.4px' }}>
      <div className="fixed inset-0 sf-noise pointer-events-none z-0" />

      <div className="fixed top-1/4 -left-20 w-[250px] h-[250px] bg-gradient-to-br from-[var(--primary)]/5 to-[var(--secondary)]/5 rounded-full blur-[60px] pointer-events-none z-0 animate-aurora-light" />
      <div className="fixed bottom-1/4 -right-20 w-[280px] h-[280px] bg-gradient-to-br from-[var(--secondary)]/5 to-[var(--primary)]/5 rounded-full blur-[60px] pointer-events-none z-0 animate-aurora-light" style={{ animationDelay: '-8s' }} />

      <ToastContainer />
      <ApplicationRefresh />
      <DesktopUpdatesPanel />
      <LiveNotifications />
      <Sidebar />

        {isOpen && (
          <div
            className="fixed inset-0 z-40 cursor-default will-change-transform"
            style={{ transform: `translateX(${offset}px)` }}
            onClick={closeSidebar}
          />
        )}

      <motion.div
        initial={false}
        animate={{ x: offset }}
        transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
        className={`${pathname === '/dashboard/customers' ? 'h-dvh flex flex-col overflow-hidden' : 'min-h-screen'} relative z-30 will-change-transform`}
      >
        <DeviceModeBanner />
        <AnimatePresence mode="wait">
          <motion.div
            key={pathname}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
            className={`${pathname === '/dashboard/customers' ? 'flex-1 min-h-0' : ''} will-change-transform`}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </div>
  )
}
