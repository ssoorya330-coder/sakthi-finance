// API records are never cached: they belong to account-scoped SQLite.
const SHELL = 'sakthi-finance-offline-shell-v2'
self.addEventListener('install', () => self.skipWaiting())
self.addEventListener('activate', event => event.waitUntil((async () => {
  for (const key of await caches.keys()) {
    if (key === 'sakthi-finance-v1' || key === 'sakthi-finance-cdn-v1') await caches.delete(key)
  }
  await self.clients.claim()
})()))
self.addEventListener('fetch', event => {
  const request=event.request, url=new URL(request.url)
  if(url.origin!==self.location.origin||request.method!=='GET'||url.pathname.startsWith('/api/'))return
  const asset=url.pathname.startsWith('/_next/static/')||url.pathname.startsWith('/offline-sql/')||/\.(?:png|svg|woff2?)$/.test(url.pathname)
  const page=request.mode==='navigate'&&(url.pathname.startsWith('/dashboard')||url.pathname==='/database')
  if(!asset&&!page)return
  event.respondWith((async()=>{
    const cache=await caches.open(SHELL)
    // Hashed production chunks are immutable. Development chunks can keep the
    // same URL after an edit, so do not serve those stale while connected.
    const immutable=asset&&/[a-f0-9]{8,}/i.test(url.pathname)&&!url.pathname.includes('turbopack')
    if(immutable){const cached=await cache.match(request);if(cached)return cached}
    try {
      const response=await fetch(request,{signal:AbortSignal.timeout(page?5000:15000)})
      if(response.status>=500)throw new Error('Application server unavailable')
      if(response.ok&&!response.redirected)await cache.put(page?url.pathname:request,response.clone())
      return response
    } catch(error) {
      const cached=await cache.match(page?url.pathname:request)
      if(cached)return cached
      throw error
    }
  })())
})
