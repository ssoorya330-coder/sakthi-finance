import { NextRequest, NextResponse } from 'next/server'
import { dbQuery } from '@/server/database'
import { requireAuthWithPermission } from '@/lib/api-utils'

export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('collections:read');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const today = new Date().toISOString().split('T')[0]
    const userId = user.userId

    let query = 'SELECT dc.*, c.full_name as customer_name FROM daily_collection dc JOIN customers c ON dc.customer_id = c.id WHERE dc.collection_date = $1'
    const params: any[] = [today]
    if (userId) { query += ' AND dc.user_id = $2'; params.push(userId) }
    query += ' ORDER BY dc.created_at DESC'

    const result = await dbQuery(query, params)
    const total = result.rows.reduce((sum: number, r: any) => sum + parseFloat(r.amount), 0)
    return NextResponse.json({ data: result.rows, total })
  } catch (err: any) {
    console.error('[GET /api/daily-collection] Error:', err.message)
    return NextResponse.json(
      { error: 'Failed to fetch daily collection', details: err.message },
      { status: 500 }
    )
  }
}
