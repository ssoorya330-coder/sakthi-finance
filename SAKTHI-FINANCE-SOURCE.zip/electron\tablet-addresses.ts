import type {NetworkInterfaceInfo} from 'node:os'

/** Prefer local Wi-Fi/LAN over VPN adapters; never advertise disconnected adapters. */
export function tabletAddresses(interfaces:NodeJS.Dict<NetworkInterfaceInfo[]>,port:number):string[] {
  const candidates=Object.entries(interfaces).flatMap(([name,items])=>(items??[]).flatMap(item=>{
    if(item.family!=='IPv4'||item.internal||item.address.startsWith('169.254.')||item.address==='0.0.0.0')return []
    const octets=item.address.split('.').map(Number)
    const privateLan=octets[0]===10||(octets[0]===172&&octets[1]>=16&&octets[1]<=31)||(octets[0]===192&&octets[1]===168)
    const virtual=/tailscale|vpn|wireguard|zerotier|virtual|vethernet|vmware|docker|wsl|loopback/i.test(name)
    const wifi=/wi[ -]?fi|wireless|wlan/i.test(name)
    return [{address:item.address,rank:virtual?4:privateLan?(wifi?0:1):3}]
  }))
  candidates.sort((a,b)=>a.rank-b.rank||a.address.localeCompare(b.address))
  return [...new Set(candidates.map(item=>`https://${item.address}:${port}`))]
}
