import { Client } from 'pg'
import { readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { randomBytes } from 'node:crypto'
import assert from 'node:assert/strict'
import jwt from 'jsonwebtoken'
import { createRequire } from 'node:module'

// Every mutation is confined to a newly created, uniquely named QA database.
// The real configured database is read only for before/after integrity hashes.
async function main() {
const config = JSON.parse(await readFile(path.join(process.env.APPDATA!, 'com.sakthifinance.desktop/runtime.json'), 'utf8'))
const base = config.DATABASE_URL ? { connectionString: config.DATABASE_URL } : { host: config.DB_HOST, port: Number(config.DB_PORT), database: config.DB_NAME, user: config.DB_USER, password: config.DB_PASSWORD }
const production = new Client({ ...base, connectionTimeoutMillis: 5000 })
await production.connect()
async function fingerprint() {
  const results = []
  for (const table of ['customers', 'loans', 'payments']) {
    const data = await production.query(`SELECT COUNT(*)::int AS count, md5(COALESCE(string_agg(hash, '' ORDER BY hash), '')) AS checksum FROM (SELECT md5(row_to_json(t)::text) AS hash FROM ${table} t) rows`)
    results.push({ table, ...data.rows[0] })
  }
  return results
}
const before = await fingerprint()
const database = `sf_electron_qa_${Date.now()}_${randomBytes(3).toString('hex')}`
await production.query(`CREATE DATABASE "${database}"`)
if (config.DATABASE_URL) { const url = new URL(config.DATABASE_URL); url.pathname = '/' + database; process.env.DATABASE_URL = url.toString() }
else { Object.assign(process.env, config); delete process.env.DATABASE_URL; process.env.DB_NAME = database }
process.env.JWT_ACCESS_SECRET = randomBytes(48).toString('hex')
process.env.JWT_REFRESH_SECRET = randomBytes(48).toString('hex')
const tests: { test: string; status: string }[] = []
let failure = false
const db = await import('../../src/server/database')
const worker = createRequire(path.join(process.cwd(), 'package.json'))('./dist-electron/api/routes.js')
try {
  await db.ensureSchema()
  await db.dbQuery("INSERT INTO users(user_id,email,full_name,role,role_id) SELECT $1,$2,$3,'owner',role_id FROM roles WHERE role_name='owner'", ['qa-owner-a', 'a@example.invalid', 'QA Owner A'])
  await db.dbQuery("INSERT INTO users(user_id,email,full_name,role,role_id) SELECT $1,$2,$3,'owner',role_id FROM roles WHERE role_name='owner'", ['qa-owner-b', 'b@example.invalid', 'QA Owner B'])
  const token = (id: string) => jwt.sign({ sub: id, name: 'QA', email: id + '@example.invalid', role: 'owner', provider: 'google' }, process.env.JWT_ACCESS_SECRET!, { expiresIn: '15m' })
  const a = token('qa-owner-a'), b = token('qa-owner-b')
  const call = (identity: string | null, pathname: string, method = 'GET', body?: unknown) => worker.callApi(identity, { path: pathname, method, body })
  const run = async (test: string, operation: () => Promise<void>) => { try { await operation(); tests.push({ test, status: 'PASS' }) } catch { tests.push({ test, status: 'FAIL' }); failure = true } }
  await run('anonymous IPC customer request rejected', async () => { assert.equal((await call(null, '/customers')).status, 401) })
  let customerId = '', loanId = ''
  await run('existing customer+loan creation handler through IPC dispatcher', async () => {
    const result = await call(a, '/customer', 'POST', { full_name: 'QA Customer', phone_number: '9000000001', city: 'QA City', business: 'QA Business', loan_date: '2026-09-30', due_date: '2026-10-10', loan_amount: 1000, interest_rate: 10, interest_amount: 100, total_amount: 1100, installment_amount: 110, duration: 10, remaining_days: 10, loan_type: 'Daily' })
    assert.ok(result.ok)
    const rows = await db.dbQuery('SELECT c.id,l.loan_id FROM customers c JOIN loans l ON l.customer_id=c.id WHERE c.user_id=$1', ['qa-owner-a'])
    assert.equal(rows.rows.length, 1); customerId = String(rows.rows[0].id); loanId = rows.rows[0].loan_id
  })
  await run('dynamic customer route resolves and reads matching record', async () => { assert.equal((await call(a, '/customer/' + customerId)).status, 200) })
  await run('second owner cannot access first owner customer', async () => { assert.ok([403,404].includes((await call(b, '/customer/' + customerId)).status)) })
  await run('payment insert preserves date and independently reduces balance', async () => {
    assert.ok((await call(a, '/payment', 'POST', { loan_id: loanId, customer_id: customerId, amount: 300, payment_date: '2026-09-30', payment_time: '16:30:00', payment_mode: 'Cash' })).ok)
    const result = await db.dbQuery('SELECT outstanding FROM kanaku_loan_balances WHERE loan_id=$1', [loanId]); assert.equal(Number(result.rows[0].outstanding), 800)
    const payments = await db.dbQuery('SELECT payment_date,amount FROM payments WHERE loan_id=$1', [loanId]); assert.equal(payments.rows.length,1); assert.equal(payments.rows[0].payment_date,'2026-09-30'); assert.equal(Number(payments.rows[0].amount),300)
  })
  await run('overpayment rejected without another payment insert', async () => {
    assert.equal((await call(a, '/payment', 'POST', { loan_id: loanId, customer_id: customerId, amount: 801, payment_date: '2026-09-30' })).status, 400)
    assert.equal((await db.dbQuery('SELECT COUNT(*)::int AS n FROM payments WHERE loan_id=$1',[loanId])).rows[0].n,1)
  })
  await run('second owner cannot post payment to another owner loan', async () => { assert.ok([403,404].includes((await call(b, '/payment', 'POST', { loan_id: loanId, customer_id: customerId, amount: 1 })).status)) })
  await run('customer, loan, payment, dashboard and audit reads use local PostgreSQL', async () => {
    for (const route of ['/customers','/loans','/payments','/dashboard','/audit/summary']) assert.ok((await call(a,route)).ok, route)
  })
  await run('financial audit records saved with mutations', async () => {
    const result = await db.dbQuery("SELECT COUNT(*)::int AS n FROM audit_events WHERE user_id=$1", ['qa-owner-a']); assert.ok(result.rows[0].n >= 3)
  })
  await run('data persists after database pool restart', async () => {
    await db.closePool(); await worker.closePool()
    assert.ok((await call(a,'/payments')).ok)
  })
} catch { failure = true; tests.push({ test: 'QA database setup/workflow', status: 'FAIL' }) }
finally {
  await db.closePool(); await worker.closePool()
  const after = await fingerprint(); const unchanged = JSON.stringify(before) === JSON.stringify(after)
  tests.push({ test: 'production financial data unchanged (counts and full row checksums)', status: unchanged ? 'PASS' : 'FAIL' }); failure ||= !unchanged
  await production.end()
  await writeFile('test-reports/ELECTRON_POSTGRES_TEST.json', JSON.stringify({ date: '2026-09-30', database, testDatabaseRetained: true, tests, productionBefore: before, productionAfter: after }, null, 2))
  console.log(JSON.stringify({ database, passed: tests.filter(t=>t.status==='PASS').length, failed: tests.filter(t=>t.status==='FAIL').length, tests }))
  process.exitCode = failure ? 1 : 0
}
}
void main().catch(() => { console.error('Isolated PostgreSQL test could not start. No credentials are logged.'); process.exitCode = 1 })
