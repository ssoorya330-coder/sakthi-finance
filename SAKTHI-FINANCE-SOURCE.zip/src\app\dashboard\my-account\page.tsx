'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import MyAccountPage from '@/features/customer/MyAccountPage'

export default function MyAccountPageRoute() {
  return (
    <ClientPageGate requireRole="customer">
      <MyAccountPage />
    </ClientPageGate>
  )
}
