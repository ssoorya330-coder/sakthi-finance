'use client'

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useAuthStore } from '@/store/auth-store'

interface NotificationList {
  items: { id: string; title: string; message: string | null; type: string; isRead: boolean; createdAt: string }[]
  total: number
  unread: number
  page: number
}

export function useNotifications(page = 1) {
  const userId = useAuthStore(s => s.userId)
  return useQuery<NotificationList>({
    queryKey: ['notifications', userId, page], enabled: !!userId, placeholderData: undefined,
    queryFn: async ({ signal }) => {
      const response = await fetch(`/api/notifications?page=${page}`, { signal, cache: 'no-store' })
      if (!response.ok) throw new Error('Unable to load notifications. Please try again.')
      return response.json()
    },
    staleTime: 0, refetchInterval: 30000, refetchOnWindowFocus: true,
  })
}

export function useReadNotification() {
  const client = useQueryClient()
  const userId = useAuthStore(s => s.userId)
  return useMutation({
    mutationFn: async (selection: { id: string } | { all: true }) => {
      const response = await fetch('/api/notifications', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(selection),
      })
      if (!response.ok) throw new Error('Unable to mark notifications as read. Please try again.')
    },
    onSuccess: () => client.invalidateQueries({ queryKey: ['notifications', userId] }),
  })
}
