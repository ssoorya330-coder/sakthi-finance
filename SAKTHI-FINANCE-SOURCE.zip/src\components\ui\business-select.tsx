'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { createPortal } from 'react-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Briefcase, Check, ChevronDown } from 'lucide-react'
import { cn } from '@/lib/utils'

export const BUSINESS_OPTIONS = [
  'Farmer (விவசாயி)',
  'Tea Shop (தேநீர் கடை)',
  'Bakery Shop (பேக்கரி)',
  'Business (வணிகம்)',
  'Government Job (அரசு வேலை)',
  'Police (காவல்துறை)',
  'Reporter (செய்தியாளர்)',
  'Pani Puri Shop (பானி பூரி கடை)',
  'Chicken Stall (கோழி இறைச்சி கடை)',
  'Mutton Stall (ஆட்டு இறைச்சி கடை)',
  'Tailor Shop (தையல் கடை)',
  'Daily Wages (தினக்கூலி)',
  'Mestri (மேஸ்திரி)',
  'Kothanar (கொத்தனார்)',
  'Other (மற்றவை)',
]

interface BusinessSelectProps {
  value: string
  onChange: (value: string) => void
  error?: string
}

export default function BusinessSelect({ value, onChange, error }: BusinessSelectProps) {
  const [open, setOpen] = useState(false)
  const [highlightedIndex, setHighlightedIndex] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLButtonElement>(null)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const itemRefs = useRef<(HTMLButtonElement | null)[]>([])

  const [dropdownStyle, setDropdownStyle] = useState<React.CSSProperties>({})

  const updatePosition = useCallback(() => {
    if (!triggerRef.current) return
    const rect = triggerRef.current.getBoundingClientRect()
    setDropdownStyle({
      position: 'fixed',
      top: rect.bottom + 6,
      left: rect.left,
      width: rect.width,
    })
  }, [])

  useEffect(() => {
    if (!open) return
    updatePosition()
    const handler = () => updatePosition()
    window.addEventListener('scroll', handler, { passive: true, capture: true })
    window.addEventListener('resize', handler)
    return () => {
      window.removeEventListener('scroll', handler, { capture: true })
      window.removeEventListener('resize', handler)
    }
  }, [open, updatePosition])

  useEffect(() => {
    if (!open) return
    setHighlightedIndex(0)
  }, [open])

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (
        containerRef.current && !containerRef.current.contains(e.target as Node) &&
        dropdownRef.current && !dropdownRef.current.contains(e.target as Node)
      ) {
        setOpen(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  useEffect(() => {
    itemRefs.current = itemRefs.current.slice(0, BUSINESS_OPTIONS.length)
  }, [])

  const selectOption = useCallback(
    (opt: string) => {
      onChange(opt)
      setOpen(false)
    },
    [onChange],
  )

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!open) {
      if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') {
        e.preventDefault()
        setOpen(true)
        requestAnimationFrame(updatePosition)
      }
      return
    }

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault()
        setHighlightedIndex((prev) => {
          const next = prev < BUSINESS_OPTIONS.length - 1 ? prev + 1 : prev
          itemRefs.current[next]?.scrollIntoView({ block: 'nearest' })
          return next
        })
        break
      case 'ArrowUp':
        e.preventDefault()
        setHighlightedIndex((prev) => {
          const next = prev > 0 ? prev - 1 : prev
          itemRefs.current[next]?.scrollIntoView({ block: 'nearest' })
          return next
        })
        break
      case 'Enter':
        e.preventDefault()
        if (BUSINESS_OPTIONS[highlightedIndex]) {
          selectOption(BUSINESS_OPTIONS[highlightedIndex])
        }
        break
      case 'Escape':
        e.preventDefault()
        setOpen(false)
        break
    }
  }

  return (
    <div className="relative" ref={containerRef}>
      <button
        ref={triggerRef}
        type="button"
        onClick={() => {
          setOpen(!open)
          if (!open) requestAnimationFrame(updatePosition)
        }}
        onKeyDown={handleKeyDown}
        className={cn(
          'relative flex w-full h-[44px] items-center rounded-xl border bg-white text-sm outline-none transition-all duration-200',
          open
            ? 'border-[var(--primary)]/30 ring-2 ring-[var(--primary)]/10'
            : error
              ? 'border-red-400'
              : 'border-slate-200',
        )}
      >
        <span className="pointer-events-none absolute left-4 top-1/2 z-10 flex h-5 w-5 -translate-y-1/2 items-center justify-center">
          <Briefcase className="h-5 w-5 text-slate-400" />
        </span>

        <span
          className={cn(
            'ml-12 flex-1 text-left truncate pr-8',
            value ? 'text-[#0F172A] font-medium' : 'text-slate-400',
          )}
        >
          {value || 'Select Business'}
        </span>

        <ChevronDown
          className={cn(
            'absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400 transition-transform duration-200',
            open && 'rotate-180',
          )}
        />
      </button>

      {open && createPortal(
        <motion.div
          ref={dropdownRef}
          initial={{ opacity: 0, y: -8, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -8, scale: 0.96 }}
          transition={{ duration: 0.15, ease: 'easeOut' }}
          className="z-[var(--z-dropdown)] rounded-xl border border-slate-200 bg-white shadow-lg"
          style={dropdownStyle}
        >
          <div className="max-h-[280px] overflow-y-auto py-1.5">
            {BUSINESS_OPTIONS.map((opt, i) => (
              <button
                key={opt}
                ref={(el) => { itemRefs.current[i] = el }}
                type="button"
                onClick={() => selectOption(opt)}
                onMouseEnter={() => setHighlightedIndex(i)}
                className={cn(
                  'w-full flex items-center gap-3 px-4 py-3 text-left transition-colors duration-100',
                  highlightedIndex === i && 'bg-slate-100',
                  opt === value && 'bg-[var(--primary-soft)]',
                )}
              >
                <span
                  className={cn(
                    'flex-1 text-[15px] leading-relaxed text-[#0F172A]',
                    opt === value ? 'font-medium' : 'font-medium',
                  )}
                >
                  {opt}
                </span>
                {opt === value && (
                  <Check className="h-4 w-4 shrink-0 text-[var(--primary)]" />
                )}
              </button>
            ))}
          </div>
        </motion.div>,
        document.body
      )}

      {error && (
        <motion.p
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-xs text-red-500 mt-1.5 flex items-center gap-1"
        >
          <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M18 6L6 18M6 6l12 12" />
          </svg>
          {error}
        </motion.p>
      )}
    </div>
  )
}
