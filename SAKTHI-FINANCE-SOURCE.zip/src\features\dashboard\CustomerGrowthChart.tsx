'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'
import { Users } from 'lucide-react'
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'
import { useCustomerStore } from '@/store/customer-store'
import { computeCustomerGrowth } from './dashboard-data'
import { chartAnimationProps, axisProps, gridLineProps } from './dashboard-animations'

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
      className="bg-white/95 backdrop-blur-sm rounded-xl border border-slate-100 shadow-xl px-4 py-3"
    >
      <p className="text-xs font-medium text-slate-500 mb-1">{label}</p>
      <p className="text-sm font-bold text-slate-900">Total: {payload[0].payload.totalCustomers}</p>
      <p className="text-xs text-slate-500">+{payload[0].value} new</p>
    </motion.div>
  )
}

function EmptyState() {
  return (
    <div className="h-[270px] flex items-center justify-center">
      <div className="text-center">
        <Users className="w-10 h-10 text-slate-300 mx-auto mb-3" />
        <p className="text-sm text-slate-400 font-medium">No customer data available</p>
        <p className="text-xs text-slate-300 mt-1">Add customers to see growth trends</p>
      </div>
    </div>
  )
}

export default function CustomerGrowthChart() {
  const customers = useCustomerStore((s) => s.customers)
  const data = useMemo(() => computeCustomerGrowth(customers), [customers])

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.6 }}
      className="relative bg-white/70 backdrop-blur-xl rounded-[20px] border border-white/20 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] p-6 overflow-hidden"
    >
      <div className="absolute inset-0 sf-pattern-dots opacity-40 pointer-events-none" />
      <div className="flex items-center justify-between mb-6 relative">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
            <Users className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-slate-900">Customer Growth</h3>
            <p className="text-xs text-slate-500">New customer registrations over time</p>
          </div>
        </div>
      </div>
      {data.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="h-[270px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="customerGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.2} />
                  <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid {...gridLineProps} />
              <XAxis dataKey="month" {...axisProps} />
              <YAxis {...axisProps} />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey="newCustomers"
                stroke="var(--primary)"
                strokeWidth={2.5}
                fill="url(#customerGrad)"
                dot={false}
                activeDot={{ r: 6, fill: 'var(--primary)', strokeWidth: 2, stroke: '#fff' }}
                {...chartAnimationProps}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}
    </motion.div>
  )
}
