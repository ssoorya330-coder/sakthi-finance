import { requireAdminAccessPage } from '@/lib/admin-access'
import AdminAccessPage from '@/features/admin-access/AdminAccessPage'

export default async function AdminAccessPageRoute() {
  const user = await requireAdminAccessPage()
  return <AdminAccessPage userName={user.name} role={user.role} />
}
