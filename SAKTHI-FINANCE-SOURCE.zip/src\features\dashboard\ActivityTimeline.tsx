'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'
import {
  CreditCard,
  UserPlus,
  ArrowUpRight,
  Clock,
} from 'lucide-react'
import { useCustomerStore } from '@/store/customer-store'
import { formatINR } from '@/lib/dashboard-utils'
import Link from 'next/link'

const statusColors: Record<string, { bg: string; text: string; dot: string }> = {
  Active: { bg: 'bg-[var(--primary-soft)]', text: 'text-[var(--primary)]', dot: 'bg-[var(--primary)]' },
  Completed: { bg: 'bg-[#FFFBEB]', text: 'text-[var(--secondary)]', dot: 'bg-[var(--secondary)]' },
  Overdue: { bg: 'bg-red-50', text: 'text-red-700', dot: 'bg-red-500' },
  Aborted: { bg: 'bg-red-100', text: 'text-red-800', dot: 'bg-red-600' },
}

export default function ActivityTimeline() {
  const customers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)

  const recentActivities = useMemo(() => {
    const activities: { id: string; type: string; title: string; description: string; amount?: number; time: string; customerName: string; status: string }[] = []

    const recentPayments = [...paymentHistory]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5)

    const customerMap = new Map(customers.map((c) => [c.id, c]))

    for (const p of recentPayments) {
      const c = customerMap.get(p.customerId)
      activities.push({
        id: `payment-${p.id}`,
        type: 'payment',
        title: `Payment received from ${c?.fullName || 'Unknown'}`,
        description: `${p.paymentMethod || 'Cash'} • ${new Date(p.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}`,
        amount: p.paymentAmount,
        time: new Date(p.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }),
        customerName: c?.fullName || 'Unknown',
        status: c?.status || 'Active',
      })
    }

    const recentCustomers = [...customers]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 3)

    for (const c of recentCustomers) {
      if (!activities.some((a) => a.id === `customer-${c.id}`)) {
        activities.push({
          id: `customer-${c.id}`,
          type: 'customer',
          title: `${c.fullName} added as new customer`,
          description: `${c.area || c.city || 'N/A'} • ${c.loanType || 'N/A'}`,
          time: new Date(c.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }),
          customerName: c.fullName,
          status: c.status,
        })
      }
    }

    return activities.sort((a, b) => {
      const dateA = new Date(a.time).getTime()
      const dateB = new Date(b.time).getTime()
      return dateB - dateA
    }).slice(0, 6)
  }, [customers, paymentHistory])

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="relative bg-white/70 backdrop-blur-xl rounded-[20px] border border-white/20 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] p-6 overflow-hidden"
    >
      <div className="absolute inset-0 sf-pattern-dots opacity-40 pointer-events-none" />
      <div className="flex items-center justify-between mb-4 relative">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
            <Clock className="w-[16px] h-[16px] text-white" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Recent Activities</h3>
            <p className="text-[11px] text-slate-500">Latest transactions and updates</p>
          </div>
        </div>
        <Link
          href="/dashboard/customers"
          className="flex items-center gap-1 text-xs font-medium text-[var(--primary)] hover:text-[var(--primary-hover)] transition-colors"
        >
          View All
          <ArrowUpRight className="w-3.5 h-3.5" />
        </Link>
      </div>
      <div className="space-y-1 relative">
        {recentActivities.map((item, i) => {
          const statusStyle = statusColors[item.status] || statusColors.Active
          const isPayment = item.type === 'payment'
          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: 0.1 + i * 0.05 }}
              whileHover={{ x: 4, backgroundColor: 'rgba(248,250,252,0.6)' }}
              className="flex items-center gap-3 p-3 rounded-[12px] transition-all hover:bg-slate-50/60"
            >
              <div className={`w-9 h-9 rounded-[11px] flex items-center justify-center text-white text-xs font-bold flex-shrink-0 shadow-md ${
                isPayment ? 'bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)]' : 'bg-gradient-to-br from-[var(--secondary)] to-[#B8943A]'
              }`}>
                {item.customerName.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium text-slate-900 truncate">{item.title}</p>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${statusStyle.bg} ${statusStyle.text} flex-shrink-0`}>
                    {item.status}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">{item.description}</p>
              </div>
              <div className="text-right flex-shrink-0">
                {item.amount && (
                  <p className="text-sm font-semibold text-[var(--primary)]">
                    +{formatINR(item.amount)}
                  </p>
                )}
                <p className="text-xs text-slate-400">{item.time}</p>
              </div>
            </motion.div>
          )
        })}
      </div>
    </motion.div>
  )
}
