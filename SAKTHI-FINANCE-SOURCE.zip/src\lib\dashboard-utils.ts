/**
 * Format number in Indian comma system (lakhs/crores)
 * e.g., ₹1,23,45,678
 */
export function formatINR(amount: number): string {
  const safeAmount = Number(amount) || 0
  const isNeg = safeAmount < 0
  const abs = Math.abs(safeAmount)
  const [intPart, decPart] = abs.toFixed(2).split('.')
  const lastThree = intPart.slice(-3)
  const rest = intPart.slice(0, -3)
  const formatted = rest.length > 0
    ? `${rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',')},${lastThree}`
    : lastThree
  const result = decPart === '00' ? formatted : `${formatted}.${decPart}`
  return isNeg ? `₹-${result}` : `₹${result}`
}

/**
 * Format number in Indian comma system without ₹ symbol
 */
export function formatINNumber(amount: number): string {
  const safeAmount = Number(amount) || 0
  const abs = Math.abs(safeAmount)
  const [intPart] = abs.toFixed(0).split('.')
  const lastThree = intPart.slice(-3)
  const rest = intPart.slice(0, -3)
  return rest.length > 0
    ? `${rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',')},${lastThree}`
    : lastThree
}

/**
 * Format percentage with sign
 */
export function formatPercent(value: number): string {
  const sign = value >= 0 ? '+' : ''
  return `${sign}${value.toFixed(1)}%`
}

/**
 * Generate sparkline data from array
 */
export function generateSparkData(values: number[]): { x: number; y: number }[] {
  return values.map((v, i) => ({ x: i, y: v }))
}

/**
 * Animate counter from 0 to target
 */
export function animateValue(
  from: number,
  to: number,
  duration: number,
  callback: (v: number) => void
): () => void {
  const startTime = performance.now()
  let raf: number
  function update(currentTime: number) {
    const elapsed = currentTime - startTime
    const progress = Math.min(elapsed / duration, 1)
    const eased = 1 - Math.pow(1 - progress, 3)
    callback(Math.round(from + (to - from) * eased))
    if (progress < 1) raf = requestAnimationFrame(update)
  }
  raf = requestAnimationFrame(update)
  return () => cancelAnimationFrame(raf)
}
