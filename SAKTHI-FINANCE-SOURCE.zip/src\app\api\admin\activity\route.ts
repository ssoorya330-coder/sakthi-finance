import { NextRequest, NextResponse } from 'next/server';
import { requireOwner } from '@/lib/api-utils';
import { dbQuery } from '@/server/database';

export const dynamic = 'force-dynamic';

const KIND_ACTIONS: Record<string, string[]> = {
  login: ['LOGIN', 'LOGOUT', 'LOGIN_FAILED'],
  system: [
    'USER_CREATED',
    'USER_STATUS_CHANGED',
    'ROLE_CHANGED',
    'DEVICE_LOGOUT',
    'UNAUTHORIZED_ACCESS',
    'BACKUP_CREATED',
    'BACKUP_RESTORED',
    'DATA_EXPORTED',
    'DATA_IMPORTED',
    'DATA_DIRECTORY_MIGRATED',
    'DATA_DIRECTORY_CONFIG_CHANGED',
    'STORAGE_LOCATION_CREATED',
    'STORAGE_LOCATION_UPDATED',
    'STORAGE_LOCATION_DELETED',
    'SETTINGS_UPDATED',
  ],
};

const KIND_ENTITY_TYPES: Record<string, string[]> = {
  data: ['customer', 'loan', 'payment'],
};

const MAX_LIMIT = 200;

/**
 * Admin-only activity feeds for the Admin Access sub-sections.
 * Owner-only: explicit rule role === 'owner' (Admin and Customer get 403).
 * Always returns predictable JSON; empty tables yield empty arrays.
 *
 * kinds: login | system | data
 * filters: q (user/action/IP), role, status, dateFrom, dateTo, page, limit
 */
export async function GET(request: NextRequest) {
  const auth = await requireOwner();
  if (auth.error) return auth.error;

  try {
    const sp = new URL(request.url).searchParams;
    const kind = sp.get('kind') || 'login';
    const q = (sp.get('q') || '').trim();
    const role = (sp.get('role') || '').trim();
    const status = (sp.get('status') || '').trim();
    const dateFrom = sp.get('dateFrom') || null;
    const dateTo = sp.get('dateTo') || null;
    const page = Math.max(parseInt(sp.get('page') || '1', 10) || 1, 1);
    const limit = Math.min(Math.max(parseInt(sp.get('limit') || '25', 10) || 25, 1), MAX_LIMIT);
    const offset = (page - 1) * limit;

    const params: any[] = [];
    let i = 1;
    const conds: string[] = [];

    if (kind === 'data') {
      conds.push(`(entity_type = ANY($${i}) OR action = 'DATA_EXPORTED')`);
      params.push(KIND_ENTITY_TYPES.data);
      i += 1;
    } else {
      const actions = KIND_ACTIONS[kind];
      if (!actions) {
        return NextResponse.json({ error: 'Unknown activity kind' }, { status: 400 });
      }
      conds.push(`action = ANY($${i})`);
      params.push(actions);
      i += 1;
    }
    if (q) {
      conds.push(`(performed_by ILIKE $${i} OR action ILIKE $${i} OR ip_address ILIKE $${i} OR COALESCE(entity_id, '') ILIKE $${i})`);
      params.push(`%${q}%`);
      i += 1;
    }
    if (role) {
      conds.push(`user_role = $${i}`);
      params.push(role);
      i += 1;
    }
    if (status) {
      conds.push(`result = $${i}`);
      params.push(status);
      i += 1;
    }
    if (dateFrom) {
      conds.push(`created_at >= $${i}`);
      params.push(new Date(dateFrom));
      i += 1;
    }
    if (dateTo) {
      const end = new Date(dateTo);
      if (/^\d{4}-\d{2}-\d{2}$/.test(dateTo)) end.setDate(end.getDate() + 1);
      conds.push(`created_at < $${i}`);
      params.push(end);
      i += 1;
    }

    const where = `WHERE ${conds.join(' AND ')}`;
    const rows = await dbQuery(
      `SELECT seq, audit_id, created_at, action, entity_type,
              COALESCE(entity_id, customer_id, loan_id, payment_id) AS entity_ref,
              performed_by, user_role, ip_address, client_info, reason, result, changes
       FROM audit_events ${where}
       ORDER BY created_at DESC, seq DESC
       LIMIT $${i} OFFSET $${i + 1}`,
      [...params, limit, offset]
    );
    const counted = await dbQuery(
      `SELECT COUNT(*) AS c FROM audit_events ${where}`,
      params
    );
    const events = Array.isArray(rows.rows) ? rows.rows : [];
    const total = Number(counted.rows[0]?.c) || 0;
    return NextResponse.json({
      events,
      total,
      page,
      limit,
      totalPages: Math.max(Math.ceil(total / limit), 1),
    });
  } catch (err: any) {
    console.error('[GET /api/admin/activity] Error:', err?.message || err);
    return NextResponse.json(
      { error: 'Unable to load activity. Please try again.' },
      { status: 500 }
    );
  }
}
