$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$fixtureDirectory = Join-Path (Get-Location) ('test-reports\voice-fixture-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $fixtureDirectory | Out-Null
$wavePath = Join-Path $fixtureDirectory 'hello-world.wav'
$synthesizer = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {
    $synthesizer.SelectVoiceByHints([System.Speech.Synthesis.VoiceGender]::NotSet, [System.Speech.Synthesis.VoiceAge]::NotSet, 0, [System.Globalization.CultureInfo]::GetCultureInfo('en-US'))
    $synthesizer.SetOutputToWaveFile($wavePath)
    $synthesizer.Speak('Hello world')
} finally { $synthesizer.Dispose() }
$events = @(& '.\dist-electron\native\SakthiSpeech.exe' 'en-IN' '--wave' $wavePath | ForEach-Object { $_ | ConvertFrom-Json })
$text = (($events | Where-Object { $_.type -eq 'result' } | ForEach-Object { $_.text }) -join ' ')
if ($text.Trim().TrimEnd('.').ToLowerInvariant() -ne 'hello world') { throw 'Generated English audio did not produce the expected transcript.' }
$unsupported = & '.\dist-electron\native\SakthiSpeech.exe' 'ta-IN' | ConvertFrom-Json
if ($unsupported.error -ne 'language-not-supported') { throw 'Unsupported language was not reported correctly.' }
Write-Output 'PASS: English audio transcribed locally as hello world; en-IN uses installed English dialect; Tamil reports missing language. No microphone recorded.'
$nameWave = Join-Path $fixtureDirectory 'soorya.wav'
$nameSynthesizer = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {
    $nameSynthesizer.SelectVoiceByHints([System.Speech.Synthesis.VoiceGender]::NotSet, [System.Speech.Synthesis.VoiceAge]::NotSet, 0, [System.Globalization.CultureInfo]::GetCultureInfo('en-US'))
    $nameSynthesizer.SetOutputToWaveFile($nameWave)
    $namePrompt = New-Object System.Speech.Synthesis.PromptBuilder
    $namePrompt.AppendBreak([TimeSpan]::FromMilliseconds(500))
    $namePrompt.AppendText('Soorya')
    $namePrompt.AppendBreak([TimeSpan]::FromMilliseconds(1000))
    $nameSynthesizer.Speak($namePrompt)
} finally { $nameSynthesizer.Dispose() }
$nameEvents = @('["Soorya","Kumar","Ravi"]' | & '.\dist-electron\native\SakthiSpeech.exe' 'en-IN' '--context' '--wave' $nameWave | ForEach-Object { $_ | ConvertFrom-Json })
$recognizedName = (($nameEvents | Where-Object { $_.type -eq 'result' } | ForEach-Object { $_.text }) -join ' ')
if ($recognizedName.Trim() -ne 'Soorya') { throw 'Generated Soorya audio did not match the supplied name hint.' }
Write-Output 'PASS: generated Soorya audio recognized with the customer-name grammar. Human microphone accuracy remains untested.'
