'use client'

import { useMemo, memo, useDeferredValue } from 'react'
import dynamic from 'next/dynamic'
import DashboardHeader from './DashboardHeader'
import KpiCard from './KpiCard'
import { useCustomerStore } from '@/store/customer-store'
import type { KpiCardData } from './dashboard.types'
import { computeSparkData, computeChangePercent } from './dashboard-data'

const CollectionOverview = dynamic(() => import('./CollectionOverview'), { ssr: false, loading: () => <div className="h-[320px] animate-pulse bg-slate-100 rounded-2xl" /> })
const LoanStatusChart = dynamic(() => import('./LoanStatusChart'), { ssr: false, loading: () => <div className="h-[320px] animate-pulse bg-slate-100 rounded-2xl" /> })
const TodayCollection = dynamic(() => import('./TodayCollection'), { ssr: false, loading: () => <div className="h-[260px] animate-pulse bg-slate-100 rounded-2xl" /> })
const PaymentStatusChart = dynamic(() => import('./PaymentStatusChart'), { ssr: false, loading: () => <div className="h-[260px] animate-pulse bg-slate-100 rounded-2xl" /> })
const AreaCustomersChart = dynamic(() => import('./AreaCustomersChart'), { ssr: false, loading: () => <div className="h-[260px] animate-pulse bg-slate-100 rounded-2xl" /> })
const BusinessTypeChart = dynamic(() => import('./BusinessTypeChart'), { ssr: false, loading: () => <div className="h-[260px] animate-pulse bg-slate-100 rounded-2xl" /> })
const CollectionCalendar = dynamic(() => import('./CollectionCalendar'), { ssr: false, loading: () => <div className="h-[320px] animate-pulse bg-slate-100 rounded-2xl" /> })

const Dashboard = memo(function Dashboard() {
  const customersRaw = useCustomerStore((s) => s.customers)
  const paymentHistoryRaw = useCustomerStore((s) => s.paymentHistory)
  const customers = useDeferredValue(customersRaw)
  const paymentHistory = useDeferredValue(paymentHistoryRaw)

  const storeStats = useMemo(() => ({
    totalCustomers: customers.length,
    activeCustomers: customers.filter((c) => c.status === 'Active').length,
    completedCustomers: customers.filter((c) => c.status === 'Completed').length,
    abortedCustomers: customers.filter((c) => c.status === 'Aborted').length,
    totalLoanAmount: customers.reduce((sum, c) => sum + (Number(c.loanAmount) || 0), 0),
    totalInterest: customers.reduce((sum, c) => sum + (Number(c.interestAmount) || 0), 0),
    totalAmount: customers.reduce((sum, c) => sum + ((Number(c.loanAmount) || 0) + (Number(c.interestAmount) || 0)), 0),
    totalReceived: paymentHistory.reduce((sum, p) => sum + ((Number(p.paymentAmount) || 0)), customers.reduce((sum,c)=>sum+(c.offlinePaidAmount||0),0)),
  }), [customers, paymentHistory])

  const sparkData = useMemo(() => ({
    customers: computeSparkData(customers, paymentHistory, 'customers'),
    active: computeSparkData(customers, paymentHistory, 'active'),
    completed: computeSparkData(customers, paymentHistory, 'completed'),
    aborted: computeSparkData(customers, paymentHistory, 'aborted'),
    loan: computeSparkData(customers, paymentHistory, 'loan'),
    interest: computeSparkData(customers, paymentHistory, 'interest'),
    totalAmount: computeSparkData(customers, paymentHistory, 'totalAmount'),
    balance: computeSparkData(customers, paymentHistory, 'balance'),
  }), [customers, paymentHistory])

  const balanceAmount = useMemo(() => Math.max(0, Number(storeStats.totalAmount) - Number(storeStats.totalReceived) || 0), [storeStats])

  const kpiData: KpiCardData[] = useMemo(() => [
    { id: 'total-customers', title: 'Total Customers', value: storeStats.totalCustomers, change: computeChangePercent(customers, paymentHistory, 'customers'), changeLabel: 'Overall Customers', icon: 'Users', iconColor: 'text-blue-600', iconBg: 'bg-blue-50', sparkData: sparkData.customers },
    { id: 'active-customers', title: 'Active Customers', value: storeStats.activeCustomers, change: computeChangePercent(customers, paymentHistory, 'active'), changeLabel: 'Currently Active', icon: 'UserCheck', iconColor: 'text-emerald-600', iconBg: 'bg-emerald-50', sparkData: sparkData.active },
    { id: 'completed-customers', title: 'Completed Customers', value: storeStats.completedCustomers, change: computeChangePercent(customers, paymentHistory, 'completed'), changeLabel: 'Loans Completed', icon: 'BadgeCheck', iconColor: 'text-indigo-600', iconBg: 'bg-indigo-50', sparkData: sparkData.completed },
    { id: 'aborted-customers', title: 'Aborted Customers', value: storeStats.abortedCustomers, change: computeChangePercent(customers, paymentHistory, 'aborted'), changeLabel: 'Closed / Aborted', icon: 'UserX', iconColor: 'text-red-600', iconBg: 'bg-red-50', sparkData: sparkData.aborted },
    { id: 'loan-amount-given', title: 'Amount Given', value: storeStats.totalLoanAmount, change: computeChangePercent(customers, paymentHistory, 'loan'), changeLabel: 'Principal Amount', icon: 'Wallet', iconColor: 'text-cyan-600', iconBg: 'bg-cyan-50', sparkData: sparkData.loan },
    { id: 'interest-amount', title: 'Interest Amount', value: storeStats.totalInterest, change: computeChangePercent(customers, paymentHistory, 'interest'), changeLabel: 'Interest Earned', icon: 'Percent', iconColor: 'text-pink-600', iconBg: 'bg-pink-50', sparkData: sparkData.interest },
    { id: 'total-amount', title: 'Total Amount', value: storeStats.totalAmount, change: computeChangePercent(customers, paymentHistory, 'totalAmount'), changeLabel: 'Overall Finance Amount', icon: 'IndianRupee', iconColor: 'text-amber-600', iconBg: 'bg-amber-50', sparkData: sparkData.totalAmount },
    { id: 'balance-amount', title: 'Balance Amount', value: balanceAmount, change: computeChangePercent(customers, paymentHistory, 'balance'), changeLabel: 'Pending Collection', icon: 'Coins', iconColor: 'text-teal-600', iconBg: 'bg-teal-50', sparkData: sparkData.balance },
  ], [storeStats, balanceAmount, sparkData, customers, paymentHistory])

  return (
    <div className="dashboard-overview min-h-screen relative" style={{ contentVisibility: 'auto' as any }}>
      <DashboardHeader />
      <main className="px-4 sm:px-6 py-6 sm:py-10 max-w-[1600px] mx-auto">
        <section className="mb-8" style={{ contain: 'layout paint' }}>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 2xl:grid-cols-4 gap-4 sm:gap-6">
            {kpiData.map((card, i) => (
              <div key={card.id} style={{ contentVisibility: 'auto' as any, containIntrinsicSize: '0 148px' }}>
                <KpiCard data={card} index={i} />
              </div>
            ))}
          </div>
        </section>

        <section className="mb-8" style={{ contain: 'layout paint', contentVisibility: 'auto' as any }}>
          <div className="grid grid-cols-1 xl:grid-cols-[1fr_400px] gap-6">
            <div style={{ contain: 'layout paint' }}><CollectionOverview /></div>
            <div style={{ contain: 'layout paint' }}><LoanStatusChart /></div>
          </div>
        </section>

        <section className="mb-8" style={{ contain: 'layout paint', contentVisibility: 'auto' as any }}>
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            <TodayCollection />
            <PaymentStatusChart />
            <AreaCustomersChart />
            <BusinessTypeChart />
            <div className="lg:col-span-2 xl:col-span-2"><CollectionCalendar /></div>
          </div>
        </section>

      </main>
    </div>
  )
})

export default Dashboard
