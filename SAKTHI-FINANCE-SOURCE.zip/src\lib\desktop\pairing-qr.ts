/** Public, short-lived pairing invitation. Never include session/device tokens. */
export function pairingQr(input:{address:string;fingerprint:string;code:string;expiresAt:number;laptopName:string;environment:string}) {
  const url=new URL(input.address)
  if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash||url.pathname!=='/'
    ||!/^[0-9a-f]{64}$/.test(input.fingerprint)||!/^\d{6}$/.test(input.code)
    ||!Number.isSafeInteger(input.expiresAt)||!['development','production'].includes(input.environment)
    ||input.laptopName.length<1||input.laptopName.length>100||/[\x00-\x1f\x7f]/.test(input.laptopName))throw Error('Invalid pairing invitation')
  return JSON.stringify({type:'sakthi-pairing',version:1,address:input.address,fingerprint:input.fingerprint,
    code:input.code,expiresAt:input.expiresAt,laptopName:input.laptopName,environment:input.environment})
}
