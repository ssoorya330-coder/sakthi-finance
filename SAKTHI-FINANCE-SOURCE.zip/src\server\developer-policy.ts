import type { Pool } from 'pg'

// One-time role policy change, with previous assignments retained for review.
// Customer-linked portal logins remain customer logins. No business data moves.
export async function migrateDeveloperPolicy(pool:Pool) {
  const tx=await pool.connect()
  try {
    await tx.query('BEGIN')
    await tx.query('SELECT pg_advisory_xact_lock(721904223)')
    const done=await tx.query("SELECT 1 FROM sakthi_migrations WHERE name='developer-owner-policy-v1'")
    if(!done.rows.length){
      await tx.query(`CREATE TABLE IF NOT EXISTS developer_policy_previous_roles AS
        SELECT user_id,role,role_id,NOW() AS preserved_at FROM users WHERE customer_id IS NULL`)
      await tx.query(`UPDATE users SET role='owner',role_id=(SELECT role_id FROM roles WHERE role_name='owner'),updated_at=NOW()
        WHERE customer_id IS NULL AND (role IS DISTINCT FROM 'owner' OR role_id IS DISTINCT FROM (SELECT role_id FROM roles WHERE role_name='owner'))`)
      await tx.query("INSERT INTO sakthi_migrations(name) VALUES('developer-owner-policy-v1')")
    }
    await tx.query('COMMIT')
  } catch(error){await tx.query('ROLLBACK');throw error}
  finally{tx.release()}
}
