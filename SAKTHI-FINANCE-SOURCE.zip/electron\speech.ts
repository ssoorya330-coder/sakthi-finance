import { spawn, type ChildProcessWithoutNullStreams } from 'node:child_process'
import path from 'node:path'
import { existsSync } from 'node:fs'
import { transcribeWave } from './offline-transcription'
import { VoicePreview } from './voice-preview'

export type VoiceEvent = { id: string; type: 'ready' | 'sound' | 'processing' | 'interim' | 'result' | 'error' | 'end'; text?: string; error?: string; language?: string }
type Attempt = { id: string; child?: ChildProcessWithoutNullStreams; controller: AbortController; preview?: VoicePreview; cancelled: boolean; processing: boolean }
export class WindowsVoice {
  private active: Attempt | null = null
  private cancelledIds = new Set<string>()
  async start(id: string, lang: string, consent: () => Promise<boolean>, send: (event: VoiceEvent) => void, phrases?: unknown) {
    if (!/^[a-zA-Z0-9-]{1,80}$/.test(id) || !/^[a-z]{2,3}(?:-[A-Za-z]{2,4})?$/.test(lang)) throw Error('Invalid voice request')
    if (this.cancelledIds.has(id)) return
    this.cancel()
    const attempt: Attempt = { id, cancelled: false, processing: false, controller: new AbortController() }
    this.active = attempt
    let ended = false, deadline: ReturnType<typeof setTimeout> | undefined
    const emit = (event: Omit<VoiceEvent, 'id'>) => { if (!attempt.cancelled && !ended) send({ ...event, id }) }
    const finish = () => { if (ended) return; emit({ type: 'end' }); ended = true; clearTimeout(deadline); void attempt.preview?.close(); if (this.active === attempt) this.active = null }
    try {
      if (!await consent()) { emit({ type: 'error', error: 'not-allowed' }); finish(); return }
      if (attempt.cancelled) return
      const root = process.env.SAKTHI_HELPER_ROOT || path.join(__dirname, 'native')
      if (![path.join(root, 'SakthiAudio.exe'), path.join(root, 'voice/whisper-cli.exe'), path.join(root, 'voice/ggml-small-q5_1.bin')].every(existsSync)) {
        emit({ type: 'error', error: 'model-missing' }); finish(); return
      }
      const child = spawn(path.join(root, 'SakthiAudio.exe'), [], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] })
      attempt.child = child
      // Fast display-only decoding; final results retain the more accurate beam.
      attempt.preview = new VoicePreview((wav, signal) => transcribeWave(root, wav, lang, signal, phrases, true), text => emit({ type: 'interim', text }))
      let pending = '', receivedAudio = false, reportedError = false
      deadline = setTimeout(() => { emit({ type: 'error', error: 'timeout' }); child.kill(); finish() }, 35000)
      child.stdout.setEncoding('utf8')
      child.stdout.on('data', (chunk: string) => {
        if (ended || attempt.cancelled) return
        pending += chunk
        if (pending.length > 1500000) { reportedError = true; emit({ type: 'error', error: 'audio-capture' }); child.kill(); return }
        let index: number
        while ((index = pending.indexOf('\n')) >= 0) {
          const line = pending.slice(0, index); pending = pending.slice(index + 1)
          try {
            const value = JSON.parse(line)
            if (ended || attempt.cancelled) break
            if (value.type === 'ready' || value.type === 'sound') emit({ type: value.type })
            if (value.type === 'error') { reportedError = true; emit({ type: 'error', error: value.error === 'no-speech' ? 'no-speech' : 'audio-capture' }) }
            if (value.type === 'preview-audio' && typeof value.data === 'string' && !receivedAudio) attempt.preview?.push(Buffer.from(value.data, 'base64'))
            if (value.type === 'audio' && typeof value.data === 'string' && !receivedAudio && !attempt.cancelled) {
              receivedAudio = true; attempt.processing = true; clearTimeout(deadline)
              const wav = Buffer.from(value.data, 'base64')
              emit({ type: 'processing' })
              void attempt.preview!.close().then(() => transcribeWave(root, wav, lang, attempt.controller.signal, phrases))
                .then(text => emit({ type: 'result', text }))
                .catch(error => emit({ type: 'error', error: error instanceof Error ? error.message : 'recognition-failed' }))
                .finally(() => { wav.fill(0); finish() })
            }
          } catch { /* Never log audio or transcripts. */ }
        }
      })
      child.stderr.resume(); child.stdin.on('error', () => {})
      child.on('error', () => { reportedError = true; emit({ type: 'error', error: 'helper-unavailable' }); finish() })
      child.on('close', code => {
        if (!receivedAudio) { if (!reportedError && !attempt.cancelled) emit({ type: 'error', error: code ? 'audio-capture' : 'no-speech' }); finish() }
        pending = ''
      })
    } catch { emit({ type: 'error', error: 'helper-unavailable' }); finish() }
  }
  stop(id: string) {
    if (this.active?.id === id && this.active.processing) return
    if (this.active?.id === id && this.active.child) this.active.child.stdin.end('stop\n')
    else this.cancel(id)
  }
  cancel(id?: string) {
    const cancelled = id || this.active?.id
    if (cancelled) { this.cancelledIds.add(cancelled); if (this.cancelledIds.size > 256) this.cancelledIds.delete(this.cancelledIds.values().next().value!) }
    if (!this.active || (id && this.active.id !== id)) return
    this.active.cancelled = true; this.active.controller.abort(); void this.active.preview?.close(); this.active.child?.kill(); this.active = null
  }
}
