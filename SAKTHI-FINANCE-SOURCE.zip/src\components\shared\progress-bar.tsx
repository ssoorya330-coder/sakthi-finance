'use client';

import { cn } from '@/lib/utils';

interface ProgressBarProps {
  value: number;
  max?: number;
  className?: string;
  showLabel?: boolean;
  label?: string;
  showPercentage?: boolean;
}

export default function ProgressBar({
  value,
  max = 100,
  className,
  showLabel = false,
  label,
  showPercentage = false,
}: ProgressBarProps) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));

  return (
    <div className={cn('w-full', className)}>
      {showLabel && label && (
        <div className="flex justify-between items-center mb-2">
          <span className="text-[12px] text-text-tertiary">{label}</span>
          <span className="text-[12px] font-medium text-gold-400">
            {Math.round(pct)}%
          </span>
        </div>
      )}
      <div className="relative h-[4px] w-full rounded-full bg-border-subtle overflow-hidden">
        <div
          className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-gold-600 via-gold-400 to-gold-300 transition-all duration-300 ease-out"
          style={{ width: `${pct}%` }}
        >
          <div className="absolute inset-0 sf-shimmer-bg rounded-full" />
        </div>
      </div>
      {showPercentage && (
        <div className="mt-2 text-center">
          <span className="text-[14px] font-semibold text-gold-400 tabular-nums">
            {Math.round(pct)}%
          </span>
        </div>
      )}
    </div>
  );
}
