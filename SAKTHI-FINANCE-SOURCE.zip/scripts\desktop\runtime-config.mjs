export const runtimeKeys = [
  'DATABASE_URL', 'DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD',
  'GOOGLE_CLIENT_ID', 'NEXT_PUBLIC_GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET',
  'GOOGLE_DESKTOP_CLIENT_ID', 'GOOGLE_DESKTOP_CLIENT_SECRET',
  'JWT_ACCESS_SECRET', 'JWT_REFRESH_SECRET',
]

export function validateRuntimeConfig(source) {
  const config = Object.fromEntries(runtimeKeys.filter(key => typeof source[key] === 'string').map(key => [key, source[key]]))
  if (!config.DATABASE_URL && !['DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD'].every(key => config[key]?.trim())) {
    throw new Error('Database settings are missing. No fallback database will be opened.')
  }
  for (const key of ['JWT_ACCESS_SECRET', 'JWT_REFRESH_SECRET']) {
    if (!config[key] || config[key].length < 32 || /default|changeme|placeholder|REPLACE_WITH/i.test(config[key])) {
      throw new Error('Private desktop session keys are not configured.')
    }
  }
  if (config.JWT_ACCESS_SECRET === config.JWT_REFRESH_SECRET) throw new Error('Desktop session keys must be distinct.')
  if (!config.GOOGLE_DESKTOP_CLIENT_ID || !config.GOOGLE_DESKTOP_CLIENT_SECRET) throw new Error('Desktop Google sign-in is not configured.')
  return config
}

export function databaseProbeConfig(config) {
  return {
    ...(config.DATABASE_URL ? { connectionString: config.DATABASE_URL } : {
      host: config.DB_HOST, port: Number(config.DB_PORT), database: config.DB_NAME,
      user: config.DB_USER, password: config.DB_PASSWORD,
    }),
    connectionTimeoutMillis: 3000, query_timeout: 3000, statement_timeout: 3000,
  }
}
