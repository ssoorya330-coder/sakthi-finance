import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { validateStoragePath, validPurposes } from '@/server/storage'
import { dbQuery } from '@/server/database'

/** Pre-flight validation for the Add Storage wizard (no side effects). */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const check = await validateStoragePath(body.path || '')
    if (!check.ok) return NextResponse.json({ ok: false, error: check.error }, { status: 200 })

    const dup = await dbQuery('SELECT id FROM storage_locations WHERE LOWER(path) = LOWER($1) LIMIT 1', [
      check.normalizedPath,
    ])
    if (dup.rows.length > 0) {
      return NextResponse.json({ ok: false, error: 'This location is already configured.' }, { status: 200 })
    }
    return NextResponse.json({
      ok: true,
      normalizedPath: check.normalizedPath,
      drive: check.drive,
      freeBytes: check.freeBytes,
      purposes: validPurposes(),
    })
  } catch (err: any) {
    return NextResponse.json(
      { ok: false, error: 'Validation failed', details: err.message },
      { status: 500 }
    )
  }
}
