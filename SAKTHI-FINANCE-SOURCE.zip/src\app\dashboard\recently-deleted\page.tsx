'use client'

import { useEffect, useRef, useState } from 'react'
import { Search, X, Menu, RotateCcw, Trash2 } from 'lucide-react'
import { clearCache } from '@/services/api-client'
import { useCustomerStore } from '@/store/customer-store'
import { useSidebarStore } from '@/store/sidebar-store'
import { formatCurrency } from '@/features/dashboard/dashboard.styles'
import VoiceMicButton from '@/components/ui/voice-mic-button'

type DeletedKanaku = { loan_id:string; customer_code:string; full_name:string; cycle_number:number; kanaku_number:number; purge_after:string; payment_count:number; loan_amount:string; interest_rate:string; total_amount:string; received_amount:string; balance_amount:string }
function ConfirmRecordAction({ action, row, onCancel, onConfirm }: { action:'restore'|'delete'; row:DeletedKanaku; onCancel:()=>void; onConfirm:()=>void }) {
  const dialog=useRef<HTMLDialogElement>(null)
  const submitted=useRef(false)
  const deleting=action==='delete'
  useEffect(()=>{
    const element=dialog.current
    element?.showModal()
    return ()=>element?.close()
  },[])
  return <dialog ref={dialog} onCancel={event=>{event.preventDefault();onCancel()}}
    aria-labelledby="record-confirm-title" aria-describedby="record-confirm-description"
    className="fixed inset-0 m-auto w-[calc(100%-2rem)] max-w-md max-h-[90dvh] overflow-y-auto rounded-2xl border border-[#EADCCD] bg-[#FFFDF5] p-0 text-[var(--text-primary)] shadow-2xl backdrop:bg-black/40 backdrop:backdrop-blur-sm">
    <div className="h-1.5 bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)]" />
    <div className="p-6">
      <div className="mb-4 flex items-center justify-between">
        <span className="rounded-xl bg-[var(--primary)]/10 p-3 text-[var(--primary)]">{deleting?<Trash2 aria-hidden="true" className="h-6 w-6" />:<RotateCcw aria-hidden="true" className="h-6 w-6" />}</span>
        <span className="text-xs font-semibold tracking-widest text-[var(--primary)]">SAKTHI FINANCE</span>
      </div>
      <h2 id="record-confirm-title" className="text-xl font-bold text-[var(--primary)]">{deleting?'Delete permanently?':'Restore this Kanaku?'}</h2>
      <div className="my-4 rounded-xl border border-[#EADCCD] bg-white p-3">
        <p className="font-semibold break-words">{row.customer_code} · {row.full_name}</p>
        <p className="mt-1 text-sm text-slate-600">Cycle {row.cycle_number} · Kanaku {row.kanaku_number}</p>
      </div>
      <p id="record-confirm-description" className="text-sm leading-relaxed text-slate-600">{deleting
        ? `This Kanaku and its ${row.payment_count} payments will be permanently removed. You cannot restore them afterward. Other Kanaku and the customer profile remain unchanged. Audit history and backups are retained.`
        : 'This Kanaku and its payments will be restored. Existing amounts and other Kanaku will remain unchanged.'}</p>
      <div className="mt-6 flex flex-wrap justify-end gap-3">
        <button autoFocus type="button" onClick={onCancel} className="rounded-xl border border-[#EADCCD] bg-white px-4 py-2.5 text-sm font-semibold focus-visible:outline-2 focus-visible:outline-[var(--primary)]">Cancel</button>
        <button type="button" onClick={()=>{if(submitted.current)return;submitted.current=true;onConfirm()}} className="rounded-xl bg-[var(--primary)] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#9B2525] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--primary)]">{deleting?'Delete Permanently':'Restore'}</button>
      </div>
    </div>
  </dialog>
}
export default function RecentlyDeleted() {
  const toggleSidebar = useSidebarStore(state => state.toggleSidebar)
  const sidebarOpen = useSidebarStore(state => state.isOpen)
  const [rows,setRows] = useState<DeletedKanaku[]>([])
  const [message,setMessage] = useState('Loading…')
  const [busy,setBusy] = useState(false)
  const [confirmation,setConfirmation] = useState<{action:'restore'|'delete';row:DeletedKanaku}|null>(null)
  const [search,setSearch] = useState('')
  const query = search.trim().toLocaleLowerCase()
  const filteredRows = rows.filter(row => !query ||
    String(row.full_name || '').toLocaleLowerCase().includes(query) ||
    String(row.customer_code || '').toLocaleLowerCase().includes(query))
  async function load() {
    try {
      const response=await fetch('/api/kanaku-trash',{cache:'no-store'})
      const data=await response.json()
      if(!response.ok)throw new Error(data.error || 'Connect to the laptop to view Recently Deleted.')
      setRows(data.data);setMessage('')
    } catch(error) {setMessage(error instanceof Error?error.message:'Unable to load Recently Deleted.')}
  }
  useEffect(()=>{void load()},[])
  async function deletePermanently(row:DeletedKanaku) {
    if(busy)return
    setBusy(true)
    try {
      const response=await fetch('/api/kanaku-trash',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({loanId:row.loan_id,confirmation:'DELETE PERMANENTLY'})})
      const data=await response.json()
      if(!response.ok)throw new Error(data.error || 'Deletion was not confirmed. Refresh before retrying.')
      clearCache();await useCustomerStore.getState().refresh();await load()
      setMessage('Selected Kanaku and its payments permanently deleted. Other records are unchanged.')
    } catch(error){setMessage(error instanceof Error?error.message:'Deletion was not confirmed. Refresh before retrying.')}
    finally{setBusy(false)}
  }
  async function restore(loanId:string) {
    if(busy)return
    const row=rows.find(record=>record.loan_id===loanId)
    if(!row)return
    setBusy(true)
    try {
      const response=await fetch('/api/kanaku-trash',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({loanId})})
      const data=await response.json()
      if(!response.ok)throw new Error(data.error || 'Unable to restore. No records were changed.')
      clearCache();await useCustomerStore.getState().refresh();await load()
      setMessage('Kanaku and its payments restored.')
    } catch(error) {setMessage(error instanceof Error?error.message:'Restore failed. Please retry.')}
    finally {setBusy(false)}
  }
  return <main className="p-6 space-y-4 text-[var(--primary)]">
    <div className="flex items-center gap-3">
      <button type="button" onClick={toggleSidebar} aria-label="Toggle navigation menu" aria-expanded={sidebarOpen}
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-[#EADCCD] bg-white text-[var(--text-primary)] transition-colors hover:bg-rose-50 focus-visible:outline-2 focus-visible:outline-[var(--primary)]">
        <Menu className="h-4 w-4" aria-hidden="true" />
      </button>
    </div>
    <h1 className="text-2xl font-bold">Deleted Customers</h1>
    <p className="text-sm font-medium">Recently deleted Kanaku · 30-day recovery</p>
    <p className="text-sm">Only the selected Kanaku and its payments are removed after 30 days. Other Kanaku and customer profiles are kept. Recovery requires a connection to the laptop.</p>
    <p role="status">{message}</p>
    <div className="flex items-center gap-2 max-w-xl">
    <div className="relative flex-1 min-w-0">
      <label htmlFor="deleted-customer-search" className="sr-only">Search deleted customers by name or customer ID</label>
      <Search aria-hidden="true" className="absolute left-3 top-3 h-5 w-5 text-[var(--primary)]/60" />
      <input id="deleted-customer-search" type="search" value={search} onChange={event=>setSearch(event.target.value)}
        placeholder="Search by customer name or ID…"
        className="w-full rounded-xl border border-[#EADCCD] bg-white py-3 pl-10 pr-12 text-sm outline-none focus:ring-2 focus:ring-[var(--primary)]/20" />
      {search && <button type="button" aria-label="Clear customer search" onClick={()=>setSearch('')} className="absolute right-2 top-2 rounded-lg p-2 hover:bg-rose-50"><X aria-hidden="true" className="h-4 w-4" /></button>}
    </div>
    <VoiceMicButton inputType="search" value={search} onPreview={setSearch} onResult={text=>setSearch(text.replace(/\./g,'').trim())} />
    </div>
    {rows.length>0 && <p className="text-sm" role="status">Showing {filteredRows.length} of {rows.length} deleted Kanaku records</p>}
    {!message && rows.length===0 && <p>No deleted customer Kanaku records.</p>}
    {rows.length>0 && filteredRows.length===0 && <p>No deleted customers match your search.</p>}
    {filteredRows.map(row=><section key={row.loan_id} className="bg-white border border-[#EADCCD] rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
      <div><h2 className="font-semibold">{row.customer_code} · {row.full_name}</h2>
        <p>Cycle {row.cycle_number} · Kanaku {row.kanaku_number} · {row.payment_count} payments</p>
        <dl className="my-3 grid grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="rounded-xl bg-[#FFF8E5] px-3 py-2"><dt className="text-xs">Loan Amount</dt><dd className="font-semibold">{formatCurrency(Number(row.loan_amount))}</dd></div>
          <div className="rounded-xl bg-[#FFF8E5] px-3 py-2"><dt className="text-xs">Interest %</dt><dd className="font-semibold">{Number(row.interest_rate)}%</dd></div>
          <div className="rounded-xl bg-[#FFF8E5] px-3 py-2"><dt className="text-xs">Total Amount</dt><dd className="font-semibold">{formatCurrency(Number(row.total_amount))}</dd></div>
          <div className="rounded-xl bg-emerald-50 px-3 py-2"><dt className="text-xs text-emerald-800">Amount Received</dt><dd className="font-semibold text-emerald-800">{formatCurrency(Number(row.received_amount))}</dd></div>
          <div className="rounded-xl bg-rose-50 px-3 py-2"><dt className="text-xs">Total Balance Amount</dt><dd className="font-semibold">{formatCurrency(Number(row.balance_amount))}</dd></div>
        </dl>
        <p className="text-sm">Recovery ends: {new Date(row.purge_after).toLocaleDateString('en-IN')}</p></div>
      <div className="flex flex-wrap gap-2">
        <button type="button" disabled={busy || Date.parse(row.purge_after)<=Date.now()} onClick={()=>setConfirmation({action:'restore',row})} className="flex items-center gap-2 rounded-xl bg-[var(--primary)] px-4 py-2 text-sm font-medium text-white disabled:opacity-40"><RotateCcw className="h-4 w-4" aria-hidden="true" />Restore</button>
        <button type="button" disabled={busy} onClick={()=>setConfirmation({action:'delete',row})} className="flex items-center gap-2 rounded-xl border border-red-200 px-4 py-2 text-sm font-medium text-red-700 hover:bg-red-50 disabled:opacity-40"><Trash2 className="h-4 w-4" aria-hidden="true" />Delete Permanently</button>
      </div>
    </section>)}
    {confirmation && <ConfirmRecordAction action={confirmation.action} row={confirmation.row} onCancel={()=>setConfirmation(null)} onConfirm={()=>{
      const selected=confirmation
      setConfirmation(null)
      if(selected.action==='restore')void restore(selected.row.loan_id)
      else void deletePermanently(selected.row)
    }} />}
  </main>
}
