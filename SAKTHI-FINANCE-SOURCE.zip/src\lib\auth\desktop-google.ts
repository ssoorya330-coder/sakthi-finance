import { randomBytes, createHash, timingSafeEqual } from 'node:crypto'
import { createServer, type Server } from 'node:http'
import { OAuth2Client } from 'google-auth-library'

type Outcome = { status: 'pending' } | { status: 'complete'; credential: string } | { status: 'failed'; error: string }
type Attempt = { server: Server; timer: NodeJS.Timeout; outcome: Outcome; claimed: boolean }
type Exchange = (code: string, verifier: string, redirect: string, nonce: string) => Promise<string>

export function validDesktopOrigin(request: Request) {
  const url = new URL(request.url)
  return ['localhost', '127.0.0.1'].includes(url.hostname)
    && request.headers.get('origin') === url.origin
    && !['cross-site', 'same-site'].includes(request.headers.get('sec-fetch-site') || '')
}

function equalSecret(a: string, b: string) {
  const left = Buffer.from(a), right = Buffer.from(b)
  return left.length === right.length && timingSafeEqual(left, right)
}

// No database writes here. The existing Google route still verifies the returned
// ID token, resolves the account and creates the ordinary Sakthi Finance session.
export class DesktopGoogleBroker {
  private attempts = new Map<string, Attempt>()
  constructor(private lifetime = 300_000, private limit = 4) {}

  async start(clientId: string, exchange: Exchange) {
    if (this.attempts.size >= this.limit) throw new Error('Too many sign-in attempts. Cancel an attempt or wait five minutes.')
    const ticket = randomBytes(32).toString('base64url')
    const state = randomBytes(32).toString('base64url')
    const nonce = randomBytes(32).toString('base64url')
    const verifier = randomBytes(48).toString('base64url')
    const challenge = createHash('sha256').update(verifier).digest('base64url')
    let redirect = ''
    const server = createServer({ maxHeaderSize: 8192, requestTimeout: 3000, headersTimeout: 3000 }, async (req, res) => {
      res.setHeader('Cache-Control', 'no-store')
      res.setHeader('Content-Type', 'text/plain; charset=utf-8')
      res.setHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'")
      res.setHeader('Referrer-Policy', 'no-referrer')
      res.setHeader('Connection', 'close')
      let callback: URL
      try { callback = new URL(req.url || '/', redirect) }
      catch { res.writeHead(400).end('Invalid callback'); return }
      const params = callback.searchParams
      const attempt = this.attempts.get(ticket)
      if (!attempt || attempt.claimed || req.method !== 'GET' || callback.origin !== new URL(redirect).origin
        || callback.pathname !== '/oauth/callback' || params.getAll('state').length !== 1
        || !equalSecret(params.get('state') || '', state)) {
        res.writeHead(400).end('Invalid sign-in callback. Return to Sakthi Finance.')
        return
      }
      attempt.claimed = true
      // Close the listener as soon as the correct callback is claimed. The code
      // exchange continues in memory; no credentials are rendered in the browser.
      // The callback page is branded and closes itself; it renders no URL data.
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' })
      res.end(`<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Sakthi Finance</title><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f8f8eb;color:#821d25;font:16px system-ui}main{text-align:center;max-width:420px;padding:32px}p{line-height:1.6;color:#555}</style></head><body><main><h1>Sakthi Finance</h1><p>Sign-in was successful.</p><p>You can return to the Sakthi Finance application — this page closes automatically.</p></main><script>setTimeout(function(){window.close()},1200)</script></body></html>`)
      server.close()
      if (params.has('error')) {
        attempt.outcome = { status: 'failed', error: 'Google sign-in was cancelled or denied. Please try again.' }
        return
      }
      const code = params.get('code') || ''
      if (params.getAll('code').length !== 1 || !code || code.length > 4096) {
        attempt.outcome = { status: 'failed', error: 'Invalid Google response. Please sign in again.' }
        return
      }
      try {
        const credential = await exchange(code, verifier, redirect, nonce)
        if (this.attempts.get(ticket) === attempt) attempt.outcome = { status: 'complete', credential }
      } catch {
        // Never include OAuth library exceptions: they may contain codes/secrets.
        attempt.outcome = { status: 'failed', error: 'Google sign-in could not finish. Check the Desktop OAuth configuration and your connection, then retry.' }
      }
    })
    server.setTimeout(3000, socket => socket.destroy())
    const timer = setTimeout(() => this.cancel(ticket), this.lifetime)
    timer.unref()
    this.attempts.set(ticket, { server, timer, outcome: { status: 'pending' }, claimed: false })
    try {
      await new Promise<void>((resolve, reject) => {
        server.once('error', reject)
        server.listen(0, '127.0.0.1', () => resolve())
      })
      server.unref()
      const address = server.address()
      if (!address || typeof address === 'string') throw new Error('Unable to open sign-in callback')
      redirect = `http://127.0.0.1:${address.port}/oauth/callback`
      const url = new URL('https://accounts.google.com/o/oauth2/v2/auth')
      url.search = new URLSearchParams({ client_id: clientId, redirect_uri: redirect, response_type: 'code',
        scope: 'openid email profile', state, nonce, code_challenge: challenge, code_challenge_method: 'S256',
        prompt: 'select_account' }).toString()
      return { ticket, url: url.toString() }
    } catch {
      this.cancel(ticket)
      throw new Error('Unable to start local Google sign-in. Please retry.')
    }
  }

  poll(ticket: string): Outcome | { status: 'expired' } {
    const attempt = this.attempts.get(ticket)
    if (!attempt) return { status: 'expired' }
    const result = attempt.outcome
    if (result.status !== 'pending') this.cancel(ticket)
    return result
  }

  cancel(ticket: string) {
    const attempt = this.attempts.get(ticket)
    if (!attempt) return
    clearTimeout(attempt.timer)
    attempt.server.close()
    attempt.server.closeAllConnections()
    this.attempts.delete(ticket)
  }
}

export function desktopGoogleExchange(clientId: string, clientSecret: string): Exchange {
  return async (code, verifier, redirect, nonce) => {
    // Explicit timeout and fixed Google endpoint. Never return access/refresh tokens.
    const response = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST', signal: AbortSignal.timeout(15_000), redirect: 'error',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret,
        code, code_verifier: verifier, redirect_uri: redirect, grant_type: 'authorization_code' }),
    })
    if (!response.ok) throw new Error('Google exchange rejected')
    const data = await response.json()
    if (typeof data.id_token !== 'string') throw new Error('Missing Google identity')
    const verified = await new OAuth2Client({ clientId, transporterOptions: { timeout: 15_000 } })
      .verifyIdToken({ idToken: data.id_token, audience: clientId })
    const payload = verified.getPayload()
    if (!payload || payload.nonce !== nonce || payload.email_verified !== true) throw new Error('Invalid Google identity')
    return data.id_token
  }
}

const globalBroker = globalThis as typeof globalThis & { sakthiDesktopGoogle?: DesktopGoogleBroker }
export const desktopGoogleBroker = globalBroker.sakthiDesktopGoogle ??= new DesktopGoogleBroker()
