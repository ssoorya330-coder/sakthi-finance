'use client'

/**
 * Electron renderer bridge.
 *
 * When running inside the Sakthi Finance desktop app the preload script
 * exposes window.sakthi. This module:
 *   1. routes every same-origin fetch('/api/...') through IPC into the main
 *      process, where the EXISTING application handlers run — no HTTP server,
 *   2. synthesizes a standard Response so existing call sites keep working
 *      (status checks, .json(), .blob(), .text(), arrayBuffer, headers),
 *   3. reports desktop mode to the app so it can hide web-only features.
 *
 * In a normal browser (including Next dev in a regular tab) it does nothing.
 */

interface DesktopBridgeApi {
  tablet: {
    status: () => Promise<TabletStatus>
    enable: (environment:'development'|'production') => Promise<TabletStatus>
    disable: () => Promise<TabletStatus>
    code: () => Promise<{code:string;expiresAt:number}>
    decide: (requestId:string,approve:boolean) => Promise<TabletStatus>
    revoke: (id:string) => Promise<TabletStatus>
  }
  updates: {
    onlineStatus: () => Promise<import('../../../electron/online-updates').OnlineUpdateStatus>
    check: () => Promise<import('../../../electron/online-updates').OnlineUpdateStatus>
    download: () => Promise<import('../../../electron/online-updates').OnlineUpdateStatus>
    restart: () => Promise<{ok: boolean}>
    onEvent: (callback: (state: import('../../../electron/online-updates').OnlineUpdateStatus) => void) => () => void
    status: () => Promise<UpdateStatus>
    select: () => Promise<UpdateStatus>
    install: () => Promise<{ ok: boolean }>
  }
  voice: {
    start: (id: string, lang: string, phrases?: string[]) => Promise<void>
    resetPermission: () => Promise<{ ok: boolean }>
    stop: (id: string) => Promise<void>
    cancel: (id: string) => Promise<void>
    onEvent: (callback: (event: import('../../../electron/speech').VoiceEvent) => void) => () => void
  }
  startSignIn: () => Promise<{ ok: boolean; isNewUser?: boolean; user?: unknown; error?: string }>
  cancelSignIn: () => Promise<{ ok: boolean }>
  restoreSession: () => Promise<{ ok: boolean; user?: unknown }>
  setName: (name: string) => Promise<{ ok: boolean; user?: unknown; error?: string }>
  logout: () => Promise<{ ok: boolean }>
  api: (call: {
    path: string
    method?: string
    body?: unknown
    query?: Record<string, string | number | boolean | undefined>
    form?: Array<{ name: string; value?: string; bytes?: number[]; filename?: string; type?: string }>
  }) => Promise<{
    status: number
    ok: boolean
    data: unknown
    binary?: { base64: string; mimeType: string; fileName?: string }
  }>
  chooseDirectory: () => Promise<{ ok: boolean; path?: string }>
  chooseSavePath: (options?: { defaultName?: string; filters?: Array<{ name: string; extensions: string[] }> }) => Promise<{ ok: boolean; path?: string }>
  writeExport: (payload: { path: string; data: string; encoding?: 'utf8' | 'base64' }) => Promise<{ ok: boolean; error?: string }>
  appInfo: () => Promise<{ version: string; electron: string; chrome: string; node: string }>
  platform: string
}
export interface UpdateStatus { version: string; release?: { version: string; notes: string }; ready: boolean; busy: boolean; progress: number; message: string }
export interface TabletStatus {enabled:boolean;laptopName:string;environment?:string;fingerprint?:string;addresses:string[];pending:Array<{requestId:string;deviceName:string;deviceId:string}>;devices:Array<{deviceId:string;deviceName:string}>}

declare global {
  interface Window {
    sakthi?: DesktopBridgeApi
  }
}

export function isDesktopApp(): boolean {
  return typeof window !== 'undefined' && typeof window.sakthi !== 'undefined'
}

export function desktopApi(): DesktopBridgeApi {
  if (!isDesktopApp()) throw new Error('Desktop bridge unavailable')
  return window.sakthi as DesktopBridgeApi
}

const passthroughHeaders = new Set(['content-type', 'content-disposition'])

export function parseTargetUrl(url: string): { path: string; query: Record<string, string> } | null {
  try {
    const parsed = new URL(url, 'http://sakthi.desktop')
    if (!['http://sakthi.desktop', 'app://sakthi.local', 'http://localhost:3000'].includes(`${parsed.protocol}//${parsed.host}`)) return null
    if (!parsed.pathname.startsWith('/api/')) return null
    const query: Record<string, string> = {}
    parsed.searchParams.forEach((value, key) => {
      query[key] = value
    })
    return { path: parsed.pathname.slice('/api'.length), query }
  } catch {
    return null
  }
}

let installed = false

export function installDesktopFetchBridge(): void {
  if (installed || !isDesktopApp()) return
  installed = true
  const originalFetch = window.fetch.bind(window)

  window.fetch = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    const rawUrl = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url
    const target = parseTargetUrl(rawUrl)
    if (!target) return originalFetch(input, init)

    const bridge = desktopApi()
    const method = (init?.method || (typeof input !== 'string' && !(input instanceof URL) ? input.method : 'GET') || 'GET').toUpperCase()
    init?.signal?.throwIfAborted()
    // These calls keep sessions inside main and return only the current user.
    if (['/auth/refresh', '/auth/supabase/session'].includes(target.path)) {
      const restored = await bridge.restoreSession()
      const user = restored.user as { userId: string; email: string; name: string; role: string } | undefined
      return Response.json(user ? { authenticated: true, user: { ...user, id: user.userId }, access_token: '', access_token_expires_in: 900 } : { authenticated: false }, { status: restored.ok ? 200 : 401 })
    }
    if (target.path === '/auth/logout') return Response.json(await bridge.logout())

    let body: unknown
    let form: Parameters<DesktopBridgeApi['api']>[0]['form']
    if (init?.body !== undefined && init.body !== null) {
      if (typeof init.body === 'string') {
        try {
          body = JSON.parse(init.body)
        } catch {
          body = init.body
        }
      } else if (init.body instanceof FormData) {
        form = []
        for (const [name, value] of init.body.entries()) {
          form.push(typeof value === 'string' ? { name, value } : { name, filename: value.name, type: value.type, bytes: Array.from(new Uint8Array(await value.arrayBuffer())) })
        }
      } else {
        return originalFetch(input, init)
      }
    } else if (typeof input !== 'string' && !(input instanceof URL)) {
      try {
        const cloned = input.clone()
        const text = await cloned.text()
        body = text ? JSON.parse(text) : undefined
      } catch {
        body = undefined
      }
    }

    const result = await bridge.api({ path: target.path, method, body, form, query: target.query })
    if ([204, 205, 304].includes(result.status) || method === 'HEAD') return new Response(null, { status: result.status })
    if (result.binary) {
      const bytes = Uint8Array.from(atob(result.binary.base64), (c) => c.charCodeAt(0))
      const headers: Record<string, string> = { 'content-type': result.binary.mimeType }
      if (result.binary.fileName) {
        headers['content-disposition'] = `attachment; filename="${result.binary.fileName}"`
      }
      return new Response(bytes, { status: result.status, headers })
    }
    const data = result.data
    const headers: Record<string, string> = {}
    if (data !== null && data !== undefined) {
      headers['content-type'] = 'application/json'
    }
    const serialized = data === undefined ? 'null' : JSON.stringify(data ?? null)
    return new Response(serialized, { status: result.status, headers })
  }
}
