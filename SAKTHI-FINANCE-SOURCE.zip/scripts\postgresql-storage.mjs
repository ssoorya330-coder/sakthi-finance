import fs from 'node:fs';
import dotenv from 'dotenv';
import pg from 'pg';

const inherited = new Set(Object.keys(process.env));
for (const file of ['.env', '.env.local']) {
  if (fs.existsSync(file)) for (const [key, value] of Object.entries(dotenv.parse(fs.readFileSync(file)))) {
    if (!inherited.has(key)) process.env[key] = value;
  }
}
const client = new pg.Client(process.env.DATABASE_URL ? {
  connectionString: process.env.DATABASE_URL, connectionTimeoutMillis: 5000,
} : {
  host: process.env.DB_HOST || 'localhost', port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_NAME || 'sakthi_finance', user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD, connectionTimeoutMillis: 5000,
});
const apply = process.argv.includes('--apply');
const tables = ['customers','loans','payments','daily_collection','audit_events','audit_logs','reports','users','refresh_tokens','notifications'];
const quote = (value) => '"' + value.replaceAll('"', '""') + '"';
const fingerprint = (table) => client.query(`SELECT count(*)::text AS records,
  sum(('x' || substr(md5(row_to_json(t)::text),1,15))::bit(60)::bigint)::text AS checksum
  FROM public.${quote(table)} t`);
const inspect = async () => (await client.query(`SELECT c.relname AS table_name,
  pg_total_relation_size(c.oid)::float8 AS allocated_bytes, c.reloptions AS maintenance,
  (SELECT count(*)::int FROM pg_attribute a WHERE a.attrelid=c.oid AND a.attnum>0
    AND NOT a.attisdropped AND a.attcompression='p') AS pglz_columns
  FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
  WHERE n.nspname='public' AND c.relkind='r' AND c.relname=ANY($1) ORDER BY c.relname`, [tables])).rows;

try {
  await client.connect();
  await client.query("SET lock_timeout = '3s'");
  await client.query("SET statement_timeout = '60s'");
  const before = await inspect();
  const report = { mode: apply ? 'apply' : 'inspect', before };
  if (apply) {
    if ((await client.query('SHOW autovacuum')).rows[0].autovacuum !== 'on') {
      throw new Error('Global autovacuum must be enabled first');
    }
    await client.query('BEGIN');
    try {
      // Exercise the server's actual compressor and exact decoding, not a mock.
      await client.query('CREATE TEMP TABLE sf_native_compression_test (body text COMPRESSION pglz, data jsonb COMPRESSION pglz) ON COMMIT DROP');
      await client.query(`INSERT INTO sf_native_compression_test VALUES
        (repeat('சக்தி finance 99999999999999.99 ', 2000),
         jsonb_build_object('amount','99999999999999.99','notes',repeat('Verified history ',2000)))`);
      const native = (await client.query(`SELECT
        body = repeat('சக்தி finance 99999999999999.99 ',2000)
          AND data = jsonb_build_object('amount','99999999999999.99','notes',repeat('Verified history ',2000)) AS exact,
        pg_column_compression(body) AS text_codec,
        pg_column_compression(data) AS json_codec
        FROM sf_native_compression_test`)).rows[0];
      if (!native.exact || native.text_codec !== 'pglz' || native.json_codec !== 'pglz') throw new Error('Native compression round trip failed');
      report.nativeCompressionVerified = true;
      const fingerprints = new Map();
      for (const table of before.map((r) => r.table_name)) {
        await client.query(`LOCK TABLE public.${quote(table)} IN SHARE MODE`);
        fingerprints.set(table, JSON.stringify((await fingerprint(table)).rows));
      }
      await client.query(fs.readFileSync(new URL('../migrations/004_postgresql_storage_policy.sql', import.meta.url), 'utf8'));
      for (const [table, original] of fingerprints) {
        if (JSON.stringify((await fingerprint(table)).rows) !== original) throw new Error('Data verification failed');
      }
      await client.query('COMMIT');
      report.dataVerified = true;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    }
    report.vacuumed = [];
    // Ordinary VACUUM only: reuse obsolete row versions without rewriting
    // live data. Disabling truncation avoids its optional exclusive tail lock.
    for (const table of before.map((r) => r.table_name)) {
      await client.query(`VACUUM (ANALYZE, TRUNCATE FALSE) public.${quote(table)}`);
      report.vacuumed.push(table);
    }
    report.after = await inspect();
  }
  console.log(JSON.stringify(report, null, 2));
} catch (error) {
  console.error(`PostgreSQL maintenance stopped. Code: ${error.code || 'verification_or_configuration_failure'}. Completed metadata transactions may remain; no business records were deleted.`);
  process.exitCode = 1;
} finally {
  await client.end();
}
