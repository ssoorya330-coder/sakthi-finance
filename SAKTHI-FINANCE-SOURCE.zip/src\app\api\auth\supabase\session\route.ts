import { NextResponse } from 'next/server';
import { getFullUserFromToken } from '@/config/supabase-auth';
import { dbQuery } from '@/server/database';

export const dynamic = 'force-dynamic';

/**
 * Returns the current app user resolved from either the Supabase Auth session
 * or the app JWT. Used by the frontend to hydrate the auth store after a
 * Supabase Google login (callback lands here via redirect, then dashboard).
 */
export async function GET() {
  try {
    const user = await getFullUserFromToken(true);
    if (!user) {
      return NextResponse.json({ authenticated: false }, { status: 401 });
    }
    if (!user.isActive) {
      return NextResponse.json({ authenticated: false, code: 'account_inactive' }, { status: 403 });
    }
    const schema = await dbQuery("SELECT data_type FROM information_schema.columns WHERE table_schema='public' AND table_name='customers' AND column_name='id'");
    return NextResponse.json({
      authenticated: true,
      customerIdFormat: schema.rows[0]?.data_type,
      user: {
        id: user.userId,
        email: user.email,
        name: user.name,
        role: user.role,
      },
    }, { headers: { 'Cache-Control': 'no-store' } });
  } catch {
    return NextResponse.json({ error: 'Session temporarily unavailable' }, { status: 503 });
  }
}
