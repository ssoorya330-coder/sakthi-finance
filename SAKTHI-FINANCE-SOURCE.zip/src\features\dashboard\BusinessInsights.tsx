'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'
import {
  Trophy,
  TrendingDown,
  MapPin,
  Clock,
  Star,
  Percent,
} from 'lucide-react'
import { useCustomerStore } from '@/store/customer-store'
import { computeBusinessInsights } from './dashboard-data'

export default function BusinessInsights() {
  const customers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const insightsData = useMemo(() => computeBusinessInsights(customers, paymentHistory), [customers, paymentHistory])

  const insights = [
    { id: 'highest-day', label: 'Highest Collection Day', value: insightsData.highestDay.value, sub: insightsData.highestDay.sub, icon: Trophy, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { id: 'lowest-day', label: 'Lowest Collection Day', value: insightsData.lowestDay.value, sub: insightsData.lowestDay.sub, icon: TrendingDown, color: 'text-rose-600', bg: 'bg-rose-50' },
    { id: 'active-area', label: 'Most Active Area', value: insightsData.activeArea.value, sub: insightsData.activeArea.sub, icon: MapPin, color: 'text-blue-600', bg: 'bg-blue-50' },
    { id: 'avg-daily', label: 'Average Daily Collection', value: insightsData.avgDaily.value, sub: insightsData.avgDaily.sub, icon: Clock, color: 'text-violet-600', bg: 'bg-violet-50' },
    { id: 'best-month', label: 'Best Month', value: insightsData.bestMonth.value, sub: insightsData.bestMonth.sub, icon: Star, color: 'text-amber-600', bg: 'bg-amber-50' },
    { id: 'success-rate', label: 'Collection Success Rate', value: insightsData.successRate.value, sub: insightsData.successRate.sub, icon: Percent, color: 'text-teal-600', bg: 'bg-teal-50' },
  ]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.8 }}
      className="relative bg-white/70 backdrop-blur-xl rounded-[20px] border border-white/20 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] p-6 overflow-hidden"
    >
      <div className="absolute inset-0 sf-pattern-dots opacity-40 pointer-events-none" />
      <div className="flex items-center gap-3 mb-6 relative">
        <div className="w-10 h-10 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
          <Star className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-base font-semibold text-slate-900">Business Insights</h3>
          <p className="text-xs text-slate-500">Key metrics and performance indicators</p>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 relative">
        {insights.map((item, i) => {
          const Icon = item.icon as React.ComponentType<{ className?: string }>
          const gradColors: Record<string, string> = {
            'text-emerald-600': 'from-[var(--primary)] to-[var(--primary-hover)]',
            'text-rose-600': 'from-[var(--primary-hover)] to-[var(--primary)]',
            'text-blue-600': 'from-[var(--primary)] to-[var(--primary-hover)]',
            'text-violet-600': 'from-[var(--primary)] to-[var(--primary-hover)]',
            'text-amber-600': 'from-[var(--secondary)] to-[#B8943A]',
            'text-teal-600': 'from-[var(--primary)] to-[var(--primary-hover)]',
          }
          const grad = gradColors[item.color] || 'from-blue-400 to-blue-600'
          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.9 + i * 0.05 }}
              whileHover={{ y: -2, backgroundColor: 'rgba(255,255,255,0.6)' }}
              className="flex items-start gap-3 p-4 rounded-[12px] bg-white/50 backdrop-blur-sm border border-white/30 hover:border-white/50 hover:shadow-md transition-all duration-200"
            >
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${grad} flex items-center justify-center shadow-md flex-shrink-0`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-900 mb-0.5">{item.value}</p>
                <p className="text-xs font-medium text-slate-600">{item.label}</p>
                <p className="text-xs text-slate-400 mt-0.5">{item.sub}</p>
              </div>
            </motion.div>
          )
        })}
      </div>
    </motion.div>
  )
}
