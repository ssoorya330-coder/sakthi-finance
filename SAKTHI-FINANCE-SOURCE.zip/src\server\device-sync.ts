import { createHash } from 'node:crypto'
import { dbQuery, ensureSchema } from './database'
import type { PoolClient } from 'pg'

export function digest(value: unknown): string {
  const stable = (v: any): any => Array.isArray(v) ? v.map(stable) : v && typeof v === 'object'
    ? Object.fromEntries(Object.keys(v).sort().map(k => [k, stable(v[k])])) : v
  return createHash('sha256').update(JSON.stringify(stable(value))).digest('hex')
}

export async function ensureDeviceSyncSchema() {
  await ensureSchema()
  await dbQuery(`CREATE TABLE IF NOT EXISTS device_sync_receipts (
    owner_id TEXT NOT NULL, operation_id UUID NOT NULL, device_id UUID NOT NULL,
    fingerprint TEXT NOT NULL, response JSONB NOT NULL, recorded_at TIMESTAMPTZ NOT NULL,
    committed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), PRIMARY KEY (owner_id, operation_id)
  )`)
}

/** Conservative whole-customer revision, including payments and loan status.
 * A change to any related financial record requires explicit conflict review. */
export async function customerRevision(tx: Pick<PoolClient, 'query'>, owner: string, id: string) {
  const r = await tx.query(`SELECT jsonb_build_object(
    'customer', to_jsonb(c),
    'loans', COALESCE((SELECT jsonb_agg(to_jsonb(l) ORDER BY l.loan_id) FROM loans l WHERE l.customer_id=c.id AND l.user_id=c.user_id),'[]'::jsonb),
    'payments', COALESCE((SELECT jsonb_agg(to_jsonb(p) ORDER BY p.payment_id) FROM payments p WHERE p.customer_id=c.id AND p.user_id=c.user_id),'[]'::jsonb)
  ) AS record FROM customers c WHERE c.id::text=$1 AND c.user_id=$2`, [id, owner])
  return r.rows[0] ? { revision: digest(r.rows[0].record), record: r.rows[0].record } : null
}

/** Same revision representation as conflict checks, without 10,000 round trips. */
export async function customerRevisions(tx: Pick<PoolClient, 'query'>, owner: string) {
  const result=await tx.query(`WITH grouped_loans AS (
    SELECT customer_id,jsonb_agg(to_jsonb(l) ORDER BY loan_id) AS records FROM loans l WHERE user_id=$1 GROUP BY customer_id
  ), grouped_payments AS (
    SELECT customer_id,jsonb_agg(to_jsonb(p) ORDER BY payment_id) AS records FROM payments p WHERE user_id=$1 GROUP BY customer_id
  ) SELECT c.id::text AS id,jsonb_build_object('customer',to_jsonb(c),'loans',COALESCE(l.records,'[]'::jsonb),'payments',COALESCE(p.records,'[]'::jsonb)) AS record
  FROM customers c LEFT JOIN grouped_loans l ON l.customer_id=c.id LEFT JOIN grouped_payments p ON p.customer_id=c.id WHERE c.user_id=$1`,[owner])
  return Object.fromEntries(result.rows.map(row=>[row.id,digest(row.record)])) as Record<string,string>
}
