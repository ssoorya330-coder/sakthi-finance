import { app } from 'electron'
import { appendFileSync, statSync, renameSync } from 'node:fs'
import path from 'node:path'
type Event = 'startup' | 'ready' | 'setup_failure' | 'database_failure' | 'ipc_failure' | 'ipc_denied' | 'auth_failure' | 'renderer_failure' | 'unexpected_failure' | 'shutdown'
export function logEvent(event: Event) {
  try {
    const file = path.join(app.getPath('userData'), 'desktop-events.log')
    try { if (statSync(file).size > 1048576) renameSync(file, file + '.previous') } catch {}
    appendFileSync(file, `${new Date().toISOString()} ${event}\n`)
  } catch { /* logging must not expose private values or crash the app */ }
}
