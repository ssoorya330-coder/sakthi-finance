'use client'

import { useMemo, useEffect, useRef, useState, useCallback } from 'react'
import { createPortal } from 'react-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Z_INDEX } from '@/lib/z-index'

const WEEKDAYS = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su']

interface CalendarGridProps {
  viewDate: Date
  selectedDate?: Date | null
  startDate?: Date | null
  endDate?: Date | null
  onDayClick?: (day: number) => void
  compact?: boolean
  showAdjacent?: boolean
}

function getDayCellClass(
  day: number,
  month: number,
  year: number,
  isCurrentMonth: boolean,
  selectedDate: Date | null | undefined,
  startDate: Date | null | undefined,
  endDate: Date | null | undefined,
  compact: boolean,
  today: Date,
): string {
  const cellSize = compact ? 'w-6 h-6' : 'w-full h-9'
  const textSize = compact ? 'text-[10px]' : 'text-xs'
  const base = `${cellSize} ${textSize} rounded-xl transition-all duration-150 flex items-center justify-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9F3939] focus-visible:ring-offset-2 active:scale-95`

  if (!isCurrentMonth) return `${base} text-[#D9D0BE]`

  const date = new Date(year, month, day)
  const isSelectedDate =
    selectedDate != null &&
    date.getDate() === selectedDate.getDate() &&
    date.getMonth() === selectedDate.getMonth() &&
    date.getFullYear() === selectedDate.getFullYear()

  const isRangeStart =
    startDate != null &&
    date.getTime() === startDate.getTime()

  const isRangeEnd =
    endDate != null &&
    date.getTime() === endDate.getTime()

  const inRange =
    startDate != null &&
    endDate != null &&
    date >= startDate &&
    date <= endDate

  const isTodayDate =
    today.getDate() === day &&
    today.getMonth() === month &&
    today.getFullYear() === year

  if (isSelectedDate || isRangeStart || isRangeEnd) {
    return `${base} bg-gradient-to-br from-[#A33B45] to-[var(--primary)] text-white font-bold shadow-[0_4px_10px_rgba(127,29,29,0.25)]`
  }

  if (inRange) {
    return `${base} bg-[#F5F0E6] text-[#1E1B14]`
  }

  if (isTodayDate) {
    return `${base} bg-amber-50 text-[#854D0E] font-semibold border border-amber-400`
  }

  return `${base} text-[#34252C] font-medium hover:bg-rose-100 hover:text-[var(--primary)]`
}

export default function CalendarGrid({
  viewDate,
  selectedDate,
  startDate,
  endDate,
  onDayClick,
  compact = false,
  showAdjacent = false,
}: CalendarGridProps) {
  const year = viewDate.getFullYear()
  const month = viewDate.getMonth()
  const today = useMemo(() => new Date(), [])

  const cells = useMemo(() => {
    const daysInMonth = new Date(year, month + 1, 0).getDate()
    const firstDayOfWeek = new Date(year, month, 1).getDay()
    const adjustedFirstDay = firstDayOfWeek === 0 ? 6 : firstDayOfWeek - 1
    const daysInPrevMonth = new Date(year, month, 0).getDate()
    const totalCells = Math.ceil((adjustedFirstDay + daysInMonth) / 7) * 7

    const result: { day: number; isCurrentMonth: boolean; key: string }[] = []

    if (showAdjacent) {
      for (let i = adjustedFirstDay - 1; i >= 0; i--) {
        result.push({ day: daysInPrevMonth - i, isCurrentMonth: false, key: `pm-${i}` })
      }
    } else {
      for (let i = 0; i < adjustedFirstDay; i++) {
        result.push({ day: 0, isCurrentMonth: false, key: `e-${i}` })
      }
    }

    for (let i = 1; i <= daysInMonth; i++) {
      result.push({ day: i, isCurrentMonth: true, key: `d-${i}` })
    }

    if (showAdjacent) {
      const remaining = totalCells - result.length
      for (let i = 1; i <= remaining; i++) {
        result.push({ day: i, isCurrentMonth: false, key: `nm-${i}` })
      }
    } else {
      while (result.length < totalCells) {
        result.push({ day: 0, isCurrentMonth: false, key: `e-${result.length}` })
      }
    }

    return result
  }, [year, month, showAdjacent])

  const gap = compact ? 'gap-0.5' : 'gap-1'

  const handleDaysKeyDown = (e: React.KeyboardEvent) => {
    const key = e.key
    if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(key)) return
    const target = e.target as HTMLElement
    const dayAttr = target.dataset.day
    if (!dayAttr) return
    e.preventDefault()
    let next = Number(dayAttr)
    if (key === 'ArrowLeft') next -= 1
    else if (key === 'ArrowRight') next += 1
    else if (key === 'ArrowUp') next -= 7
    else if (key === 'ArrowDown') next += 7
    const daysInMonth = new Date(year, month + 1, 0).getDate()
    if (next < 1 || next > daysInMonth) return
    const container = target.closest('[data-calendar-days]')
    const nextBtn = container?.querySelector<HTMLButtonElement>(`[data-day="${next}"]`)
    nextBtn?.focus({ preventScroll: true })
  }

  return (
    <>
      <div className={`grid grid-cols-7 ${gap} mb-1`}>
        {WEEKDAYS.map((d) => (
          <div key={d} className="text-center text-[10px] uppercase tracking-wider font-bold text-[#80656A] py-2">
            {d}
          </div>
        ))}
      </div>
      <div className={`grid grid-cols-7 ${gap}`} data-calendar-days onKeyDown={handleDaysKeyDown}>
        {cells.map((cell) => {
          if (!cell.day && !cell.isCurrentMonth) {
            return (
              <div
                key={cell.key}
                className={compact ? 'w-6 h-6' : 'w-9 h-9'}
              />
            )
          }

          const cls = getDayCellClass(
            cell.day,
            month,
            year,
            cell.isCurrentMonth,
            selectedDate,
            startDate,
            endDate,
            compact,
            today,
          )

          if (!cell.isCurrentMonth) {
            return (
              <div key={cell.key} className={cls}>
                {cell.day}
              </div>
            )
          }

          return (
            <button
              type="button"
              key={cell.key}
              aria-label={new Date(year, month, cell.day).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
              aria-pressed={selectedDate?.getFullYear() === year && selectedDate?.getMonth() === month && selectedDate?.getDate() === cell.day}
              data-day={cell.day}
              onClick={() => onDayClick?.(cell.day)}
              className={cls}
            >
              {cell.day}
            </button>
          )
        })}
      </div>
    </>
  )
}

/* ─── Reusable date picker popover wrapper ─── */

interface DatePickerDropdownProps {
  isOpen: boolean
  onClose: () => void
  children: React.ReactNode
  width?: number
  anchorRef?: React.RefObject<HTMLElement | null>
}

export function DatePickerDropdown({
  isOpen,
  onClose,
  children,
  width = 360,
  anchorRef,
}: DatePickerDropdownProps) {
  const dropdownRef = useRef<HTMLDivElement>(null)
  const onCloseRef = useRef(onClose)
  onCloseRef.current = onClose

  const [position, setPosition] = useState<{
    top: number
    left: number
    placement: 'bottom' | 'top'
  } | null>(null)

  const updatePosition = useCallback(() => {
    const anchor = anchorRef?.current
    if (!anchor) return
    const rect = anchor.getBoundingClientRect()
    const gap = 6
    const popupHeight = dropdownRef.current?.offsetHeight || 340
    const placeBelow = rect.bottom + gap + popupHeight <= window.innerHeight
    const top = placeBelow
      ? rect.bottom + gap
      : Math.max(8, rect.top - gap - popupHeight)
    const left = Math.min(Math.max(8, rect.left), Math.max(8, window.innerWidth - width - 8))
    setPosition({ top, left, placement: placeBelow ? 'bottom' : 'top' })
  }, [anchorRef, width])

  useEffect(() => {
    if (!isOpen) return
    updatePosition()
    let ticking = false
    const handleScrollOrResize = () => {
      if (ticking) return
      ticking = true
      requestAnimationFrame(() => {
        updatePosition()
        ticking = false
      })
    }
    window.addEventListener('resize', handleScrollOrResize)
    document.addEventListener('scroll', handleScrollOrResize, { passive: true, capture: true })
    return () => {
      window.removeEventListener('resize', handleScrollOrResize)
      document.removeEventListener('scroll', handleScrollOrResize, { capture: true })
    }
  }, [isOpen, updatePosition])

  // Reposition after mounting and when a month needs more calendar rows.
  useEffect(() => {
    if (!isOpen || !position || !dropdownRef.current) return
    const observer = new ResizeObserver(updatePosition)
    observer.observe(dropdownRef.current)
    return () => observer.disconnect()
  }, [isOpen, Boolean(position), updatePosition])

  useEffect(() => {
    if (!isOpen) return
    const handlePointerDown = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Node
      if (dropdownRef.current?.contains(target)) return
      if (anchorRef?.current?.contains(target)) return
      onCloseRef.current()
    }
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        onCloseRef.current()
      }
    }
    document.addEventListener('mousedown', handlePointerDown)
    document.addEventListener('touchstart', handlePointerDown)
    document.addEventListener('keydown', handleKeyDown)
    return () => {
      document.removeEventListener('mousedown', handlePointerDown)
      document.removeEventListener('touchstart', handlePointerDown)
      document.removeEventListener('keydown', handleKeyDown)
    }
  }, [isOpen, anchorRef])

  useEffect(() => {
    if (isOpen) {
      dropdownRef.current?.focus({ preventScroll: true })
    } else {
      anchorRef?.current?.focus({ preventScroll: true })
    }
  }, [isOpen, anchorRef])

  return typeof document === 'undefined' ? null : createPortal(
    <AnimatePresence>
      {isOpen && position && (
        <motion.div
          ref={dropdownRef}
          key="datepicker-dropdown"
          role="dialog"
          aria-label="Date picker"
          tabIndex={-1}
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.96, transition: { duration: 0.14 } }}
          transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
          className="border border-white rounded-[24px] p-4 shadow-[0_20px_60px_rgba(82,30,41,0.22),0_0_0_1px_rgba(127,29,29,0.08)] outline-none"
          style={{
            background: 'radial-gradient(ellipse at top right, rgba(244,193,119,.32), transparent 60%), radial-gradient(ellipse at bottom left, rgba(244,177,193,.24), transparent 65%), #FFFCF8',
            position: 'fixed',
            top: position.top,
            left: position.left,
            width,
            maxWidth: 'calc(100vw - 16px)',
            maxHeight: 'calc(100dvh - 16px)',
            overflowY: 'auto',
            zIndex: Z_INDEX.calendar,
            transformOrigin: position.placement === 'bottom' ? 'top left' : 'bottom left',
          }}
        >
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden rounded-[24px]">
            <div className="absolute inset-0 opacity-[0.18]" style={{ backgroundImage: 'radial-gradient(#B88763 0.7px, transparent 0.7px)', backgroundSize: '12px 12px' }} />
            <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full border border-[#C79543]/20" />
            <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full border border-[#C79543]/20" />
            <div className="absolute -bottom-12 -left-12 h-32 w-32 rotate-12 rounded-[32px] border border-[#AC6679]/15 bg-rose-100/20" />
            <div className="absolute bottom-9 right-5 h-3 w-3 rotate-45 border border-[#C79543]/25" />
            <svg className="absolute inset-0 h-full w-full" viewBox="0 0 320 400" preserveAspectRatio="none" fill="none">
              <defs>
                <pattern id="calendar-edge-weave" width="16" height="16" patternUnits="userSpaceOnUse">
                  <path d="M0 8 8 0 16 8 8 16Z" stroke="#C79543" strokeOpacity="0.13" strokeWidth="0.7" />
                </pattern>
              </defs>
              <path d="M0 0H320V12H0ZM0 388H320V400H0Z" fill="url(#calendar-edge-weave)" />
              <g stroke="#A9657A" strokeOpacity="0.22" strokeWidth="1.2">
                <path d="M4 124C28 92 10 56 40 28M9 102Q34 92 24 72M13 78Q-1 61 13 47M23 52Q46 51 40 28" />
                <path d="M316 280C290 312 314 351 276 382M308 304Q288 308 294 329M307 331Q324 346 308 359M295 361Q273 356 276 382" />
              </g>
              <g fill="#C79543" fillOpacity="0.3">
                <path d="m278 16 2 6 6 2-6 2-2 6-2-6-6-2 6-2Z" />
                <path d="m39 353 2 5 5 2-5 2-2 5-2-5-5-2 5-2Z" />
                <circle cx="299" cy="46" r="2" />
                <circle cx="20" cy="335" r="1.5" />
              </g>
              <path d="M68 394Q160 370 252 394M86 398Q160 380 234 398" stroke="#C79543" strokeOpacity="0.22" />
            </svg>
          </div>
          <div className="relative z-10">{children}</div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  )
}

/* ─── Calendar Navigation Buttons ─── */

interface CalendarNavProps {
  viewDate: Date
  onPrev: () => void
  onNext: () => void
  format?: 'long' | 'short'
}

export function CalendarNav({ viewDate, onPrev, onNext, format = 'long' }: CalendarNavProps) {
  const label = viewDate.toLocaleDateString('en-IN', {
    month: format === 'long' ? 'long' : 'short',
    year: 'numeric',
  })

  return (
    <div className="flex items-center justify-between mb-3 rounded-2xl bg-white/80 border border-white px-2 py-3 shadow-sm">
      <button
        type="button"
        aria-label="Previous month"
        onClick={onPrev}
        className="w-8 h-8 rounded-xl flex items-center justify-center bg-rose-50 hover:bg-rose-100 transition-colors focus-visible:ring-2 focus-visible:ring-[var(--primary)]"
      >
        <ChevronLeft className="w-3.5 h-3.5 text-[#6B6250]" />
      </button>
      <p className="text-[15px] font-semibold text-[#1E1B14] text-center">{label}</p>
      <button
        type="button"
        aria-label="Next month"
        onClick={onNext}
        className="w-8 h-8 rounded-xl flex items-center justify-center bg-rose-50 hover:bg-rose-100 transition-colors focus-visible:ring-2 focus-visible:ring-[var(--primary)]"
      >
        <ChevronRight className="w-3.5 h-3.5 text-[#6B6250]" />
      </button>
    </div>
  )
}

/* ─── Calendar Footer ─── */

interface CalendarFooterProps {
  onToday: () => void
  onClear?: () => void
}

export function CalendarFooter({ onToday, onClear }: CalendarFooterProps) {
  return (
    <div className="border-t-[0.5px] border-[#EFE9DC] mt-3 pt-3 flex items-center justify-between">
      {onClear ? (
        <button
          type="button"
          onClick={onClear}
          className="rounded-xl px-3 py-2 text-xs font-semibold text-[#73545C] hover:bg-white transition-colors focus-visible:ring-2 focus-visible:ring-[var(--primary)]"
        >
          Clear
        </button>
      ) : (
        <div />
      )}
      <button
        type="button"
        onClick={onToday}
        className="rounded-xl bg-[var(--primary)] px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-[#9B303A] transition-colors focus-visible:ring-2 focus-visible:ring-[var(--primary)] focus-visible:ring-offset-2"
      >
        Today
      </button>
    </div>
  )
}
