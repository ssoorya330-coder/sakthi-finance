import Link from 'next/link'
import { notFound } from 'next/navigation'
import AppLoading from '@/components/ui/app-loading'

export default function LoadingPreview() {
  if (process.env.NODE_ENV !== 'development') notFound()
  return <>
    <AppLoading fullScreen />
    <Link href="/dashboard" className="fixed bottom-6 left-1/2 -translate-x-1/2 rounded-xl border border-[#7F1D1D]/20 bg-white px-5 py-3 text-sm font-semibold text-[#7F1D1D]">Close preview · Back to dashboard</Link>
  </>
}
