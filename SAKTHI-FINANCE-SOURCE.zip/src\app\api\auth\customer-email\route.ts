import { NextResponse } from 'next/server'

/** Retired authentication endpoint. Finance customer records are unchanged. */
export async function POST() {
  return NextResponse.json({ error: 'Customer portal login has been retired.', code: 'login_retired' }, { status: 410 })
}
