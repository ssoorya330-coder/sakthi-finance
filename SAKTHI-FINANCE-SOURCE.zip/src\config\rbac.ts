export type Role = 'owner' | 'admin' | 'manager' | 'employee' | 'viewer' | 'collector' | 'customer';

export type Permission =
  | 'dashboard:read'
  | 'customers:read'
  | 'customers:create'
  | 'customers:update'
  | 'customers:delete'
  | 'customers:read_all'
  | 'loans:read'
  | 'loans:create'
  | 'loans:update'
  | 'loans:delete'
  | 'payments:read'
  | 'payments:create'
  | 'payments:update'
  | 'payments:delete'
  | 'collections:read'
  | 'collections:create'
  | 'reports:read'
  | 'reports:export'
  | 'users:manage'
  | 'audit:read'
  | 'settings:manage'
  | 'security:manage';

/** Canonical roles for user management UI. `manager`/`collector` are legacy. */
export const ACTIVE_ROLES: Array<'owner' | 'admin' | 'employee' | 'viewer'> = [
  'owner',
  'admin',
  'employee',
  'viewer',
];

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  owner: [
    'dashboard:read',
    'customers:read', 'customers:create', 'customers:update', 'customers:delete', 'customers:read_all',
    'loans:read', 'loans:create', 'loans:update', 'loans:delete',
    'payments:read', 'payments:create', 'payments:update', 'payments:delete',
    'collections:read', 'collections:create',
    'reports:read', 'reports:export',
    'users:manage', 'audit:read', 'settings:manage', 'security:manage',
  ],
  admin: [
    'dashboard:read',
    'customers:read', 'customers:create', 'customers:update', 'customers:delete', 'customers:read_all',
    'loans:read', 'loans:create', 'loans:update', 'loans:delete',
    'payments:read', 'payments:create', 'payments:update', 'payments:delete',
    'collections:read', 'collections:create',
    'reports:read', 'reports:export',
    'users:manage', 'audit:read', 'settings:manage',
  ],
  manager: [
    'dashboard:read',
    'customers:read', 'customers:create', 'customers:update', 'customers:read_all',
    'loans:read', 'loans:create', 'loans:update',
    'payments:read', 'payments:create',
    'collections:read', 'collections:create',
    'reports:read',
  ],
  employee: [
    'dashboard:read',
    // Employees manage their OWN records only — every customer/loan/payment
    // route additionally enforces user_id = session user, so one account can
    // never touch another account's rows.
    'customers:read', 'customers:create', 'customers:update', 'customers:delete',
    'loans:read', 'loans:create', 'loans:update',
    'payments:create', 'payments:read',
    'collections:read', 'collections:create',
    'reports:read',
  ],
  viewer: ['dashboard:read', 'customers:read', 'loans:read', 'payments:read', 'collections:read', 'reports:read'],
  // Self-service customer: read-only access to their own records only.
  // Never granted users:manage, audit:read, or settings:manage, so Admin
  // Access and all admin APIs remain denied.
  customer: ['dashboard:read', 'customers:read', 'loans:read', 'payments:read', 'collections:read', 'reports:read'],
  // Legacy alias: `collector` rows are migrated to `employee` in the DB.
  // Kept here so old JWTs / old rows still resolve safely until migrated.
  collector: [
    'dashboard:read',
    'customers:read', 'customers:create', 'customers:update', 'customers:delete',
    'payments:create', 'payments:read',
    'collections:read', 'collections:create',
  ],
};

/** Normalize any stored role string to a known Role. Legacy `collector` → `employee`. */
export function normalizeRole(raw: string | null | undefined): Role {
  if (raw === 'owner') return 'owner';
  if (raw === 'admin') return 'admin';
  if (raw === 'manager') return 'manager';
  if (raw === 'employee') return 'employee';
  if (raw === 'viewer') return 'viewer';
  if (raw === 'customer') return 'customer';
  // Legacy value, migrated in DB to `employee`.
  return 'employee';
}

export function hasPermission(role: Role | null | undefined, permission: Permission): boolean {
  if (!role) return false;
  return ROLE_PERMISSIONS[normalizeRole(role)]?.includes(permission) ?? false;
}

export function canReadAllRecords(role: Role | null | undefined): boolean {
  return hasPermission(role, 'customers:read_all');
}

export function isOwner(role: Role | null | undefined): boolean {
  return normalizeRole(role ?? null) === 'owner';
}

export function isAdmin(role: Role | null | undefined): boolean {
  const r = normalizeRole(role ?? null);
  return r === 'admin' || r === 'owner';
}

export function isManager(role: Role | null | undefined): boolean {
  return normalizeRole(role ?? null) === 'manager';
}

export function isCollector(role: Role | null | undefined): boolean {
  const r = normalizeRole(role ?? null);
  return r === 'employee' || (role === 'collector');
}

export function isEmployee(role: Role | null | undefined): boolean {
  const r = normalizeRole(role ?? null);
  return r === 'employee';
}

export function isViewer(role: Role | null | undefined): boolean {
  return normalizeRole(role ?? null) === 'viewer';
}

export function isCustomer(role: Role | null | undefined): boolean {
  return normalizeRole(role ?? null) === 'customer';
}

/**
 * Whether `actorRole` may assign `targetRole` to another user.
 * - owner: may assign any role (including owner).
 * - admin: may assign admin/employee/viewer/customer (and legacy manager),
 *   but NEVER owner, and never modify an owner account (enforced in the API
 *   route). An admin can never grant themselves Owner privileges.
 * - everyone else: may not manage users at all.
 */
export function canAssignRole(
  actorRole: Role | null | undefined,
  targetRole: string | null | undefined
): boolean {
  const actor = normalizeRole(actorRole ?? null);
  if (actor === 'owner') return true;
  if (actor === 'admin') {
    return targetRole === 'admin' || targetRole === 'employee' || targetRole === 'viewer' || targetRole === 'manager' || targetRole === 'customer';
  }
  return false;
}
