'use client';

import { useRef, useState, type KeyboardEvent, ClipboardEvent } from 'react';
import { cn } from '@/lib/utils';

interface OTPInputProps {
  length?: number;
  value: string;
  onChange: (value: string) => void;
  error?: string;
}

export default function OTPInput({
  length = 4,
  value,
  onChange,
  error,
}: OTPInputProps) {
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const [focusedIndex, setFocusedIndex] = useState<number | null>(null);

  const chars = value.split('');

  const handleChange = (index: number, char: string) => {
    if (!/^\d*$/.test(char)) return;

    const newValue =
      value.substring(0, index) + char + value.substring(index + 1);
    onChange(newValue);

    if (char && index < length - 1) {
      inputRefs.current[index + 1]?.focus({ preventScroll: true });
    }
  };

  const handleKeyDown = (index: number, e: KeyboardEvent) => {
    if (e.key === 'Backspace') {
      if (!chars[index] && index > 0) {
        const newValue = value.substring(0, index - 1) + value.substring(index);
        onChange(newValue);
        inputRefs.current[index - 1]?.focus({ preventScroll: true });
      } else {
        const newValue = value.substring(0, index) + value.substring(index + 1);
        onChange(newValue);
      }
      e.preventDefault();
    }
  };

  const handlePaste = (e: ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, length);
    onChange(pasted);
    inputRefs.current[Math.min(pasted.length, length - 1)]?.focus({ preventScroll: true });
  };

  return (
    <div className="space-y-2">
      <div className="flex gap-3 justify-center">
        {Array.from({ length }).map((_, i) => (
          <input
            key={i}
            ref={(el) => {
              inputRefs.current[i] = el;
            }}
            type="text"
            inputMode="numeric"
            maxLength={1}
            value={chars[i] || ''}
            onChange={(e) => handleChange(i, e.target.value)}
            onKeyDown={(e) => handleKeyDown(i, e)}
            onPaste={handlePaste}
            onFocus={() => setFocusedIndex(i)}
            onBlur={() => setFocusedIndex(null)}
            className={cn(
              'w-[56px] h-[66px] rounded-[14px] text-center text-[22px] font-semibold',
              'bg-bg-elevated/60 border outline-none transition-all duration-300',
              'text-text-primary placeholder:text-text-muted',
              chars[i]
                ? 'border-gold-500/40 shadow-[0_0_0_3px_rgba(201,168,76,0.06)]'
                : focusedIndex === i
                  ? 'border-gold-500/30 shadow-[0_0_0_3px_rgba(201,168,76,0.05)]'
                  : 'border-border-default hover:border-border-strong',
            )}
          />
        ))}
      </div>
      <div className="h-5 overflow-hidden">
        {error && (
          <p className="text-[12px] text-error text-center mt-1">
            {error}
          </p>
        )}
      </div>
    </div>
  );
}
