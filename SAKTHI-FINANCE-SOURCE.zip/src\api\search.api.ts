import { apiGet } from './client';
import type { ApiResponse } from '@/types/api.types';
import type { SearchResponse } from './types';

function unwrap<T>(res: ApiResponse<T>): T {
  if (!res.success || res.data === undefined) {
    throw new Error(res.message || 'Request failed');
  }
  return res.data;
}

export const searchApi = {
  async search(query: string, type?: string): Promise<SearchResponse> {
    const params: Record<string, string> = { q: query };
    if (type) params.type = type;
    const res = await apiGet<ApiResponse<SearchResponse>>('/api/search', {
      params,
    });
    return unwrap(res);
  },
};
