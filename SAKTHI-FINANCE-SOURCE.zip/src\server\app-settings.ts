import { dbQuery } from './database';

export const SESSION_TIMEOUT_KEY = 'security.session_timeout_minutes';
export const MAX_SESSIONS_KEY = 'security.max_sessions_per_user';

export const DEFAULT_SESSION_TIMEOUT_MINUTES = 15;
export const DEFAULT_MAX_SESSIONS = 10;

export async function getAppSetting(key: string, fallback: string): Promise<string> {
  try {
    const result = await dbQuery<{ value: string | null }>(
      'SELECT value FROM settings WHERE key = $1 LIMIT 1',
      [key]
    );
    const v = result.rows[0]?.value;
    return v === null || v === undefined || v === '' ? fallback : v;
  } catch {
    return fallback;
  }
}

export async function setAppSetting(key: string, value: string): Promise<string> {
  await dbQuery(
    `INSERT INTO settings (key, value, category, updated_at)
     VALUES ($1, $2, 'security', NOW())
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, category = 'security', updated_at = NOW()`,
    [key, value]
  );
  return value;
}

export async function getSessionTimeoutMinutes(): Promise<number> {
  const raw = await getAppSetting(SESSION_TIMEOUT_KEY, String(DEFAULT_SESSION_TIMEOUT_MINUTES));
  const n = Math.floor(Number(raw));
  if (!Number.isFinite(n) || n < 5 || n > 480) return DEFAULT_SESSION_TIMEOUT_MINUTES;
  return n;
}

export async function getMaxSessionsPerUser(): Promise<number> {
  const raw = await getAppSetting(MAX_SESSIONS_KEY, String(DEFAULT_MAX_SESSIONS));
  const n = Math.floor(Number(raw));
  if (!Number.isFinite(n) || n < 1 || n > 50) return DEFAULT_MAX_SESSIONS;
  return n;
}
