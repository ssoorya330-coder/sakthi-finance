'use client'

import { downloadExcel } from '@/lib/download-excel'
import VoiceMicButton from '@/components/ui/voice-mic-button'
import { formatCustomerCode } from '@/utils/customer-id'

import { useState, useMemo, useCallback, Suspense } from 'react'
import { motion } from 'framer-motion'
import {
  UserX,
  Search,
  IndianRupee,
  AlertTriangle,
  TrendingDown,
  Eye,
  FileText,
  FileSpreadsheet,
  Printer,
  Filter,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react'
import { useCustomerStore } from '@/store/customer-store'
import { useSidebarStore } from '@/store/sidebar-store'
import { formatCurrency, formatDateDMY } from '@/features/dashboard/dashboard.styles'
import PaymentHistoryDrawer from '@/components/dashboard/PaymentHistoryDrawer'
import Link from 'next/link'
import type { Customer } from '@/types/customer.types'
import { useAuthStore } from '@/store/auth-store'
import { hasPermission } from '@/config/rbac'
import { clearCache } from '@/services/api-client'
import { useToastStore } from '@/store/toast-store'
import { useQueryClient } from '@tanstack/react-query'

const ITEMS_PER_PAGE = 15

function ExportButton({ icon: Icon, label, onClick }: { icon: React.FC<{ className?: string }>; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[var(--primary)]/30 bg-white text-sm font-medium text-[var(--primary)] hover:bg-[var(--primary-soft)] hover:border-[var(--primary)]/40 transition-colors active:scale-[0.97]"
    >
      <Icon className="w-4 h-4" />
      {label}
    </button>
  )
}

function AbortedContent() {
  const role=useAuthStore(s=>s.role)
  const addToast=useToastStore(s=>s.addToast)
  const queryClient=useQueryClient()
  const [unaborting,setUnaborting]=useState<string|null>(null)
  async function unabort(customer:Customer) {
    if(unaborting)return
    if(!window.confirm(`Unabort ${customer.fullName} (${customer.customerCode})? Existing payments and balances will stay unchanged.`))return
    setUnaborting(customer.id)
    try {
      const userId=useAuthStore.getState().userId
      if(userId && localStorage.getItem(`sf-device-mode:${userId}`)==='on')throw new Error('Sync pending work and return to online mode before unaborting.')
      const response=await fetch(`/api/customer/${encodeURIComponent(customer.id)}/unabort`,{method:'POST'})
      const result=await response.json()
      if(!response.ok)throw new Error(result.error || 'Unable to unabort customer.')
      clearCache()
      await useCustomerStore.getState().refresh()
      await queryClient.invalidateQueries()
      addToast(result.status==='Completed'?'Customer un-aborted. Fully paid records are in Completed Customers.':'Customer un-aborted and returned to Customer Details.')
    } catch(error){addToast(error instanceof Error?error.message:'Unable to unabort customer.','error')}
    finally{setUnaborting(null)}
  }
  const customers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const getDisplayId = useCustomerStore((s) => s.getDisplayId)
  const { toggleSidebar } = useSidebarStore()
  const [search, setSearch] = useState('')
  const [areaFilter, setAreaFilter] = useState('All')
  const [currentPage, setCurrentPage] = useState(1)
  const [viewingCustomer, setViewingCustomer] = useState<Customer | null>(null)

  const aborted = useMemo(() =>
    customers.filter((c) => c.status === 'Aborted'),
  [customers])

  const areas = useMemo(() => {
    const unique = [...new Set(aborted.map((c) => c.area).filter(Boolean))]
    return ['All', ...unique.sort()]
  }, [aborted])

  const filtered = useMemo(() => {
    let result = aborted.filter((c) => {
      const q = search.toLowerCase()
      return (
        c.fullName.toLowerCase().includes(q) ||
        c.mobileNumber.includes(q) ||
        c.id.includes(q) ||
        (c.area && c.area.toLowerCase().includes(q))
      )
    })
    if (areaFilter !== 'All') {
      result = result.filter((c) => c.area === areaFilter)
    }
    return result
  }, [aborted, search, areaFilter])

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE)
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE
    return filtered.slice(start, start + ITEMS_PER_PAGE)
  }, [filtered, currentPage])

  const stats = useMemo(() => {
    const totalAborted = aborted.length
    const amountCollected = aborted.reduce((sum, c) => {
      const payments = paymentHistory.filter((p) => p.customerId === c.id)
      return sum + payments.reduce((s, p) => s + p.paymentAmount, c.offlinePaidAmount||0)
    }, 0)
    const outstandingBalance = aborted.reduce((sum, c) => {
      const paid = paymentHistory
        .filter((p) => p.customerId === c.id)
        .reduce((s, p) => s + p.paymentAmount, c.offlinePaidAmount||0)
      return sum + Math.max(0, (c.totalAmount || 0) - paid)
    }, 0)
    const totalDue = outstandingBalance + amountCollected
    const recoveryPct = totalDue > 0 ? Math.min(100, (amountCollected / totalDue) * 100) : 0
    return { totalAborted, amountCollected, outstandingBalance, recoveryPct }
  }, [aborted, paymentHistory])

  const getCollectedAmount = useCallback((customerId: string) => {
    return paymentHistory
      .filter((p) => p.customerId === customerId)
      .reduce((sum, p) => sum + p.paymentAmount, 0)
  }, [paymentHistory])

  const getRemainingBalance = useCallback((c: Customer) => {
    const paid = paymentHistory
      .filter((p) => p.customerId === c.id)
      .reduce((sum, p) => sum + p.paymentAmount, 0)
    return Math.max(0, (c.totalAmount || 0) - paid)
  }, [paymentHistory])

  const handleExportCSV = useCallback(() => {
    const headers = ['Customer Code', 'Customer Name', 'Mobile', 'Area', 'Loan Amount', 'Amount Collected', 'Remaining Balance', 'Loan Date', 'Abort Date', 'Abort Reason']
    const rows = filtered.map((c) => [
      c.id, c.fullName, c.mobileNumber, c.area || '',
      Number(c.loanAmount) || 0, getCollectedAmount(c.id), getRemainingBalance(c),
      formatDateDMY(c.loanDate || ''), c.abortedAt ? formatDateDMY(c.abortedAt) : '', c.abortReason || '',
    ])
    const csv = [headers.join(','), ...rows.map((r) => r.map((v) => `"${v}"`).join(','))].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'aborted-customers.csv'; a.click()
    URL.revokeObjectURL(url)
  }, [filtered, getCollectedAmount, getRemainingBalance])

  const handleExportExcel = useCallback(() => {
    const headers = ['Customer Code', 'Customer Name', 'Mobile', 'Area', 'Loan Amount', 'Amount Collected', 'Remaining Balance', 'Loan Date', 'Abort Date', 'Abort Reason']
    const rows = filtered.map((c) => [
      formatCustomerCode(c.customerCode), c.fullName, c.mobileNumber, c.area || '',
      Number(c.loanAmount) || 0, getCollectedAmount(c.id), getRemainingBalance(c),
      formatDateDMY(c.loanDate || ''), c.abortedAt ? formatDateDMY(c.abortedAt) : '', c.abortReason || '',
    ])
    void downloadExcel('aborted-customers.xlsx', 'Sakthi Finance - Aborted Customers', headers, rows)
  }, [filtered, getCollectedAmount, getRemainingBalance])

  const handlePrint = useCallback(() => { window.print() }, [])

  return (
    <div className="h-screen bg-[var(--background)] flex flex-col overflow-hidden">
      {/* Header */}
      <div className="bg-white border-b border-[rgba(212,175,55,0.15)] px-8 py-4 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={toggleSidebar}
              className="w-10 h-10 rounded-xl border border-transparent flex items-center justify-center hover:bg-[var(--primary-soft)] hover:border-[var(--primary)]/20 transition-colors flex-shrink-0 active:scale-95"
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round">
                <path d="M3 5h14" /><path d="M3 10h14" /><path d="M3 15h14" />
              </svg>
            </button>
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[var(--primary-hover)] to-[var(--primary)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
                <UserX className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Aborted Customers</h1>
                <p className="text-sm text-slate-500 mt-0.5">{filtered.length} customer{filtered.length !== 1 ? 's' : ''}</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <ExportButton icon={FileText} label="CSV" onClick={handleExportCSV} />
            <ExportButton icon={FileSpreadsheet} label="Excel" onClick={handleExportExcel} />
            <ExportButton icon={Printer} label="Print" onClick={handlePrint} />
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="px-8 pt-5 pb-3 flex-shrink-0">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: 'Aborted Customers', value: stats.totalAborted, icon: UserX, color: 'from-[var(--primary-hover)] to-[var(--primary)]' },
            { label: 'Outstanding Balance', value: formatCurrency(stats.outstandingBalance), icon: AlertTriangle, color: 'from-[var(--primary-hover)] to-[var(--primary)]' },
            { label: 'Amount Collected', value: formatCurrency(stats.amountCollected), icon: IndianRupee, color: 'from-[var(--secondary)] to-[#B8943A]' },
            { label: 'Recovery Rate', value: `${stats.recoveryPct.toFixed(1)}%`, icon: TrendingDown, color: 'from-[var(--primary)] to-[var(--primary-hover)]' },
          ].map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.06 }}
              className="bg-white rounded-[18px] border border-[rgba(212,175,55,0.2)] p-4 shadow-[0_1px_2px_rgba(0,0,0,0.04)]"
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}>
                  <stat.icon className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">{stat.label}</p>
                  <p className="text-xl font-bold text-slate-900">{stat.value}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Search & Filters */}
      <div className="px-8 pb-3 flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by name, phone, ID, or area..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setCurrentPage(1) }}
              className="w-full h-12 pl-12 pr-4 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 placeholder:text-slate-400 outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/10 transition-all"
            />
          </div>
          <VoiceMicButton inputType="search" value={search} onPreview={text=>{setSearch(text);setCurrentPage(1)}} onResult={text=>{setSearch(text.replace(/\./g,'').trim());setCurrentPage(1)}} />
          <div className="relative">
            <Filter className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
            <select
              value={areaFilter}
              onChange={(e) => { setAreaFilter(e.target.value); setCurrentPage(1) }}
              className="h-12 pl-10 pr-10 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/10 transition-all appearance-none cursor-pointer min-w-[160px]"
            >
              {areas.map((a) => (
                <option key={a} value={a}>{a === 'All' ? 'All Areas' : a}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 px-8 pb-6 min-h-0">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-white rounded-[24px] border border-[rgba(212,175,55,0.25)] shadow-[0_1px_3px_rgba(0,0,0,0.04),0_4px_12px_rgba(0,0,0,0.03)] overflow-hidden h-full flex flex-col"
        >
          {filtered.length === 0 ? (
            <div className="px-6 py-16 text-center flex-1 flex flex-col items-center justify-center">
              <div className="w-16 h-16 rounded-2xl bg-red-50 flex items-center justify-center mx-auto mb-4">
                <UserX className="w-8 h-8 text-red-400" />
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-1">No aborted customers</h3>
              <p className="text-sm text-slate-500">
                {aborted.length === 0
                  ? 'No customers have been aborted yet.'
                  : 'Try adjusting your search or filter criteria.'}
              </p>
            </div>
          ) : (
            <div className="overflow-auto flex-1" style={{ maxHeight: 'calc(100vh - 320px)' }}>
              <table className="w-[1400px]">
                <thead className="sticky top-0 z-30">
                  <tr className="border-b border-[var(--secondary)]/30 bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)]">
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)]">Customer Code</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)]">Customer Name</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Mobile</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Area</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Loan Amount</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Amount Collected</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Remaining Balance</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Loan Date</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Abort Date</th>
                    <th className="text-left text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap">Abort Reason</th>
                    <th className="text-center text-xs font-semibold text-[var(--secondary)] uppercase tracking-wider px-4 py-3 whitespace-nowrap bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)]">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {paginated.map((c, index) => {
                    const collected = getCollectedAmount(c.id)
                    const remaining = getRemainingBalance(c)
                    const rowBg = index % 2 === 0 ? 'bg-white' : 'bg-[#FCFBF4]'
                    return (
                      <tr key={c.id} className={`border-b border-[rgba(212,175,55,0.12)] last:border-0 hover:bg-[rgba(212,175,55,0.08)] transition-colors ${rowBg}`}>
                        <td className={`px-4 py-3 text-sm font-semibold text-slate-900 ${rowBg}`}>{getDisplayId(c)}</td>
                        <td className={`px-4 py-3 ${rowBg}`}>
                          <Link href={`/dashboard/customers/${c.id}`} className="flex items-center gap-2.5 group">
                            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[var(--primary-hover)] to-[var(--primary)] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                              {c.fullName.charAt(0)}
                            </div>
                            <span className="text-sm font-medium text-slate-900 group-hover:text-[var(--primary)] transition-colors">{c.fullName}</span>
                          </Link>
                        </td>
                        <td className="px-4 py-3 text-sm text-slate-600">{c.mobileNumber}</td>
                        <td className="px-4 py-3 text-sm text-slate-600">{c.area || '—'}</td>
                        <td className="px-4 py-3 text-sm font-medium text-slate-900">{formatCurrency(Number(c.loanAmount) || 0)}</td>
                        <td className="px-4 py-3 text-sm font-semibold text-[var(--primary)]">{formatCurrency(collected)}</td>
                        <td className="px-4 py-3 text-sm font-semibold text-red-700">{formatCurrency(remaining)}</td>
                        <td className="px-4 py-3 text-sm text-slate-500">{formatDateDMY(c.loanDate || '')}</td>
                        <td className="px-4 py-3 text-sm text-slate-500">
                          {c.abortedAt ? formatDateDMY(c.abortedAt) : '—'}
                        </td>
                        <td className="px-4 py-3 text-sm text-slate-500 max-w-[150px] truncate" title={c.abortReason || ''}>
                          {c.abortReason || '—'}
                        </td>
                        <td className={`px-4 py-3 ${rowBg}`}>
                          <div className="flex items-center gap-1.5 justify-center">
                            {hasPermission(role,'customers:update') && hasPermission(role,'loans:update') && <button disabled={unaborting!==null} onClick={()=>void unabort(c)} className="rounded-lg border border-[var(--primary)]/20 px-3 py-2 text-xs font-semibold text-[var(--primary)] hover:bg-rose-50 disabled:opacity-40">{unaborting===c.id?'Restoring…':'Unabort'}</button>}
                            <button
                              onClick={() => setViewingCustomer(c)}
                              className="w-8 h-8 rounded-lg border border-transparent flex items-center justify-center hover:bg-[var(--primary-soft)] hover:border-[var(--primary)]/20 transition-colors"
                              title="Payment History"
                            >
                              <Eye className="w-4 h-4 text-[var(--primary)]" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="px-6 py-3 border-t border-[rgba(212,175,55,0.15)] flex items-center justify-between">
              <p className="text-xs text-slate-500">Page {currentPage} of {totalPages}</p>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="w-8 h-8 rounded-lg border border-[var(--primary)]/20 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="w-4 h-4 text-[var(--primary)]" />
                </button>
                {Array.from({ length: totalPages }, (_, i) => i + 1)
                  .filter((p) => p === 1 || p === totalPages || Math.abs(p - currentPage) <= 1)
                  .reduce<(number | string)[]>((acc, p, i, arr) => {
                    if (i > 0 && p - (arr[i - 1] as number) > 1) acc.push('...')
                    acc.push(p)
                    return acc
                  }, [])
                  .map((p, i) =>
                    typeof p === 'string' ? (
                      <span key={`ell-${i}`} className="w-8 h-8 flex items-center justify-center text-xs text-slate-400">...</span>
                    ) : (
                      <button
                        key={p}
                        onClick={() => setCurrentPage(p)}
                                        className={`w-8 h-8 rounded-lg text-xs font-medium transition-colors ${p === currentPage ? 'bg-[var(--primary)] text-white shadow-sm' : 'border border-[var(--primary)]/20 text-[var(--primary)] hover:bg-[var(--primary-soft)]'}`}
                      >
                        {p}
                      </button>
                    ),
                  )}
                <button
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="w-8 h-8 rounded-lg border border-[var(--primary)]/20 flex items-center justify-center hover:bg-[var(--primary-soft)] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <ChevronRight className="w-4 h-4 text-[var(--primary)]" />
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>

      {/* Payment History Drawer */}
      <PaymentHistoryDrawer
        customer={viewingCustomer}
        isOpen={!!viewingCustomer}
        onClose={() => setViewingCustomer(null)}
      />
    </div>
  )
}

export default function AbortedCustomersPage() {
  return (
    <Suspense fallback={null}>
      <AbortedContent />
    </Suspense>
  )
}
