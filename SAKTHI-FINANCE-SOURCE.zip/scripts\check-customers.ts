import { dbQuery } from '../src/server/database';

(async () => {
  try {
    const r = await dbQuery('SELECT id, full_name, phone_number, loan_amount, status FROM customers');
    console.log('Customers in DB:', JSON.stringify(r.rows, null, 2));
  } catch (e: any) {
    console.log('FAILED:', e.message);
  }
  process.exit();
})();
