import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { requireAuth } from '@/lib/api-utils';
import { dbQuery } from '@/server/database';
import { normalizePhone } from '@/lib/phone';
import { normalizeSql } from '@/server/phone-normalize-sql';
import { rateLimit, rateLimitKey } from '@/lib/rate-limit';
import { recordAuditStandalone, requestMeta } from '@/server/audit';

export const dynamic = 'force-dynamic';

const bodySchema = z.object({
  phone: z.string().min(1, 'Mobile number is required'),
});

/**
 * Link the authenticated Google user's account to their customer record.
 *
 * Preconditions: caller is already authenticated AND has the customer role.
 * The mobile number only identifies WHICH customer/person to link — it never
 * creates a session on its own. The link (users.customer_id) is stored
 * server-side; the customer id is never trusted from the client.
 *
 * Person grouping: one person may own several kanaku rows sharing the same
 * number. Rows with the same normalized name form one person and are all
 * served together — never rejected as "multiple accounts". Rows with
 * genuinely different names sharing one number are ambiguous and are NOT
 * merged; the caller is asked to contact support instead.
 *
 * A person-group already linked to a different user is never silently
 * re-linked (prevents account takeover by number knowledge).
 */
export async function POST(request: NextRequest) {
  const auth = await requireAuth();
  if (auth.error) return auth.error;
  if (auth.user.role !== 'customer') {
    return NextResponse.json(
      { error: 'Only customer accounts link a mobile number here.' },
      { status: 403 }
    );
  }

  try {
    if (!rateLimit(rateLimitKey(request, 'cust-link-ip'), 20, 3_600_000)) {
      return NextResponse.json(
        { error: 'Too many requests. Please try again later.' },
        { status: 429 }
      );
    }
    const body = await request.json().catch(() => ({}));
    const parsed = bodySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: 'Enter your registered mobile number.' }, { status: 400 });
    }
    const phone = normalizePhone(parsed.data.phone);
    if (!phone) {
      return NextResponse.json({ error: 'Enter a valid 10-digit mobile number.' }, { status: 400 });
    }

    const meta = requestMeta(request);
    // Match the cached canonical column AND live-normalize both stored
    // phone fields, so a stale or never-backfilled cache can never cause a
    // false "not found" for a genuinely existing number.
    const matched = await dbQuery<{ id: string; customer_code: string; full_name: string; created_at: string }>(
      `SELECT id, customer_code, full_name, created_at FROM customers
       WHERE phone_normalized = $1
          OR ${normalizeSql('phone_number')} = $1
          OR ${normalizeSql('alternate_phone')} = $1
       ORDER BY created_at ASC`,
      [phone]
    );
    if (matched.rows.length === 0) {
      return NextResponse.json(
        { error: 'No customer account was found for this mobile number.' },
        { status: 404 }
      );
    }
    // Person grouping: same normalized name => same person, even across
    // several kanaku rows. Different names sharing one number is genuinely
    // ambiguous — never merge those silently.
    const nameOf = (n: any) => String(n || '').trim().toLowerCase().replace(/\s+/g, ' ');
    const distinctNames = [...new Set(matched.rows.map((r) => nameOf(r.full_name)).filter(Boolean))];
    if (distinctNames.length > 1) {
      return NextResponse.json(
        { error: 'This number matches multiple different customers. Please contact support.' },
        { status: 409 }
      );
    }
    const group = matched.rows;
    // Primary pointer: earliest-created row. Only a pointer — every grouped
    // row's data is served together, nothing is hidden or picked over.
    const customer = group[0];

    // Self-heal the canonical cache when it was stale or missing.
    await dbQuery(
      `UPDATE customers SET phone_normalized = $1
       WHERE id = ANY($2) AND COALESCE(phone_normalized, '') <> $1`,
      [phone, group.map((r) => r.id)]
    ).catch(() => {});

    // Any group row linked to someone else? Never steal the link.
    const existing = await dbQuery<{ user_id: string }>(
      `SELECT user_id FROM users WHERE customer_id = ANY($1) LIMIT 1`,
      [group.map((r) => r.id)]
    );
    const holder = existing.rows[0]?.user_id || null;
    if (holder && holder !== auth.user.userId) {
      try {
        await recordAuditStandalone({
          action: 'UNAUTHORIZED_ACCESS',
          entityType: 'customer',
          entityId: customer.id,
          actor: { userId: auth.user.userId, name: auth.user.name, role: 'customer' },
          ipAddress: meta.ip,
          clientInfo: meta.client,
          reason: 'link attempt on already-linked customer',
          result: 'FAILED',
        });
      } catch {}
      return NextResponse.json(
        { error: 'This customer account is already linked. Please contact support.' },
        { status: 409 }
      );
    }

    if (holder !== auth.user.userId) {
      await dbQuery(`UPDATE users SET customer_id = $1, updated_at = NOW() WHERE user_id = $2`, [
        customer.id,
        auth.user.userId,
      ]);
      try {
        await recordAuditStandalone({
          action: 'CUSTOMER_LINKED',
          entityType: 'customer',
          entityId: customer.id,
          actor: { userId: auth.user.userId, name: auth.user.name, role: 'customer' },
          ipAddress: meta.ip,
          clientInfo: meta.client,
          result: 'SUCCESS',
          changes: [
            { field: 'customer', label: 'Customer', before: null, after: customer.customer_code },
            { field: 'accounts', label: 'Linked Accounts', before: null, after: group.length },
          ],
        });
      } catch {}
    }

    return NextResponse.json({
      ok: true,
      customerCode: customer.customer_code,
      name: customer.full_name,
      accounts: group.length,
    });
  } catch (err: any) {
    console.error('[Customer link] Error:', err?.message || err);
    return NextResponse.json({ error: 'Something went wrong. Please try again.' }, { status: 500 });
  }
}
