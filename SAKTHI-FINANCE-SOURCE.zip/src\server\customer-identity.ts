import { dbQuery } from './database'

/** Resolve old bookmarks/drafts while operational data uses numeric IDs. */
export async function resolveCustomerId(raw: unknown): Promise<string> {
  const id = typeof raw === 'string' || typeof raw === 'number' ? String(raw) : ''
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) return id
  const result = await dbQuery('SELECT customer_id::text AS id FROM customer_id_mappings WHERE legacy_id = $1', [id])
  return result.rows[0]?.id || id
}
