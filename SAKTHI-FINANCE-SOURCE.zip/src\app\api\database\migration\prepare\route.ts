import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import {
  validateStoragePath,
  getDataDirectory,
  getDataDirSizeBytes,
  getDiskUsageForPath,
} from '@/server/storage'

/**
 * STEP 3 — Prepare destination: exists/writable/local/not-the-data-dir,
 * plus enough free space for the full data directory (+10% margin).
 * No side effects.
 */
export async function POST(request: NextRequest) {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error

  try {
    const body = await request.json()
    const check = await validateStoragePath(body.destination || '')
    if (!check.ok) return NextResponse.json({ ok: false, error: check.error }, { status: 200 })

    const dest = (check.normalizedPath as string).toLowerCase()
    const dataDir = await getDataDirectory()
    if (dataDir) {
      const dd = dataDir.replace(/\//g, '\\').toLowerCase().replace(/\\$/, '')
      const dn = dest.replace(/\\$/, '')
      if (dn === dd || dn.startsWith(dd + '\\')) {
        return NextResponse.json(
          { ok: false, error: 'Destination must not be the current data directory or inside it.' },
          { status: 200 }
        )
      }
    }

    // Destination must be empty (or non-existent — it will be created by the copy).
    try {
      const fs = await import('fs')
      const entries = fs.readdirSync(check.normalizedPath as string)
      if (entries.length > 0) {
        return NextResponse.json(
          { ok: false, error: 'Destination folder must be empty. Choose an empty folder.' },
          { status: 200 }
        )
      }
    } catch (e: any) {
      if (e?.code !== 'ENOENT') {
        return NextResponse.json({ ok: false, error: 'Destination cannot be read.' }, { status: 200 })
      }
    }

    const [srcSize, usage] = await Promise.all([
      getDataDirSizeBytes(),
      (async () => getDiskUsageForPath(check.normalizedPath as string))(),
    ])
    const required = srcSize !== null ? Math.ceil(srcSize * 1.1) : null
    if (required !== null && usage && usage.freeBytes < required) {
      return NextResponse.json(
        {
          ok: false,
          error: `Not enough free space. Need ${required.toLocaleString()} bytes, only ${usage.freeBytes.toLocaleString()} bytes free.`,
        },
        { status: 200 }
      )
    }

    return NextResponse.json({
      ok: true,
      normalizedPath: check.normalizedPath,
      drive: check.drive,
      freeBytes: usage?.freeBytes ?? check.freeBytes ?? null,
      requiredBytes: required,
      sourceBytes: srcSize,
    })
  } catch (err: any) {
    return NextResponse.json(
      { ok: false, error: 'Validation failed', details: err.message },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json({ error: 'Use POST with { destination }.' }, { status: 405 });
}
