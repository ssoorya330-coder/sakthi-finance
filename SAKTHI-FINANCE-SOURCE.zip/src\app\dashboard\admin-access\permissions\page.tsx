'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import PermissionsContent from '@/features/admin-access/PermissionsContent'

export default function PermissionsContentPage() {
  return (
    <ClientPageGate requireRole="owner">
      <PermissionsContent />
    </ClientPageGate>
  )
}
