'use client'

import { Activity, ShieldAlert, Users, XCircle } from 'lucide-react'
import { cn } from '@/lib/utils'
import AdminSectionShell, { AdminError, AdminLoading } from './AdminSectionShell'
import { useAdminApi } from './useAdminApi'

interface SecurityOverview {
  totalUsers: number
  activeUsers: number
  activeSessions: number
  failedLogins: number
  securityEvents: Array<{
    created_at?: string | null
    action?: string | null
    performed_by?: string | null
    user_role?: string | null
    result?: string | null
  }>
}

const fmtDT = (iso: string | null | undefined) => {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: true,
    })
  } catch {
    return '—'
  }
}

export default function SecurityContent() {
  const { data, state, retrying, retry } = useAdminApi<SecurityOverview>('/api/admin/security/overview', (j) => ({
    totalUsers: Number(j?.totalUsers) || 0,
    activeUsers: Number(j?.activeUsers) || 0,
    activeSessions: Number(j?.activeSessions) || 0,
    failedLogins: Number(j?.failedLogins) || 0,
    securityEvents: Array.isArray(j?.securityEvents) ? j.securityEvents : [],
  }))

  const cards = data
    ? [
        { label: 'Total Users', value: data.totalUsers.toLocaleString('en-IN'), icon: Users },
        { label: 'Active Sessions', value: data.activeSessions.toLocaleString('en-IN'), icon: Activity },
        { label: 'Failed Login Attempts', value: data.failedLogins.toLocaleString('en-IN'), icon: XCircle },
        { label: 'Security Events', value: data.securityEvents.length.toLocaleString('en-IN'), icon: ShieldAlert },
      ]
    : []

  return (
    <AdminSectionShell title="Security Overview" subtitle="Users, sessions, and recent security events" icon="system">
      {state === 'loading' && <AdminLoading />}
      {state === 'unauthorized' && (
        <AdminError message="You are not authorized to access this page." onRetry={retry} retrying={retrying} />
      )}
      {state === 'failed' && (
        <AdminError message="Unable to connect to the database. Please try again." onRetry={retry} retrying={retrying} />
      )}
      {state === 'ready' && data && (
        <>
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
            {cards.map((c) => (
              <div key={c.label} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
                <c.icon className="w-5 h-5 text-[var(--primary)]" />
                <p className="text-xl font-extrabold text-slate-900 tabular-nums mt-2">{c.value}</p>
                <p className="text-[11px] font-semibold text-slate-500 mt-0.5">{c.label}</p>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-bold text-slate-900">Recent Security Events</p>
            </div>
            {data.securityEvents.length === 0 ? (
              <p className="px-4 py-8 text-center text-sm text-slate-500">No security events recorded yet.</p>
            ) : (
              <div className="divide-y divide-slate-100">
                {data.securityEvents.map((e, i) => (
                  <div key={i} className="px-4 py-3 flex flex-wrap items-center gap-x-4 gap-y-1">
                    <span className="text-[13px] font-bold text-slate-900">{(e.action || '—').replace(/_/g, ' ')}</span>
                    <span className="text-xs text-slate-500 tabular-nums">{fmtDT(e.created_at)}</span>
                    <span className="text-xs text-slate-500">
                      By <b>{e.performed_by || '—'}</b>
                      {e.user_role ? ` (${e.user_role})` : ''}
                    </span>
                    <span className="ml-auto">
                      <span className={cn(
                        'inline-flex items-center px-2 py-0.5 rounded-lg text-[11px] font-bold border whitespace-nowrap',
                        e.result === 'FAILED'
                          ? 'bg-red-50 text-red-700 border-red-200'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      )}>
                        {e.result || '—'}
                      </span>
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </AdminSectionShell>
  )
}
