import { NextRequest, NextResponse } from 'next/server';
import { requireOwner } from '@/lib/api-utils';
import { normalizeRole } from '@/config/rbac';
import { dbQuery } from '@/server/database';
import {
  revokeRefreshTokenById,
  revokeAllRefreshTokensForUser,
  revokeAllSessionsExcept,
} from '@/lib/auth/tokens';
import { actorFromAuthUser, requestMeta, recordAuditStandalone } from '@/server/audit';
import { rateLimit, rateLimitKey } from '@/lib/rate-limit';

export const dynamic = 'force-dynamic';

async function targetRoleOf(userId: string): Promise<string | null> {
  const r = await dbQuery(
    `SELECT r.role_name, u.role FROM users u LEFT JOIN roles r ON u.role_id = r.role_id WHERE u.user_id = $1 LIMIT 1`,
    [userId]
  );
  if (r.rows.length === 0) return null;
  return normalizeRole(r.rows[0].role_name || r.rows[0].role);
}

/**
 * List recent sessions (refresh-token records with device/IP metadata).
 * Owner/Admin only. Never returns token hashes.
 */
export async function GET(request: NextRequest) {
  const auth = await requireOwner();
  if (auth.error) return auth.error;

  try {
    const sp = new URL(request.url).searchParams;
    const userId = (sp.get('userId') || '').trim();
    const params: any[] = [];
    let where = `revoked_at IS NULL AND expires_at > NOW()`;
    if (userId) {
      where += ` AND rt.user_id = $1`;
      params.push(userId);
    }
    const rows = await dbQuery(
      `SELECT rt.id, rt.user_id, u.email, u.full_name,
              COALESCE(r.role_name, u.role) AS role,
              rt.created_at, rt.last_used_at, rt.expires_at,
              rt.user_agent, rt.ip_address
       FROM refresh_tokens rt
       LEFT JOIN users u ON u.user_id = rt.user_id
       LEFT JOIN roles r ON u.role_id = r.role_id
       WHERE ${where}
       ORDER BY COALESCE(rt.last_used_at, rt.created_at) DESC
       LIMIT 100`,
      params
    );
    return NextResponse.json({ sessions: Array.isArray(rows.rows) ? rows.rows : [] });
  } catch (err: any) {
    console.error('[GET /api/admin/devices] Error:', err?.message || err);
    return NextResponse.json(
      { error: 'Unable to load sessions. Please try again.' },
      { status: 500 }
    );
  }
}

interface RevokeBody {
  /** Revoke one session by row id (requires userId for ownership binding). */
  tokenId?: string;
  userId?: string;
  /** Revoke every other active session for the user except `exceptTokenId`. */
  allOthers?: boolean;
  exceptTokenId?: string;
}

/**
 * Force-logout sessions server-side by revoking refresh-token rows.
 * The affected devices fail their next silent refresh (401) and must sign
 * in again; their access tokens additionally expire within the configured
 * session timeout. Every revocation is audited.
 */
export async function POST(request: NextRequest) {
  const auth = await requireOwner();
  if (auth.error) return auth.error;

  if (!rateLimit(rateLimitKey(request, 'admin-devices-revoke'), 30, 60_000)) {
    return NextResponse.json({ error: 'Too many requests. Please slow down.' }, { status: 429 })
  }

  try {
    const body = (await request.json().catch(() => ({}))) as RevokeBody;
    const meta = requestMeta(request);
    const actor = actorFromAuthUser(auth.user);
    const actorRole = normalizeRole(auth.user.role);

    const forbidOwnerTarget = async (targetUserId: string): Promise<NextResponse | null> => {
      const tRole = await targetRoleOf(targetUserId);
      if (tRole === 'owner' && actorRole !== 'owner') {
        try {
          await recordAuditStandalone({
            action: 'UNAUTHORIZED_ACCESS',
            entityType: 'session',
            entityId: targetUserId,
            actor,
            ipAddress: meta.ip,
            clientInfo: meta.client,
            reason: 'Attempt to revoke an Owner session',
            result: 'FAILED',
          });
        } catch {}
        return NextResponse.json(
          { error: 'Only the Owner can manage Owner sessions' },
          { status: 403 }
        );
      }
      return null;
    };

    // ── Single device logout ─────────────────────────────────────
    if (body.tokenId && body.userId) {
      const denied = await forbidOwnerTarget(body.userId);
      if (denied) return denied;
      const revoked = await revokeRefreshTokenById(body.tokenId, body.userId);
      if (!revoked) {
        return NextResponse.json({ error: 'Session not found or already ended' }, { status: 404 });
      }
      await recordAuditStandalone({
        action: 'DEVICE_LOGOUT',
        entityType: 'session',
        entityId: String(body.tokenId).slice(0, 8),
        actor,
        ipAddress: meta.ip,
        clientInfo: meta.client,
        result: 'SUCCESS',
        changes: [{ field: 'user', label: 'User', before: null, after: body.userId }],
      }).catch(() => {});
      return NextResponse.json({ ok: true, revoked: 1 });
    }

    // ── Logout all other devices ─────────────────────────────────
    if (body.userId && body.allOthers) {
      const denied = await forbidOwnerTarget(body.userId);
      if (denied) return denied;
      let revoked: number;
      if (body.exceptTokenId) {
        revoked = await revokeAllSessionsExcept(body.userId, body.exceptTokenId);
      } else {
        // No current-session reference supplied: keep the single most
        // recently active session so the admin's own device is not
        // needlessly signed out, revoke everything older.
        const keep = await dbQuery(
          `SELECT id FROM refresh_tokens
           WHERE user_id = $1 AND revoked_at IS NULL AND expires_at > NOW()
           ORDER BY COALESCE(last_used_at, created_at) DESC LIMIT 1`,
          [body.userId]
        );
        const keepId: string | null = keep.rows[0]?.id || null;
        if (!keepId) {
          return NextResponse.json({ ok: true, revoked: 0 });
        }
        revoked = await revokeAllSessionsExcept(body.userId, keepId);
      }
      await recordAuditStandalone({
        action: 'DEVICE_LOGOUT',
        entityType: 'session',
        entityId: body.userId,
        actor,
        ipAddress: meta.ip,
        clientInfo: meta.client,
        reason: 'Logout all other devices',
        result: 'SUCCESS',
        changes: [{ field: 'revoked', label: 'Sessions Revoked', before: null, after: revoked }],
      }).catch(() => {});
      return NextResponse.json({ ok: true, revoked });
    }

    return NextResponse.json(
      { error: 'Provide tokenId+userId for one device, or userId+allOthers for the rest.' },
      { status: 400 }
    );
  } catch (err: any) {
    console.error('[POST /api/admin/devices] Error:', err?.message || err);
    return NextResponse.json({ error: 'Failed to revoke session' }, { status: 500 });
  }
}

/** Force-logout every session of a user (used by Account Management). */
export async function DELETE(request: NextRequest) {
  const auth = await requireOwner();
  if (auth.error) return auth.error;

  if (!rateLimit(rateLimitKey(request, 'admin-devices-revoke'), 30, 60_000)) {
    return NextResponse.json({ error: 'Too many requests. Please slow down.' }, { status: 429 })
  }

  try {
    const userId = new URL(request.url).searchParams.get('userId') || '';
    if (!userId) {
      return NextResponse.json({ error: 'userId is required' }, { status: 400 });
    }
    const actorRole = normalizeRole(auth.user.role);
    const tRole = await targetRoleOf(userId);
    if (tRole === 'owner' && actorRole !== 'owner') {
      return NextResponse.json(
        { error: 'Only the Owner can manage Owner sessions' },
        { status: 403 }
      );
    }
    await revokeAllRefreshTokensForUser(userId);
    const meta = requestMeta(request);
    await recordAuditStandalone({
      action: 'DEVICE_LOGOUT',
      entityType: 'session',
      entityId: userId,
      actor: actorFromAuthUser(auth.user),
      ipAddress: meta.ip,
      clientInfo: meta.client,
      reason: 'Force logout all sessions',
      result: 'SUCCESS',
    }).catch(() => {});
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    console.error('[DELETE /api/admin/devices] Error:', err?.message || err);
    return NextResponse.json({ error: 'Failed to revoke sessions' }, { status: 500 });
  }
}
