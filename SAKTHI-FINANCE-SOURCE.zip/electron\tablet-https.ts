import https from 'node:https'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { X509Certificate, createHash } from 'node:crypto'
import { PairingError, TabletPairing, type PairingScope, type TabletGrant } from './tablet-pairing'

interface TabletHostOptions {
  key: string; cert: string; pairing: TabletPairing
  // Resolve these from the current authenticated laptop session on EACH call.
  scope(): Promise<PairingScope>
  verifyGoogle(idToken: string): Promise<{subject: string}>
  // Explicit bounded protocol only, never a generic desktop API proxy.
  execute(grant: TabletGrant, action: 'summaries' | 'sync', body: unknown): Promise<unknown>
}

export class TabletHttpsHost {
  private server?: https.Server
  private requests = new Map<string,{count:number;reset:number}>()
  constructor(private options: TabletHostOptions) {}
  fingerprint() { return createHash('sha256').update(new X509Certificate(this.options.cert).raw).digest('hex') }
  async start(host = '127.0.0.1', port = 0): Promise<number> {
    if(this.server) throw Error('Tablet service already started')
    const server = https.createServer({key:this.options.key,cert:this.options.cert,minVersion:'TLSv1.2',maxHeaderSize:8192},(req,res)=>{void this.handle(req,res)})
    server.requestTimeout=15000; server.headersTimeout=10000; server.keepAliveTimeout=2000; server.maxConnections=16
    this.server=server
    try { await new Promise<void>((resolve,reject)=>{server.once('error',reject);server.listen(port,host,()=>{server.removeListener('error',reject);resolve()})}) }
    catch(error){this.server=undefined;throw error}
    const address=server.address()
    if(!address||typeof address==='string')throw Error('Tablet listener unavailable')
    return address.port
  }
  async stop() {
    const server=this.server;this.server=undefined
    if(server) { server.closeAllConnections();await new Promise<void>((resolve,reject)=>server.close(e=>e?reject(e):resolve())) }
    this.requests.clear()
  }
  private async body(req: IncomingMessage) {
    if(req.headers['content-type']?.split(';')[0].trim()!=='application/json')throw new PairingError(415,'JSON required')
    const chunks:Buffer[]=[];let size=0
    for await(const chunk of req) { size+=chunk.length;if(size>100000)throw new PairingError(413,'Request too large');chunks.push(Buffer.from(chunk)) }
    try {return JSON.parse(Buffer.concat(chunks).toString('utf8'))} catch {throw new PairingError(400,'Invalid JSON')}
  }
  private reply(res:ServerResponse,status:number,value:unknown) {
    if(res.destroyed)return
    res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})
    res.end(JSON.stringify(value))
  }
  private async handle(req:IncomingMessage,res:ServerResponse) {
    const timer=setTimeout(()=>{req.destroy();res.destroy()},15000);timer.unref()
    try {
      // This is a native-only interface; reject browser origins and preflights.
      if(req.headers.origin || req.headers['sec-fetch-site'])throw new PairingError(403,'Native device connection required')
      const now=Date.now()
      for(const[key,value]of this.requests)if(value.reset<=now)this.requests.delete(key)
      const ip=req.socket.remoteAddress||'unknown' // Never trust proxy headers.
      if(!this.requests.has(ip)&&this.requests.size>=128)throw new PairingError(429,'Too many connections')
      const bucket=this.requests.get(ip)||{count:0,reset:now+60000};this.requests.set(ip,bucket)
      if(++bucket.count>600)throw new PairingError(429,'Request rate exceeded')
      if(req.method!=='POST'||!['/tablet/pair','/tablet/status','/tablet/summaries','/tablet/sync'].includes(req.url||''))throw new PairingError(404,'Unknown tablet operation')
      const body=await this.body(req)
      if(!body||typeof body!=='object'||Array.isArray(body))throw new PairingError(400,'Object required')
      const scope=await this.options.scope()
      if(req.url==='/tablet/pair') {
        if(typeof body.googleIdToken!=='string'||body.googleIdToken.length>12000||typeof body.code!=='string'||typeof body.deviceId!=='string'||typeof body.deviceName!=='string')throw new PairingError(400,'Invalid pairing request')
        const identity=await this.options.verifyGoogle(body.googleIdToken)
        this.reply(res,202,this.options.pairing.request({code:body.code,deviceId:body.deviceId,deviceName:body.deviceName,verifiedGoogleSubject:identity.subject}));return
      }
      const header=req.headers.authorization
      if(!header?.startsWith('Bearer '))throw new PairingError(401,'Device credential required')
      const grant=await this.options.pairing.authenticate(header.slice(7),scope)
      if(req.url==='/tablet/status') {
        this.reply(res,200,{laptopId:scope.laptopId,databaseId:scope.databaseId,environment:scope.environment,ownerId:scope.ownerId,deviceId:grant.deviceId});return
      }
      this.reply(res,200,await this.options.execute(grant,req.url==='/tablet/sync'?'sync':'summaries',body))
    }catch(error){this.reply(res,error instanceof PairingError?error.status:503,{error:error instanceof PairingError?error.message:'Laptop service unavailable; retain pending records and retry'})}
    finally{clearTimeout(timer)}
  }
}
