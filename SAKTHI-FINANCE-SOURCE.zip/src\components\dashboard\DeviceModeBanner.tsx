'use client'
import { useEffect, useState } from 'react'
import { useAuthStore } from '@/store/auth-store'
import { deviceMode, synchronizeDevice } from '@/lib/device-sync/browser'
import { useSyncConnection } from '@/lib/device-sync/use-connection'
import { readWorkspace } from '@/lib/device-sync/local'
import { pending } from '@/lib/device-sync/model'

export default function DeviceModeBanner() {
  const user=useAuthStore(s=>s.userId)
  const [enabled,setEnabled]=useState(false)
  const {connected}=useSyncConnection(user)
  const [syncMessage,setSyncMessage]=useState('')
  const [summary,setSummary]=useState({lastSync:'',customers:0,pending:0})
  useEffect(()=>{
    if(!user||!enabled)return
    let live=true
    const update=()=>{void readWorkspace(user).then(w=>{if(live&&w)setSummary({lastSync:w.lastSync||w.snapshot.capturedAt,customers:w.snapshot.customers.length,pending:w.queue.filter(pending).length})}).catch(()=>{})}
    update();window.addEventListener('sf-device-sync-changed',update)
    return()=>{live=false;window.removeEventListener('sf-device-sync-changed',update)}
  },[user,enabled])
  useEffect(()=>{
    if(!user||!enabled||!connected)return
    let stopped=false,running=false
    const flush=async()=>{
      if(stopped||running||localStorage.getItem(`sf-auto-sync:${user}`)!=='on')return
      running=true
      try {
        const workspace=await readWorkspace(user)
        if(!workspace?.queue.some(pending)||workspace.queue.some(o=>pending(o)&&o.status==='CONFLICT'))return
        if(stopped)return
        setSyncMessage('Syncing saved entries…')
        const result=await synchronizeDevice(user)
        if(!stopped)setSyncMessage(result.message)
      }catch(e){if(!stopped)setSyncMessage((e as Error).message)}finally{running=false}
    }
    void flush()
    const timer=window.setInterval(flush,15000)
    return()=>{stopped=true;clearInterval(timer)}
  },[user,enabled,connected])
  useEffect(()=>{
    const update=()=>setEnabled(!!user&&deviceMode(user));update()
    const navigate=(event:MouseEvent)=>{
      if(!user||!deviceMode(user)||event.button!==0||event.ctrlKey||event.metaKey)return
      const anchor=(event.target as Element)?.closest?.('a[href]') as HTMLAnchorElement|null
      if(anchor&&anchor.origin===location.origin&&(anchor.pathname.startsWith('/dashboard')||anchor.pathname==='/database')){
        event.preventDefault();event.stopPropagation();location.assign(anchor.href)
      }
    }
    window.addEventListener('sf-device-sync-changed',update);window.addEventListener('storage',update);document.addEventListener('click',navigate,true)
    return()=>{window.removeEventListener('sf-device-sync-changed',update);window.removeEventListener('storage',update);document.removeEventListener('click',navigate,true)}
  },[user,connected])
  return enabled?<div role="status" className="relative z-40 border-b border-amber-200 bg-amber-50 px-5 py-2 text-sm text-amber-900">{connected?'Laptop Connected':'OFFLINE'} · Data as of: {summary.lastSync?new Date(summary.lastSync).toLocaleString('en-IN'):'Not synced'} · Customers Available: {summary.customers.toLocaleString('en-IN')} · Pending: {summary.pending}. <a className="font-bold underline" href="/database">Sync Now</a><span className="block text-xs">History-based reports on this device include only entries since the last sync; full history stays on the laptop.</span>{syncMessage&&<span className="block text-xs">{syncMessage}</span>}</div>:null
}
