import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbTransaction } from '@/server/database'
import { ensureDeviceSyncSchema, customerRevisions } from '@/server/device-sync'
import { syncTransaction } from '@/server/sync-context'
import { GET as customers } from '@/app/api/customers/route'
import { GET as loans } from '@/app/api/loans/route'

export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('customers:create')
  if (auth.error) return auth.error
  try {
    await ensureDeviceSyncSchema()
    const snapshot = await dbTransaction(async client => {
      await client.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ')
      return syncTransaction.run({ client }, async () => {
        const read = async (handler: typeof customers, path: string) => {
          const response = await handler(new NextRequest(new URL(path, request.url)))
          if (!response.ok) throw new Error('Not permitted to download the required offline records.')
          return response.json()
        }
        const c = await read(customers, '/api/customers?limit=1000000')
        const l = await read(loans, '/api/loans')
        const revisions = await customerRevisions(client, auth.user.userId)
        const paidByCustomer = new Map<string, number>()
        const summaries = l.data.map((row: Record<string, any>) => {
          paidByCustomer.set(String(row.customer_id), (paidByCustomer.get(String(row.customer_id)) || 0) + Number(row.paid_amount || 0))
          const { notes, request_key, ...summary } = row
          return { ...summary, snapshot_paid_amount: Number(row.paid_amount || 0) }
        })
        return { schemaVersion: 2, userId: auth.user.userId,
          customers: c.data.map((row: Record<string, any>) => ({ ...row, loan_notes: undefined, offline_paid_amount: paidByCustomer.get(String(row.id)) || 0 })),
          loans: summaries, payments: [], revisions, customerCount: c.data.length, loanCount: summaries.length, capturedAt: new Date().toISOString() }
      })
    })
    return NextResponse.json(snapshot, { headers: { 'Cache-Control': 'no-store' } })
  } catch {
    return NextResponse.json({ error: 'Laptop database is unavailable. Your local records have not been changed.' }, { status: 503 })
  }
}
