'use client'

import { useEffect, useState } from 'react'
import { version as buildVersion } from '../../package.json'
import type {} from '@/lib/desktop/bridge'

/** Desktop runtime is authoritative; web builds use their package version. */
export function useAppVersion() {
  const [version, setVersion] = useState(buildVersion)
  useEffect(() => {
    let active = true
    void window.sakthi?.appInfo().then(info => {
      if (active && /^\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(info.version)) setVersion(info.version)
    }).catch(() => {})
    return () => { active = false }
  }, [])
  return `v${version}`
}
