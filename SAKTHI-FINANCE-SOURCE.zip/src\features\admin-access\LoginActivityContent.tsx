'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'
import { classifyIpLocation, parseUserAgent } from '@/lib/device-info'
import AdminSectionShell, { AdminEmpty, AdminError, AdminLoading } from './AdminSectionShell'

interface LoginRow {
  seq?: number
  audit_id?: string | null
  created_at?: string | null
  action?: string | null
  performed_by?: string | null
  user_role?: string | null
  ip_address?: string | null
  client_info?: string | null
  result?: string | null
  changes?: Array<{ field?: string; label?: string; before?: any; after?: any }> | null
}

const fmtDate = (iso: string | null | undefined) => {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
  } catch {
    return '—'
  }
}

const fmtTime = (iso: string | null | undefined) => {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })
  } catch {
    return '—'
  }
}

const sessionOf = (r: LoginRow): string => {
  const c = Array.isArray(r.changes) ? r.changes.find((x) => x?.field === 'session') : null
  const v = c?.after
  return v === null || v === undefined || v === '' ? '—' : String(v)
}

export default function LoginActivityContent() {
  const [events, setEvents] = useState<LoginRow[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(true)
  const [failed, setFailed] = useState<null | 'denied' | 'error'>(null)
  const [retrying, setRetrying] = useState(false)

  const [q, setQ] = useState('')
  const [role, setRole] = useState('')
  const [status, setStatus] = useState('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const mountedRef = useRef(true)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const buildUrl = useCallback(
    (p: number) => {
      const sp = new URLSearchParams({ kind: 'login', page: String(p), limit: '25' })
      if (q.trim()) sp.set('q', q.trim())
      if (role) sp.set('role', role)
      if (status) sp.set('status', status)
      if (dateFrom) sp.set('dateFrom', dateFrom)
      if (dateTo) sp.set('dateTo', dateTo)
      return `/api/admin/activity?${sp.toString()}`
    },
    [q, role, status, dateFrom, dateTo]
  )

  const load = useCallback(
    async (p: number, isRetry = false) => {
      if (isRetry) setRetrying(true)
      else setLoading(true)
      setFailed(null)
      try {
        const res = await fetch(buildUrl(p), { credentials: 'include' })
        if (res.status === 401 || res.status === 403) {
          if (mountedRef.current) setFailed('denied')
          return
        }
        if (!res.ok) throw new Error(`Request failed (${res.status})`)
        const data = await res.json().catch(() => null)
        if (mountedRef.current) {
          setEvents(Array.isArray(data?.events) ? data.events : [])
          setTotal(Number(data?.total) || 0)
          setTotalPages(Number(data?.totalPages) || 1)
          setPage(Number(data?.page) || p)
        }
      } catch {
        if (mountedRef.current) setFailed('error')
      } finally {
        if (mountedRef.current) {
          setLoading(false)
          setRetrying(false)
        }
      }
    },
    [buildUrl]
  )

  useEffect(() => {
    mountedRef.current = true
    load(1)
    return () => {
      mountedRef.current = false
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [load])

  const onSearch = (v: string) => {
    setQ(v)
    if (timerRef.current) clearTimeout(timerRef.current)
    timerRef.current = setTimeout(() => load(1), 500)
  }

  const applySelect = (setter: (v: string) => void) => (v: string) => {
    setter(v)
    setTimeout(() => load(1), 0)
  }

  const clearAll = () => {
    setQ('')
    setRole('')
    setStatus('')
    setDateFrom('')
    setDateTo('')
    setTimeout(() => load(1), 0)
  }

  const inputCls =
    'px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-[var(--primary)]/30 focus:outline-none bg-white min-w-0'

  return (
    <AdminSectionShell title="Login Activity" subtitle="Monitor user login activity and account access" icon="login">
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
        <div className="flex flex-wrap gap-2">
          <input
            value={q}
            onChange={(e) => onSearch(e.target.value)}
            placeholder="Search user, action, IP…"
            className={cn(inputCls, 'flex-1 min-w-[180px]')}
          />
          <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className={inputCls} title="From date" />
          <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className={inputCls} title="To date" />
          <select value={role} onChange={(e) => applySelect(setRole)(e.target.value)} className={inputCls}>
            <option value="">All roles</option>
            {['owner', 'admin', 'manager', 'employee', 'viewer', 'customer'].map((r) => (
              <option key={r} value={r} className="capitalize">{r}</option>
            ))}
          </select>
          <select value={status} onChange={(e) => applySelect(setStatus)(e.target.value)} className={inputCls}>
            <option value="">All statuses</option>
            <option value="SUCCESS">SUCCESS</option>
            <option value="FAILED">FAILED</option>
          </select>
          <button onClick={() => load(1)} className="px-4 py-2 rounded-xl bg-[var(--primary)] text-white text-xs font-semibold hover:bg-[#912222]">Apply</button>
          <button onClick={clearAll} className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-medium hover:bg-slate-50">Clear</button>
        </div>
      </div>

      {loading && <AdminLoading />}
      {!loading && failed === 'denied' && (
        <AdminError message="You are not authorized to access this page." onRetry={() => load(page, true)} retrying={retrying} />
      )}
      {!loading && failed === 'error' && (
        <AdminError message="Unable to connect to the database. Please try again." onRetry={() => load(page, true)} retrying={retrying} />
      )}
      {!loading && !failed &&
        (events.length === 0 ? (
          <AdminEmpty message="No login activity recorded yet" />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-bold text-slate-900">
                Logins <span className="text-slate-400 font-semibold">({total.toLocaleString('en-IN')})</span>
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm min-w-[1080px]">
                <thead>
                  <tr className="bg-gradient-to-r from-[var(--primary)] to-[var(--primary-hover)] text-left">
                    {['User', 'Role', 'Date', 'Time', 'IP', 'Location', 'Device', 'Browser', 'OS', 'Status', 'Session'].map((h) => (
                      <th key={h} className="px-3 py-2.5 text-[11px] font-bold uppercase tracking-wider text-[#F3DFA7] whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {events.map((e, i) => {
                    const d = parseUserAgent(e.client_info)
                    return (
                      <tr key={e.audit_id || e.seq || i} className="hover:bg-slate-50">
                        <td className="px-3 py-2.5 text-xs font-bold text-slate-900 whitespace-nowrap">{e.performed_by || '—'}</td>
                        <td className="px-3 py-2.5 text-xs text-slate-600 capitalize whitespace-nowrap">{e.user_role || '—'}</td>
                        <td className="px-3 py-2.5 text-xs text-slate-600 tabular-nums whitespace-nowrap">{fmtDate(e.created_at)}</td>
                        <td className="px-3 py-2.5 text-xs text-slate-600 tabular-nums whitespace-nowrap">{fmtTime(e.created_at)}</td>
                        <td className="px-3 py-2.5 text-xs font-mono text-slate-600 whitespace-nowrap">{e.ip_address || '—'}</td>
                        <td className="px-3 py-2.5 text-xs text-slate-500 whitespace-nowrap">{classifyIpLocation(e.ip_address)}</td>
                        <td className="px-3 py-2.5 text-xs text-slate-600 whitespace-nowrap">{d.device}</td>
                        <td className="px-3 py-2.5 text-xs text-slate-600 whitespace-nowrap">{d.browser}</td>
                        <td className="px-3 py-2.5 text-xs text-slate-600 whitespace-nowrap">{d.os}</td>
                        <td className="px-3 py-2.5">
                          <span className={cn(
                            'inline-flex items-center px-2 py-0.5 rounded-lg text-[11px] font-bold border whitespace-nowrap',
                            e.result === 'FAILED'
                              ? 'bg-red-50 text-red-700 border-red-200'
                              : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          )}>
                            {e.action === 'LOGIN_FAILED' ? 'FAILED' : e.result || '—'}
                          </span>
                        </td>
                        <td className="px-3 py-2.5 text-xs font-mono text-slate-500 whitespace-nowrap">{sessionOf(e)}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
            <div className="px-4 py-3 border-t border-slate-100 flex items-center justify-between">
              <p className="text-xs text-slate-500">Page {page} of {totalPages}</p>
              <div className="flex gap-2">
                <button disabled={page <= 1 || loading} onClick={() => load(page - 1)} className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold hover:bg-slate-50 disabled:opacity-40">Prev</button>
                <button disabled={page >= totalPages || loading} onClick={() => load(page + 1)} className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold hover:bg-slate-50 disabled:opacity-40">Next</button>
              </div>
            </div>
          </div>
        ))}
    </AdminSectionShell>
  )
}
