'use client'

import { createContext, useContext, useEffect, useRef } from 'react'
import posthog from 'posthog-js'

const PostHogContext = createContext<typeof posthog | null>(null)

export function PostHogProvider({ children }: { children: React.ReactNode }) {
  const initialized = useRef(false)

  useEffect(() => {
    if (typeof window === 'undefined' || initialized.current) return

    const key = process.env.NEXT_PUBLIC_POSTHOG_KEY
    const host = process.env.NEXT_PUBLIC_POSTHOG_HOST || 'https://app.posthog.com'

    if (key) {
      posthog.init(key, {
        api_host: host,
        capture_pageview: true,
        capture_pageleave: true,
      })
      initialized.current = true
    }
  }, [])

  return (
    <PostHogContext.Provider value={posthog}>
      {children}
    </PostHogContext.Provider>
  )
}

export function usePostHog() {
  return useContext(PostHogContext)
}
