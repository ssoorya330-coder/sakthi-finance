const fs = require('node:fs');
const vm = require('node:vm');
const ts = require('typescript');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
require('dotenv').config({ quiet: true });
const { Client } = require('pg');
const out = {};
vm.runInNewContext(ts.transpileModule(fs.readFileSync('src/server/kanaku-schema.ts', 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText, { exports: out });
(async () => {
  const db = new Client({ connectionString: process.env.DATABASE_URL });
  await db.connect();
  try {
    await db.query('BEGIN');
    await db.query('SELECT pg_advisory_xact_lock(721904221)');
    await db.query('LOCK TABLE customers, loans, payments, audit_events IN SHARE ROW EXCLUSIVE MODE');
    const snapshot = async () => {
      const result = {};
      for (const table of ['customers', 'loans', 'payments', 'audit_events']) {
        const rows = (await db.query(`SELECT (to_jsonb(t) - ARRAY['cycle_number','kanaku_number','legacy_paid_amount','request_key','kanaku_group_key'])::text AS data FROM ${table} t ORDER BY (to_jsonb(t) - ARRAY['cycle_number','kanaku_number','legacy_paid_amount','request_key','kanaku_group_key'])::text`)).rows;
        result[table] = { count: rows.length, hash: crypto.createHash('sha256').update(JSON.stringify(rows)).digest('hex') };
      }
      return result;
    };
    const before = await snapshot();
    await db.query(out.kanakuMigration);
    assert.deepEqual(await snapshot(), before, 'Existing records must remain unchanged');
    await db.query('COMMIT');
    console.log('Kanaku migration committed. Existing customer, loan, payment and audit values verified unchanged.', Object.fromEntries(Object.entries(before).map(([table, value]) => [table, value.count])));
  } catch (error) { await db.query('ROLLBACK'); throw error; }
  finally { await db.end(); }
})().catch(error => { console.error(error.message); process.exitCode = 1; });
