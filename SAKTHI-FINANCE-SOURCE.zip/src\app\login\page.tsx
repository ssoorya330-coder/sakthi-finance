'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { Loader2, AlertCircle } from 'lucide-react'
import BrandLogo from '@/components/ui/brand-logo'
import { useAuthStore } from '@/store/auth-store'
import { CustomerPhoneVerification } from '@/components/auth/customer-phone-verification'
import { desktopGoogleSignIn as desktopGoogleSignInTauri, isTauriApp } from '@/lib/auth/desktop-google-client'
import { isDesktopApp } from '@/lib/desktop/bridge'
import { desktopSignIn, desktopSetDisplayName, desktopCancelSignIn, desktopAuthErrorText } from '@/lib/desktop/auth-client'

declare global {
  interface Window {
    google?: {
      accounts: {
        id: {
          initialize: (config: any) => void
          prompt: (callback?: (notification: any) => void) => void
          renderButton: (element: HTMLElement, config: any) => void
        }
      }
    }
  }
}

const GOOGLE_CLIENT_ID = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || ''
const SUPABASE_CONFIGURED = Boolean(
  process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
)

type LoginError = 'not_authorized' | 'account_disabled' | 'db_unavailable' | 'auth_error' | 'google_not_configured' | null

export default function LoginPage() {
  const router = useRouter()
  const setUser = useAuthStore((s) => s.setUser)
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)
  const role = useAuthStore((s) => s.role)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<LoginError>(null)
  const [errorMsg, setErrorMsg] = useState('')
  const [pendingCustomer, setPendingCustomer] = useState<{ id: string; email: string; name: string } | null>(null)
  const googleButtonRef = useRef<HTMLDivElement>(null)
  const initializedRef = useRef(false)
  const signingInRef = useRef(false)
  const pendingCredentialRef = useRef<string | null>(null)
  const [needsName, setNeedsName] = useState(false)
  const [displayName, setDisplayName] = useState('')
  const [desktop, setDesktop] = useState(false)
  const [desktopWaiting, setDesktopWaiting] = useState(false)
  const desktopAttempt = useRef<AbortController | null>(null)
  useEffect(() => () => desktopAttempt.current?.abort(), [])

  // Redirect if already authenticated (customers go to their account page)
  useEffect(() => {
    if (isAuthenticated) {
      router.replace(role === 'customer' ? '/dashboard/my-account' : '/dashboard')
    }
  }, [isAuthenticated, role, router])

  // If we landed here with a Supabase session (OAuth callback set sb-*
  // cookies but the zustand store is empty), hydrate from the server.
  useEffect(() => {
    if (isAuthenticated || !SUPABASE_CONFIGURED) return
    let cancelled = false
    fetch('/api/auth/supabase/session', { credentials: 'include' })
      .then(async (res) => {
        if (!res.ok || cancelled) return
        const data = await res.json()
        if (data?.authenticated && data.user && !cancelled) {
          setUser({
            userId: data.user.id,
            email: data.user.email,
            name: data.user.name,
            role: data.user.role || 'employee',
          })
          router.replace(data.user.role === 'customer' ? '/dashboard/my-account' : '/dashboard')
        }
      })
      .catch(() => {})
    return () => {
      cancelled = true
    }
  }, [isAuthenticated, setUser, router])

  const handleGoogleCredentialResponse = useCallback(async (response: { credential: string }, name?: string) => {
    if (signingInRef.current) return
    signingInRef.current = true
    setLoading(true)
    setError(null)
    setErrorMsg('')

    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id_token: response.credential, client_type: isDesktopApp() ? 'desktop' : 'web', mode: 'signin', ...(name ? { display_name: name } : {}) }),
      })

      const data = await res.json()
      if (res.ok && data.code === 'name_required') {
        pendingCredentialRef.current = response.credential
        setNeedsName(true)
        setLoading(false)
        return
      }

      if (!res.ok) {
        if (res.status === 403 && data.code === 'not_authorized') {
          setError('not_authorized')
          setErrorMsg(data.error)
        } else if (res.status === 403 && data.code === 'account_disabled') {
          setError('account_disabled')
          setErrorMsg(data.error)
        } else if (res.status === 503) {
          setError('db_unavailable')
          setErrorMsg(data.error)
        } else if (data.code === 'google_not_configured') {
          setError('google_not_configured')
          setErrorMsg(data.error)
        } else {
          setError('auth_error')
          setErrorMsg(data.error || 'Authentication failed')
        }
        setLoading(false)
        return
      }

      // The server has established the session using HttpOnly cookies.
      pendingCredentialRef.current = null
      setNeedsName(false)

      const loginRole = data.user.role === 'collector' ? 'employee' : data.user.role || 'employee'
      if (loginRole === 'customer') {
        setPendingCustomer({ id: data.user.id, email: data.user.email, name: data.user.name })
        setLoading(false)
        return
      }

      // Set user in auth store
      setUser({
        userId: data.user.id,
        email: data.user.email,
        name: data.user.name,
        role: loginRole,
      })

      router.replace(loginRole === 'customer' ? '/dashboard/my-account' : '/dashboard')
    } catch (err) {
      console.error('[Login] Error:', err)
      setError('auth_error')
      setErrorMsg('Network error. Please try again.')
      setLoading(false)
    } finally {
      signingInRef.current = false
    }
  }, [setUser, router])

  // Initialize Google Identity Services
  useEffect(() => {
    if (isTauriApp() || isDesktopApp()) { setDesktop(true); return }
    if (!GOOGLE_CLIENT_ID) {
      setError('google_not_configured')
      setErrorMsg('Google Sign-In client ID is not configured.')
      return
    }

    if (initializedRef.current) return
    initializedRef.current = true

    // Load the Google Identity Services script
    const script = document.createElement('script')
    script.src = 'https://accounts.google.com/gsi/client'
    script.async = true
    script.defer = true
    script.onload = () => {
      if (window.google?.accounts?.id) {
        window.google.accounts.id.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: handleGoogleCredentialResponse,
          auto_select: false,
          cancel_on_tap_outside: true,
        })

        // Render the Google Sign-In button
        if (googleButtonRef.current) {
          window.google.accounts.id.renderButton(googleButtonRef.current, {
            type: 'standard',
            theme: 'outline',
            size: 'large',
            // Google Identity Services requires a numeric pixel width.
            // The parent container remains responsive around this button.
            width: 384,
            text: 'signin_with',
            shape: 'rectangular',
            logo_alignment: 'left',
          })
        }
      }
    }
    script.onerror = () => {
      setError('google_not_configured')
      setErrorMsg('Failed to load Google Sign-In. Check your network connection.')
    }
    document.head.appendChild(script)

    return () => {
      initializedRef.current = false
      script.onload = null
      // Cleanup script on unmount
      try {
        document.head.removeChild(script)
      } catch {}
    }
  }, [handleGoogleCredentialResponse])

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#F7F9EC] px-4 py-10">
      {/* Background decorations */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full bg-[#7F1D1D]/[0.03] blur-[120px]" />
        <div className="absolute bottom-0 right-0 w-[600px] h-[600px] rounded-full bg-[#D4AF37]/[0.04] blur-[100px]" />
      </div>

      <div className="relative w-full max-w-[420px]">
        {/* Logo and Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-40 h-40 rounded-[22px] bg-[#FFFAED] shadow-[0_12px_40px_rgba(212,175,55,0.2)] mb-5">
            <BrandLogo className="w-full h-full" />
          </div>
          <h1 className="text-2xl font-bold text-[#27253B] tracking-tight">SAKTHI FINANCE</h1>
          <p className="text-sm text-[#6A6A72] mt-1.5">Finance Management System</p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-[24px] shadow-[0_8px_40px_rgba(0,0,0,0.08)] border border-[#E8E5E0] p-8">
          <h2 className="text-lg font-semibold text-[#27253B] text-center mb-1">Welcome Back</h2>
          <p className="text-sm text-[#6A6A72] text-center mb-8">Sign in to access your account</p>

          {pendingCustomer && (
            <CustomerPhoneVerification
              user={pendingCustomer}
              onVerified={() => router.replace('/dashboard/my-account')}
            />
          )}
          {!pendingCustomer && (GOOGLE_CLIENT_ID || SUPABASE_CONFIGURED) && <div className="border-t border-[#E8E5E0] pt-5 mb-4 text-center text-xs text-[#6A6A72]">Sign in with your authorized Google account</div>}

          {/* Error Display */}
          {error && (
            <div className="mb-6 p-4 rounded-[14px] bg-red-50 border border-red-200">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-red-800">
                    {error === 'not_authorized' && 'Not Authorized'}
                    {error === 'account_disabled' && 'Account Disabled'}
                    {error === 'db_unavailable' && 'Service Unavailable'}
                    {error === 'google_not_configured' && 'Configuration Error'}
                    {error === 'auth_error' && 'Authentication Error'}
                  </p>
                  <p className="text-sm text-red-600 mt-1">{errorMsg}</p>
                </div>
              </div>
            </div>
          )}

          {/* Google Sign-In Button (direct GIS → local JWT; kept working) */}
          {needsName && <form className="space-y-4" onSubmit={async e => {
            e.preventDefault()
            if (isDesktopApp()) {
              if (loading || !displayName.trim()) return
              setLoading(true)
              try {
                const user = await desktopSetDisplayName(displayName.trim())
                if (!user) throw Error('Could not save your name. Please sign in again.')
                setUser({ userId: user.userId, email: user.email, name: user.name, role: user.role as never })
                router.replace('/dashboard')
              } catch (error) { setError('auth_error'); setErrorMsg(error instanceof Error ? error.message : 'Please retry.') }
              finally { setLoading(false) }
              return
            }
            if (displayName.trim() && pendingCredentialRef.current) void handleGoogleCredentialResponse({ credential: pendingCredentialRef.current }, displayName.trim())
          }}>
            <div><h3 className="font-semibold text-[#7F1D1D]">What should we call you?</h3><p className="text-sm text-slate-500 mt-1">Enter the name you want to use in Sakthi Finance.</p></div>
            <label className="block text-sm text-slate-700">Your name
              <input autoFocus required maxLength={100} autoComplete="name" value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="Example: SOORYA S" className="mt-2 w-full rounded-xl border border-[#E8CFCF] px-4 py-3 outline-none focus:ring-2 focus:ring-[#7F1D1D]/20" />
            </label>
            <button disabled={loading || !displayName.trim()} className="w-full rounded-xl bg-[#7F1D1D] text-white py-3 disabled:opacity-50">{loading ? 'Saving…' : 'Save and continue'}</button>
            <button type="button" disabled={loading} className="w-full text-sm text-slate-500" onClick={() => { pendingCredentialRef.current = null; setNeedsName(false); setDisplayName(''); setError(null) }}>Use a different Google account</button>
          </form>}
          {!pendingCustomer && <div className={needsName ? 'hidden' : 'flex flex-col items-center gap-4'}>
            {desktop && !desktopWaiting && <button type="button" disabled={loading} className="w-full h-[48px] rounded-[14px] bg-[#7F1D1D] text-white text-sm font-medium disabled:opacity-50" onClick={async () => {
              if (desktopAttempt.current) return
              const controller = new AbortController()
              desktopAttempt.current = controller
              setDesktopWaiting(true); setError(null); setErrorMsg('')
              try {
                if (isDesktopApp()) {
                  // Electron: sign-in completes inside the app window; the
                  // main process creates the session — no token reaches here.
                  const result = await desktopSignIn()
                  if (controller.signal.aborted) return
                  if (!result.ok) {
                    setError('auth_error')
                    setErrorMsg(desktopAuthErrorText(result.error || 'failed'))
                    return
                  }
                  if (result.isNewUser) {
                    setNeedsName(true)
                    return
                  }
                  const user = result.user!
                  setUser({ userId: user.userId, email: user.email, name: user.name, role: user.role as never })
                  router.replace(user.role === 'customer' ? '/dashboard/my-account' : '/dashboard')
                  return
                }
                const credential = await desktopGoogleSignInTauri(controller.signal)
                controller.signal.throwIfAborted()
                await handleGoogleCredentialResponse({ credential })
              } catch (error) {
                if (!controller.signal.aborted) { setError('auth_error'); setErrorMsg(error instanceof Error ? error.message : 'Desktop sign-in failed. Please retry.') }
              } finally { desktopAttempt.current = null; setDesktopWaiting(false) }
            }}>Continue with Google</button>}
            {desktopWaiting && <div className="text-center text-sm text-[#6A6A72] space-y-3"><p>Complete sign-in in your browser. Sakthi Finance will continue automatically.</p><button type="button" className="text-[#7F1D1D] underline" onClick={() => { desktopCancelSignIn(); desktopAttempt.current?.abort() }}>Cancel sign-in</button></div>}
            <div ref={googleButtonRef} className={loading || desktop ? 'hidden' : 'w-full'} />
            {loading && (
              <div className="flex items-center justify-center gap-3 w-full h-[48px] rounded-[14px] bg-[#F7F9EC] border border-[#E8E5E0]">
                <Loader2 className="w-5 h-5 animate-spin text-[#7F1D1D]" />
                <span className="text-sm text-[#6A6A72]">Signing in...</span>
              </div>
            )}
            {SUPABASE_CONFIGURED && !loading && !desktop && (
              <button
                type="button"
                onClick={async () => {
                  setLoading(true)
                  try {
                    const { signInWithGoogleSupabase } = await import('@/lib/supabase/client')
                    await signInWithGoogleSupabase('/dashboard')
                  } catch (err) {
                    console.error('[Login] Supabase sign-in error:', err)
                    setError('auth_error')
                    setErrorMsg('Supabase Google sign-in failed. Please try again.')
                    setLoading(false)
                  }
                }}
                className="w-full h-[48px] rounded-[14px] bg-[#27253B] text-white text-sm font-medium hover:bg-[#3a3854] transition-colors"
              >
                Continue with Google (Supabase)
              </button>
            )}
          </div>}

          {/* Info text */}
          <p className="text-xs text-[#9A9AA2] text-center mt-6 leading-relaxed">
            Only authorized accounts can access this application.
            <br />
            Contact the administrator if you need access.
          </p>
        </div>

        {/* Footer */}
        <p className="text-xs text-[#9A9AA2] text-center mt-6">
          &copy; {new Date().getFullYear()} Sakthi Finance. All rights reserved.
        </p>
      </div>
    </div>
  )
}
