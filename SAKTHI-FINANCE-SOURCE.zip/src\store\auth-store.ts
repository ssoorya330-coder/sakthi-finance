﻿import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export type UserRole = 'owner' | 'admin' | 'manager' | 'employee' | 'viewer' | 'customer';

interface AuthUser {
  id: string;
  email: string | null;
  name: string | null;
  role: UserRole;
}

interface Session {
  user: AuthUser | null;
  accessToken: string | null;
  expiresAt: number | null;
}

interface AuthState {
  user: AuthUser | null;
  session: Session | null;
  userId: string | null;
  userEmail: string | null;
  userName: string | null;
  role: UserRole;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isManager: boolean;
  isCollector: boolean;
  isLoading: boolean;
  loading: boolean;
  isLoggingOut: boolean;
  splashComplete: boolean;
  _hasHydrated: boolean;

  setUser: (params: {
    userId?: string;
    email: string;
    name: string;
    role: UserRole;
  }) => void;
  setSession: (session: Session | null, user: AuthUser | null) => void;
  setLoading: (value: boolean) => void;
  setLoggingOut: (value: boolean) => void;
  setSplashComplete: (value: boolean) => void;
  setHasHydrated: (value: boolean) => void;
  logout: () => void;
}

const STORAGE_KEY = 'sf-auth';

function resolveRole(raw: string | null | undefined): UserRole {
  if (raw === 'owner') return 'owner';
  if (raw === 'admin') return 'admin';
  if (raw === 'manager') return 'manager';
  if (raw === 'viewer') return 'viewer';
  if (raw === 'customer') return 'customer';
  // Legacy `collector` maps to `employee`; default is least-privilege staff.
  return 'employee';
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      session: null,
      userId: null,
      userEmail: null,
      userName: null,
      role: 'employee',
      isAuthenticated: false,
      isAdmin: false,
      isManager: false,
      isCollector: true,
      isLoading: true,
      loading: true,
      isLoggingOut: false,
      splashComplete: false,
      _hasHydrated: false,

      setUser: ({ userId, email, name, role }) => {
        const id = userId || null;
        const resolved = resolveRole(role);
        set((state) => ({
          user: id ? { id, email, name, role: resolved } : null,
          session: state.session && id ? {
            ...state.session,
            user: { id, email, name, role: resolved },
          } : null,
          userId: id,
          userEmail: email,
          userName: name,
          role: resolved,
          isAuthenticated: Boolean(id),
          isAdmin: resolved === 'admin' || resolved === 'owner',
          isManager: resolved === 'manager',
          isCollector: resolved === 'employee',
          splashComplete: true,
          isLoading: false,
          loading: false,
        }));
      },

      setSession: (session, user) => {
        if (session && user) {
          const id = user.id;
          const email = user.email ?? null;
          const name =
            user.name ||
            user.email?.split('@')[0] ||
            '';
          const resolved = resolveRole(user.role);
          set({
            user,
            session,
            userId: id,
            userEmail: email,
            userName: name,
            role: resolved,
            isAuthenticated: true,
            isAdmin: resolved === 'admin' || resolved === 'owner',
            isManager: resolved === 'manager',
            isCollector: resolved === 'employee',
            isLoading: false,
            loading: false,
            splashComplete: true,
          });
        } else {
          set({
            user: null,
            session: null,
            userId: null,
            userEmail: null,
            userName: null,
            role: 'employee',
            isAuthenticated: false,
            isAdmin: false,
            isManager: false,
            isCollector: true,
            isLoading: false,
            loading: false,
            splashComplete: true,
          });
        }
      },

      setLoading: (value) => set({ isLoading: value, loading: value }),

      setLoggingOut: (value) => set({ isLoggingOut: value }),

      setSplashComplete: (value) => set({ splashComplete: value }),

      setHasHydrated: (value) => set({ _hasHydrated: value }),

      logout: () => {
        set({
          user: null,
          session: null,
          userId: null,
          userEmail: null,
          userName: null,
          role: 'employee',
          isAuthenticated: false,
          isAdmin: false,
          isManager: false,
          isCollector: true,
          isLoggingOut: false,
          isLoading: false,
          loading: false,
        });
      },
    }),
    {
      name: STORAGE_KEY,
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        userId: state.userId,
        userEmail: state.userEmail,
        userName: state.userName,
        role: state.role,
        isAuthenticated: state.isAuthenticated,
        isAdmin: state.isAdmin,
        isManager: state.isManager,
        isCollector: state.isCollector,
      }),
      onRehydrateStorage: () => {
        return (state, error) => {
          if (error) {
            console.warn('[AuthStore] rehydrate error', error);
          }
          if (state) {
            (state as any)._hasHydrated = true;
            (state as any).isLoading = false;
            (state as any).loading = false;
          }
        };
      },
      merge: (persistedState, currentState) => {
        const p = persistedState as unknown as Record<string, unknown> | undefined;
        if (!p) return currentState;
        const merged = { ...currentState, ...(p as Partial<AuthState>) };
        // Normalize legacy persisted `collector` role to `employee` once.
        if ((merged as { role?: string }).role === 'collector') {
          (merged as { role?: string }).role = 'employee';
        }
        return merged;
      },
    }
  )
);

export function clearAuthPersistedState(): void {
  if (typeof window !== 'undefined') {
    localStorage.removeItem(STORAGE_KEY);
    sessionStorage.removeItem(STORAGE_KEY);
  }
}

export function getUserId(): string | null {
  const s = useAuthStore.getState();
  return s.userId || s.user?.id || null;
}
