import { NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { captureDbSnapshot } from '@/server/storage'

export const dynamic = 'force-dynamic'

/**
 * STEP 8/9 — Application-level snapshot for before/after comparison:
 * version, data directory, databases, table row counts (exact for key
 * tables), database size. Metadata and counts only — no record contents.
 */
export async function GET() {
  const auth = await requireAuthWithPermission('settings:manage')
  if (auth.error) return auth.error
  try {
    const snapshot = await captureDbSnapshot()
    return NextResponse.json({ snapshot, capturedAt: new Date().toISOString() })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Failed to capture verification snapshot', details: err.message },
      { status: 500 }
    )
  }
}
