import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import {
  fy,
  fyOf,
  fyPeriodLabel,
  availableFinancialYears,
  overallSummary,
  customerSummary,
  loanDetails,
  transactionLedger,
  reconcile,
  dataQualityChecks,
} from '@/server/financial-audit'

export const dynamic = 'force-dynamic'

/**
 * Financial audit data for the selected Financial Year (April–March).
 * Everything is computed in PostgreSQL from real business tables through
 * one authoritative calculation module shared by UI, Excel, CSV and print.
 */
export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('audit:read')
  if (auth.error) return auth.error

  try {
    const searchParams = new URL(request.url).searchParams
    const years = await availableFinancialYears(auth.user.userId)
    const current = fyOf()
    const fyParam = parseInt(searchParams.get('fy') || '', 10)
    const selected = years.some((y) => y.startYear === fyParam) ? fy(fyParam) : current

    const ledgerPage = Math.max(parseInt(searchParams.get('ledgerPage') || '1', 10) || 1, 1)
    const ledgerLimit = Math.min(Math.max(parseInt(searchParams.get('ledgerLimit') || '25', 10) || 25, 1), 200)

    const [overall, customers, loans, ledgerPageData, dataQuality] = await Promise.all([
      overallSummary(auth.user.userId, selected),
      customerSummary(auth.user.userId, selected),
      loanDetails(auth.user.userId, selected),
      transactionLedger(auth.user.userId, selected, ledgerPage, ledgerLimit),
      dataQualityChecks(auth.user.userId, selected),
    ])
    // Reconciliation needs the FULL ledger, not just the page.
    const full = ledgerPageData.total > ledgerPageData.rows.length
      ? await transactionLedger(auth.user.userId, selected, 1, Math.min(ledgerPageData.total, 100000))
      : ledgerPageData
    const reconciliation = reconcile(overall, customers, loans, full.rows)

    return NextResponse.json({
      years: years.map((y) => ({ startYear: y.startYear, label: y.label })),
      fy: { startYear: selected.startYear, label: selected.label, period: fyPeriodLabel(selected) },
      generatedAt: new Date().toISOString(),
      generatedBy: auth.user.email || auth.user.userId,
      overall,
      customers,
      loans,
      ledger: ledgerPageData.rows,
      ledgerTotal: ledgerPageData.total,
      ledgerPage,
      ledgerPages: Math.max(Math.ceil(ledgerPageData.total / ledgerLimit), 1),
      reconciliation,
      dataQuality,
      allocationRule: 'Payments are applied to principal first; interest is the remainder. Received always equals principal + interest.',
    })
  } catch (err: any) {
    console.error('[GET /api/audit/financial] Error:', err.message)
    return NextResponse.json({ error: 'Failed to load financial audit' }, { status: 500 })
  }
}
