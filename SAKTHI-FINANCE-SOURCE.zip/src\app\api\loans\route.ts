import { resolveCustomerId } from '@/server/customer-identity'
import { NextRequest, NextResponse } from 'next/server'
import { dbQuery } from '@/server/database'
import { requireAuthWithPermission } from '@/lib/api-utils'

export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('loans:read');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const userId = user.userId
    const { searchParams } = new URL(request.url)
    const customerId = await resolveCustomerId(searchParams.get('customer_id'))
    const status = searchParams.get('status')

    let query = `SELECT l.*, c.full_name as customer_name, c.customer_code
      FROM kanaku_loan_balances l JOIN customers c ON l.customer_id = c.id WHERE 1=1`
    const params: any[] = []
    let paramIdx = 1

    if (userId) { query += ` AND l.user_id = $${paramIdx++}`; params.push(userId) }
    if (customerId) { query += ` AND l.kanaku_group_key IN (SELECT kanaku_group_key FROM loans WHERE customer_id = $${paramIdx++} AND user_id = $1)`; params.push(customerId) }
    if (status) { query += ` AND l.status = $${paramIdx++}`; params.push(status) }
    query += ' ORDER BY l.cycle_number DESC, l.kanaku_number ASC'

    const result = await dbQuery(query, params)
    return NextResponse.json({ data: result.rows })
  } catch (err: any) {
    console.error('[GET /api/loans] Error:', err.message)
    return NextResponse.json(
      { error: 'Failed to fetch loans', details: err.message },
      { status: 500 }
    )
  }
}
