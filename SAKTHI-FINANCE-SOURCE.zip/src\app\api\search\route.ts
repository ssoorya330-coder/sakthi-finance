import { NextRequest, NextResponse } from 'next/server'
import { dbQuery } from '@/server/database'
import { requireAuthWithPermission } from '@/lib/api-utils'

export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('customers:read');
  if (auth.error) return auth.error;
  const { user } = auth;

  try {
    const { searchParams } = new URL(request.url)
    const q = searchParams.get('q') || ''
    const userId = user.userId
    if (!q.trim()) {
      return NextResponse.json({ data: [] })
    }

    let query = `
      SELECT c.id, c.customer_code, c.full_name, c.phone_number,
        c.area_id, c.city_id, c.business_id, c.status, c.created_at,
        ra.name AS area_name, rc.name AS city_name, rb.name AS business_name,
        l.loan_date, l.due_date
      FROM customers c
      LEFT JOIN ref_area ra ON c.area_id = ra.id
      LEFT JOIN ref_city rc ON c.city_id = rc.id
      LEFT JOIN ref_business rb ON c.business_id = rb.id
      LEFT JOIN loans l ON l.customer_id = c.id
      WHERE (c.full_name ILIKE $1 OR c.phone_number ILIKE $1 OR c.customer_code ILIKE $1
        OR ra.name ILIKE $1 OR rc.name ILIKE $1 OR rb.name ILIKE $1)
    `
    const params: any[] = [`%${q}%`]
    let paramIdx = 2
    if (userId) { query += ` AND c.user_id = $${paramIdx++}`; params.push(userId) }
    query += ' ORDER BY c.full_name LIMIT 50'

    const result = await dbQuery(query, params)
    return NextResponse.json({ data: result.rows })
  } catch (err: any) {
    console.error('[GET /api/search] Error:', err.message)
    return NextResponse.json(
      { error: 'Failed to search customers', details: err.message },
      { status: 500 }
    )
  }
}
