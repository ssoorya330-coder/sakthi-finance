'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuthStore } from '@/store/auth-store'
import PageLoading from '@/components/ui/page-loading'

/**
 * Client-side page gate for the packaged desktop app (static export has no
 * per-request SSR). Preserves the same redirects the server gates enforced:
 * unauthenticated → /login, wrong role → /dashboard.
 */

export function ClientPageGate({
  children,
  requireRole,
}: {
  children: React.ReactNode
  requireRole: 'owner' | 'staff' | 'customer'
}) {
  const router = useRouter()
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)
  const isLoading = useAuthStore((s) => s.isLoading)
  const role = useAuthStore((s) => s.role)
  const [allowed, setAllowed] = useState(false)

  useEffect(() => {
    if (isLoading) return
    if (!isAuthenticated) {
      router.replace('/login')
      return
    }
    const staff = role === 'owner' || role === 'admin' || role === 'manager' || role === 'employee' || role === 'viewer'
    if (requireRole === 'owner' && role !== 'owner') {
      router.replace('/dashboard')
      return
    }
    if (requireRole === 'staff' && !staff) {
      rolesGuardedDashboard()
      return
    }
    setAllowed(true)
  }, [isAuthenticated, isLoading, role, requireRole, router])

  function rolesGuardedDashboard() {
    router.replace('/dashboard')
  }

  if (!allowed) return <PageLoading fullScreen />
  return <>{children}</>
}
