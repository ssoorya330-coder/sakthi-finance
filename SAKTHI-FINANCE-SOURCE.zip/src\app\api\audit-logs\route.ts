import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { dbQuery } from '@/server/database'

export async function GET(request: NextRequest) {
  const auth = await requireAuthWithPermission('audit:read')
  if (auth.error) return auth.error

  try {
    const { searchParams } = new URL(request.url)
    const limit = Math.min(parseInt(searchParams.get('limit') || '100'), 500)
    const offset = parseInt(searchParams.get('offset') || '0')
    const action = searchParams.get('action')
    const entityType = searchParams.get('entity_type')

    let query = `
      SELECT a.id, a.action, a.entity_type, a.entity_id, a.details, a.user_id,
             u.full_name as user_name, u.email as user_email, a.created_at
      FROM audit_logs a
      LEFT JOIN users u ON a.user_id = u.user_id
      WHERE 1=1
    `
    const params: any[] = []
    let paramIndex = 1

    if (action) {
      query += ` AND a.action = $${paramIndex}`
      params.push(action)
      paramIndex++
    }
    if (entityType) {
      query += ` AND a.entity_type = $${paramIndex}`
      params.push(entityType)
      paramIndex++
    }

    query += ` ORDER BY a.created_at DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`
    params.push(limit, offset)

    const result = await dbQuery(query, params)

    const countResult = await dbQuery('SELECT COUNT(*) as total FROM audit_logs')

    return NextResponse.json({
      logs: result.rows,
      total: parseInt(countResult.rows[0]?.total || '0'),
    })
  } catch (err: any) {
    console.error('[GET /api/audit-logs] Error:', err.message)
    return NextResponse.json({ error: 'Failed to fetch audit logs' }, { status: 500 })
  }
}
