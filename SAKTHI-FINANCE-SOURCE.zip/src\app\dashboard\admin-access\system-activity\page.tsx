'use client'

import { ClientPageGate } from '@/components/auth/client-page-gate'
import SystemActivityContent from '@/features/admin-access/SystemActivityContent'

export default function SystemActivityContentPage() {
  return (
    <ClientPageGate requireRole="owner">
      <SystemActivityContent />
    </ClientPageGate>
  )
}
