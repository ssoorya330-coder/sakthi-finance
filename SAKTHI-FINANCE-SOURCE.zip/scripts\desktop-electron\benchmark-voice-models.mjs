// Synthetic fixtures only. No microphone, customer files or external transcription.
import { spawn } from 'node:child_process'
import { readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
const root=path.resolve('desktop/voice-runtime')
const cases=[['sakthivel','Sakthivel'],['name','Soorya'],['requested-name','Arul Vettri'],['unseen-city','Coimbatore'],['double-phone','9987654321']]
const results=[]
for(const model of ['small-q5_1','large-v3-turbo-q5_0']) {
  for(const [id,expected] of cases){
    const started=Date.now()
    const audio=await readFile(`test-reports/offline-voice-fixtures/${id}.wav`)
    const actual=await new Promise((resolve,reject)=>{
      const child=spawn(path.join(root,'bin/Release/whisper-cli.exe'),['-m',path.join(root,`ggml-${model}.bin`),'-f','-','-of','sakthi-memory','-l','en','-t','6','-ng','-np','-nt','-sns','-nf','-bs','5','-ac','768','--prompt','Indian English names and addresses: Soorya, Ravi Kumar, Salem, Chennai, Gandhi Road.'],{windowsHide:true,stdio:['pipe','pipe','pipe']})
      let text='';const timer=setTimeout(()=>child.kill(),120000)
      child.stdout.on('data',chunk=>{text+=chunk;if(text.length>16000)child.kill()})
      child.stderr.resume();child.stdin.on('error',()=>{})
      child.on('error',reject)
      child.on('close',code=>{clearTimeout(timer);code===0?resolve(text.trim()):reject(Error(`Inference failed: ${code}`))})
      child.stdin.end(audio)
    })
    const result={model,id,expected,actual,milliseconds:Date.now()-started}
    results.push(result);console.log(JSON.stringify(result))
  }
}
await writeFile('test-reports/VOICE_MODEL_COMPARISON.json',JSON.stringify({date:new Date().toISOString(),scope:'Synthetic speech, CPU only; not human accent validation',results},null,2))
