import { NextRequest, NextResponse } from 'next/server'
import { requireAuthWithPermission } from '@/lib/api-utils'
import { actorFromAuthUser, recordAuditStandalone } from '@/server/audit'

export async function POST(request:NextRequest) {
  const auth=await requireAuthWithPermission('customers:create')
  if(auth.error)return auth.error
  const body=await request.json().catch(()=>null)
  if(!body||!['started','finished'].includes(body.event)||typeof body.deviceId!=='string'||body.deviceId.length>64)return NextResponse.json({error:'Invalid sync activity.'},{status:400})
  try {
    const counts=Object.fromEntries(['synced','duplicates','failed','conflicts'].map(key=>[key,Math.max(0,Math.min(1000000,Number(body[key])||0))]))
    await recordAuditStandalone({action:body.event==='started'?'DEVICE_SYNC_STARTED':'DEVICE_SYNC_FINISHED',entityType:'system',actor:actorFromAuthUser(auth.user),result:'SUCCESS',
      reason:'Device-reported sync session. Committed records have individual DEVICE_RECORD_SYNCED audit events.',
      after:{device_id:body.deviceId,...counts,reported_at:new Date().toISOString()}})
    return NextResponse.json({ok:true})
  } catch {return NextResponse.json({error:'Could not record sync activity.'},{status:503})}
}
