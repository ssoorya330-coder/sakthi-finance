import type { Customer } from '@/types/customer.types'

const DAY_MS = 86_400_000

/** Customer lists include new entries and disbursals as well as collections. */
export function matchesCustomerDateRange(customer: Customer, from: string, to: string): boolean {
  if (customer.kanakuSchedules?.some(schedule => matchesCustomerDateRange({ ...customer, ...schedule, kanakuSchedules: undefined }, from, to))) return true
  const start = parseDay(from)
  const end = parseDay(to)
  if (!start || !end || start > end) return false
  const inRange = (day: Date | null) => day !== null && day >= start && day <= end
  if (inRange(parseDay(customer.loanDate || ''))) return true

  // Creation is a timestamp: use the same local calendar as the Today picker.
  const created = new Date(customer.createdAt)
  if (Number.isFinite(created.getTime())) {
    const createdDay = /^\d{4}-\d{2}-\d{2}$/.test(customer.createdAt)
      ? parseDay(customer.createdAt)
      : new Date(Date.UTC(created.getFullYear(), created.getMonth(), created.getDate()))
    if (inRange(createdDay)) return true
  }
  return hasCollectionInRange(customer, from, to)
}

function parseDay(value: string): Date | null {
  const key = value.slice(0, 10)
  if (!/^\d{4}-\d{2}-\d{2}$/.test(key)) return null
  const date = new Date(`${key}T00:00:00Z`)
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === key ? date : null
}

/** Scheduled collections start one installment period after disbursal. */
export function hasCollectionInRange(customer: Customer, from: string, to: string): boolean {
  const loan = parseDay(customer.loanDate || '')
  const start = parseDay(from)
  const end = parseDay(to)
  const duration = Number(customer.duration)
  if (!loan || !start || !end || start > end || end <= loan || !Number.isInteger(duration) || duration <= 0) return false
  const due = parseDay(customer.dueDate || '')
  const endTime = Math.min(end.getTime(), due?.getTime() ?? Infinity)
  const startTime = start.getTime()
  const type = customer.loanType

  if (type === 'Daily' || type === 'Weekly') {
    const period = (type === 'Weekly' ? 7 : 1) * DAY_MS
    const installment = Math.max(1, Math.ceil((startTime - loan.getTime()) / period))
    return installment <= duration && loan.getTime() + installment * period <= endTime
  }
  if (type !== 'Monthly' && type !== 'Yearly') return false
  const periodMonths = type === 'Yearly' ? 12 : 1
  const months = (start.getUTCFullYear() - loan.getUTCFullYear()) * 12 + start.getUTCMonth() - loan.getUTCMonth()
  let installment = Math.max(1, Math.floor(months / periodMonths))
  // Only the period containing the range start and the following period can
  // contain the first matching collection. Clamp month ends without date drift.
  for (let attempt = 0; attempt < 2 && installment <= duration; attempt++, installment++) {
    const month = new Date(Date.UTC(loan.getUTCFullYear(), loan.getUTCMonth() + installment * periodMonths, 1))
    const lastDay = new Date(Date.UTC(month.getUTCFullYear(), month.getUTCMonth() + 1, 0)).getUTCDate()
    month.setUTCDate(Math.min(loan.getUTCDate(), lastDay))
    if (month.getTime() >= startTime && month.getTime() <= endTime) return true
  }
  return false
}
