export function calculateKanaku(input: Record<string, unknown>) {
  const amount = Number(input.loan_amount)
  const rate = Number(input.interest_rate ?? 0)
  const duration = Number(input.duration)
  const type = String(input.loan_type || 'Daily')
  const date = String(input.loan_date || '')
  if (!/^\d+(\.\d{1,2})?$/.test(String(input.loan_amount)) || !Number.isFinite(amount) || amount <= 0 || amount > 99999999.99) throw new Error('Enter a valid loan amount with up to two decimal places.')
  if (!Number.isFinite(rate) || rate < 0 || rate > 99.99 || Math.abs(Math.round(rate * 100) - rate * 100) > 0.00001) throw new Error('Interest must be between 0 and 99.99%.')
  if (!Number.isInteger(duration) || duration < 1 || duration > 32767) throw new Error('Enter a valid whole-number duration.')
  if (!['Daily', 'Weekly', 'Monthly', 'Yearly'].includes(type)) throw new Error('Choose a valid loan type.')
  const start = new Date(`${date}T00:00:00Z`)
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(start.getTime()) || start.toISOString().slice(0, 10) !== date) throw new Error('Choose a valid loan date.')
  const end = new Date(start)
  if (type === 'Daily' || type === 'Weekly') end.setUTCDate(end.getUTCDate() + duration * (type === 'Weekly' ? 7 : 1))
  else {
    end.setUTCDate(1)
    end.setUTCMonth(end.getUTCMonth() + duration * (type === 'Yearly' ? 12 : 1))
    end.setUTCDate(Math.min(start.getUTCDate(), new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth() + 1, 0)).getUTCDate()))
  }
  if (end.getUTCFullYear() > 9999) throw new Error('Loan duration exceeds the supported date range.')
  const interest = Math.round(amount * rate) / 100
  const total = Math.round((amount + interest) * 100) / 100
  if (total > 99999999.99) throw new Error('Loan total exceeds the supported amount.')
  return { amount, rate, duration, type, date, dueDate: end.toISOString().slice(0, 10), interest, total, installment: Math.round(total / duration * 100) / 100 }
}
