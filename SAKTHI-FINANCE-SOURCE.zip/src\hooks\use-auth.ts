"use client";

import { useCallback } from "react";
import { useAuthStore, clearAuthPersistedState } from "@/store/auth-store";
import { useCustomerStore, clearAllOfflineCustomerCaches } from "@/store/customer-store";
import { logout as apiLogout } from "@/lib/auth/client-auth";

export function useAuthActions() {
  const user = useAuthStore((s) => s.user);
  const userId = useAuthStore((s) => s.userId);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const setLoggingOut = useAuthStore((s) => s.setLoggingOut);
  const isLoggingOut = useAuthStore((s) => s.isLoggingOut);

  const handleLogin = useCallback(() => {
    window.location.href = "/login";
  }, []);

  const handleRegister = useCallback(() => {
    window.location.href = "/login";
  }, []);

  const handleLogout = useCallback(async () => {
    setLoggingOut(true);

    try {
      await apiLogout();
    } catch {
      // proceed regardless
    }

    clearAuthPersistedState();
    // Account isolation: drop every cached customer/payment snapshot and
    // reset the in-memory store so the next login cannot see the previous
    // account's data (the redirect below also reloads the page).
    clearAllOfflineCustomerCaches();
    try {
      useCustomerStore.setState({
        customers: [],
        lastCustomerNumber: 0,
        receivedPayments: {},
        paymentHistory: [],
        initialized: false,
        loading: false,
        userId: null,
        savedTodayCollection: 0,
        todayCollection: 0,
      });
    } catch {}

    const authKeys = ['sf-auth', 'sf-sync', 'sf-sidebar', 'sf-toast'];
    authKeys.forEach((key) => {
      try {
        localStorage.removeItem(key);
        sessionStorage.removeItem(key);
      } catch {}
    });
    try {
      Object.keys(localStorage).forEach((k) => {
        if (k.startsWith('sb-')) localStorage.removeItem(k);
      });
    } catch {}

    useAuthStore.getState().logout();

    window.location.href = "/login";
  }, [setLoggingOut]);

  return {
    error: "",
    success: "",
    setError: (_msg: string) => {},
    setSuccess: (_msg: string) => {},
    handleLogin,
    handleRegister,
    handleLogout,
    isSignedIn: !!isAuthenticated,
    isAuthenticated,
    userId: userId || "",
    isLoggingOut,
    user,
  };
}
