// Deterministic parsing only. No amounts, IDs or names are fuzzily substituted.
const small: Record<string, number> = { zero:0,one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10,eleven:11,twelve:12,thirteen:13,fourteen:14,fifteen:15,sixteen:16,seventeen:17,eighteen:18,nineteen:19,twenty:20,thirty:30,forty:40,fifty:50,sixty:60,seventy:70,eighty:80,ninety:90 }
export function parseSpokenNumber(input: string): number | null {
  const text = input.toLowerCase().trim().replace(/^(?:rupees?|rs\.?|₹)\s*/, '').replace(/\s*(?:rupees?|percent|%)$/, '').replace(/-/g, ' ')
  if (/^(?:\d+|\d{1,3}(?:,\d{3})+|\d{1,2}(?:,\d{2})*,\d{3})(?:\.\d{1,2})?$/.test(text)) {
    const n = Number(text.replace(/,/g, '')); return n <= 1e12 ? n : null
  }
  const pieces = text.split(' point ')
  if (pieces.length > 2) return null
  const tokens = pieces[0].split(/\s+/).filter(w => w !== 'and')
  let total = 0, group = 0, lastScale = Infinity, previous = ''
  for (const token of tokens) {
    if (token in small) {
      if (previous in small && !(small[previous] >= 20 && small[previous] % 10 === 0 && small[token] > 0 && small[token] < 10)) return null
      group += small[token]
    } else if (token === 'hundred') {
      if (group < 1 || group > 9 || previous === 'hundred') return null
      group *= 100
    } else {
      const scale = ({ thousand:1000,lakh:100000,lakhs:100000,crore:10000000,crores:10000000 } as Record<string,number>)[token]
      if (!scale || !group || scale >= lastScale || group >= scale) return null
      total += group * scale; group = 0; lastScale = scale
    }
    previous = token
  }
  let value = total + group
  if (pieces[1]) {
    const digits = pieces[1].split(/\s+/).map(w => w in small && small[w] < 10 ? String(small[w]) : /^\d$/.test(w) ? w : '?').join('')
    if (!/^\d{1,2}$/.test(digits)) return null
    value += Number(`0.${digits}`)
  }
  return Number.isFinite(value) && value <= 1e12 ? value : null
}
export type VoiceIntent = { type: 'navigate'; path: string } | { type: 'search'; name: string } | { type: 'payment'; name: string; amount: number } | { type: 'unknown' }
const routes: Record<string,string> = {
  dashboard:'/dashboard', customers:'/dashboard/customers', 'receive payment':'/dashboard/customers', 'payment history':'/dashboard/customers',
  'completed loans':'/dashboard/completed-customers', 'completed customers':'/dashboard/completed-customers',
  'aborted loans':'/dashboard/aborted-customers', 'aborted customers':'/dashboard/aborted-customers',
  'audit and reports':'/dashboard/audit', audit:'/dashboard/audit', reports:'/dashboard/audit',
  'database management':'/database', database:'/database', settings:'/dashboard/settings',
}
export function parseVoiceCommand(input: string): VoiceIntent {
  const text = input.trim().replace(/[.!?]+$/, '').replace(/\s+/g, ' ')
  const destination = text.toLowerCase().replace(/^(?:open|show|go to|take me to|i want to)\s+/, '')
  if (routes[destination]) return { type:'navigate', path:routes[destination] }
  const payment = text.match(/^(?:receive(?: payment)?|add payment of|record) (.+?)(?: payment)? (?:from|for)(?: customer)? (.+)$/i)
  const paid = text.match(/^(.+?) paid (.+)$/i)
  if (payment || paid) {
    const amount = parseSpokenNumber(payment ? payment[1] : paid![2])
    const name = (payment ? payment[2] : paid![1]).trim()
    return amount !== null && amount > 0 && name ? {type:'payment',name,amount} : {type:'unknown'}
  }
  const search = text.match(/^(?:find|search(?: customer)?|show(?: customer)?|open) (.+?)(?: customer(?: details)?)?$/i)
  return search?.[1] ? { type:'search',name:search[1] } : {type:'unknown'}
}

/** Local suggestions only. The caller must require an explicit selection. */
export function suggestCustomerNames(query: string, names: string[]): string[] {
  const q=query.trim().toLocaleLowerCase()
  if(q.length<3 || q.length>80) return []
  return [...new Set(names)].filter(name=>{
    const n=name.toLocaleLowerCase().slice(0,80)
    if(n.includes(q) || n.split(' ').some(part=>part.startsWith(q))) return true
    const row=Array.from({length:q.length+1},(_,i)=>i)
    for(let i=1;i<=n.length;i++){
      let prev=row[0];row[0]=i
      for(let j=1;j<=q.length;j++){
        const old=row[j]
        row[j]=Math.min(row[j]+1,row[j-1]+1,prev+(n[i-1]===q[j-1]?0:1));prev=old
      }
    }
    return row[q.length]<=Math.min(2,Math.floor(q.length/4))
  }).slice(0,5)
}
