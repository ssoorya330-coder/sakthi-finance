'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'
import {
  Banknote,
  IndianRupee,
  Clock,
  TrendingUp,
  Calendar,
  CalendarDays,
  CalendarCheck,
  BarChart,
} from 'lucide-react'
import { formatINR } from '@/lib/dashboard-utils'
import { useCustomerStore } from '@/store/customer-store'
import { computeFinancialSummary } from './dashboard-data'

export default function FinancialSummary() {
  const customers = useCustomerStore((s) => s.customers)
  const paymentHistory = useCustomerStore((s) => s.paymentHistory)
  const summary = useMemo(() => computeFinancialSummary(customers, paymentHistory), [customers, paymentHistory])

  const summaryItems = [
    { id: 'loan-given', label: 'Total Loan Given', value: summary.totalLoanGiven, icon: Banknote, color: 'text-[var(--primary)]', bg: 'bg-[var(--primary-soft)]' },
    { id: 'amount-received', label: 'Total Amount Received', value: summary.totalAmountReceived, icon: IndianRupee, color: 'text-[var(--primary)]', bg: 'bg-[var(--primary-soft)]' },
    { id: 'pending', label: 'Pending Collection', value: summary.pendingCollection, icon: Clock, color: 'text-[var(--secondary)]', bg: 'bg-[var(--primary-soft)]' },
    { id: 'interest', label: 'Interest Earned', value: summary.interestEarned, icon: TrendingUp, color: 'text-[var(--primary)]', bg: 'bg-[var(--primary-soft)]' },
    { id: 'today-income', label: "Today's Income", value: summary.todayIncome, icon: Calendar, color: 'text-[var(--primary)]', bg: 'bg-[var(--primary-soft)]' },
    { id: 'monthly', label: 'Monthly Income', value: summary.monthlyIncome, icon: CalendarDays, color: 'text-[var(--secondary)]', bg: 'bg-[var(--primary-soft)]' },
    { id: 'yearly', label: 'Yearly Income', value: summary.yearlyIncome, icon: CalendarCheck, color: 'text-[var(--primary)]', bg: 'bg-[var(--primary-soft)]' },
    { id: 'avg-loan', label: 'Average Loan Amount', value: summary.avgLoan, icon: BarChart, color: 'text-[var(--primary)]', bg: 'bg-[var(--primary-soft)]' },
  ]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.7 }}
      className="relative bg-white/70 backdrop-blur-xl rounded-[20px] border border-white/20 shadow-[0_1px_3px_rgba(0,0,0,0.04),0_8px_24px_rgba(0,0,0,0.04)] p-6 overflow-hidden"
    >
      <div className="absolute inset-0 sf-pattern-dots opacity-40 pointer-events-none" />
      <div className="flex items-center gap-3 mb-6 relative">
        <div className="w-10 h-10 rounded-[11px] bg-gradient-to-br from-[var(--primary)] to-[var(--primary-hover)] flex items-center justify-center shadow-lg shadow-[var(--primary)]/20">
          <IndianRupee className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-base font-semibold text-slate-900">Financial Summary</h3>
          <p className="text-xs text-slate-500">Complete financial overview</p>
        </div>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 relative">
        {summaryItems.map((item, i) => {
          const Icon = item.icon as React.ComponentType<{ className?: string }>
          const gradColors: Record<string, string> = {
            'text-[var(--primary)]': 'from-[var(--primary)] to-[var(--primary-hover)]',
            'text-[var(--secondary)]': 'from-[var(--secondary)] to-[#B8943A]',
          }
          const grad = gradColors[item.color] || 'from-[var(--primary)] to-[var(--primary-hover)]'
          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.8 + i * 0.05 }}
              whileHover={{ y: -2 }}
              className="p-4 rounded-[12px] bg-white/50 backdrop-blur-sm border border-white/30 hover:border-white/50 hover:shadow-md transition-all duration-200"
            >
              <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${grad} flex items-center justify-center shadow-md mb-3`}>
                <Icon className="w-4 h-4 text-white" />
              </div>
              <p className="text-xl font-bold text-slate-900 tracking-tight mb-0.5">
                {formatINR(item.value)}
              </p>
              <p className="text-xs text-slate-500">{item.label}</p>
            </motion.div>
          )
        })}
      </div>
    </motion.div>
  )
}
